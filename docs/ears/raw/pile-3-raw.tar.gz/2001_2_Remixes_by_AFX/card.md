## 2001 - 2 Remixes by AFX (draft card from Ears 3 tools, 2026-10-25)

How it was made: EP or short record (3 usable tracks): every track. Deep pass on: Flow Coma (AFX Remix); Box Energy (AFX Remix); Bonus High Frequency Sounds. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Flow Coma (AFX Remix)**: share of power drums 71%, bass 14%, other 10%, vocals 4%.
  - vocals stem holds 4.3%: bleed on an instrumental, not a voice.
  - meter tool 120 BPM is three quarters of the drum-grid beat of 161.3 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Box Energy (AFX Remix)**: share of power drums 53%, bass 2%, other 38%, vocals 7%.
  - bass stem is thin (2.1%): bass notes, pumping and wobble are guesses.
  - meter tool 85 BPM agrees with the drum-grid beat of 84.7 BPM.
- **Bonus High Frequency Sounds**: share of power drums 0%, bass 0%, other 93%, vocals 7%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 67 to 120 BPM (octave-uncertain); keys D# ionian, D phrygian, D ionian; mix width -38 to -20 dB; chord changes 2 to 26 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Bonus High Frequency Sounds: other group `other-1` (177 notes, 59% of the track's note energy)
- In synth terms: around D6, harmonic (string/reed/pad-like), slow swell, falls 0 dB/s, centered.
- Hear it at: 0:47.4 (D6, 0.51 s, +47 dB alone), 0:09.7 (D6, 0.83 s, +46 dB alone), 0:46.4 (D6, 0.79 s, +45 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 1148 (1127 to 1148) Hz; attack 210 (17 to 453) ms; decay -0 (-2 to 0) dB/s
  - brightness at the start 2285 (2214 to 2297) Hz; slope over the note 0.00 (-0.00 to 0.04) octaves
  - harmonic share 0.99 (0.75 to 1.00); partials off whole multiples 3 (0 to 33) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.0 (-0.1 to -0.0) dB; pan -0.01 (-0.01 to -0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. Box Energy (AFX Remix): other group `other-1` (484 notes, 42% of the track's note energy)
- In synth terms: around D2, bell- or metal-like (partials off whole multiples), soft attack, falls 42 dB/s, centered.
- Hear it at: 4:27.8 (?, 0.45 s, +34 dB alone), 4:32.8 (?, 0.43 s, +30 dB alone), 4:27.2 (?, 0.84 s, +29 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 73 (44 to 103) Hz; attack 87 (19 to 388) ms; decay -42 (-185 to -2) dB/s
  - brightness at the start 525 (245 to 1070) Hz; slope over the note -0.05 (-1.12 to 0.65) octaves
  - harmonic share 0.30 (0.12 to 0.76); partials off whole multiples 74 (35 to 133) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.4 (-8.5 to -1.4) dB; pan -0.01 (-0.03 to -0.00); left-right correlation 1.00 (0.96 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. Flow Coma (AFX Remix): drums group `drums-1` (374 notes, 37% of the track's note energy)
- In synth terms: low thump, soft attack, falls 69 dB/s, centered.
- Hear it at: 0:30.1 (B1, 0.12 s, +48 dB alone), 0:29.3 (F#1, 0.24 s, +45 dB alone), 2:47.9 (A1, 0.56 s, +43 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 54 (42 to 66) Hz; attack 42 (17 to 150) ms; decay -69 (-162 to -16) dB/s
  - brightness at the start 126 (78 to 372) Hz; slope over the note 0.00 (-0.07 to 2.55) octaves
  - harmonic share 0.75 (0.12 to 0.98); partials off whole multiples 186 (54 to 302) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-1.3 to -0.0) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S4. Bonus High Frequency Sounds: other group `other-2` (86 notes, 24% of the track's note energy)
- In synth terms: around B6, mixed or noisy partials, slow swell, falls 0 dB/s, centered.
- Hear it at: 1:10.7 (A#6, 0.48 s, +47 dB alone), 0:12.9 (B6, 0.53 s, +47 dB alone), 0:12.3 (B6, 0.29 s, +48 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 1937 (1855 to 2120) Hz; attack 179 (27 to 385) ms; decay -0 (-3 to 0) dB/s
  - brightness at the start 2256 (2180 to 2296) Hz; slope over the note -0.01 (-0.11 to 0.04) octaves
  - harmonic share 0.09 (0.04 to 0.18); partials off whole multiples 0 (0 to 0) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.0 (-0.0 to -0.0) dB; pan -0.01 (-0.01 to -0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. Flow Coma (AFX Remix): bass group `bass-1` (476 notes, 22% of the track's note energy)
- In synth terms: around G#1, bell- or metal-like (partials off whole multiples), quick attack, falls 79 dB/s, centered.
- Hear it at: 2:51.7 (G#1, 0.28 s, +18 dB alone), 2:52.0 (G#1, 0.27 s, +17 dB alone), 2:52.4 (G#1, 0.3 s, +16 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 51 (40 to 54) Hz; attack 32 (9 to 139) ms; decay -79 (-242 to -34) dB/s
  - brightness at the start 240 (136 to 327) Hz; slope over the note -0.12 (-0.84 to 0.68) octaves
  - harmonic share 0.66 (0.11 to 0.99); partials off whole multiples 72 (16 to 185) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.3 (-11.2 to -2.7) dB; pan -0.00 (-0.00 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. Box Energy (AFX Remix): drums group `drums-1` (186 notes, 20% of the track's note energy)
- In synth terms: mid snap, soft attack, falls 26 dB/s, centered.
- Hear it at: 5:14.1 (?, 0.38 s, +34 dB alone), 5:11.3 (?, 0.36 s, +32 dB alone), 5:12.0 (?, 0.26 s, +32 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 53 (35 to 130) Hz; attack 99 (12 to 370) ms; decay -26 (-53 to -2) dB/s
  - brightness at the start 1334 (770 to 1948) Hz; slope over the note -0.10 (-1.97 to 1.00) octaves
  - harmonic share 0.38 (0.18 to 0.74); partials off whole multiples 96 (47 to 159) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.6 (-2.6 to -0.0) dB; pan -0.01 (-0.02 to -0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Flow Coma (AFX Remix) sections:** 12 boundaries at 0:03.0, 0:16.0, 0:30.0, 1:03.0, 1:20.0, 2:00.0, 2:22.0, 2:48.0, 3:21.0, 3:37.0, 4:19.0, 4:42.0; section lengths median 22 s (range 3 to 42). Reliable for sections of 10 s or more.
- **Flow Coma (AFX Remix) stem entries and exits:** drums plays 94% of the time (in: from the start; out: 4:43.0); bass plays 88% of the time (in: 0:02.5, 2:19.0, 2:48.0, 2:58.0, 4:26.5; out: 2:16.0, 2:41.5, 2:53.5, 4:12.5, 4:53.5); other plays 82% of the time (in: 0:19.0, 0:30.0, 2:48.5; out: 0:25.5, 2:41.5, 4:37.0); vocals plays 52% of the time (in: 0:53.5, 1:11.0, 1:30.0, 1:45.5, 2:23.0; out: 0:29.5, 1:05.5, 1:21.5, 1:34.5, 2:00.0).
- **Flow Coma (AFX Remix) floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Flow Coma (AFX Remix) brightness sweeps (0.7 octave or more):** mix up 2.5 oct 0:00.0 to 0:05.5; mix up 3.5 oct 0:12.5 to 0:19.0; mix down 5.6 oct 0:19.0 to 0:31.5; mix up 3.6 oct 0:31.5 to 0:36.5; mix up 4.5 oct 0:48.5 to 0:58.5; mix down 2.9 oct 0:58.5 to 1:04.5; mix up 3.0 oct 1:11.0 to 1:20.0; mix up 0.8 oct 1:25.5 to 1:36.0 (52 more in techniques.json).
- **Flow Coma (AFX Remix) echo times:** drums: 718 ms (+11.9 dB, 1 later repeats).
- **Flow Coma (AFX Remix) pumping locked to the kick:** other dips 2.4 dB at the kick (peak 354 ms after, kick every 0.37 s); bass dips 4.1 dB at the kick (peak 95 ms after, kick every 0.37 s). The tool reads about 70% of the true depth, so this is a floor.
- **Flow Coma (AFX Remix) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Flow Coma (AFX Remix) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Box Energy (AFX Remix) sections:** 16 boundaries at 0:13.0, 0:34.0, 0:53.0, 1:14.0, 1:30.0, 1:46.0, 2:38.0, 2:58.0, 3:29.0, 3:39.0, 3:58.0, 4:34.0; section lengths median 20 s (range 3 to 52). Reliable for sections of 10 s or more.
- **Box Energy (AFX Remix) stem entries and exits:** drums plays 88% of the time (in: 0:15.0, 3:37.0, 4:33.5, 4:39.0; out: 3:28.0, 4:31.0, 4:36.5, 6:11.5); bass plays 44% of the time (in: 0:17.0, 1:04.5, 2:10.0, 2:31.0, 2:47.5; out: 0:50.5, 2:02.5, 2:12.5, 2:39.0, 3:02.0); other plays 95% of the time (in: 0:03.5, 3:37.5, 5:15.0; out: 3:30.0, 5:12.0, 6:23.0); vocals plays 58% of the time (in: 0:31.5, 0:45.5, 1:14.0, 1:32.5, 1:45.5; out: 0:37.0, 0:56.5, 1:23.0, 1:36.0, 2:04.5).
- **Box Energy (AFX Remix) floor drops (kick and bass out 2 s or more while the rest plays):** 0.68 a minute: 2:29.0 for 2.5 s, 3:27.0 for 10.8 s, 4:30.2 for 4.0 s, 4:35.8 for 4.5 s.
- **Box Energy (AFX Remix) brightness sweeps (0.7 octave or more):** mix up 3.4 oct 0:25.5 to 0:34.0; mix down 1.2 oct 0:34.5 to 0:40.0; mix down 0.9 oct 0:51.0 to 0:56.5; mix down 1.1 oct 1:07.5 to 1:13.0; mix down 2.3 oct 1:28.0 to 1:38.5; mix up 0.8 oct 2:22.0 to 2:27.0; mix down 1.2 oct 2:30.0 to 2:35.0; mix up 2.9 oct 2:35.0 to 2:42.0 (68 more in techniques.json).
- **Box Energy (AFX Remix) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Box Energy (AFX Remix) pumping locked to the kick:** bass dips 1.8 dB at the kick (peak 70 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **Box Energy (AFX Remix) tape wobble and speed:** other wobbles about 17 cents at 8.0 Hz.
- **Box Energy (AFX Remix) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Box Energy (AFX Remix) builds:** 2:29.0 to 2:53.0.
- **Bonus High Frequency Sounds sections:** 5 boundaries at 0:11.0, 0:21.0, 0:58.0, 1:34.0, 1:56.0; section lengths median 16 s (range 2 to 37). Reliable for sections of 10 s or more.
- **Bonus High Frequency Sounds stem entries and exits:** drums plays 7% of the time (in: 0:23.0; out: 0:31.0); bass plays 0% of the time (in: from the start; out: never); other plays 99% of the time (in: from the start; out: never); vocals plays 31% of the time (in: 0:04.0, 0:57.0, 1:27.5; out: 0:07.5, 1:00.5).
- **Bonus High Frequency Sounds floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Bonus High Frequency Sounds brightness sweeps (0.7 octave or more):** bass down 0.9 oct 0:01.0 to 0:06.5; bass down 0.8 oct 1:31.5 to 1:38.5.
- **Bonus High Frequency Sounds echo times:** drums: 444 ms (+12.2 dB, 2 later repeats).
- **Bonus High Frequency Sounds pumping locked to the kick:** bass dips 1.9 dB at the kick (peak 259 ms after, kick every 0.30 s). The tool reads about 70% of the true depth, so this is a floor.
- **Bonus High Frequency Sounds tape wobble and speed:** bass wobbles about 13 cents at 0.4 Hz; bass speed moves up to 7 cents in 4 s.
- **Bonus High Frequency Sounds stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Flow Coma (AFX Remix) meter:** about 120 BPM (could be 60 or 240; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.78 of the beat; no cross-rhythm claim.
- **Flow Coma (AFX Remix) key and mode:** D# ionian (major) (low confidence: the key signature margin is 0.016, so read this as a guess); pitch-class weights G# 0.13, G 0.11, D# 0.10, A 0.09, D 0.09.
- **Flow Coma (AFX Remix) chords:** 22 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.4 to 4.7 s); 27 distinct chords; most time on G#maj7 48%, C#maj7 10%, G7 9%, D#maj7 6%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  56% of the changes land on a beat (chance would be 60%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Flow Coma (AFX Remix) bass:** root-note movement / mixed; 0.17 notes a second; most time on E 0.45, D# 0.29, G# 0.11, B 0.06; steps 24%, thirds 4%, fourths and fifths 10%, octaves 2%, repeats 60%.
- **Flow Coma (AFX Remix) top line (from the 'other' stem; read by ear before trusting):** 847 notes, range 32 semitones (10th to 90th percentile); steps 38%, thirds 12%, fourths and fifths 12%, leaps 29%, repeats 9%; median interval 3 semitones; 47% of moves go up; phrases of about 14 notes, arch 33%, rising 17%, falling 17%, flat or wavy 33%. Reliable only when the line sits clearly above its accompaniment.
- **Flow Coma (AFX Remix) repetition:** 149 bars of 2.0 s; strongest repeat distances 1 bars (0.68); 14% of bars near-duplicate an earlier bar.
- **Box Energy (AFX Remix) meter:** about 85 BPM (could be 43 or 170; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.23); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Box Energy (AFX Remix) key and mode:** D phrygian (low confidence: the key signature margin is 0.006, so read this as a guess); pitch-class weights F 0.10, D 0.09, D# 0.09, A# 0.09, C# 0.09.
- **Box Energy (AFX Remix) chords:** 26 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.6 s (10th to 90th percentile 0.7 to 4.3 s); 40 distinct chords; most time on Dmaj7 10%, D#maj7 10%, A#maj7 9%, C#maj7 7%. The old counter in this same run said 5; Ears 1's 2-s counter said 3.  43% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Box Energy (AFX Remix) bass:** root-note movement / mixed; 0.13 notes a second; most time on D 0.39, G 0.23, C 0.12, F# 0.08; steps 8%, thirds 2%, fourths and fifths 4%, octaves 0%, repeats 81%.
- **Box Energy (AFX Remix) top line (from the 'other' stem; read by ear before trusting):** 854 notes, range 16 semitones (10th to 90th percentile); steps 27%, thirds 14%, fourths and fifths 20%, leaps 27%, repeats 12%; median interval 4 semitones; 48% of moves go up; phrases of about 11 notes, arch 33%, rising 19%, falling 37%, flat or wavy 12%. Reliable only when the line sits clearly above its accompaniment.
- **Box Energy (AFX Remix) repetition:** 276 bars of 1.4 s; strongest repeat distances 1 bars (0.62), 4 bars (0.53), 8 bars (0.36); 7% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Bonus High Frequency Sounds meter:** about 67 BPM (could be 34 or 134; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.06); swung: off-beat at 0.72 of the beat; no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **Bonus High Frequency Sounds key and mode:** D ionian (major) (low confidence: the key signature margin is 0.014, so read this as a guess); fits D major pentatonic; pitch-class weights D 0.37, C# 0.26, F# 0.06, G 0.04, B 0.04.
- **Bonus High Frequency Sounds chords:** 2 changes a minute (2 a minute are chords that last 1.5 s or more); median chord 2.2 s (10th to 90th percentile 1.5 to 66.7 s); 4 distinct chords; most time on Dmaj7 92%, B5 5%, F#5 2%, F5 2%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Bonus High Frequency Sounds top line (from the 'other' stem; read by ear before trusting):** 187 notes, range 0 semitones (10th to 90th percentile); steps 4%, thirds 0%, fourths and fifths 1%, leaps 1%, repeats 94%; median interval 0 semitones; 50% of moves go up; phrases of about 15 notes, arch 0%, rising 0%, falling 0%, flat or wavy 100%. Reliable only when the line sits clearly above its accompaniment.
- **Bonus High Frequency Sounds repetition:** 14 bars of 8.0 s; strongest repeat distances 1 bars (0.61); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Flow Coma (AFX Remix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -34 (corr 1.00); low_120_500 -33 (corr 1.00); mid_500_2k -31 (corr 1.00); pres_2k_5k -32 (corr 1.00); air_gt5k -34 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -34/-32/-31 dB.
- **Flow Coma (AFX Remix) by part:** drums: 71% of the power, width -34 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-32 dB); bass: 15% of the power, width -38 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-36 dB); other: 10% of the power, width -32 dB, pan -0.02, mono loss 0.0 dB, widest in sub_lt120 (-31 dB); vocals: 4% of the power, width -36 dB, pan -0.01, mono loss 0.0 dB, widest in mid_500_2k (-35 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Box Energy (AFX Remix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -23 (corr 0.99); low_120_500 -22 (corr 0.99); mid_500_2k -16 (corr 0.95); pres_2k_5k -21 (corr 0.98); air_gt5k -22 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -32/-29/-3 dB.
- **Box Energy (AFX Remix) by part:** drums: 52% of the power, width -26 dB, pan -0.02, mono loss 0.0 dB, widest in mid_500_2k (-23 dB); bass: 2% of the power, width -18 dB, pan +0.01, mono loss 0.1 dB, widest in sub_lt120 (-17 dB); other: 38% of the power, width -16 dB, pan -0.02, mono loss 0.1 dB, widest in mid_500_2k (-13 dB); vocals: 7% of the power, width -18 dB, pan -0.03, mono loss 0.1 dB, widest in low_120_500 (-16 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Bonus High Frequency Sounds mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -26 (corr 0.99); low_120_500 -27 (corr 1.00); mid_500_2k -36 (corr 1.00); pres_2k_5k -38 (corr 1.00); air_gt5k -20 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -39/-38/-36 dB.
- **Bonus High Frequency Sounds by part:** drums: 0% of the power, width -31 dB, pan -0.00, mono loss 0.0 dB, widest in mid_500_2k (-36 dB); bass: 0% of the power, width -23 dB, pan -0.00, mono loss 0.0 dB, widest in mid_500_2k (-24 dB); other: 93% of the power, width -38 dB, pan -0.01, mono loss 0.0 dB, widest in mid_500_2k (-37 dB); vocals: 7% of the power, width -35 dB, pan -0.01, mono loss 0.0 dB, widest in pres_2k_5k (-35 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Flow Coma (AFX Remix): 120 BPM, 11 settled chords a minute, 15% of energy above 2 kHz, width -33 dB; Box Energy (AFX Remix): 85 BPM, 14 settled chords a minute, 12% of energy above 2 kHz, width -20 dB; Bonus High Frequency Sounds: 67 BPM, 2 settled chords a minute, 83% of energy above 2 kHz, width -38 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: Bonus High Frequency Sounds: 83% of energy above 2 kHz (bright or harsh).

### For later
- Flow Coma (AFX Remix), other group `other-1` (418 notes): around A2, mixed or noisy partials, soft attack, falls 70 dB/s, centered; hear it at 1:31.0, 0:34.5. **[JUDGMENT]** why it waits.
- Flow Coma (AFX Remix), drums group `drums-2` (126 notes): mid snap, soft attack, falls 92 dB/s, centered; hear it at 4:41.5, 4:39.7. **[JUDGMENT]** why it waits.
- Box Energy (AFX Remix), drums group `drums-2` (117 notes): low thump, quick attack, falls 16 dB/s, gets brighter over the note, centered; hear it at 5:10.4, 5:57.6. **[JUDGMENT]** why it waits.
- Box Energy (AFX Remix), vocals group `vocals-1` (228 notes): around C3, bell- or metal-like (partials off whole multiples), soft attack, falls 45 dB/s, centered; hear it at 3:36.0, 3:30.9. **[JUDGMENT]** why it waits.
- Bonus High Frequency Sounds, vocals group `vocals-1` (218 notes): around F#5, bell- or metal-like (partials off whole multiples), quick attack, falls 415 dB/s, centered; hear it at 1:56.4, 1:56.2. **[JUDGMENT]** why it waits.
- Flow Coma (AFX Remix), vocals group `vocals-1` (189 notes): around D2, bell- or metal-like (partials off whole multiples), soft attack, falls 85 dB/s, centered; hear it at 4:07.7, 4:11.7. **[JUDGMENT]** why it waits.
- Box Energy (AFX Remix), bass group `bass-1` (425 notes): around D2, harmonic (string/reed/pad-like), quick attack, falls 222 dB/s, centered; hear it at 5:40.3, 2:33.6. **[JUDGMENT]** why it waits.
- Box Energy (AFX Remix), vocals group `vocals-2` (166 notes): around A#4, bell- or metal-like (partials off whole multiples), soft attack, falls 157 dB/s, centered; hear it at 3:36.2, 0:13.4. **[JUDGMENT]** why it waits.
