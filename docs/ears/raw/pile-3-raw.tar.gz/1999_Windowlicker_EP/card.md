## 1999 - Windowlicker EP (draft card from Ears 3 tools, 2026-10-25)

How it was made: EP or short record (5 usable tracks): every track. Deep pass on: - Windowlicker; - Equation; - Nannou; - Windowlicker [Original Demo]; - Equation [Early Version, Edit]. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- Windowlicker**: share of power drums 15%, bass 48%, other 18%, vocals 19%.
  - meter tool 123 BPM agrees with the drum-grid beat of 123.0 BPM.
- **- Equation**: share of power drums 53%, bass 4%, other 35%, vocals 8%.
  - bass stem is thin (4.3%): bass notes, pumping and wobble are guesses.
  - meter tool 83 BPM is half of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Nannou**: share of power drums 20%, bass 0%, other 80%, vocals 0%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 101 BPM is two thirds of the drum-grid beat of 151.9 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Windowlicker [Original Demo]**: share of power drums 40%, bass 19%, other 13%, vocals 28%.
  - meter tool 123 BPM agrees with the drum-grid beat of 123.0 BPM.
- **- Equation [Early Version, Edit]**: share of power drums 64%, bass 26%, other 11%, vocals 0%.
  - vocals stem holds 0.1%: bleed on an instrumental, not a voice.
  - meter tool 105 BPM is two thirds of the drum-grid beat of 156.7 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 83 to 123 BPM (octave-uncertain); keys C aeolian, G locrian, F lydian, D# ionian; mix width -23 to -7 dB; chord changes 20 to 50 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Nannou: other group `other-1` (312 notes, 43% of the track's note energy)
- In synth terms: around A3, mixed or noisy partials, quick attack, falls 26 dB/s, centered.
- Hear it at: 2:11.6 (E4, 0.56 s, +59 dB alone), 2:07.8 (A3, 0.43 s, +56 dB alone), 2:16.9 (A3, 0.37 s, +56 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 221 (110 to 332) Hz; attack 37 (10 to 142) ms; decay -26 (-54 to -12) dB/s
  - brightness at the start 1100 (808 to 1615) Hz; slope over the note -0.03 (-0.45 to 0.00) octaves
  - harmonic share 0.71 (0.10 to 0.97); partials off whole multiples 41 (9 to 142) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.5 (-2.4 to -0.1) dB; pan -0.02 (-0.06 to 0.00); left-right correlation 0.97 (0.92 to 0.98)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. - Equation [Early Version, Edit]: drums group `drums-1` (381 notes, 38% of the track's note energy)
- In synth terms: mid snap, quick attack, falls 134 dB/s, leans right (+0.41).
- Hear it at: 1:21.6 (F1, 0.24 s, +41 dB alone), 0:55.8 (F1, 0.08 s, +40 dB alone), 0:07.0 (B1, 0.1 s, +36 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 57 (37 to 235) Hz; attack 25 (9 to 97) ms; decay -134 (-319 to -48) dB/s
  - brightness at the start 756 (399 to 1620) Hz; slope over the note 0.00 (-0.72 to 0.61) octaves
  - harmonic share 0.49 (0.16 to 0.83); partials off whole multiples 84 (34 to 195) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.1 (-8.4 to -1.5) dB; pan 0.41 (0.13 to 0.59); left-right correlation 0.54 (-0.04 to 0.75)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S3. - Equation: other group `other-1` (338 notes, 36% of the track's note energy)
- In synth terms: around G1, bell- or metal-like (partials off whole multiples), soft attack, falls 84 dB/s, centered.
- Hear it at: 0:47.3 (F#2, 0.19 s, +50 dB alone), 3:18.5 (G2, 0.58 s, +49 dB alone), 3:19.1 (G2, 0.22 s, +49 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 48 (34 to 139) Hz; attack 89 (20 to 435) ms; decay -84 (-430 to -3) dB/s
  - brightness at the start 614 (209 to 1766) Hz; slope over the note 0.00 (-1.36 to 1.55) octaves
  - harmonic share 0.40 (0.10 to 0.81); partials off whole multiples 86 (29 to 189) cents
  - vibrato 0 (0 to 24) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.3 (-22.4 to -0.6) dB; pan 0.00 (-0.02 to 0.03); left-right correlation 0.99 (0.97 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. - Nannou: other group `other-2` (188 notes, 31% of the track's note energy)
- In synth terms: around E5, bell- or metal-like (partials off whole multiples), soft attack, falls 20 dB/s, centered.
- Hear it at: 2:21.1 (F5, 0.35 s, +58 dB alone), 2:08.4 (F5, 0.55 s, +57 dB alone), 2:10.9 (E5, 0.41 s, +57 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 663 (591 to 703) Hz; attack 49 (10 to 142) ms; decay -20 (-39 to -5) dB/s
  - brightness at the start 818 (689 to 1182) Hz; slope over the note -0.01 (-0.20 to 0.01) octaves
  - harmonic share 0.88 (0.29 to 0.98); partials off whole multiples 68 (0 to 300) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-1.6 to -0.1) dB; pan -0.06 (-0.08 to -0.02); left-right correlation 0.98 (0.94 to 0.98)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. - Equation: drums group `drums-1` (322 notes, 26% of the track's note energy)
- In synth terms: low thump, quick attack, falls 61 dB/s, centered.
- Hear it at: 1:50.8 (A1, 0.25 s, +43 dB alone), 1:17.1 (A#1, 0.18 s, +43 dB alone), 1:17.3 (C#1, 0.3 s, +41 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 47 (36 to 62) Hz; attack 30 (16 to 119) ms; decay -61 (-374 to -5) dB/s
  - brightness at the start 115 (80 to 207) Hz; slope over the note 0.08 (-0.12 to 1.64) octaves
  - harmonic share 0.24 (0.06 to 0.71); partials off whole multiples 174 (98 to 300) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-2.1 to -0.0) dB; pan 0.02 (-0.01 to 0.04); left-right correlation 0.99 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S6. - Equation [Early Version, Edit]: drums group `drums-2` (119 notes, 25% of the track's note energy)
- In synth terms: low thump, quick attack, falls 85 dB/s, gets brighter over the note, centered.
- Hear it at: 0:55.7 (E2, 0.11 s, +44 dB alone), 0:31.4 (F2, 0.11 s, +41 dB alone), 0:56.3 (A1, 0.1 s, +39 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (38 to 75) Hz; attack 30 (24 to 125) ms; decay -85 (-340 to -46) dB/s
  - brightness at the start 141 (88 to 235) Hz; slope over the note 0.70 (0.00 to 1.64) octaves
  - harmonic share 0.42 (0.05 to 0.89); partials off whole multiples 172 (57 to 251) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-1.0 to -0.2) dB; pan -0.01 (-0.05 to 0.02); left-right correlation 0.90 (0.83 to 0.94)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S7. - Windowlicker: bass group `bass-1` (346 notes, 24% of the track's note energy)
- In synth terms: around G1, bell- or metal-like (partials off whole multiples), slow swell, falls 72 dB/s, centered.
- Hear it at: 3:01.7 (F#1, 0.19 s, +21 dB alone), 5:52.7 (B0, 0.41 s, +20 dB alone), 5:53.4 (D#2, 0.34 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (34 to 75) Hz; attack 155 (27 to 292) ms; decay -72 (-424 to -7) dB/s
  - brightness at the start 128 (93 to 211) Hz; slope over the note 0.00 (-0.27 to 0.78) octaves
  - harmonic share 0.33 (0.04 to 0.94); partials off whole multiples 103 (28 to 225) cents
  - vibrato 0 (0 to 27) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.7 (-11.8 to -0.7) dB; pan -0.04 (-0.14 to 0.10); left-right correlation 1.00 (0.98 to 1.00)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S8. - Windowlicker [Original Demo]: drums group `drums-1` (199 notes, 23% of the track's note energy)
- In synth terms: low thump, quick attack, falls 102 dB/s, gets brighter over the note, centered.
- Hear it at: 0:45.9 (?, 0.27 s, +12 dB alone), 1:24.9 (?, 0.26 s, +12 dB alone), 1:48.3 (?, 0.29 s, +12 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 30 (30 to 30) Hz; attack 32 (13 to 33) ms; decay -102 (-111 to -97) dB/s
  - brightness at the start 117 (101 to 148) Hz; slope over the note 0.84 (-0.23 to 4.61) octaves
  - harmonic share 0.98 (0.98 to 0.99); partials off whole multiples 104 (77 to 131) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.9 (-4.2 to -1.1) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- Windowlicker sections:** 17 boundaries at 0:23.0, 0:53.0, 1:05.0, 1:24.0, 1:38.0, 1:54.0, 2:10.0, 2:27.0, 2:44.0, 2:56.0, 3:12.0, 3:27.0; section lengths median 17 s (range 8 to 70). Reliable for sections of 10 s or more.
- **- Windowlicker stem entries and exits:** drums plays 91% of the time (in: 0:16.0, 2:38.0; out: 2:31.0, 5:56.0); bass plays 90% of the time (in: 0:08.0, 0:26.0, 2:38.0, 3:59.5, 4:28.0; out: 0:18.5, 2:31.5, 3:54.5, 4:25.5, 6:00.0); other plays 89% of the time (in: 0:38.0, 0:49.5, 3:01.0; out: 0:30.5, 0:40.5, 2:39.5, 6:05.0); vocals plays 66% of the time (in: 0:08.0, 0:33.5, 0:40.0, 0:50.5, 2:43.5; out: 0:03.0, 0:10.5, 0:36.5, 0:43.0, 2:32.5).
- **- Windowlicker floor drops (kick and bass out 2 s or more while the rest plays):** 0.91 a minute: 0:18.8 for 2.8 s, 2:31.0 for 2.2 s, 2:34.0 for 3.8 s, 3:55.5 for 2.2 s, 4:50.0 for 3.0 s.
- **- Windowlicker brightness sweeps (0.7 octave or more):** mix down 3.0 oct 0:01.5 to 0:11.5; mix up 1.9 oct 0:15.0 to 0:24.5; mix up 2.7 oct 0:33.0 to 0:39.0; mix down 1.0 oct 0:39.0 to 0:46.0; mix up 1.5 oct 1:09.5 to 1:15.5; mix down 3.1 oct 1:17.0 to 1:23.0; mix down 1.4 oct 1:38.0 to 1:47.0; mix up 1.8 oct 1:51.0 to 1:56.5 (62 more in techniques.json).
- **- Windowlicker echo times:** drums: 489 ms (+18.3 dB, 2 later repeats).
- **- Windowlicker pumping locked to the kick:** other dips 4.7 dB at the kick (peak 30 ms after, kick every 0.48 s); bass dips 3.2 dB at the kick (peak 30 ms after, kick every 0.48 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Windowlicker tape wobble and speed:** other wobbles about 16 cents at 4.5 Hz.
- **- Windowlicker stereo movement:** bass pan range 0.25; other pan range 0.33; vocals pan range 0.32.
- **- Windowlicker builds:** 2:35.0 to 2:55.0.
- **- Equation sections:** 17 boundaries at 0:08.0, 0:23.0, 0:44.0, 0:55.0, 1:08.0, 2:04.0, 2:39.0, 3:07.0, 3:20.0, 3:50.0, 4:03.0, 4:22.0; section lengths median 14 s (range 7 to 56). Reliable for sections of 10 s or more.
- **- Equation stem entries and exits:** drums plays 83% of the time (in: 3:19.0, 4:19.0, 4:28.5, 5:00.5; out: 3:15.0, 4:16.0, 4:26.0, 4:35.5, 5:22.5); bass plays 29% of the time (in: 0:16.5, 0:32.5, 0:54.0, 1:09.5, 2:34.0; out: 0:24.5, 0:38.5, 1:05.5, 1:30.5, 2:45.5); other plays 92% of the time (in: 0:06.5, 1:17.5, 3:42.0, 4:19.0; out: 1:12.5, 3:39.0, 4:11.5, 5:42.0); vocals plays 39% of the time (in: 0:03.0, 0:44.0, 1:11.0, 1:23.5, 2:01.0; out: 0:09.0, 0:47.0, 1:15.5, 1:48.5, 2:03.5).
- **- Equation floor drops (kick and bass out 2 s or more while the rest plays):** 2.12 a minute: 0:45.0 for 3.8 s, 1:44.8 for 3.0 s, 3:13.5 for 6.0 s, 4:18.0 for 2.0 s, 4:24.8 for 5.0 s, 4:32.0 for 7.2 s, 4:40.0 for 23.2 s, 5:06.8 for 3.5 s.
- **- Equation brightness sweeps (0.7 octave or more):** mix down 4.0 oct 0:03.0 to 0:09.5; mix up 2.2 oct 0:16.5 to 0:23.0; mix down 4.4 oct 0:23.0 to 0:29.0; mix up 1.8 oct 0:29.0 to 0:34.0; mix up 1.5 oct 0:40.0 to 0:46.0; mix up 2.5 oct 0:56.5 to 1:01.5; mix up 1.2 oct 1:04.0 to 1:09.0; mix down 5.6 oct 1:09.0 to 1:21.0 (61 more in techniques.json).
- **- Equation echo times:** drums: 359 ms (+11.8 dB, 3 later repeats).
- **- Equation pumping locked to the kick:** bass dips 4.2 dB at the kick (peak 140 ms after, kick every 0.33 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Equation tape wobble and speed:** other wobbles about 6 cents at 0.3 Hz; bass wobbles about 15 cents at 0.5 Hz.
- **- Equation stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Equation builds:** 1:02.0 to 1:22.0; 1:45.0 to 2:09.0.
- **- Nannou sections:** 14 boundaries at 0:08.0, 0:32.0, 1:02.0, 1:17.0, 1:42.0, 1:55.0, 2:06.0, 2:27.0, 2:49.0, 3:13.0, 3:35.0, 3:45.0; section lengths median 15 s (range 5 to 30). Reliable for sections of 10 s or more.
- **- Nannou stem entries and exits:** drums plays 77% of the time (in: 1:12.5, 1:53.5, 2:40.0; out: 1:09.0, 1:42.5, 2:07.5, 4:04.5); bass plays 0% of the time (in: from the start; out: never); other plays 98% of the time (in: from the start; out: 4:11.5); vocals plays 0% of the time (in: from the start; out: never).
- **- Nannou floor drops:** low end too sparse to say (on in under 75% of the track).
- **- Nannou brightness sweeps (0.7 octave or more):** mix down 1.6 oct 0:05.5 to 0:10.5; mix up 0.9 oct 0:28.5 to 0:34.0; mix down 1.5 oct 0:39.5 to 0:50.5; mix up 2.5 oct 1:12.5 to 1:19.0; mix down 1.9 oct 1:39.5 to 1:45.0; mix up 3.2 oct 1:51.5 to 2:00.5; mix down 2.3 oct 2:00.5 to 2:11.0; mix up 0.7 oct 2:22.0 to 2:28.5 (19 more in techniques.json).
- **- Nannou echo times:** drums: 394 ms (+16.9 dB, 2 later repeats).
- **- Nannou pumping locked to the kick:** bass dips 13.6 dB at the kick (peak 150 ms after, kick every 0.23 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Nannou tape wobble and speed:** other wobbles about 6 cents at 4.3 Hz.
- **- Nannou stereo movement:** drums pan range 0.72.
- **- Windowlicker [Original Demo] sections:** 8 boundaries at 0:22.0, 0:47.0, 1:02.0, 1:19.0, 1:34.0, 2:02.0, 2:22.0, 2:35.0; section lengths median 17 s (range 2 to 28). Reliable for sections of 10 s or more.
- **- Windowlicker [Original Demo] stem entries and exits:** drums plays 100% of the time (in: from the start; out: never); bass plays 100% of the time (in: from the start; out: never); other plays 100% of the time (in: from the start; out: never); vocals plays 100% of the time (in: from the start; out: never).
- **- Windowlicker [Original Demo] floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Windowlicker [Original Demo] brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:33.0 to 0:38.5; mix up 1.0 oct 0:52.0 to 0:58.5; mix down 1.9 oct 0:59.0 to 1:04.5; mix up 1.1 oct 1:12.5 to 1:18.0; mix down 1.4 oct 1:18.5 to 1:24.5; mix up 1.8 oct 1:34.0 to 1:39.0; mix down 1.9 oct 1:39.0 to 1:44.5; mix up 0.8 oct 1:44.5 to 1:49.5 (14 more in techniques.json).
- **- Windowlicker [Original Demo] echo times:** drums: 489 ms (+24.0 dB, 2 later repeats).
- **- Windowlicker [Original Demo] pumping locked to the kick:** other dips 1.8 dB at the kick (peak 464 ms after, kick every 0.49 s); bass dips 9.4 dB at the kick (peak 449 ms after, kick every 0.49 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Windowlicker [Original Demo] tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Windowlicker [Original Demo] stereo movement:** vocals pan range 0.36, cycling every 31 s.
- **- Equation [Early Version, Edit] sections:** 7 boundaries at 0:13.0, 0:24.0, 0:50.0, 1:01.0, 1:12.0, 1:27.0, 1:37.0; section lengths median 11 s (range 9 to 26). Reliable for sections of 10 s or more.
- **- Equation [Early Version, Edit] stem entries and exits:** drums plays 95% of the time (in: 1:42.0; out: 1:38.0); bass plays 58% of the time (in: 0:11.5, 0:36.0, 1:00.0, 1:24.5; out: 0:25.0, 0:49.0, 1:13.5); other plays 98% of the time (in: 0:01.5; out: never); vocals plays 44% of the time (in: 0:11.5, 0:41.5, 1:01.0, 1:25.0; out: 0:25.0, 0:48.0, 1:13.5, 1:39.5).
- **- Equation [Early Version, Edit] floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Equation [Early Version, Edit] brightness sweeps (0.7 octave or more):** mix down 2.5 oct 0:02.5 to 0:14.0; mix up 1.2 oct 0:27.5 to 0:34.0; mix down 2.0 oct 0:34.5 to 0:47.5; mix up 1.7 oct 0:47.5 to 0:56.5; mix down 2.2 oct 0:58.5 to 1:08.5; mix up 2.3 oct 1:09.0 to 1:18.0; mix down 3.1 oct 1:18.0 to 1:28.0; mix up 2.1 oct 1:32.5 to 1:38.0 (8 more in techniques.json).
- **- Equation [Early Version, Edit] echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Equation [Early Version, Edit] pumping locked to the kick:** other dips 2.6 dB at the kick (peak 165 ms after, kick every 0.29 s); bass dips 4.7 dB at the kick (peak 85 ms after, kick every 0.29 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Equation [Early Version, Edit] tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Equation [Early Version, Edit] stereo movement:** drums pan range 0.59; other pan range 0.61; vocals pan range 0.50.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Windowlicker meter:** about 123 BPM (could be 61 or 246; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.10); swung: off-beat at 0.55 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Windowlicker key and mode:** C aeolian (minor) (low confidence: the key signature margin is 0.011, so read this as a guess); pitch-class weights C 0.16, D# 0.14, G 0.10, G# 0.09, D 0.08.
- **- Windowlicker chords:** 39 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.2 s (10th to 90th percentile 0.6 to 2.8 s); 33 distinct chords; most time on G#maj7 18%, Cmaj7 13%, C5 12%, Cmin7 10%. The old counter in this same run said 15; Ears 1's 2-s counter said 13.  64% of the changes land on a beat (chance would be 61%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Windowlicker bass:** root-note movement / mixed; 0.69 notes a second; most time on C 0.34, D# 0.29, G# 0.15, B 0.10; steps 4%, thirds 20%, fourths and fifths 11%, octaves 4%, repeats 48%.
- **- Windowlicker top line (from the 'other' stem; read by ear before trusting):** 751 notes, range 15 semitones (10th to 90th percentile); steps 15%, thirds 19%, fourths and fifths 23%, leaps 25%, repeats 18%; median interval 4 semitones; 48% of moves go up; phrases of about 8 notes, arch 43%, rising 27%, falling 20%, flat or wavy 10%. Reliable only when the line sits clearly above its accompaniment.
- **- Windowlicker repetition:** 376 bars of 1.0 s; strongest repeat distances 1 bars (0.55), 8 bars (0.40), 16 bars (0.22); 25% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Equation meter:** about 83 BPM (could be 42 or 166; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Equation key and mode:** G locrian (low confidence: the key signature margin is 0.002, so read this as a guess); pitch-class weights C# 0.11, C 0.10, D 0.09, D# 0.09, G# 0.08.
- **- Equation chords:** 31 changes a minute (16 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.7 to 3.7 s); 43 distinct chords; most time on C#maj7 22%, Fmaj7 9%, G#maj7 8%, Dmaj7 7%. The old counter in this same run said 6; Ears 1's 2-s counter said 4.  45% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Equation bass:** root-note movement / mixed; 0.10 notes a second; most time on E 0.37, B 0.19, G 0.13, A# 0.08; steps 23%, thirds 3%, fourths and fifths 11%, octaves 0%, repeats 40%.
- **- Equation top line (from the 'other' stem; read by ear before trusting):** 728 notes, range 34 semitones (10th to 90th percentile); steps 34%, thirds 14%, fourths and fifths 12%, leaps 27%, repeats 14%; median interval 3 semitones; 50% of moves go up; phrases of about 8 notes, arch 34%, rising 23%, falling 26%, flat or wavy 17%. Reliable only when the line sits clearly above its accompaniment.
- **- Equation repetition:** 240 bars of 1.4 s; strongest repeat distances 1 bars (0.53), 32 bars (0.12), 19 bars (0.11); 9% of bars near-duplicate an earlier bar.
- **- Nannou meter:** about 101 BPM (could be 51 or 203; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.05); swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Nannou key and mode:** F lydian (key signature margin 0.037); pitch-class weights E 0.20, F 0.17, A 0.12, D 0.12, C 0.10.
- **- Nannou chords:** 40 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 1.1 s (10th to 90th percentile 0.6 to 3.0 s); 27 distinct chords; most time on Dsus2 21%, Fmaj7 12%, Amin7 8%, Dmin7 7%. The old counter in this same run said 20; Ears 1's 2-s counter said 21.  44% of the changes land on a beat (chance would be 51%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Nannou top line (from the 'other' stem; read by ear before trusting):** 455 notes, range 22 semitones (10th to 90th percentile); steps 13%, thirds 13%, fourths and fifths 14%, leaps 48%, repeats 13%; median interval 7 semitones; 49% of moves go up; phrases of about 7 notes, arch 28%, rising 48%, falling 21%, flat or wavy 3%. Reliable only when the line sits clearly above its accompaniment.
- **- Nannou repetition:** 53 bars of 4.7 s; strongest repeat distances 1 bars (0.59), 19 bars (0.02), 26 bars (-0.02); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Windowlicker [Original Demo] meter:** about 123 BPM (could be 61 or 246; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.16); no clear off-beat onsets; no cross-rhythm claim.
- **- Windowlicker [Original Demo] key and mode:** D# ionian (major) (low confidence: the key signature margin is 0.009, so read this as a guess); pitch-class weights C 0.15, G 0.14, D# 0.12, A# 0.08, F 0.07.
- **- Windowlicker [Original Demo] chords:** 50 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.5 to 1.7 s); 10 distinct chords; most time on Cmin7 35%, G#maj7 20%, C5 12%, Cmaj7 12%. The old counter in this same run said 11; Ears 1's 2-s counter said 12.  83% of the changes land on a beat (chance would be 61%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Windowlicker [Original Demo] bass:** root-note movement / mixed; 0.68 notes a second; most time on G# 0.33, D# 0.33, F 0.32, C 0.03; steps 0%, thirds 35%, fourths and fifths 30%, octaves 0%, repeats 13%.
- **- Windowlicker [Original Demo] top line (from the 'other' stem; read by ear before trusting):** 397 notes, range 15 semitones (10th to 90th percentile); steps 12%, thirds 24%, fourths and fifths 25%, leaps 30%, repeats 8%; median interval 5 semitones; 53% of moves go up; phrases of about 10 notes, arch 85%, rising 9%, falling 6%, flat or wavy 0%. Reliable only when the line sits clearly above its accompaniment.
- **- Windowlicker [Original Demo] repetition:** 160 bars of 1.0 s; strongest repeat distances 32 bars (0.99), 8 bars (0.52), 24 bars (0.46); 85% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Equation [Early Version, Edit] meter:** about 105 BPM (could be 53 or 211; the tool cannot tell the beat level), 8 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Equation [Early Version, Edit] key and mode:** G locrian (low confidence: the key signature margin is 0.008, so read this as a guess); pitch-class weights C# 0.13, C 0.12, D 0.10, G 0.09, G# 0.09.
- **- Equation [Early Version, Edit] chords:** 20 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.7 to 5.9 s); 13 distinct chords; most time on C#maj7 52%, G#maj7 11%, Dmin7 9%, D7 5%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  50% of the changes land on a beat (chance would be 53%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Equation [Early Version, Edit] bass:** slides between notes; 0.08 notes a second; most time on F# 0.49, G 0.30, C 0.07, A 0.05; steps 43%, thirds 14%, fourths and fifths 29%, octaves 0%, repeats 14%.
- **- Equation [Early Version, Edit] top line (from the 'other' stem; read by ear before trusting):** 231 notes, range 27 semitones (10th to 90th percentile); steps 47%, thirds 13%, fourths and fifths 7%, leaps 20%, repeats 13%; median interval 2 semitones; 53% of moves go up; phrases of about 8 notes, arch 19%, rising 31%, falling 31%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **- Equation [Early Version, Edit] repetition:** 23 bars of 4.6 s; strongest repeat distances 5 bars (0.40), 11 bars (0.37), 1 bars (0.33); 14% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Windowlicker mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.98); low_120_500 -17 (corr 0.97); mid_500_2k -14 (corr 0.94); pres_2k_5k -11 (corr 0.87); air_gt5k -10 (corr 0.83); over time (2-s windows) 10th/50th/90th percentile -23/-18/-10 dB.
- **- Windowlicker by part:** drums: 15% of the power, width -16 dB, pan -0.11, mono loss 0.1 dB, widest in pres_2k_5k (-13 dB); bass: 48% of the power, width -18 dB, pan -0.15, mono loss 0.1 dB, widest in low_120_500 (-18 dB); other: 19% of the power, width -13 dB, pan -0.17, mono loss 0.2 dB, widest in mid_500_2k (-12 dB); vocals: 19% of the power, width -17 dB, pan -0.05, mono loss 0.1 dB, widest in mid_500_2k (-15 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Equation mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -22 (corr 0.99); low_120_500 -25 (corr 1.00); mid_500_2k -23 (corr 0.99); pres_2k_5k -19 (corr 0.97); air_gt5k -33 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -38/-29/-26 dB.
- **- Equation by part:** drums: 53% of the power, width -24 dB, pan +0.02, mono loss 0.0 dB, widest in sub_lt120 (-23 dB); bass: 5% of the power, width -22 dB, pan -0.02, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); other: 34% of the power, width -25 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-22 dB); vocals: 8% of the power, width -17 dB, pan -0.02, mono loss 0.1 dB, widest in pres_2k_5k (-12 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Nannou mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -1 (corr 0.13); low_120_500 -17 (corr 0.97); mid_500_2k -16 (corr 0.96); pres_2k_5k -11 (corr 0.84); air_gt5k -5 (corr 0.48); over time (2-s windows) 10th/50th/90th percentile -17/-11/-8 dB.
- **- Nannou by part:** drums: 22% of the power, width -5 dB, pan +0.00, mono loss 1.2 dB, widest in air_gt5k (-4 dB); bass: 0% of the power, width -4 dB, pan -0.12, mono loss 1.4 dB, widest in pres_2k_5k (-3 dB); other: 78% of the power, width -16 dB, pan -0.09, mono loss 0.1 dB, widest in mid_500_2k (-16 dB); vocals: 0% of the power, width -22 dB, pan +0.01, mono loss 0.0 dB, widest in air_gt5k (-20 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Windowlicker [Original Demo] mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 0.99); low_120_500 -15 (corr 0.93); mid_500_2k -15 (corr 0.94); pres_2k_5k -14 (corr 0.92); air_gt5k -7 (corr 0.68); over time (2-s windows) 10th/50th/90th percentile -19/-15/-13 dB.
- **- Windowlicker [Original Demo] by part:** drums: 39% of the power, width -23 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-27 dB); bass: 19% of the power, width -45 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-45 dB); other: 13% of the power, width -17 dB, pan -0.03, mono loss 0.1 dB, widest in sub_lt120 (-13 dB); vocals: 29% of the power, width -11 dB, pan +0.03, mono loss 0.3 dB, widest in mid_500_2k (-11 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Equation [Early Version, Edit] mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -15 (corr 0.94); low_120_500 -10 (corr 0.85); mid_500_2k -2 (corr 0.27); pres_2k_5k 3 (corr -0.46); air_gt5k -1 (corr 0.07); over time (2-s windows) 10th/50th/90th percentile -5/-4/-2 dB.
- **- Equation [Early Version, Edit] by part:** drums: 65% of the power, width -7 dB, pan +0.26, mono loss 0.8 dB, widest in mid_500_2k (-1 dB); bass: 22% of the power, width -19 dB, pan -0.08, mono loss 0.0 dB, widest in low_120_500 (-20 dB); other: 12% of the power, width -5 dB, pan +0.26, mono loss 1.2 dB, widest in mid_500_2k (-3 dB); vocals: 0% of the power, width 4 dB, pan +0.45, mono loss 5.8 dB, widest in pres_2k_5k (6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Windowlicker: 123 BPM, 14 settled chords a minute, 9% of energy above 2 kHz, width -16 dB; - Equation: 83 BPM, 16 settled chords a minute, 15% of energy above 2 kHz, width -23 dB; - Nannou: 101 BPM, 13 settled chords a minute, 25% of energy above 2 kHz, width -11 dB; - Windowlicker [Original Demo]: 123 BPM, 15 settled chords a minute, 3% of energy above 2 kHz, width -16 dB; - Equation [Early Version, Edit]: 105 BPM, 13 settled chords a minute, 6% of energy above 2 kHz, width -7 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: - Nannou: 25% of energy above 2 kHz (bright or harsh).

### For later
- - Nannou, drums group `drums-1` (475 notes): high tick, quick attack, falls 1122 dB/s, centered; hear it at 0:04.4, 2:47.5. **[JUDGMENT]** why it waits.
- - Windowlicker, vocals group `vocals-1` (302 notes): around A2, mixed or noisy partials, slow swell, falls 20 dB/s, centered; hear it at 1:54.5, 4:14.1. **[JUDGMENT]** why it waits.
- - Windowlicker, other group `other-1` (409 notes): around G#1, bell- or metal-like (partials off whole multiples), slow swell, falls 21 dB/s, centered; hear it at 2:34.7, 0:14.0. **[JUDGMENT]** why it waits.
- - Windowlicker, bass group `bass-2` (154 notes): around D#2, harmonic (string/reed/pad-like), soft attack, falls 11 dB/s, centered; hear it at 2:39.5, 2:56.8. **[JUDGMENT]** why it waits.
- - Equation, drums group `drums-2` (177 notes): mid snap, quick attack, falls 102 dB/s, centered; hear it at 1:15.3, 3:53.5. **[JUDGMENT]** why it waits.
- - Equation [Early Version, Edit], other group `other-1` (447 notes): around F#1, bell- or metal-like (partials off whole multiples), soft attack, falls 113 dB/s, centered; hear it at 1:41.5, 1:42.6. **[JUDGMENT]** why it waits.
- - Windowlicker [Original Demo], drums group `drums-2` (250 notes): mid snap, quick attack, falls 238 dB/s, gets brighter over the note, centered; hear it at 0:14.2, 2:10.3. **[JUDGMENT]** why it waits.
- - Equation [Early Version, Edit], bass group `bass-1` (92 notes): around B1, bell- or metal-like (partials off whole multiples), quick attack, falls 218 dB/s, centered; hear it at 1:08.4, 1:08.3. **[JUDGMENT]** why it waits.
