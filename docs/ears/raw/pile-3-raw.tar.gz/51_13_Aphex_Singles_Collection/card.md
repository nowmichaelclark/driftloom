## 51-13 Aphex Singles Collection (draft card from Ears 3 tools, 2026-10-25)

How it was made: 11 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: Aphex Twin_51+13 Aphex Singles Collection_01_On; Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit); Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb; Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips. Typical track: Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit). Least like the rest: Aphex Twin_51+13 Aphex Singles Collection_10_Ventolin (Asthma Beats mix), Aphex Twin_51+13 Aphex Singles Collection_08_Icct Hedral (Philip Glass Orchestration).
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Aphex Twin_51+13 Aphex Singles Collection_01_On**: share of power drums 28%, bass 60%, other 10%, vocals 2%.
  - vocals stem holds 1.7%: bleed on an instrumental, not a voice.
  - meter tool 135 BPM agrees with the drum-grid beat of 136.1 BPM.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit)**: share of power drums 73%, bass 3%, other 16%, vocals 8%.
  - bass stem is thin (3.2%): bass notes, pumping and wobble are guesses.
  - meter tool 84 BPM agrees with the drum-grid beat of 83.3 BPM.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb**: share of power drums 61%, bass 31%, other 8%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 140 BPM agrees with the drum-grid beat of 139.5 BPM.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips**: share of power drums 35%, bass 52%, other 13%, vocals 1%.
  - vocals stem holds 0.7%: bleed on an instrumental, not a voice.
  - meter tool 86 BPM does not match the drum-grid beat of 37.7 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 84 to 140 BPM (octave-uncertain); keys A# aeolian, A# mixolydian, A# dorian, G# ionian; mix width -30 to -17 dB; chord changes 6 to 46 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Aphex Twin_51+13 Aphex Singles Collection_01_On: bass group `bass-1` (372 notes, 53% of the track's note energy)
- In synth terms: around A#1, harmonic (string/reed/pad-like), slow swell, falls 65 dB/s, centered.
- Hear it at: 4:59.4 (A#1, 0.46 s, +14 dB alone), 5:02.9 (A#1, 0.45 s, +12 dB alone), 5:27.8 (?, 0.47 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 58 (43 to 60) Hz; attack 245 (122 to 358) ms; decay -65 (-648 to -2) dB/s
  - brightness at the start 85 (71 to 106) Hz; slope over the note 0.00 (-0.23 to 0.14) octaves
  - harmonic share 0.99 (0.68 to 1.00); partials off whole multiples 21 (4 to 141) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.0 (-2.0 to -0.5) dB; pan 0.00 (-0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S2. Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips: bass group `bass-1` (423 notes, 45% of the track's note energy)
- In synth terms: around G#1, harmonic (string/reed/pad-like), slow swell, falls 252 dB/s, centered.
- Hear it at: 3:49.1 (G#1, 0.5 s, +6 dB alone), 3:42.4 (G#1, 0.36 s, +11 dB alone), 3:47.6 (G#1, 0.24 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 52 (43 to 59) Hz; attack 167 (71 to 405) ms; decay -252 (-642 to -1) dB/s
  - brightness at the start 98 (72 to 578) Hz; slope over the note 0.00 (-0.15 to 1.34) octaves
  - harmonic share 0.96 (0.35 to 1.00); partials off whole multiples 43 (11 to 194) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.0 (-5.7 to -1.2) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S3. Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit): other group `other-1` (195 notes, 39% of the track's note energy)
- In synth terms: around G#2, bell- or metal-like (partials off whole multiples), soft attack, falls 16 dB/s, centered.
- Hear it at: 1:13.9 (D#2, 0.27 s, +45 dB alone), 1:14.3 (D3, 0.18 s, +46 dB alone), 1:14.2 (D3, 0.11 s, +45 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 103 (48 to 231) Hz; attack 148 (36 to 644) ms; decay -16 (-78 to -0) dB/s
  - brightness at the start 392 (248 to 1382) Hz; slope over the note 0.00 (-0.69 to 0.54) octaves
  - harmonic share 0.49 (0.14 to 0.88); partials off whole multiples 81 (32 to 165) cents
  - vibrato 0 (0 to 17) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.2 (-11.8 to -0.0) dB; pan 0.00 (-0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb: bass group `bass-1` (398 notes, 36% of the track's note energy)
- In synth terms: around A#1, harmonic (string/reed/pad-like), soft attack, falls 60 dB/s, centered.
- Hear it at: 5:41.4 (A#1, 0.49 s, +8 dB alone), 5:15.7 (A#1, 0.57 s, +7 dB alone), 4:48.3 (C#2, 0.08 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 59 (57 to 62) Hz; attack 96 (61 to 176) ms; decay -60 (-164 to -29) dB/s
  - brightness at the start 71 (70 to 75) Hz; slope over the note 0.03 (-0.03 to 0.22) octaves
  - harmonic share 0.98 (0.95 to 1.00); partials off whole multiples 46 (16 to 120) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.0 (-4.6 to -1.2) dB; pan -0.02 (-0.03 to -0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S5. Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit): drums group `drums-1` (107 notes, 24% of the track's note energy)
- In synth terms: low thump, soft attack, falls 18 dB/s, centered.
- Hear it at: 1:15.2 (A1, 0.23 s, +18 dB alone), 0:55.9 (A#1, 0.47 s, +17 dB alone), 0:56.1 (A#1, 0.54 s, +15 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (46 to 62) Hz; attack 77 (20 to 150) ms; decay -18 (-43 to 5) dB/s
  - brightness at the start 137 (100 to 486) Hz; slope over the note 0.00 (-0.05 to 2.22) octaves
  - harmonic share 0.32 (0.07 to 0.94); partials off whole multiples 144 (64 to 228) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.6 (-5.1 to -0.2) dB; pan 0.01 (-0.01 to 0.03); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S6. Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips: drums group `drums-1` (426 notes, 23% of the track's note energy)
- In synth terms: high tick, soft attack, falls 36 dB/s, centered.
- Hear it at: 1:23.3 (B5, 0.2 s, +38 dB alone), 1:34.4 (B5, 0.21 s, +38 dB alone), 1:26.5 (B5, 0.21 s, +37 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 164 (51 to 1004) Hz; attack 75 (10 to 240) ms; decay -36 (-168 to -11) dB/s
  - brightness at the start 2730 (997 to 3399) Hz; slope over the note 0.02 (0.00 to 0.76) octaves
  - harmonic share 0.39 (0.06 to 0.98); partials off whole multiples 101 (11 to 163) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.8 (-5.6 to -0.3) dB; pan 0.00 (-0.01 to 0.02); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S7. Aphex Twin_51+13 Aphex Singles Collection_01_On: drums group `drums-1` (335 notes, 19% of the track's note energy)
- In synth terms: low thump, soft attack, falls 454 dB/s, gets brighter over the note, centered.
- Hear it at: 4:18.2 (G1, 0.12 s, +35 dB alone), 4:57.3 (F#1, 0.13 s, +30 dB alone), 4:14.6 (G1, 0.12 s, +28 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 41 (31 to 57) Hz; attack 52 (51 to 64) ms; decay -454 (-519 to -386) dB/s
  - brightness at the start 130 (95 to 208) Hz; slope over the note 0.65 (-0.08 to 3.42) octaves
  - harmonic share 0.11 (0.04 to 0.70); partials off whole multiples 191 (105 to 338) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.0 (-3.1 to -0.3) dB; pan -0.04 (-0.07 to -0.02); left-right correlation 0.98 (0.97 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb: drums group `drums-1` (179 notes, 17% of the track's note energy)
- In synth terms: mid snap, quick attack, falls 104 dB/s, gets brighter over the note, centered.
- Hear it at: 5:22.9 (?, 0.14 s, +40 dB alone), 5:33.2 (G1, 0.22 s, +40 dB alone), 5:36.6 (?, 0.13 s, +39 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 50 (49 to 50) Hz; attack 28 (13 to 71) ms; decay -104 (-135 to -80) dB/s
  - brightness at the start 794 (303 to 1156) Hz; slope over the note 2.19 (0.00 to 3.32) octaves
  - harmonic share 0.96 (0.64 to 0.98); partials off whole multiples 105 (69 to 212) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-2.2 to -0.2) dB; pan -0.02 (-0.03 to -0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Aphex Twin_51+13 Aphex Singles Collection_01_On sections:** 16 boundaries at 1:01.0, 1:20.0, 1:40.0, 1:52.0, 2:20.0, 2:45.0, 2:56.0, 3:08.0, 3:22.0, 3:34.0, 5:15.0, 5:30.0; section lengths median 14 s (range 11 to 101). Reliable for sections of 10 s or more.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On stem entries and exits:** drums plays 78% of the time (in: 0:54.0, 6:13.5; out: 5:43.5, 6:44.5); bass plays 71% of the time (in: 1:16.5, 6:15.0; out: 5:42.0, 6:43.5); other plays 98% of the time (in: from the start; out: 6:44.0); vocals plays 70% of the time (in: 1:15.0, 4:45.0, 6:14.0; out: 4:40.5, 5:41.0, 6:41.5).
- **Aphex Twin_51+13 Aphex Singles Collection_01_On floor drops (kick and bass out 2 s or more while the rest plays):** 0.65 a minute: 0:20.5 for 38.0 s, 0:58.0 for 7.0 s, 1:05.2 for 8.2 s, 5:41.8 for 32.2 s.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:01.5 to 0:12.0; mix up 1.9 oct 0:17.0 to 0:33.0; mix up 1.2 oct 0:58.0 to 1:03.5; mix down 2.8 oct 1:09.0 to 1:17.5; mix up 1.6 oct 1:18.0 to 1:26.5; mix down 0.7 oct 1:42.5 to 1:48.5; mix up 2.2 oct 1:48.5 to 1:57.5; mix up 1.0 oct 2:20.0 to 2:30.5 (48 more in techniques.json).
- **Aphex Twin_51+13 Aphex Singles Collection_01_On echo times:** drums: 334 ms (+16.9 dB, 1 later repeats).
- **Aphex Twin_51+13 Aphex Singles Collection_01_On pumping locked to the kick:** other dips 1.6 dB at the kick (peak 15 ms after, kick every 0.26 s); bass dips 7.3 dB at the kick (peak 239 ms after, kick every 0.26 s). The tool reads about 70% of the true depth, so this is a floor.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) sections:** 6 boundaries at 0:06.0, 0:25.0, 0:56.0, 1:09.0, 1:26.0, 1:39.0; section lengths median 13 s (range 3 to 31). Reliable for sections of 10 s or more.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) stem entries and exits:** drums plays 90% of the time (in: 0:04.5; out: 1:36.0); bass plays 90% of the time (in: 0:04.5; out: 1:36.0); other plays 98% of the time (in: from the start; out: 1:40.0); vocals plays 77% of the time (in: 0:06.0, 1:14.0, 1:25.0; out: 1:08.5, 1:18.5, 1:36.0).
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) floor drops (kick and bass out 2 s or more while the rest plays):** 2.65 a minute: 0:08.8 for 2.5 s, 0:14.8 for 2.2 s, 1:12.0 for 2.8 s, 1:18.2 for 2.8 s.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) brightness sweeps (0.7 octave or more):** mix up 2.4 oct 0:02.0 to 0:09.5; mix up 1.4 oct 0:23.5 to 0:28.5; mix down 0.8 oct 0:28.5 to 0:33.5; mix up 1.3 oct 0:34.0 to 0:39.0; mix down 1.2 oct 0:48.5 to 0:54.0; mix up 0.7 oct 1:02.5 to 1:08.5; mix down 1.6 oct 1:18.5 to 1:25.5; other up 2.7 oct 0:01.0 to 0:11.0 (7 more in techniques.json).
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) echo times:** other: 220 ms (+3.0 dB, 1 later repeats); drums: 349 ms (+4.1 dB, 3 later repeats).
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) pumping locked to the kick:** bass dips 1.8 dB at the kick (peak 5 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) tape wobble and speed:** other wobbles about 22 cents at 3.8 Hz.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) builds:** 0:26.0 to 0:51.0.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb sections:** 16 boundaries at 0:02.0, 0:30.0, 0:54.0, 1:07.0, 1:19.0, 1:47.0, 2:02.0, 2:22.0, 3:07.0, 3:18.0, 3:30.0, 3:43.0; section lengths median 18 s (range 2 to 45). Reliable for sections of 10 s or more.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb stem entries and exits:** drums plays 95% of the time (in: from the start; out: 5:42.5); bass plays 80% of the time (in: 0:24.5, 1:24.5, 1:36.5, 2:36.5, 2:45.0; out: 1:21.0, 1:28.0, 2:28.0, 2:40.0, 2:52.0); other plays 98% of the time (in: 5:41.0; out: 5:36.5, 5:55.5); vocals plays 0% of the time (in: from the start; out: never).
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb brightness sweeps (0.7 octave or more):** mix down 1.8 oct 0:32.5 to 0:41.5; mix up 1.0 oct 1:16.0 to 1:23.5; mix down 0.8 oct 1:44.0 to 1:52.5; mix up 0.7 oct 2:05.0 to 2:10.5; mix up 1.3 oct 3:41.5 to 3:46.5; mix down 0.8 oct 3:46.5 to 3:52.5; mix up 1.1 oct 4:04.0 to 4:09.5; mix down 1.2 oct 4:44.0 to 4:49.0 (21 more in techniques.json).
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb echo times:** other: 454 ms (+10.6 dB, 2 later repeats).
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb pumping locked to the kick:** other dips 5.4 dB at the kick (peak 190 ms after, kick every 0.22 s); bass dips 6.8 dB at the kick (peak 195 ms after, kick every 0.22 s). The tool reads about 70% of the true depth, so this is a floor.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips sections:** 12 boundaries at 0:05.0, 0:52.0, 1:12.0, 1:39.0, 1:50.0, 2:05.0, 2:24.0, 2:34.0, 2:49.0, 3:15.0, 3:42.0, 4:03.0; section lengths median 19 s (range 5 to 47). Reliable for sections of 10 s or more.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips stem entries and exits:** drums plays 95% of the time (in: 0:06.0; out: 4:09.5); bass plays 83% of the time (in: 0:26.5, 4:01.5; out: 3:50.5, 4:09.0); other plays 89% of the time (in: 1:38.5; out: 1:21.0, 4:06.5); vocals plays 34% of the time (in: 0:52.0, 1:25.5, 1:46.5, 2:34.0, 3:15.0; out: 1:13.0, 1:34.5, 2:04.5, 2:52.0, 3:20.5).
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips brightness sweeps (0.7 octave or more):** mix up 5.0 oct 0:00.0 to 0:07.5; mix down 3.1 oct 0:49.5 to 0:57.5; mix up 4.2 oct 1:06.0 to 1:15.5; mix up 2.1 oct 1:29.5 to 1:36.0; mix down 1.5 oct 1:46.5 to 1:53.0; mix up 2.5 oct 1:53.5 to 2:06.0; mix down 3.6 oct 2:30.5 to 2:36.5; mix up 3.5 oct 2:44.5 to 2:50.5 (31 more in techniques.json).
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips echo times:** drums: 115 ms (+6.0 dB, 2 later repeats).
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips pumping locked to the kick:** other dips 1.8 dB at the kick (peak 155 ms after, kick every 0.31 s); bass dips 8.4 dB at the kick (peak 20 ms after, kick every 0.31 s). The tool reads about 70% of the true depth, so this is a floor.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips tape wobble and speed:** other wobbles about 16 cents at 1.6 Hz.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Aphex Twin_51+13 Aphex Singles Collection_01_On meter:** about 135 BPM (could be 67 or 270; the tool cannot tell the beat level), 8 beats a bar; swung: off-beat at 0.79 of the beat; no cross-rhythm claim.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On key and mode:** A# aeolian (minor) (key signature margin 0.043); pitch-class weights C# 0.14, D# 0.12, F# 0.11, C 0.10, G# 0.10.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On chords:** 46 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.7 to 2.4 s); 18 distinct chords; most time on D#min7 38%, C#maj7 33%, G#sus2 7%, F#5 6%. The old counter in this same run said 2; Ears 1's 2-s counter said 2.  62% of the changes land on a beat (chance would be 67%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On bass:** pedal (one note held or repeated); 0.69 notes a second; most time on A# 0.82, G 0.15, G# 0.02; steps 4%, thirds 0%, fourths and fifths 1%, octaves 0%, repeats 95%.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On top line (from the 'other' stem; read by ear before trusting):** 984 notes, range 24 semitones (10th to 90th percentile); steps 10%, thirds 12%, fourths and fifths 34%, leaps 32%, repeats 12%; median interval 5 semitones; 51% of moves go up; phrases of about 9 notes, arch 46%, rising 25%, falling 9%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On repetition:** 116 bars of 3.6 s; strongest repeat distances 1 bars (0.85); 39% of bars near-duplicate an earlier bar.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) meter:** about 84 BPM (could be 42 or 168; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.25); swung: off-beat at 0.74 of the beat; no cross-rhythm claim.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) key and mode:** A# mixolydian (key signature margin 0.048); pitch-class weights A# 0.24, G# 0.12, D 0.12, D# 0.09, F 0.08.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) chords:** 22 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 1.0 to 3.9 s); 11 distinct chords; most time on A#7 57%, G#sus2 17%, D#5 7%, A#min7 7%. The old counter in this same run said 11; Ears 1's 2-s counter said 5.  45% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) bass:** root-note movement / mixed; 0.14 notes a second; most time on A# 0.52, G# 0.27, C# 0.17, D 0.04; steps 8%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 54%.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) top line (from the 'other' stem; read by ear before trusting):** 216 notes, range 2 semitones (10th to 90th percentile); steps 54%, thirds 6%, fourths and fifths 6%, leaps 1%, repeats 33%; median interval 2 semitones; 50% of moves go up; phrases of about 14 notes, arch 30%, rising 10%, falling 20%, flat or wavy 40%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) repetition:** 17 bars of 5.7 s; strongest repeat distances 1 bars (0.43), 7 bars (-0.29); 6% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb meter:** about 140 BPM (could be 70 or 280; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.03); straight eighths; no cross-rhythm claim; many unrelated periodicities found (4:3, 5:2, 5:3, 5:4), which means irregular timing, not a cross-rhythm claim.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb key and mode:** A# dorian (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights C# 0.16, C 0.16, D 0.11, D# 0.10, F 0.09.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb chords:** 11 changes a minute (8 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 1.2 to 3.1 s); 9 distinct chords; most time on C#maj7 70%, F7 10%, G7 9%, Dmin7 4%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  84% of the changes land on a beat (chance would be 70%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb bass:** slides between notes; 0.94 notes a second; most time on B 0.51, A# 0.49; steps 38%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 62%.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb top line (from the 'other' stem; read by ear before trusting):** 911 notes, range 24 semitones (10th to 90th percentile); steps 17%, thirds 5%, fourths and fifths 22%, leaps 39%, repeats 16%; median interval 7 semitones; 50% of moves go up; phrases of about 10 notes, arch 43%, rising 15%, falling 21%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb repetition:** 209 bars of 1.7 s; strongest repeat distances 2 bars (0.80), 4 bars (0.75), 6 bars (0.61); 36% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips meter:** about 86 BPM (could be 43 or 173; the tool cannot tell the beat level), bar length unclear (best guess 7, score 0.13); swung: off-beat at 0.72 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips key and mode:** G# ionian (major) (low confidence: the key signature margin is 0.008, so read this as a guess); pitch-class weights G 0.13, G# 0.11, F# 0.10, D# 0.10, C# 0.10.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips chords:** 6 changes a minute (5 a minute are chords that last 1.5 s or more); median chord 3.1 s (10th to 90th percentile 0.6 to 26.2 s); 12 distinct chords; most time on G#maj7 50%, C#maj7 30%, Gmaj7 11%, G#sus2 3%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  48% of the changes land on a beat (chance would be 43%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips bass:** pedal (one note held or repeated); 1.05 notes a second; most time on G# 0.87, G 0.09, A 0.05; steps 15%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 70%.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips top line (from the 'other' stem; read by ear before trusting):** 616 notes, range 38 semitones (10th to 90th percentile); steps 23%, thirds 1%, fourths and fifths 2%, leaps 53%, repeats 21%; median interval 10 semitones; 49% of moves go up; phrases of about 6 notes, arch 21%, rising 21%, falling 21%, flat or wavy 36%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips repetition:** 52 bars of 4.9 s; strongest repeat distances 1 bars (0.58), 22 bars (0.08), 26 bars (0.03); 35% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Aphex Twin_51+13 Aphex Singles Collection_01_On mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 0.99); low_120_500 -14 (corr 0.94); mid_500_2k -8 (corr 0.72); pres_2k_5k -12 (corr 0.89); air_gt5k -21 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -15/-12/-6 dB.
- **Aphex Twin_51+13 Aphex Singles Collection_01_On by part:** drums: 27% of the power, width -18 dB, pan -0.08, mono loss 0.1 dB, widest in low_120_500 (-16 dB); bass: 61% of the power, width -32 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-33 dB); other: 11% of the power, width -8 dB, pan -0.01, mono loss 0.6 dB, widest in mid_500_2k (-7 dB); vocals: 2% of the power, width -14 dB, pan -0.16, mono loss 0.2 dB, widest in mid_500_2k (-12 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -31 (corr 1.00); low_120_500 -30 (corr 1.00); mid_500_2k -28 (corr 1.00); pres_2k_5k -28 (corr 1.00); air_gt5k -28 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -31/-29/-28 dB.
- **Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit) by part:** drums: 73% of the power, width -30 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-27 dB); bass: 3% of the power, width -49 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-50 dB); other: 16% of the power, width -32 dB, pan +0.01, mono loss 0.0 dB, widest in mid_500_2k (-28 dB); vocals: 7% of the power, width -30 dB, pan +0.02, mono loss 0.0 dB, widest in pres_2k_5k (-28 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -30 (corr 1.00); low_120_500 -28 (corr 1.00); mid_500_2k -32 (corr 1.00); pres_2k_5k -30 (corr 1.00); air_gt5k -32 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -31/-30/-28 dB.
- **Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb by part:** drums: 59% of the power, width -30 dB, pan -0.04, mono loss 0.0 dB, widest in low_120_500 (-29 dB); bass: 33% of the power, width -31 dB, pan -0.05, mono loss 0.0 dB, widest in sub_lt120 (-31 dB); other: 8% of the power, width -30 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-28 dB); vocals: 0% of the power, width -28 dB, pan +0.00, mono loss 0.0 dB, widest in mid_500_2k (-26 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -32 (corr 1.00); low_120_500 -23 (corr 0.99); mid_500_2k -21 (corr 0.99); pres_2k_5k -30 (corr 1.00); air_gt5k -33 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -28/-27/-24 dB.
- **Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips by part:** drums: 35% of the power, width -27 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-29 dB); bass: 52% of the power, width -35 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-36 dB); other: 12% of the power, width -27 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-25 dB); vocals: 1% of the power, width -24 dB, pan -0.00, mono loss 0.0 dB, widest in mid_500_2k (-22 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Aphex Twin_51+13 Aphex Singles Collection_01_On: 135 BPM, 12 settled chords a minute, 4% of energy above 2 kHz, width -17 dB; Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit): 84 BPM, 17 settled chords a minute, 12% of energy above 2 kHz, width -30 dB; Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb: 140 BPM, 8 settled chords a minute, 8% of energy above 2 kHz, width -30 dB; Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips: 86 BPM, 5 settled chords a minute, 30% of energy above 2 kHz, width -29 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips: 30% of energy above 2 kHz (bright or harsh).

### For later
- Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips, other group `other-1` (390 notes): around G2, harmonic (string/reed/pad-like), soft attack, falls 38 dB/s, centered; hear it at 0:01.1, 0:04.0. **[JUDGMENT]** why it waits.
- Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb, other group `other-1` (398 notes): around F3, mixed or noisy partials, soft attack, falls 38 dB/s, centered; hear it at 3:53.0, 3:32.4. **[JUDGMENT]** why it waits.
- Aphex Twin_51+13 Aphex Singles Collection_03_Ventolin (Crowsmangegus mix edit), drums group `drums-2` (56 notes): low thump, soft attack, falls 118 dB/s, centered; hear it at 1:15.9, 1:15.3. **[JUDGMENT]** why it waits.
- Aphex Twin_51+13 Aphex Singles Collection_01_On, drums group `drums-2` (153 notes): mid snap, slow swell, falls 401 dB/s, centered; hear it at 4:21.5, 4:23.2. **[JUDGMENT]** why it waits.
- Aphex Twin_51+13 Aphex Singles Collection_01_On, other group `other-1` (371 notes): around F#2, mixed or noisy partials, soft attack, falls 42 dB/s, centered; hear it at 5:50.9, 5:47.3. **[JUDGMENT]** why it waits.
- Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb, drums group `drums-2` (196 notes): low thump, quick attack, falls 59 dB/s, centered; hear it at 5:18.2, 5:17.7. **[JUDGMENT]** why it waits.
- Aphex Twin_51+13 Aphex Singles Collection_05_Donkey Rhubarb, bass group `bass-2` (58 notes): around F#1, bell- or metal-like (partials off whole multiples), soft attack, falls 29 dB/s, centered; hear it at 4:43.8, 4:45.5. **[JUDGMENT]** why it waits.
- Aphex Twin_51+13 Aphex Singles Collection_07_73-Yips, drums group `drums-2` (74 notes): low thump, slow swell, falls 99 dB/s, gets brighter over the note, centered; hear it at 2:43.5, 2:43.4. **[JUDGMENT]** why it waits.
- **Aphex Twin_51+13 Aphex Singles Collection_08_Icct Hedral (Philip Glass Orchestration)** (7:57.7, 144 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 25.20 (high, album median 1.75). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin_51+13 Aphex Singles Collection_02_Pancake Lizard** (4:31.3, 118 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 19.70 (high, album median 1.75). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin_51+13 Aphex Singles Collection_09_Ventolin (Marazavose mix edit)** (3:21.4, 112 BPM by the mix-level count): stands out for brightness sweep (octaves) 2.54 (high, album median 1.03). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin_51+13 Aphex Singles Collection_12_Respect List** (0:38.9, 123 BPM by the mix-level count): stands out for pulse strength 0.07 (low, album median 0.70). Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
