## Drukqs (draft card from Ears 3 tools, 2026-10-25)

How it was made: 27 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: Aphex Twin - Jynweythek; Aphex Twin - Afx237 v.7; Aphex Twin - Orban Eq Trx 4; Aphex Twin - 54 Cymru Beats. Typical track: Aphex Twin - Jynweythek. Least like the rest: Aphex Twin - Afx237 v.7, Aphex Twin - Orban Eq Trx 4, Aphex Twin - 54 Cymru Beats.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Aphex Twin - Jynweythek**: share of power drums 0%, bass 0%, other 100%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
- **Aphex Twin - Afx237 v.7**: share of power drums 53%, bass 10%, other 36%, vocals 1%.
  - vocals stem holds 1.1%: bleed on an instrumental, not a voice.
  - meter tool 112 BPM is two thirds of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Aphex Twin - Orban Eq Trx 4**: share of power drums 38%, bass 61%, other 2%, vocals 0%.
  - other stem holds 1.6% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 90 BPM agrees with the drum-grid beat of 90.6 BPM.
- **Aphex Twin - 54 Cymru Beats**: share of power drums 51%, bass 17%, other 28%, vocals 4%.
  - vocals stem holds 4.2%: bleed on an instrumental, not a voice.
  - meter tool 112 BPM is two thirds of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 90 to 120 BPM (octave-uncertain); keys D# aeolian, A# lydian, C# lydian, D locrian; mix width -26 to -5 dB; chord changes 10 to 43 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Aphex Twin - Jynweythek: other group `other-1` (227 notes, 64% of the track's note energy)
- In synth terms: around E2, mixed or noisy partials, soft attack, falls 12 dB/s, centered.
- Hear it at: 1:29.0 (G#2, 1.09 s, +55 dB alone), 1:17.1 (B1, 1.05 s, +56 dB alone), 1:34.1 (F#2, 0.51 s, +56 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 82 (52 to 123) Hz; attack 64 (16 to 218) ms; decay -12 (-23 to -7) dB/s
  - brightness at the start 461 (388 to 574) Hz; slope over the note -0.05 (-0.32 to 0.09) octaves
  - harmonic share 0.66 (0.18 to 0.93); partials off whole multiples 48 (15 to 129) cents
  - vibrato 0 (0 to 1) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-3.0 to -0.7) dB; pan 0.00 (-0.11 to 0.15); left-right correlation 0.49 (0.02 to 0.69)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. Aphex Twin - Orban Eq Trx 4: bass group `bass-1` (169 notes, 50% of the track's note energy)
- In synth terms: around C#2, bell- or metal-like (partials off whole multiples), quick attack, falls 14 dB/s, centered.
- Hear it at: 1:01.4 (C2, 0.17 s, +23 dB alone), 0:18.8 (C2, 0.17 s, +18 dB alone), 1:14.5 (A#1, 0.26 s, +17 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 70 (58 to 98) Hz; attack 28 (13 to 126) ms; decay -14 (-133 to -3) dB/s
  - brightness at the start 81 (76 to 107) Hz; slope over the note 0.02 (-0.05 to 0.18) octaves
  - harmonic share 0.90 (0.84 to 0.96); partials off whole multiples 263 (149 to 280) cents
  - vibrato 0 (0 to 4) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.5 (-3.9 to -0.2) dB; pan 0.00 (-0.00 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S3. Aphex Twin - Jynweythek: other group `other-2` (106 notes, 36% of the track's note energy)
- In synth terms: around F#3, mixed or noisy partials, soft attack, falls 14 dB/s, centered.
- Hear it at: 0:12.0 (C#4, 0.82 s, +58 dB alone), 2:08.0 (D#3, 5.59 s, +53 dB alone), 1:16.1 (B3, 0.55 s, +57 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 185 (154 to 271) Hz; attack 87 (28 to 209) ms; decay -14 (-28 to -7) dB/s
  - brightness at the start 396 (267 to 519) Hz; slope over the note -0.03 (-0.20 to 0.25) octaves
  - harmonic share 0.85 (0.45 to 0.94); partials off whole multiples 41 (8 to 144) cents
  - vibrato 0 (0 to 1) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.9 (-2.0 to -0.6) dB; pan 0.02 (-0.13 to 0.13); left-right correlation 0.66 (0.25 to 0.79)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. Aphex Twin - 54 Cymru Beats: other group `other-1` (480 notes, 32% of the track's note energy)
- In synth terms: around G#1, mixed or noisy partials, soft attack, falls 54 dB/s, centered.
- Hear it at: 5:02.4 (?, 0.21 s, +40 dB alone), 4:57.4 (A#1, 0.28 s, +38 dB alone), 4:57.1 (?, 0.3 s, +34 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 52 (32 to 82) Hz; attack 78 (15 to 380) ms; decay -54 (-286 to -4) dB/s
  - brightness at the start 800 (186 to 2822) Hz; slope over the note 0.00 (-1.37 to 0.63) octaves
  - harmonic share 0.77 (0.47 to 1.00); partials off whole multiples 38 (10 to 116) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.4 (-11.3 to -0.5) dB; pan -0.01 (-0.07 to 0.01); left-right correlation 1.00 (0.91 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. Aphex Twin - Afx237 v.7: other group `other-1` (280 notes, 30% of the track's note energy)
- In synth terms: around A#3, mixed or noisy partials, soft attack, falls 43 dB/s, centered.
- Hear it at: 0:59.5 (?, 0.1 s, +32 dB alone), 0:51.5 (A2, 0.16 s, +35 dB alone), 3:47.4 (D#1, 0.89 s, +35 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 234 (49 to 530) Hz; attack 67 (20 to 295) ms; decay -43 (-177 to -3) dB/s
  - brightness at the start 1293 (702 to 2244) Hz; slope over the note -0.04 (-0.94 to 0.23) octaves
  - harmonic share 0.77 (0.16 to 0.99); partials off whole multiples 42 (16 to 225) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.2 (-6.7 to -0.6) dB; pan -0.02 (-0.15 to 0.12); left-right correlation 0.99 (0.84 to 1.00)
- Group quality: weak (silhouette 0.23, 4 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. Aphex Twin - Afx237 v.7: drums group `drums-1` (327 notes, 26% of the track's note energy)
- In synth terms: mid snap, quick attack, falls 55 dB/s, centered.
- Hear it at: 2:05.5 (C1, 0.18 s, +32 dB alone), 2:33.6 (?, 0.22 s, +26 dB alone), 2:34.7 (G#1, 0.21 s, +25 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 48 (34 to 93) Hz; attack 36 (12 to 114) ms; decay -55 (-107 to -17) dB/s
  - brightness at the start 947 (184 to 2850) Hz; slope over the note 0.00 (-1.63 to 2.24) octaves
  - harmonic share 0.79 (0.16 to 1.00); partials off whole multiples 99 (7 to 233) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-3.0 to -0.2) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S7. Aphex Twin - 54 Cymru Beats: drums group `drums-1` (328 notes, 22% of the track's note energy)
- In synth terms: low thump, soft attack, falls 81 dB/s, gets brighter over the note, centered.
- Hear it at: 0:22.5 (G#2, 0.1 s, +34 dB alone), 1:03.1 (?, 0.2 s, +31 dB alone), 0:18.8 (?, 0.18 s, +31 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 60 (34 to 85) Hz; attack 45 (19 to 80) ms; decay -81 (-188 to -43) dB/s
  - brightness at the start 282 (162 to 631) Hz; slope over the note 0.56 (-0.59 to 1.76) octaves
  - harmonic share 0.45 (0.05 to 0.92); partials off whole multiples 122 (56 to 232) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.7 (-3.9 to -0.0) dB; pan -0.01 (-0.02 to -0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. Aphex Twin - Orban Eq Trx 4: drums group `drums-1` (159 notes, 21% of the track's note energy)
- In synth terms: high tick, quick attack, falls 92 dB/s, centered.
- Hear it at: 0:32.6 (E1, 0.32 s, +43 dB alone), 0:21.9 (E1, 0.31 s, +43 dB alone), 1:04.6 (E1, 0.34 s, +40 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 141 (41 to 516) Hz; attack 23 (9 to 57) ms; decay -92 (-289 to -79) dB/s
  - brightness at the start 5484 (2591 to 7408) Hz; slope over the note -0.13 (-0.99 to 0.51) octaves
  - harmonic share 0.63 (0.26 to 0.95); partials off whole multiples 70 (8 to 196) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.8 (-10.3 to -0.1) dB; pan 0.05 (0.02 to 0.14); left-right correlation 0.98 (0.97 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Aphex Twin - Jynweythek sections:** 8 boundaries at 0:03.0, 0:22.0, 0:34.0, 0:49.0, 1:05.0, 1:19.0, 1:33.0, 2:09.0; section lengths median 15 s (range 3 to 36). Reliable for sections of 10 s or more.
- **Aphex Twin - Jynweythek stem entries and exits:** drums plays 30% of the time (in: 0:34.5, 0:58.5, 1:36.0, 1:45.0; out: 0:54.0, 1:11.0, 1:38.5, 1:53.5); bass plays 5% of the time (in: 1:23.5, 1:54.5; out: 1:28.5, 1:57.0); other plays 91% of the time (in: from the start; out: 2:12.0); vocals plays 0% of the time (in: from the start; out: never).
- **Aphex Twin - Jynweythek floor drops:** low end too sparse to say (on in under 75% of the track).
- **Aphex Twin - Jynweythek brightness sweeps (0.7 octave or more):** bass down 1.8 oct 0:08.5 to 0:17.5; bass down 0.8 oct 0:24.0 to 0:29.5; bass down 1.1 oct 0:32.5 to 0:38.5; bass up 1.2 oct 0:38.5 to 0:52.0; bass down 1.9 oct 0:57.0 to 1:06.5; bass up 1.5 oct 1:07.5 to 1:18.0; bass down 5.0 oct 1:18.0 to 1:25.5; bass up 4.2 oct 1:25.5 to 1:33.5 (3 more in techniques.json).
- **Aphex Twin - Jynweythek echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Aphex Twin - Jynweythek pumping locked to the kick:** bass dips 3.4 dB at the kick (peak 165 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **Aphex Twin - Jynweythek tape wobble and speed:** other wobbles about 7 cents at 1.2 Hz.
- **Aphex Twin - Jynweythek stereo movement:** other pan range 0.27.
- **Aphex Twin - Afx237 v.7 sections:** 13 boundaries at 0:27.0, 0:39.0, 0:49.0, 1:00.0, 1:22.0, 1:46.0, 2:08.0, 2:29.0, 2:52.0, 3:05.0, 3:25.0, 3:44.0; section lengths median 20 s (range 8 to 31). Reliable for sections of 10 s or more.
- **Aphex Twin - Afx237 v.7 stem entries and exits:** drums plays 77% of the time (in: 0:08.0, 0:23.5, 1:26.5; out: 0:11.0, 1:22.5, 3:47.5); bass plays 69% of the time (in: 0:16.5, 0:25.5, 0:59.5, 1:28.0, 1:59.5; out: 0:21.5, 0:49.5, 1:22.5, 1:46.0, 2:04.5); other plays 97% of the time (in: from the start; out: 4:16.0); vocals plays 22% of the time (in: 0:08.0, 0:25.5, 0:37.5, 0:48.0, 1:11.5; out: 0:23.0, 0:30.0, 0:45.0, 0:53.5, 1:15.0).
- **Aphex Twin - Afx237 v.7 floor drops (kick and bass out 2 s or more while the rest plays):** 2.03 a minute: 0:13.0 for 4.2 s, 0:20.8 for 3.8 s, 1:21.8 for 5.5 s, 3:46.5 for 6.8 s, 3:55.8 for 2.2 s, 3:59.0 for 2.8 s, 4:04.5 for 2.2 s, 4:06.8 for 2.8 s.
- **Aphex Twin - Afx237 v.7 brightness sweeps (0.7 octave or more):** mix down 2.0 oct 0:02.0 to 0:07.0; mix down 1.5 oct 0:31.0 to 0:36.0; mix down 0.8 oct 0:39.0 to 0:45.5; mix up 1.0 oct 0:46.0 to 0:52.5; mix down 1.5 oct 1:14.0 to 1:23.0; mix up 2.6 oct 1:34.0 to 1:40.0; mix down 2.0 oct 1:40.0 to 1:45.0; mix up 1.0 oct 1:45.0 to 1:51.0 (39 more in techniques.json).
- **Aphex Twin - Afx237 v.7 echo times:** drums: 339 ms (+7.7 dB, 3 later repeats).
- **Aphex Twin - Afx237 v.7 pumping locked to the kick:** other dips 2.0 dB at the kick (peak 155 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **Aphex Twin - Afx237 v.7 tape wobble and speed:** other wobbles about 5 cents at 0.8 Hz; bass wobbles about 5 cents at 0.3 Hz.
- **Aphex Twin - Afx237 v.7 stereo movement:** other pan range 0.70; vocals pan range 0.25.
- **Aphex Twin - Orban Eq Trx 4 sections:** 4 boundaries at 0:02.0, 1:00.0, 1:13.0, 1:27.0; section lengths median 13 s (range 2 to 58). Reliable for sections of 10 s or more.
- **Aphex Twin - Orban Eq Trx 4 stem entries and exits:** drums plays 91% of the time (in: from the start; out: 1:27.5); bass plays 92% of the time (in: from the start; out: 1:27.5); other plays 17% of the time (in: from the start; out: 0:16.0); vocals plays 7% of the time (in: 0:11.0, 0:55.0; out: 0:15.5, 0:57.5).
- **Aphex Twin - Orban Eq Trx 4 floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Aphex Twin - Orban Eq Trx 4 brightness sweeps (0.7 octave or more):** mix up 2.2 oct 0:00.0 to 0:06.5; mix down 4.4 oct 1:01.5 to 1:06.5; mix down 3.5 oct 1:24.5 to 1:30.5; other up 6.0 oct 0:08.5 to 0:22.0; other up 1.6 oct 0:48.5 to 0:53.5; other down 1.4 oct 1:08.0 to 1:14.0; other up 1.7 oct 1:20.5 to 1:27.5; bass up 1.3 oct 0:00.0 to 0:08.0.
- **Aphex Twin - Orban Eq Trx 4 echo times:** other: 693 ms (+4.8 dB, 2 later repeats).
- **Aphex Twin - Orban Eq Trx 4 pumping locked to the kick:** other dips 8.4 dB at the kick (peak 469 ms after, kick every 0.62 s); bass dips 21.1 dB at the kick (peak 499 ms after, kick every 0.62 s). The tool reads about 70% of the true depth, so this is a floor.
- **Aphex Twin - Orban Eq Trx 4 tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Aphex Twin - Orban Eq Trx 4 stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Aphex Twin - 54 Cymru Beats sections:** 17 boundaries at 0:04.0, 0:14.0, 0:59.0, 1:17.0, 1:38.0, 1:50.0, 2:20.0, 2:44.0, 3:01.0, 3:33.0, 3:57.0, 4:10.0; section lengths median 20 s (range 4 to 45). Reliable for sections of 10 s or more.
- **Aphex Twin - 54 Cymru Beats stem entries and exits:** drums plays 97% of the time (in: 0:03.0; out: 5:58.5); bass plays 59% of the time (in: 0:06.0, 0:49.0, 1:15.0, 1:50.0, 2:03.5; out: 0:13.0, 1:01.0, 1:40.0, 1:57.5, 2:15.5); other plays 96% of the time (in: 0:56.5; out: 0:53.5, 5:56.5); vocals plays 44% of the time (in: 0:14.0, 0:23.0, 0:50.5, 1:11.5, 1:37.5; out: 0:03.5, 0:18.0, 0:31.0, 0:53.5, 1:16.0).
- **Aphex Twin - 54 Cymru Beats floor drops (kick and bass out 2 s or more while the rest plays):** 0.18 a minute: 5:07.2 for 2.2 s.
- **Aphex Twin - 54 Cymru Beats brightness sweeps (0.7 octave or more):** mix down 2.1 oct 0:03.5 to 0:09.0; mix up 2.1 oct 0:09.0 to 0:19.5; mix up 1.7 oct 0:41.0 to 0:47.0; mix down 1.9 oct 0:47.0 to 0:53.0; mix up 1.7 oct 0:53.5 to 0:59.0; mix down 2.6 oct 1:43.5 to 1:53.0; mix up 2.5 oct 1:53.0 to 1:59.0; mix down 2.6 oct 2:07.5 to 2:14.0 (55 more in techniques.json).
- **Aphex Twin - 54 Cymru Beats echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Aphex Twin - 54 Cymru Beats pumping locked to the kick:** under 1.5 dB; none found.
- **Aphex Twin - 54 Cymru Beats tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Aphex Twin - 54 Cymru Beats stereo movement:** other pan range 0.33; vocals pan range 0.72.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Aphex Twin - Jynweythek meter:** about 120 BPM (could be 60 or 240; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim.
- **Aphex Twin - Jynweythek key and mode:** D# aeolian (minor) (key signature margin 0.036); pitch-class weights D# 0.20, G# 0.14, A# 0.12, B 0.10, F 0.09.
- **Aphex Twin - Jynweythek chords:** 40 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.4 s (10th to 90th percentile 0.5 to 2.5 s); 27 distinct chords; most time on G#min7 23%, D#sus2 12%, G#min 10%, D#5 10%. The old counter in this same run said 18; Ears 1's 2-s counter said 18.  78% of the changes land on a beat (chance would be 60%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin - Jynweythek top line (from the 'other' stem; read by ear before trusting):** 257 notes, range 14 semitones (10th to 90th percentile); steps 15%, thirds 9%, fourths and fifths 37%, leaps 30%, repeats 9%; median interval 5 semitones; 51% of moves go up; phrases of about 12 notes, arch 67%, rising 8%, falling 8%, flat or wavy 17%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin - Jynweythek repetition:** 143 bars of 1.0 s; strongest repeat distances 1 bars (0.37), 8 bars (0.33), 4 bars (0.28); 3% of bars near-duplicate an earlier bar.
- **Aphex Twin - Afx237 v.7 meter:** about 112 BPM (could be 56 or 224; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.08); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **Aphex Twin - Afx237 v.7 key and mode:** A# lydian (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights C 0.10, A 0.10, A# 0.09, G 0.09, F 0.09.
- **Aphex Twin - Afx237 v.7 chords:** 43 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.5 to 2.8 s); 54 distinct chords; most time on Fmaj7 10%, Gdim 9%, C#maj7 8%, Bmaj7 4%. The old counter in this same run said 10; Ears 1's 2-s counter said 5.  60% of the changes land on a beat (chance would be 56%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin - Afx237 v.7 bass:** root-note movement / mixed; 0.32 notes a second; most time on A# 0.43, C 0.18, G 0.12, A 0.05; steps 13%, thirds 11%, fourths and fifths 22%, octaves 1%, repeats 33%.
- **Aphex Twin - Afx237 v.7 top line (from the 'other' stem; read by ear before trusting):** 562 notes, range 31 semitones (10th to 90th percentile); steps 20%, thirds 14%, fourths and fifths 14%, leaps 42%, repeats 10%; median interval 6 semitones; 50% of moves go up; phrases of about 8 notes, arch 22%, rising 19%, falling 43%, flat or wavy 16%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin - Afx237 v.7 repetition:** 122 bars of 2.1 s; strongest repeat distances 1 bars (0.54), 8 bars (0.20), 16 bars (0.13); 2% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Aphex Twin - Orban Eq Trx 4 meter:** about 90 BPM (could be 45 or 180; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.13); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:4), which means irregular timing, not a cross-rhythm claim.
- **Aphex Twin - Orban Eq Trx 4 key and mode:** C# lydian (low confidence: the key signature margin is 0.014, so read this as a guess); fits C# major pentatonic; pitch-class weights C# 0.38, C 0.16, D 0.12, F 0.08, D# 0.06.
- **Aphex Twin - Orban Eq Trx 4 chords:** 10 changes a minute (1 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.6 to 2.9 s); 10 distinct chords; most time on C#maj7 83%, Gmaj7 6%, Dmaj7 2%, C#sus2 2%. The old counter in this same run said 3; Ears 1's 2-s counter said 1.  50% of the changes land on a beat (chance would be 45%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin - Orban Eq Trx 4 bass:** pedal (one note held or repeated); 0.82 notes a second; most time on C# 0.85, C 0.09, A# 0.03, F 0.01; steps 35%, thirds 1%, fourths and fifths 4%, octaves 3%, repeats 56%.
- **Aphex Twin - Orban Eq Trx 4 top line (from the 'other' stem; read by ear before trusting):** 206 notes, range 16 semitones (10th to 90th percentile); steps 24%, thirds 18%, fourths and fifths 20%, leaps 31%, repeats 7%; median interval 5 semitones; 50% of moves go up; phrases of about 5 notes, arch 35%, rising 20%, falling 40%, flat or wavy 5%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin - Orban Eq Trx 4 repetition:** 35 bars of 2.7 s; strongest repeat distances 4 bars (0.40), 12 bars (0.28), 2 bars (0.28); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Aphex Twin - 54 Cymru Beats meter:** about 112 BPM (could be 56 or 224; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.09); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **Aphex Twin - 54 Cymru Beats key and mode:** D locrian (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights D# 0.11, D 0.10, C 0.09, C# 0.09, E 0.09.
- **Aphex Twin - 54 Cymru Beats chords:** 31 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.7 to 3.7 s); 40 distinct chords; most time on C#maj7 18%, F#maj7 11%, G#maj7 9%, F7 7%. The old counter in this same run said 3; Ears 1's 2-s counter said 0.  55% of the changes land on a beat (chance would be 56%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Aphex Twin - 54 Cymru Beats bass:** root-note movement / mixed; 0.18 notes a second; most time on D 0.29, F 0.29, D# 0.28, G# 0.09; steps 47%, thirds 2%, fourths and fifths 2%, octaves 2%, repeats 32%.
- **Aphex Twin - 54 Cymru Beats top line (from the 'other' stem; read by ear before trusting):** 898 notes, range 25 semitones (10th to 90th percentile); steps 23%, thirds 14%, fourths and fifths 12%, leaps 39%, repeats 12%; median interval 5 semitones; 49% of moves go up; phrases of about 10 notes, arch 35%, rising 43%, falling 8%, flat or wavy 14%. Reliable only when the line sits clearly above its accompaniment.
- **Aphex Twin - 54 Cymru Beats repetition:** 342 bars of 1.1 s; strongest repeat distances 1 bars (0.52), 5 bars (0.46), 11 bars (0.32); 7% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Aphex Twin - Jynweythek mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.97); low_120_500 -6 (corr 0.62); mid_500_2k -2 (corr 0.21); pres_2k_5k -0 (corr 0.03); air_gt5k -0 (corr 0.01); over time (2-s windows) 10th/50th/90th percentile -7/-5/-2 dB.
- **Aphex Twin - Jynweythek by part:** drums: 0% of the power, width -3 dB, pan +0.06, mono loss 1.7 dB, widest in mid_500_2k (-1 dB); bass: 0% of the power, width -23 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-26 dB); other: 100% of the power, width -5 dB, pan +0.02, mono loss 1.2 dB, widest in mid_500_2k (-2 dB); vocals: 0% of the power, width -17 dB, pan -0.00, mono loss 0.1 dB, widest in mid_500_2k (-14 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Aphex Twin - Afx237 v.7 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -21 (corr 0.98); low_120_500 -15 (corr 0.94); mid_500_2k -14 (corr 0.93); pres_2k_5k -18 (corr 0.97); air_gt5k -21 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -28/-19/-6 dB.
- **Aphex Twin - Afx237 v.7 by part:** drums: 51% of the power, width -29 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-27 dB); bass: 10% of the power, width -23 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-22 dB); other: 38% of the power, width -12 dB, pan -0.08, mono loss 0.2 dB, widest in low_120_500 (-12 dB); vocals: 1% of the power, width -17 dB, pan -0.08, mono loss 0.1 dB, widest in mid_500_2k (-16 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Aphex Twin - Orban Eq Trx 4 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -30 (corr 1.00); low_120_500 -26 (corr 1.00); mid_500_2k -17 (corr 0.96); pres_2k_5k -16 (corr 0.98); air_gt5k -19 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -21/-20/-20 dB.
- **Aphex Twin - Orban Eq Trx 4 by part:** drums: 36% of the power, width -21 dB, pan +0.05, mono loss 0.0 dB, widest in air_gt5k (-19 dB); bass: 62% of the power, width -51 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-48 dB); other: 2% of the power, width -27 dB, pan +0.01, mono loss 0.0 dB, widest in low_120_500 (-24 dB); vocals: 0% of the power, width -37 dB, pan +0.00, mono loss 0.0 dB, widest in pres_2k_5k (-32 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Aphex Twin - 54 Cymru Beats mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -23 (corr 0.99); low_120_500 -18 (corr 0.97); mid_500_2k -19 (corr 0.98); pres_2k_5k -25 (corr 0.99); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -30/-24/-14 dB.
- **Aphex Twin - 54 Cymru Beats by part:** drums: 51% of the power, width -24 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-24 dB); bass: 17% of the power, width -29 dB, pan -0.04, mono loss 0.0 dB, widest in sub_lt120 (-30 dB); other: 28% of the power, width -20 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-17 dB); vocals: 5% of the power, width -11 dB, pan +0.09, mono loss 0.3 dB, widest in low_120_500 (-9 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Aphex Twin - Jynweythek: 120 BPM, 14 settled chords a minute, 1% of energy above 2 kHz, width -5 dB; Aphex Twin - Afx237 v.7: 112 BPM, 11 settled chords a minute, 26% of energy above 2 kHz, width -17 dB; Aphex Twin - Orban Eq Trx 4: 90 BPM, 1 settled chords a minute, 10% of energy above 2 kHz, width -26 dB; Aphex Twin - 54 Cymru Beats: 112 BPM, 15 settled chords a minute, 20% of energy above 2 kHz, width -21 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: Aphex Twin - Afx237 v.7: 26% of energy above 2 kHz (bright or harsh).

### For later
- Aphex Twin - Orban Eq Trx 4, drums group `drums-2` (85 notes): low thump, soft attack, falls 89 dB/s, gets brighter over the note, centered; hear it at 1:25.8, 0:53.8. **[JUDGMENT]** why it waits.
- Aphex Twin - 54 Cymru Beats, drums group `drums-2` (172 notes): mid snap, quick attack, falls 76 dB/s, centered; hear it at 1:02.5, 1:08.2. **[JUDGMENT]** why it waits.
- Aphex Twin - 54 Cymru Beats, bass group `bass-1` (439 notes): around F1, bell- or metal-like (partials off whole multiples), quick attack, falls 149 dB/s, centered; hear it at 2:45.3, 2:47.6. **[JUDGMENT]** why it waits.
- Aphex Twin - Afx237 v.7, drums group `drums-2` (173 notes): high tick, quick attack, falls 161 dB/s, centered; hear it at 2:05.9, 2:38.4. **[JUDGMENT]** why it waits.
- Aphex Twin - Afx237 v.7, other group `other-2` (164 notes): around A3, harmonic (string/reed/pad-like), soft attack, falls 54 dB/s, centered; hear it at 2:25.8, 2:25.7. **[JUDGMENT]** why it waits.
- Aphex Twin - Afx237 v.7, bass group `bass-1` (431 notes): around G1, bell- or metal-like (partials off whole multiples), quick attack, falls 120 dB/s, centered; hear it at 0:17.0, 0:26.1. **[JUDGMENT]** why it waits.
- Aphex Twin - Orban Eq Trx 4, bass group `bass-2` (27 notes): around C1, harmonic (string/reed/pad-like), quick attack, falls 7 dB/s, centered; hear it at 0:21.3, 0:45.4. **[JUDGMENT]** why it waits.
- Aphex Twin - 54 Cymru Beats, vocals group `vocals-1` (405 notes): around C3, bell- or metal-like (partials off whole multiples), soft attack, falls 69 dB/s, centered; hear it at 1:53.3, 1:50.4. **[JUDGMENT]** why it waits.
- **Aphex Twin - Lornaderek** (0:31.1, 118 BPM by the mix-level count): stands out for tail (dB a second) -32.50 (low, album median -3.50); repetition 0.08 (low, album median 0.45); pulse strength 0.10 (low, album median 0.59). Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin - Gwarek2** (6:46.9, 129 BPM by the mix-level count): stands out for brightness sweep (octaves) 5.21 (high, album median 0.98). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin - Father** (0:57.2, 65 BPM by the mix-level count): stands out for tail (dB a second) -13.80 (low, album median -3.50). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin - Gwely Mernans** (5:08.1, 162 BPM by the mix-level count): stands out for repetition 0.80 (high, album median 0.45). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin - Bbydhyonchord** (2:33.4, 123 BPM by the mix-level count): stands out for width (side/mid dB) -28.40 (low, album median -6.40). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin - Aussois** (0:13.1, 136 BPM by the mix-level count): no outstanding number. Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Aphex Twin - Bit 4** (0:25.4, 123 BPM by the mix-level count): no outstanding number. Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
