## 1996 - Girl_Boy EP (draft card from Ears 3 tools, 2026-10-24)

How it was made: 9 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: 01=03 Inkey$; 01=05 Beetles. Typical track: 01=03 Inkey$. Least like the rest: 01=05 Beetles, 01=01 Girl Boy (NLS mix).
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **01=03 Inkey$**: share of power drums 32%, bass 17%, other 49%, vocals 2%.
  - vocals stem holds 1.6%: bleed on an instrumental, not a voice.
  - meter tool 85 BPM is half of the drum-grid beat of 172.4 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **01=05 Beetles**: share of power drums 0%, bass 0%, other 100%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.3%: bleed on an instrumental, not a voice.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 85 to 92 BPM (octave-uncertain); keys C# ionian, G ionian; mix width -20 to -20 dB; chord changes 18 to 21 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 01=05 Beetles: other group `other-1` (310 notes, 99% of the track's note energy)
- In synth terms: around B2, harmonic (string/reed/pad-like), soft attack, falls 24 dB/s, centered.
- Hear it at: 0:46.9 (A2, 0.27 s, +55 dB alone), 0:05.2 (A2, 0.32 s, +55 dB alone), 0:47.1 (G2, 0.14 s, +56 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 126 (63 to 189) Hz; attack 41 (12 to 143) ms; decay -24 (-80 to -12) dB/s
  - brightness at the start 329 (237 to 526) Hz; slope over the note 0.00 (-0.34 to 0.33) octaves
  - harmonic share 0.95 (0.27 to 1.00); partials off whole multiples 16 (3 to 97) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.0 (-0.2 to -0.0) dB; pan -0.03 (-0.03 to -0.02); left-right correlation 0.99 (0.98 to 1.00)
- Group quality: weak (silhouette 0.18, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. 01=03 Inkey$: other group `other-1` (151 notes, 45% of the track's note energy)
- In synth terms: around C2, bell- or metal-like (partials off whole multiples), soft attack, falls 26 dB/s, centered.
- Hear it at: 1:16.6 (?, 2.31 s, +16 dB alone), 0:33.1 (D2, 0.29 s, +18 dB alone), 0:16.2 (C1, 0.24 s, +21 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 66 (34 to 117) Hz; attack 112 (23 to 446) ms; decay -26 (-143 to -2) dB/s
  - brightness at the start 418 (200 to 875) Hz; slope over the note 0.00 (-0.79 to 1.51) octaves
  - harmonic share 0.32 (0.07 to 0.80); partials off whole multiples 103 (38 to 199) cents
  - vibrato 0 (0 to 8) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.3 (-13.8 to -0.2) dB; pan 0.01 (0.00 to 0.03); left-right correlation 1.00 (0.98 to 1.00)
- Group quality: weak (silhouette 0.22, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. 01=03 Inkey$: drums group `drums-1` (294 notes, 22% of the track's note energy)
- In synth terms: high tick, quick attack, falls 78 dB/s, centered.
- Hear it at: 1:05.7 (B6, 0.38 s, +32 dB alone), 1:06.1 (B6, 0.37 s, +29 dB alone), 1:05.4 (B6, 0.34 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 618 (125 to 1957) Hz; attack 23 (7 to 148) ms; decay -78 (-372 to -8) dB/s
  - brightness at the start 4823 (2790 to 5486) Hz; slope over the note 0.00 (-0.27 to 0.24) octaves
  - harmonic share 0.34 (0.12 to 0.88); partials off whole multiples 71 (23 to 171) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -11.8 (-21.5 to -2.0) dB; pan 0.02 (-0.03 to 0.03); left-right correlation 1.00 (0.45 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **01=03 Inkey$ sections:** 5 boundaries at 0:02.0, 0:20.0, 0:33.0, 0:51.0, 1:15.0; section lengths median 16 s (range 2 to 24). Reliable for sections of 10 s or more.
- **01=03 Inkey$ stem entries and exits:** drums plays 89% of the time (in: from the start; out: 1:15.0); bass plays 52% of the time (in: 0:16.0, 0:50.0, 1:11.5; out: 0:41.5, 1:06.0, 1:14.0); other plays 94% of the time (in: from the start; out: 1:19.5); vocals plays 13% of the time (in: 0:29.5, 0:38.0, 1:14.5; out: 0:32.0, 0:42.0, 1:19.0).
- **01=03 Inkey$ floor drops (kick and bass out 2 s or more while the rest plays):** 0.80 a minute: 1:14.5 for 4.2 s.
- **01=03 Inkey$ brightness sweeps (0.7 octave or more):** mix up 1.7 oct 0:03.0 to 0:12.0; mix down 4.3 oct 0:12.0 to 0:19.5; mix up 3.5 oct 0:19.5 to 0:28.5; mix down 2.7 oct 0:28.5 to 0:34.5; mix up 3.5 oct 0:34.5 to 0:45.0; mix down 4.9 oct 0:45.0 to 0:53.0; mix up 1.9 oct 0:53.0 to 1:00.0; mix up 2.9 oct 1:03.0 to 1:08.0 (14 more in techniques.json).
- **01=03 Inkey$ echo times:** drums: 354 ms (+10.8 dB, 3 later repeats).
- **01=03 Inkey$ pumping locked to the kick:** bass dips 1.7 dB at the kick (peak 279 ms after, kick every 0.36 s). The tool reads about 70% of the true depth, so this is a floor.
- **01=03 Inkey$ tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **01=03 Inkey$ stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **01=05 Beetles sections:** 5 boundaries at 0:02.0, 0:21.0, 0:43.0, 1:03.0, 1:25.0; section lengths median 20 s (range 2 to 22). Reliable for sections of 10 s or more.
- **01=05 Beetles stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 23% of the time (in: 0:25.0, 1:07.0, 1:17.5; out: 0:30.5, 1:14.0, 1:26.0); other plays 93% of the time (in: from the start; out: 1:25.0); vocals plays 47% of the time (in: 0:20.5, 1:02.5; out: 0:42.0, 1:24.0).
- **01=05 Beetles floor drops:** low end too sparse to say (on in under 75% of the track).
- **01=05 Beetles brightness sweeps (0.7 octave or more):** mix up 0.7 oct 0:00.0 to 0:05.5; mix up 2.1 oct 1:20.5 to 1:27.5; other up 0.7 oct 0:00.0 to 0:05.5; other up 2.1 oct 1:20.5 to 1:27.5; bass down 0.9 oct 1:22.0 to 1:29.0.
- **01=05 Beetles echo times:** drums: 494 ms (+4.2 dB, 2 later repeats).
- **01=05 Beetles pumping locked to the kick:** other dips 4.6 dB at the kick (peak 544 ms after, kick every 0.59 s); bass dips 2.3 dB at the kick (peak 539 ms after, kick every 0.59 s). The tool reads about 70% of the true depth, so this is a floor.
- **01=05 Beetles tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **01=05 Beetles stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **01=03 Inkey$ meter:** about 85 BPM (could be 43 or 170; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.09); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **01=03 Inkey$ key and mode:** C# ionian (major) (low confidence: the key signature margin is 0.012, so read this as a guess); pitch-class weights C# 0.18, C 0.14, B 0.10, D 0.10, A# 0.08.
- **01=03 Inkey$ chords:** 21 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 1.0 to 5.9 s); 15 distinct chords; most time on Cmaj7 25%, C#maj7 24%, F#5 18%, Fmaj7 7%. The old counter in this same run said 9; Ears 1's 2-s counter said 8.  70% of the changes land on a beat (chance would be 43%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **01=03 Inkey$ bass:** pedal (one note held or repeated); 0.39 notes a second; most time on C# 0.75, D 0.11, C 0.07, A 0.04; steps 12%, thirds 0%, fourths and fifths 3%, octaves 0%, repeats 81%.
- **01=03 Inkey$ top line (from the 'other' stem; read by ear before trusting):** 211 notes, range 25 semitones (10th to 90th percentile); steps 16%, thirds 19%, fourths and fifths 17%, leaps 30%, repeats 18%; median interval 4 semitones; 52% of moves go up; phrases of about 12 notes, arch 42%, rising 25%, falling 25%, flat or wavy 8%. Reliable only when the line sits clearly above its accompaniment.
- **01=03 Inkey$ repetition:** 59 bars of 1.4 s; strongest repeat distances 1 bars (0.42), 12 bars (0.38), 24 bars (0.26); 12% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **01=05 Beetles meter:** about 92 BPM (could be 46 or 184; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.22); straight eighths; no cross-rhythm claim; many unrelated periodicities found (5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **01=05 Beetles key and mode:** G ionian (major) (key signature margin 0.022); pitch-class weights G 0.13, B 0.10, C 0.10, A# 0.10, F# 0.10.
- **01=05 Beetles chords:** 18 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 3.9 s (10th to 90th percentile 0.9 to 5.2 s); 10 distinct chords; most time on Bmaj7 23%, D#maj7 22%, B5 19%, C5 17%. The old counter in this same run said 17; Ears 1's 2-s counter said 16.  67% of the changes land on a beat (chance would be 46%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **01=05 Beetles bass:** root-note movement / mixed; 0.37 notes a second; most time on F# 0.26, G 0.22, B 0.20, F 0.18; steps 24%, thirds 9%, fourths and fifths 9%, octaves 6%, repeats 18%.
- **01=05 Beetles top line (from the 'other' stem; read by ear before trusting):** 182 notes, range 11 semitones (10th to 90th percentile); steps 10%, thirds 26%, fourths and fifths 27%, leaps 19%, repeats 18%; median interval 4 semitones; 48% of moves go up; phrases of about 10 notes, arch 45%, rising 27%, falling 9%, flat or wavy 18%. Reliable only when the line sits clearly above its accompaniment.
- **01=05 Beetles repetition:** 17 bars of 5.2 s; strongest repeat distances 8 bars (0.82), 2 bars (0.40), 6 bars (0.23); 38% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **01=03 Inkey$ mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -26 (corr 1.00); low_120_500 -21 (corr 0.99); mid_500_2k -17 (corr 0.96); pres_2k_5k -15 (corr 0.94); air_gt5k -20 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -31/-30/-7 dB.
- **01=03 Inkey$ by part:** drums: 31% of the power, width -19 dB, pan +0.03, mono loss 0.1 dB, widest in pres_2k_5k (-15 dB); bass: 17% of the power, width -27 dB, pan +0.05, mono loss 0.0 dB, widest in sub_lt120 (-27 dB); other: 50% of the power, width -19 dB, pan +0.02, mono loss 0.1 dB, widest in mid_500_2k (-16 dB); vocals: 2% of the power, width -36 dB, pan +0.01, mono loss 0.0 dB, widest in mid_500_2k (-37 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **01=05 Beetles mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -27 (corr 1.00); low_120_500 -24 (corr 0.99); mid_500_2k -16 (corr 0.96); pres_2k_5k -5 (corr 0.51); air_gt5k 5 (corr -0.56); over time (2-s windows) 10th/50th/90th percentile -22/-21/-16 dB.
- **01=05 Beetles by part:** drums: 0% of the power, width -24 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-26 dB); bass: 0% of the power, width -44 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-44 dB); other: 100% of the power, width -21 dB, pan -0.05, mono loss 0.0 dB, widest in mid_500_2k (-16 dB); vocals: 0% of the power, width -8 dB, pan -0.05, mono loss 0.6 dB, widest in pres_2k_5k (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 01=03 Inkey$: 85 BPM, 14 settled chords a minute, 21% of energy above 2 kHz, width -20 dB; 01=05 Beetles: 92 BPM, 13 settled chords a minute, 1% of energy above 2 kHz, width -20 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- 01=03 Inkey$, bass group `bass-1` (132 notes): around C2, bell- or metal-like (partials off whole multiples), soft attack, falls 34 dB/s, centered; hear it at 1:12.1, 0:37.3. **[JUDGMENT]** why it waits.
- 01=03 Inkey$, other group `other-2` (37 notes): around C2, bell- or metal-like (partials off whole multiples), soft attack, falls 36 dB/s, centered; hear it at 0:00.0, 0:00.1. **[JUDGMENT]** why it waits.
- 01=03 Inkey$, drums group `drums-2` (42 notes): low thump, soft attack, falls 29 dB/s, centered; hear it at 0:51.2, 0:51.6. **[JUDGMENT]** why it waits.
- **01=09 growth inst. [blonder]+6,ru** (2:37.8, 112 BPM by the mix-level count): stands out for repetition 0.79 (high, album median 0.40); pulse strength 0.68 (high, album median 0.44). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **01=01 Girl Boy (NLS mix)** (4:52.2, 112 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 21.80 (high, album median 4.90). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **01=04 Girl Boy (£18 Snarerush mix)** (1:57.6, 86 BPM by the mix-level count): stands out for width (side/mid dB) -0.90 (high, album median -20.10). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **01=06 Girl Boy (Redruth mix)** (1:40.9, 108 BPM by the mix-level count): stands out for tail (dB a second) -23.50 (low, album median -4.90). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
