## 1996 - Richard D. James Album (draft card from Ears 3 tools, 2026-10-24)

How it was made: 10 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: - Logon Rock Witch; - Peek 824545201; - Yellow Calx; - Girl_Boy Song. Typical track: - Logon Rock Witch. Least like the rest: - Peek 824545201, - Yellow Calx.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- Logon Rock Witch**: share of power drums 40%, bass 1%, other 59%, vocals 0%.
  - bass stem is near empty (0.7%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.1%: bleed on an instrumental, not a voice.
  - meter tool 132 BPM agrees with the drum-grid beat of 132.5 BPM.
- **- Peek 824545201**: share of power drums 44%, bass 7%, other 49%, vocals 0%.
  - vocals stem holds 0.3%: bleed on an instrumental, not a voice.
  - meter tool 85 BPM is half of the drum-grid beat of 172.4 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Yellow Calx**: share of power drums 55%, bass 6%, other 36%, vocals 3%.
  - vocals stem holds 2.9%: bleed on an instrumental, not a voice.
  - meter tool 83 BPM is half of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Girl_Boy Song**: share of power drums 8%, bass 71%, other 19%, vocals 2%.
  - vocals stem holds 2.2%: bleed on an instrumental, not a voice.
  - meter tool 113 BPM is two thirds of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 83 to 132 BPM (octave-uncertain); keys E phrygian, G mixolydian, B aeolian, G lydian; mix width -30 to -0 dB; chord changes 25 to 43 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Peek 824545201: other group `other-1` (421 notes, 46% of the track's note energy)
- In synth terms: around D2, bell- or metal-like (partials off whole multiples), soft attack, falls 18 dB/s, centered.
- Hear it at: 2:38.6 (?, 0.48 s, +57 dB alone), 2:41.8 (D2, 0.49 s, +54 dB alone), 2:38.6 (F3, 0.19 s, +57 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 73 (43 to 174) Hz; attack 148 (33 to 459) ms; decay -18 (-103 to 1) dB/s
  - brightness at the start 498 (279 to 1611) Hz; slope over the note 0.00 (-0.75 to 0.16) octaves
  - harmonic share 0.51 (0.18 to 0.80); partials off whole multiples 60 (28 to 137) cents
  - vibrato 0 (0 to 4) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.8 (-16.7 to -0.2) dB; pan 0.02 (0.01 to 0.03); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. - Logon Rock Witch: other group `other-1` (418 notes, 46% of the track's note energy)
- In synth terms: around A1, mixed or noisy partials, soft attack, falls 15 dB/s, centered.
- Hear it at: 2:55.6 (F2, 0.88 s, +51 dB alone), 2:41.3 (C1, 1.03 s, +50 dB alone), 1:42.7 (F1, 1.03 s, +51 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (41 to 110) Hz; attack 110 (26 to 300) ms; decay -15 (-72 to -0) dB/s
  - brightness at the start 964 (625 to 1388) Hz; slope over the note 0.00 (-0.36 to 0.55) octaves
  - harmonic share 0.69 (0.31 to 0.99); partials off whole multiples 40 (9 to 101) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.0 (-7.2 to -3.0) dB; pan 0.10 (-0.00 to 0.20); left-right correlation 0.09 (-0.17 to 0.34)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. - Yellow Calx: other group `other-1` (332 notes, 32% of the track's note energy)
- In synth terms: around E2, bell- or metal-like (partials off whole multiples), soft attack, falls 5 dB/s, centered.
- Hear it at: 1:24.8 (F#2, 0.29 s, +38 dB alone), 1:25.5 (F#2, 0.29 s, +38 dB alone), 1:25.1 (F#2, 0.38 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 81 (54 to 92) Hz; attack 94 (17 to 357) ms; decay -5 (-17 to 3) dB/s
  - brightness at the start 344 (221 to 442) Hz; slope over the note 0.00 (-0.17 to 0.18) octaves
  - harmonic share 0.69 (0.18 to 0.98); partials off whole multiples 60 (6 to 141) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.8 (-9.5 to -1.6) dB; pan -0.01 (-0.14 to 0.03); left-right correlation 0.99 (0.96 to 1.00)
- Group quality: weak (silhouette 0.24, 4 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. - Yellow Calx: drums group `drums-1` (330 notes, 28% of the track's note energy)
- In synth terms: high tick, quick attack, falls 92 dB/s, centered.
- Hear it at: 0:51.3 (F4, 0.28 s, +12 dB alone), 0:51.2 (F4, 0.3 s, +11 dB alone), 2:00.4 (G5, 0.92 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 346 (43 to 1361) Hz; attack 16 (6 to 186) ms; decay -92 (-360 to -7) dB/s
  - brightness at the start 4128 (2466 to 6557) Hz; slope over the note 0.00 (-0.83 to 0.16) octaves
  - harmonic share 0.46 (0.10 to 0.91); partials off whole multiples 62 (20 to 145) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.7 (-3.1 to -0.5) dB; pan 0.00 (-0.00 to 0.04); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. - Girl_Boy Song: other group `other-1` (445 notes, 23% of the track's note energy)
- In synth terms: around C#3, bell- or metal-like (partials off whole multiples), soft attack, falls 25 dB/s, centered.
- Hear it at: 4:27.5 (C4, 1.22 s, +38 dB alone), 4:30.2 (E4, 0.74 s, +36 dB alone), 4:30.2 (G#2, 1.41 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 138 (111 to 324) Hz; attack 118 (36 to 407) ms; decay -25 (-109 to -2) dB/s
  - brightness at the start 395 (165 to 979) Hz; slope over the note 0.00 (-0.57 to 0.59) octaves
  - harmonic share 0.64 (0.10 to 0.96); partials off whole multiples 67 (16 to 167) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -8.3 (-14.9 to -0.7) dB; pan -0.00 (-0.07 to 0.08); left-right correlation 0.86 (0.43 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. - Logon Rock Witch: drums group `drums-1` (249 notes, 21% of the track's note energy)
- In synth terms: low thump, soft attack, falls 32 dB/s, centered.
- Hear it at: 0:05.8 (A#1, 0.25 s, +9 dB alone), 0:13.1 (A#1, 0.21 s, +8 dB alone), 3:14.9 (A#1, 0.22 s, +4 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 57 (46 to 61) Hz; attack 48 (23 to 104) ms; decay -32 (-58 to -6) dB/s
  - brightness at the start 148 (76 to 242) Hz; slope over the note 0.00 (-0.94 to 2.50) octaves
  - harmonic share 0.79 (0.05 to 0.98); partials off whole multiples 82 (22 to 176) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.8 (-8.2 to -4.5) dB; pan -0.07 (-0.30 to 0.05); left-right correlation 0.05 (-0.06 to 0.21)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S7. - Peek 824545201: drums group `drums-1` (235 notes, 20% of the track's note energy)
- In synth terms: low thump, quick attack, falls 73 dB/s, gets darker over the note, centered.
- Hear it at: 2:57.6 (?, 0.12 s, +38 dB alone), 2:56.0 (?, 0.43 s, +26 dB alone), 0:18.8 (G1, 0.23 s, +24 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 50 (49 to 50) Hz; attack 28 (11 to 89) ms; decay -73 (-109 to -23) dB/s
  - brightness at the start 330 (268 to 559) Hz; slope over the note -0.32 (-1.39 to 1.17) octaves
  - harmonic share 0.76 (0.50 to 0.97); partials off whole multiples 106 (75 to 138) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.7 (-5.1 to -0.2) dB; pan 0.02 (0.01 to 0.03); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. - Girl_Boy Song: bass group `bass-1` (112 notes, 15% of the track's note energy)
- In synth terms: around D3, harmonic (string/reed/pad-like), soft attack, falls 52 dB/s, centered.
- Hear it at: 0:19.6 (D3, 0.37 s, +22 dB alone), 0:18.9 (D3, 0.36 s, +22 dB alone), 0:18.2 (B2, 0.39 s, +20 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 144 (128 to 145) Hz; attack 99 (79 to 399) ms; decay -52 (-118 to -36) dB/s
  - brightness at the start 145 (134 to 152) Hz; slope over the note 0.00 (-0.02 to 0.05) octaves
  - harmonic share 0.99 (0.93 to 0.99); partials off whole multiples 36 (24 to 87) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.6 (-2.5 to -0.2) dB; pan 0.03 (-0.00 to 0.06); left-right correlation 0.99 (0.97 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- Logon Rock Witch sections:** 8 boundaries at 0:02.0, 0:32.0, 1:28.0, 1:51.0, 2:07.0, 2:33.0, 3:02.0, 3:26.0; section lengths median 24 s (range 2 to 56). Reliable for sections of 10 s or more.
- **- Logon Rock Witch stem entries and exits:** drums plays 82% of the time (in: 1:30.5, 1:48.5, 2:45.0, 3:01.0; out: 1:28.0, 1:37.0, 2:33.5, 2:55.0, 3:27.5); bass plays 25% of the time (in: 0:13.5, 0:23.5, 0:34.5, 1:04.0, 2:02.0; out: 0:19.5, 0:31.0, 0:49.0, 1:11.0, 2:11.0); other plays 97% of the time (in: from the start; out: 3:27.5); vocals plays 11% of the time (in: 0:52.5, 1:05.0, 1:57.5, 2:27.0, 2:43.0; out: 0:55.5, 1:10.0, 2:00.0, 2:30.5, 2:49.5).
- **- Logon Rock Witch floor drops (kick and bass out 2 s or more while the rest plays):** 1.88 a minute: 1:27.2 for 3.8 s, 1:33.0 for 2.0 s, 1:36.2 for 12.8 s, 2:32.8 for 12.8 s, 2:47.8 for 2.8 s, 2:54.0 for 7.8 s.
- **- Logon Rock Witch brightness sweeps (0.7 octave or more):** mix down 0.9 oct 0:32.5 to 0:40.5; mix up 2.0 oct 1:48.5 to 1:55.0; mix down 2.3 oct 1:55.0 to 2:00.0; mix up 1.1 oct 3:03.5 to 3:12.5; mix down 1.1 oct 3:13.0 to 3:18.5; other down 1.6 oct 1:24.0 to 1:29.5; other up 2.2 oct 1:49.0 to 1:54.5; other up 1.5 oct 3:03.5 to 3:08.5 (17 more in techniques.json).
- **- Logon Rock Witch echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Logon Rock Witch pumping locked to the kick:** bass dips 3.1 dB at the kick (peak 190 ms after, kick every 0.32 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Logon Rock Witch tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Logon Rock Witch stereo movement:** drums pan range 0.26; other pan range 0.30; vocals pan range 0.32.
- **- Peek 824545201 sections:** 8 boundaries at 0:10.0, 0:42.0, 0:53.0, 1:18.0, 1:34.0, 1:46.0, 2:37.0, 2:50.0; section lengths median 13 s (range 10 to 51). Reliable for sections of 10 s or more.
- **- Peek 824545201 stem entries and exits:** drums plays 89% of the time (in: 0:08.0, 2:48.5; out: 2:38.5, 3:00.0); bass plays 88% of the time (in: 0:11.5, 1:52.0; out: 1:46.0, 2:57.5); other plays 94% of the time (in: 0:28.5; out: 0:26.0, 2:54.0); vocals plays 11% of the time (in: 0:08.0, 1:33.5, 2:49.0; out: 0:19.5, 1:39.0, 2:52.5).
- **- Peek 824545201 floor drops (kick and bass out 2 s or more while the rest plays):** 0.37 a minute: 2:39.8 for 5.2 s.
- **- Peek 824545201 brightness sweeps (0.7 octave or more):** mix up 2.0 oct 0:15.5 to 0:24.5; mix down 2.8 oct 0:38.5 to 0:53.5; mix down 1.2 oct 1:00.0 to 1:05.0; mix up 1.5 oct 1:05.5 to 1:10.5; mix up 2.2 oct 1:14.5 to 1:19.5; mix up 1.7 oct 1:24.0 to 1:32.0; mix down 2.6 oct 1:36.0 to 1:47.0; mix up 1.3 oct 2:01.5 to 2:08.5 (30 more in techniques.json).
- **- Peek 824545201 echo times:** drums: 180 ms (+5.6 dB, 5 later repeats).
- **- Peek 824545201 pumping locked to the kick:** bass dips 2.0 dB at the kick (peak 429 ms after, kick every 0.52 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Peek 824545201 tape wobble and speed:** bass wobbles about 10 cents at 8.0 Hz.
- **- Peek 824545201 stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Peek 824545201 builds:** 0:00.0 to 0:28.0.
- **- Yellow Calx sections:** 8 boundaries at 0:02.0, 0:13.0, 0:23.0, 0:49.0, 1:20.0, 1:46.0, 2:05.0, 2:31.0; section lengths median 26 s (range 2 to 31). Reliable for sections of 10 s or more.
- **- Yellow Calx stem entries and exits:** drums plays 96% of the time (in: from the start; out: 2:55.0); bass plays 78% of the time (in: 0:57.5, 1:04.0, 1:27.5, 1:52.0, 2:02.5; out: 0:55.0, 1:00.5, 1:24.0, 1:41.5, 2:00.0); other plays 97% of the time (in: from the start; out: 2:56.5); vocals plays 29% of the time (in: 0:22.0, 0:51.5, 0:57.5, 1:26.5, 1:38.5; out: 0:25.5, 0:55.0, 1:01.0, 1:32.5, 1:45.0).
- **- Yellow Calx floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Yellow Calx brightness sweeps (0.7 octave or more):** mix up 3.3 oct 0:09.0 to 0:15.5; mix up 3.3 oct 0:19.0 to 0:26.5; mix down 0.8 oct 0:34.0 to 0:39.5; mix up 2.4 oct 0:48.5 to 0:58.0; mix down 2.5 oct 1:11.5 to 1:23.5; mix down 1.3 oct 1:28.0 to 1:34.5; mix up 2.4 oct 1:34.5 to 1:39.5; mix down 2.5 oct 2:14.5 to 2:19.5 (20 more in techniques.json).
- **- Yellow Calx echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Yellow Calx pumping locked to the kick:** under 1.5 dB; none found.
- **- Yellow Calx tape wobble and speed:** other speed moves up to 10 cents in 4 s.
- **- Yellow Calx stereo movement:** drums pan range 0.11, cycling every 49 s; other pan range 0.18, cycling every 49 s.
- **- Yellow Calx builds:** 0:00.0 to 0:25.0.
- **- Girl_Boy Song sections:** 11 boundaries at 0:23.0, 0:50.0, 1:12.0, 1:36.0, 1:57.0, 2:17.0, 2:44.0, 3:04.0, 3:26.0, 4:02.0, 4:26.0; section lengths median 23 s (range 20 to 36). Reliable for sections of 10 s or more.
- **- Girl_Boy Song stem entries and exits:** drums plays 63% of the time (in: 0:21.0, 2:41.5, 4:01.0; out: 2:31.5, 3:05.5, 4:27.5); bass plays 82% of the time (in: 0:09.5, 0:28.5, 0:56.5, 2:14.5; out: 0:06.5, 0:25.5, 0:49.0, 1:59.0, 4:25.5); other plays 96% of the time (in: from the start; out: 4:37.5); vocals plays 22% of the time (in: 0:52.5, 2:02.5, 2:08.0, 2:44.0, 4:03.0; out: 1:01.5, 2:05.5, 2:21.5, 3:05.0, 4:07.5).
- **- Girl_Boy Song floor drops (kick and bass out 2 s or more while the rest plays):** 0.46 a minute: 0:24.8 for 4.8 s, 4:26.0 for 8.8 s.
- **- Girl_Boy Song brightness sweeps (0.7 octave or more):** mix down 2.4 oct 0:04.0 to 0:16.5; mix up 1.7 oct 0:21.5 to 0:28.5; mix up 1.6 oct 0:45.5 to 0:53.5; mix down 1.4 oct 0:54.0 to 0:59.0; mix up 1.7 oct 0:59.0 to 1:06.0; mix up 1.2 oct 1:15.0 to 1:20.5; mix down 2.5 oct 1:32.5 to 1:38.5; mix up 2.4 oct 1:51.0 to 1:59.5 (40 more in techniques.json).
- **- Girl_Boy Song echo times:** drums: 354 ms (+8.7 dB, 3 later repeats).
- **- Girl_Boy Song pumping locked to the kick:** under 1.5 dB; none found.
- **- Girl_Boy Song tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Girl_Boy Song stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Girl_Boy Song builds:** 0:08.0 to 0:34.0; 2:49.0 to 3:13.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Logon Rock Witch meter:** about 132 BPM (could be 66 or 264; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim.
- **- Logon Rock Witch key and mode:** E phrygian (key signature margin 0.026); pitch-class weights E 0.19, A 0.12, G 0.11, C 0.09, G# 0.09.
- **- Logon Rock Witch chords:** 43 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.5 to 3.7 s); 24 distinct chords; most time on C 18%, Emin 17%, A5 16%, C#min 11%. The old counter in this same run said 22; Ears 1's 2-s counter said 10.  75% of the changes land on a beat (chance would be 66%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Logon Rock Witch top line (from the 'other' stem; read by ear before trusting):** 351 notes, range 21 semitones (10th to 90th percentile); steps 22%, thirds 7%, fourths and fifths 3%, leaps 50%, repeats 19%; median interval 8 semitones; 43% of moves go up; phrases of about 11 notes, arch 55%, rising 14%, falling 10%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **- Logon Rock Witch repetition:** 235 bars of 0.9 s; strongest repeat distances 8 bars (0.54), 16 bars (0.52), 1 bars (0.40); 13% of bars near-duplicate an earlier bar.
- **- Peek 824545201 meter:** about 85 BPM (could be 42 or 170; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.05); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Peek 824545201 key and mode:** G mixolydian (key signature margin 0.043); pitch-class weights C 0.13, F 0.12, A 0.12, D 0.10, B 0.09.
- **- Peek 824545201 chords:** 33 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 1.6 s (10th to 90th percentile 0.6 to 3.1 s); 34 distinct chords; most time on Fmaj7 20%, Dmin7 14%, Csus2 8%, C#maj7 7%. The old counter in this same run said 15; Ears 1's 2-s counter said 3.  41% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Peek 824545201 bass:** root-note movement / mixed; 0.12 notes a second; most time on G 0.66, G# 0.19, C# 0.05, E 0.05; steps 30%, thirds 0%, fourths and fifths 5%, octaves 15%, repeats 40%.
- **- Peek 824545201 top line (from the 'other' stem; read by ear before trusting):** 373 notes, range 15 semitones (10th to 90th percentile); steps 21%, thirds 23%, fourths and fifths 18%, leaps 17%, repeats 21%; median interval 3 semitones; 51% of moves go up; phrases of about 120 notes, arch 0%, rising 33%, falling 33%, flat or wavy 33%. Reliable only when the line sits clearly above its accompaniment.
- **- Peek 824545201 repetition:** 64 bars of 2.8 s; strongest repeat distances 1 bars (0.44), 4 bars (0.42), 20 bars (0.18); 16% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Yellow Calx meter:** about 83 BPM (could be 42 or 167; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.04); swung: off-beat at 0.75 of the beat; no cross-rhythm claim.
- **- Yellow Calx key and mode:** B aeolian (minor) (low confidence: the key signature margin is 0.003, so read this as a guess); fits B minor pentatonic; pitch-class weights E 0.23, B 0.15, A 0.13, F# 0.12, D 0.11.
- **- Yellow Calx chords:** 35 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.4 s (10th to 90th percentile 0.7 to 2.9 s); 25 distinct chords; most time on E5 25%, A5 10%, D5 9%, Bmin 9%. The old counter in this same run said 21; Ears 1's 2-s counter said 14.  53% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Yellow Calx bass:** root-note movement / mixed; 0.33 notes a second; most time on B 0.33, A 0.27, E 0.18, F# 0.15; steps 28%, thirds 3%, fourths and fifths 20%, octaves 0%, repeats 43%.
- **- Yellow Calx top line (from the 'other' stem; read by ear before trusting):** 239 notes, range 7 semitones (10th to 90th percentile); steps 34%, thirds 3%, fourths and fifths 32%, leaps 4%, repeats 28%; median interval 2 semitones; 52% of moves go up; phrases of about 16 notes, arch 0%, rising 22%, falling 33%, flat or wavy 44%. Reliable only when the line sits clearly above its accompaniment.
- **- Yellow Calx repetition:** 28 bars of 6.5 s; strongest repeat distances 1 bars (0.46), 12 bars (-0.13); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Girl_Boy Song meter:** about 113 BPM (could be 56 or 225; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.07); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Girl_Boy Song key and mode:** G lydian (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights D 0.15, G 0.13, C# 0.11, C 0.11, B 0.08.
- **- Girl_Boy Song chords:** 25 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 2.6 s (10th to 90th percentile 1.3 to 3.4 s); 28 distinct chords; most time on Dmaj7 17%, G5 15%, C5 10%, Cmaj7 9%. The old counter in this same run said 23; Ears 1's 2-s counter said 21.  52% of the changes land on a beat (chance would be 56%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Girl_Boy Song bass:** root-note movement / mixed; 1.38 notes a second; most time on D 0.30, G 0.30, C 0.23, B 0.13; steps 7%, thirds 7%, fourths and fifths 8%, octaves 1%, repeats 75%.
- **- Girl_Boy Song top line (from the 'other' stem; read by ear before trusting):** 447 notes, range 14 semitones (10th to 90th percentile); steps 15%, thirds 16%, fourths and fifths 18%, leaps 28%, repeats 22%; median interval 4 semitones; 50% of moves go up; phrases of about 7 notes, arch 24%, rising 33%, falling 24%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **- Girl_Boy Song repetition:** 271 bars of 1.1 s; strongest repeat distances 1 bars (0.63), 11 bars (0.41), 21 bars (0.19); 5% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Logon Rock Witch mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub 1 (corr -0.07); low_120_500 -1 (corr 0.17); mid_500_2k -1 (corr 0.06); pres_2k_5k 2 (corr -0.23); air_gt5k -2 (corr 0.20); over time (2-s windows) 10th/50th/90th percentile -2/-1/1 dB.
- **- Logon Rock Witch by part:** drums: 40% of the power, width -1 dB, pan -0.13, mono loss 2.8 dB, widest in sub_lt120 (-0 dB); bass: 1% of the power, width -3 dB, pan -0.15, mono loss 1.7 dB, widest in sub_lt120 (-3 dB); other: 60% of the power, width -1 dB, pan +0.21, mono loss 2.8 dB, widest in sub_lt120 (4 dB); vocals: 0% of the power, width -2 dB, pan -0.05, mono loss 2.0 dB, widest in low_120_500 (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Peek 824545201 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -29 (corr 1.00); low_120_500 -30 (corr 1.00); mid_500_2k -33 (corr 1.00); pres_2k_5k -31 (corr 1.00); air_gt5k -31 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -32/-30/-29 dB.
- **- Peek 824545201 by part:** drums: 43% of the power, width -30 dB, pan +0.04, mono loss 0.0 dB, widest in sub_lt120 (-28 dB); bass: 7% of the power, width -34 dB, pan +0.03, mono loss 0.0 dB, widest in low_120_500 (-33 dB); other: 49% of the power, width -32 dB, pan +0.03, mono loss 0.0 dB, widest in low_120_500 (-31 dB); vocals: 0% of the power, width -34 dB, pan +0.02, mono loss 0.0 dB, widest in pres_2k_5k (-34 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Yellow Calx mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -21 (corr 0.98); low_120_500 -20 (corr 0.98); mid_500_2k -21 (corr 0.98); pres_2k_5k -27 (corr 1.00); air_gt5k -28 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -26/-22/-19 dB.
- **- Yellow Calx by part:** drums: 54% of the power, width -28 dB, pan +0.01, mono loss 0.0 dB, widest in pres_2k_5k (-27 dB); bass: 6% of the power, width -18 dB, pan -0.05, mono loss 0.1 dB, widest in low_120_500 (-17 dB); other: 36% of the power, width -20 dB, pan -0.06, mono loss 0.0 dB, widest in mid_500_2k (-19 dB); vocals: 3% of the power, width -30 dB, pan +0.01, mono loss 0.0 dB, widest in air_gt5k (-26 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Girl_Boy Song mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -16 (corr 0.95); low_120_500 -16 (corr 0.95); mid_500_2k -8 (corr 0.70); pres_2k_5k -2 (corr 0.23); air_gt5k 8 (corr -0.73); over time (2-s windows) 10th/50th/90th percentile -15/-11/-6 dB.
- **- Girl_Boy Song by part:** drums: 9% of the power, width -6 dB, pan -0.02, mono loss 1.0 dB, widest in air_gt5k (9 dB); bass: 68% of the power, width -20 dB, pan +0.04, mono loss 0.0 dB, widest in sub_lt120 (-18 dB); other: 20% of the power, width -10 dB, pan +0.03, mono loss 0.4 dB, widest in low_120_500 (-11 dB); vocals: 2% of the power, width -18 dB, pan +0.02, mono loss 0.1 dB, widest in low_120_500 (-17 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Logon Rock Witch: 132 BPM, 13 settled chords a minute, 10% of energy above 2 kHz, width -0 dB; - Peek 824545201: 85 BPM, 17 settled chords a minute, 21% of energy above 2 kHz, width -30 dB; - Yellow Calx: 83 BPM, 15 settled chords a minute, 31% of energy above 2 kHz, width -22 dB; - Girl_Boy Song: 113 BPM, 17 settled chords a minute, 3% of energy above 2 kHz, width -13 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: - Yellow Calx: 31% of energy above 2 kHz (bright or harsh).

### For later
- - Peek 824545201, drums group `drums-2` (265 notes): high tick, quick attack, falls 68 dB/s, centered; hear it at 0:22.6, 0:19.1. **[JUDGMENT]** why it waits.
- - Yellow Calx, drums group `drums-2` (170 notes): mid snap, quick attack, falls 66 dB/s, centered; hear it at 1:55.6, 2:13.0. **[JUDGMENT]** why it waits.
- - Girl_Boy Song, bass group `bass-2` (68 notes): around B2, harmonic (string/reed/pad-like), slow swell, falls 4 dB/s, centered; hear it at 3:13.4, 1:49.8. **[JUDGMENT]** why it waits.
- - Logon Rock Witch, drums group `drums-2` (151 notes): mid snap, quick attack, falls 110 dB/s, centered; hear it at 0:05.5, 0:12.9. **[JUDGMENT]** why it waits.
- - Logon Rock Witch, other group `other-2` (82 notes): around A3, mixed or noisy partials, soft attack, falls 19 dB/s, centered; hear it at 1:58.1, 2:20.0. **[JUDGMENT]** why it waits.
- - Yellow Calx, other group `other-2` (87 notes): around E1, harmonic (string/reed/pad-like), soft attack, falls 5 dB/s, centered; hear it at 1:24.0, 1:23.5. **[JUDGMENT]** why it waits.
- - Peek 824545201, other group `other-2` (78 notes): around C6, bell- or metal-like (partials off whole multiples), soft attack, falls 40 dB/s, centered; hear it at 0:05.8, 0:06.3. **[JUDGMENT]** why it waits.
- - Girl_Boy Song, drums group `drums-1` (340 notes): low thump, quick attack, falls 233 dB/s, centered; hear it at 1:12.2, 2:42.4. **[JUDGMENT]** why it waits.
- **- Cornish Acid** (2:14.8, 144 BPM by the mix-level count): stands out for repetition 0.28 (low, album median 0.44). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Corn Mouth** (2:30.9, 112 BPM by the mix-level count): stands out for repetition 0.56 (high, album median 0.44). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
