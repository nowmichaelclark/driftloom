## 1997 - Come To Daddy (draft card from Ears 3 tools, 2026-10-25)

How it was made: EP or short record (8 usable tracks): every track. Deep pass on: - Come To Daddy (Pappy Mix); - Flim; - Come To Daddy (Little Lord Faulteroy Mix); - Bucephalus Bouncing Ball; - To Cure A Weakling Child (Contour Regard); - Funny Little Man; - Come To Daddy (Mummy Mix); - IZ-US. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- Come To Daddy (Pappy Mix)**: share of power drums 56%, bass 15%, other 23%, vocals 6%.
  - vocals stem holds 5.8%: bleed on an instrumental, not a voice.
  - meter tool 108 BPM is two thirds of the drum-grid beat of 161.3 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Flim**: share of power drums 54%, bass 21%, other 25%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 74 BPM is half of the drum-grid beat of 147.8 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Come To Daddy (Little Lord Faulteroy Mix)**: share of power drums 25%, bass 50%, other 10%, vocals 15%.
  - meter tool 120 BPM agrees with the drum-grid beat of 120.2 BPM.
- **- Bucephalus Bouncing Ball**: share of power drums 72%, bass 13%, other 15%, vocals 0%.
  - vocals stem holds 0.3%: bleed on an instrumental, not a voice.
  - meter tool 112 BPM is two thirds of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- To Cure A Weakling Child (Contour Regard)**: share of power drums 38%, bass 29%, other 31%, vocals 2%.
  - vocals stem holds 1.8%: bleed on an instrumental, not a voice.
  - meter tool 81 BPM is half of the drum-grid beat of 161.3 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Funny Little Man**: share of power drums 72%, bass 14%, other 8%, vocals 7%.
  - meter tool 133 BPM agrees with the drum-grid beat of 132.5 BPM.
- **- Come To Daddy (Mummy Mix)**: share of power drums 25%, bass 68%, other 7%, vocals 0%.
  - vocals stem holds 0.3%: bleed on an instrumental, not a voice.
  - meter tool 79 BPM is half of the drum-grid beat of 156.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- IZ-US**: share of power drums 28%, bass 46%, other 22%, vocals 4%.
  - vocals stem holds 4.4%: bleed on an instrumental, not a voice.
  - meter tool 60 BPM does not match the drum-grid beat of 235.3 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 60 to 133 BPM (octave-uncertain); keys G locrian, D# lydian, G mixolydian, A aeolian, C# ionian, G phrygian, F phrygian, D# dorian; mix width -24 to -9 dB; chord changes 23 to 58 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - IZ-US: other group `other-1` (412 notes, 41% of the track's note energy)
- In synth terms: around D#2, mixed or noisy partials, soft attack, falls 9 dB/s, centered.
- Hear it at: 2:52.1 (D#2, 2.43 s, +54 dB alone), 2:51.9 (G#2, 0.52 s, +56 dB alone), 2:31.0 (C#2, 0.77 s, +49 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 76 (51 to 153) Hz; attack 106 (22 to 368) ms; decay -9 (-31 to -2) dB/s
  - brightness at the start 328 (225 to 463) Hz; slope over the note -0.00 (-0.22 to 0.29) octaves
  - harmonic share 0.75 (0.33 to 0.99); partials off whole multiples 52 (8 to 140) cents
  - vibrato 0 (0 to 8) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.5 (-15.7 to -1.0) dB; pan -0.06 (-0.09 to -0.04); left-right correlation 0.99 (0.95 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. - Bucephalus Bouncing Ball: drums group `drums-1` (297 notes, 32% of the track's note energy)
- In synth terms: mid snap, quick attack, falls 74 dB/s, centered.
- Hear it at: 3:33.3 (G1, 0.18 s, +47 dB alone), 4:25.1 (G1, 0.18 s, +47 dB alone), 3:33.1 (G1, 0.26 s, +46 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 50 (38 to 128) Hz; attack 29 (10 to 226) ms; decay -74 (-182 to -9) dB/s
  - brightness at the start 1164 (516 to 2235) Hz; slope over the note -0.20 (-2.33 to 0.54) octaves
  - harmonic share 0.50 (0.14 to 0.95); partials off whole multiples 128 (40 to 219) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-1.7 to -0.0) dB; pan -0.01 (-0.04 to 0.03); left-right correlation 0.99 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S3. - Come To Daddy (Mummy Mix): bass group `bass-1` (272 notes, 32% of the track's note energy)
- In synth terms: around E1, bell- or metal-like (partials off whole multiples), quick attack, falls 76 dB/s, centered.
- Hear it at: 1:02.1 (C#1, 0.67 s, +26 dB alone), 0:53.8 (B0, 4.57 s, +14 dB alone), 2:36.7 (F1, 1.07 s, +14 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 41 (33 to 53) Hz; attack 38 (12 to 254) ms; decay -76 (-446 to -6) dB/s
  - brightness at the start 112 (87 to 133) Hz; slope over the note 0.03 (-0.19 to 0.47) octaves
  - harmonic share 0.44 (0.05 to 0.98); partials off whole multiples 142 (27 to 252) cents
  - vibrato 0 (0 to 13) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-20.4 to -0.4) dB; pan 0.00 (-0.01 to 0.02); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S4. - To Cure A Weakling Child (Contour Regard): other group `other-1` (287 notes, 29% of the track's note energy)
- In synth terms: around F#2, mixed or noisy partials, slow swell, falls 7 dB/s, centered.
- Hear it at: 1:42.2 (F#2, 0.35 s, +48 dB alone), 1:42.6 (F#3, 0.39 s, +50 dB alone), 1:43.3 (F#2, 0.48 s, +46 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 92 (51 to 139) Hz; attack 152 (18 to 538) ms; decay -7 (-77 to -1) dB/s
  - brightness at the start 429 (336 to 644) Hz; slope over the note 0.00 (-0.28 to 0.28) octaves
  - harmonic share 0.73 (0.22 to 0.98); partials off whole multiples 44 (9 to 160) cents
  - vibrato 0 (0 to 10) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.7 (-8.7 to -1.1) dB; pan 0.01 (-0.05 to 0.11); left-right correlation 0.95 (0.65 to 0.99)
- Group quality: weak (silhouette 0.21, 4 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. - Funny Little Man: drums group `drums-1` (252 notes, 27% of the track's note energy)
- In synth terms: low thump, quick attack, falls 114 dB/s, gets brighter over the note, centered.
- Hear it at: 3:22.5 (F1, 0.41 s, +33 dB alone), 3:17.1 (F1, 0.25 s, +18 dB alone), 3:18.9 (F1, 0.25 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 44 (43 to 44) Hz; attack 35 (12 to 36) ms; decay -114 (-123 to -106) dB/s
  - brightness at the start 80 (70 to 193) Hz; slope over the note 0.48 (0.03 to 3.45) octaves
  - harmonic share 1.00 (0.90 to 1.00); partials off whole multiples 160 (69 to 287) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.8 (-2.0 to -0.3) dB; pan -0.04 (-0.05 to -0.02); left-right correlation 0.99 (0.99 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S6. - Flim: drums group `drums-1` (335 notes, 27% of the track's note energy)
- In synth terms: low thump, quick attack, falls 284 dB/s, centered.
- Hear it at: 1:54.8 (D2, 0.13 s, +21 dB alone), 1:18.2 (?, 0.28 s, +18 dB alone), 1:17.9 (A#1, 0.34 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 63 (34 to 80) Hz; attack 28 (17 to 55) ms; decay -284 (-505 to -152) dB/s
  - brightness at the start 135 (95 to 582) Hz; slope over the note 0.00 (-0.33 to 4.39) octaves
  - harmonic share 0.93 (0.07 to 1.00); partials off whole multiples 144 (8 to 272) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.7 (-4.0 to -0.5) dB; pan -0.00 (-0.03 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S7. - Come To Daddy (Mummy Mix): bass group `bass-2` (95 notes, 27% of the track's note energy)
- In synth terms: around F#2, harmonic (string/reed/pad-like), quick attack, falls 20 dB/s, centered.
- Hear it at: 1:02.7 (F2, 2.86 s, +15 dB alone), 0:58.2 (G#2, 4.46 s, +15 dB alone), 0:50.2 (B1, 3.02 s, +13 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 91 (61 to 137) Hz; attack 26 (12 to 511) ms; decay -20 (-28 to -8) dB/s
  - brightness at the start 92 (69 to 139) Hz; slope over the note 0.00 (-0.02 to 0.15) octaves
  - harmonic share 0.99 (0.95 to 1.00); partials off whole multiples 21 (1 to 210) cents
  - vibrato 0 (0 to 14) cents; detune beating 0.0 (0.0 to 0.3) Hz
  - level against the mix -2.3 (-5.2 to -0.5) dB; pan 0.03 (-0.03 to 0.07); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S8. - Come To Daddy (Pappy Mix): drums group `drums-1` (293 notes, 26% of the track's note energy)
- In synth terms: mid snap, quick attack, falls 40 dB/s, gets brighter over the note, centered.
- Hear it at: 3:59.6 (B0, 0.25 s, +42 dB alone), 3:59.4 (G#1, 0.26 s, +40 dB alone), 3:56.7 (G#1, 0.2 s, +38 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 52 (46 to 58) Hz; attack 39 (10 to 134) ms; decay -40 (-102 to -14) dB/s
  - brightness at the start 776 (335 to 1741) Hz; slope over the note 1.64 (0.00 to 3.06) octaves
  - harmonic share 0.84 (0.15 to 0.98); partials off whole multiples 130 (10 to 292) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-2.6 to -0.6) dB; pan 0.07 (0.00 to 0.12); left-right correlation 0.83 (0.73 to 0.93)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- Come To Daddy (Pappy Mix) sections:** 15 boundaries at 0:02.0, 0:26.0, 0:44.0, 1:01.0, 1:13.0, 1:25.0, 1:41.0, 2:01.0, 2:22.0, 2:43.0, 2:55.0, 3:05.0; section lengths median 16 s (range 2 to 49). Reliable for sections of 10 s or more.
- **- Come To Daddy (Pappy Mix) stem entries and exits:** drums plays 97% of the time (in: 0:06.5; out: never); bass plays 85% of the time (in: 1:56.5, 2:20.0, 2:37.0, 3:36.0; out: 1:41.5, 2:16.5, 2:27.5, 3:27.0, 4:21.0); other plays 97% of the time (in: 4:00.0; out: 3:56.0, 4:20.5); vocals plays 60% of the time (in: 0:30.0, 1:10.5, 2:24.0, 3:13.0, 4:02.5; out: 0:25.5, 1:00.5, 1:58.0, 3:10.5, 3:16.0).
- **- Come To Daddy (Pappy Mix) floor drops (kick and bass out 2 s or more while the rest plays):** 0.76 a minute: 2:20.2 for 2.0 s, 2:26.5 for 4.0 s, 2:33.0 for 3.8 s.
- **- Come To Daddy (Pappy Mix) brightness sweeps (0.7 octave or more):** mix down 1.9 oct 0:07.0 to 0:18.0; mix up 1.9 oct 0:18.5 to 0:27.5; mix up 1.0 oct 0:36.5 to 0:43.5; mix down 0.8 oct 0:44.0 to 0:52.0; mix down 1.2 oct 1:33.0 to 1:38.5; mix up 1.6 oct 1:38.5 to 1:43.5; mix down 0.9 oct 2:14.0 to 2:19.5; mix up 0.8 oct 2:40.0 to 2:45.0 (33 more in techniques.json).
- **- Come To Daddy (Pappy Mix) echo times:** drums: 364 ms (+3.4 dB, 3 later repeats).
- **- Come To Daddy (Pappy Mix) pumping locked to the kick:** other dips 2.4 dB at the kick (peak 70 ms after, kick every 0.42 s); bass dips 3.6 dB at the kick (peak 60 ms after, kick every 0.42 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Come To Daddy (Pappy Mix) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Come To Daddy (Pappy Mix) stereo movement:** drums pan range 0.36; bass pan range 0.17, cycling every 37 s; other pan range 0.29; vocals pan range 0.40.
- **- Come To Daddy (Pappy Mix) builds:** 0:00.0 to 0:29.0.
- **- Flim sections:** 9 boundaries at 0:03.0, 0:13.0, 0:31.0, 1:01.0, 1:23.0, 1:44.0, 1:54.0, 2:16.0, 2:51.0; section lengths median 20 s (range 3 to 35). Reliable for sections of 10 s or more.
- **- Flim stem entries and exits:** drums plays 77% of the time (in: 0:01.5; out: 2:18.5); bass plays 87% of the time (in: 0:02.5, 0:15.5, 1:33.0, 1:52.5; out: 0:12.5, 1:30.0, 1:47.0, 2:48.5); other plays 96% of the time (in: from the start; out: 2:51.5); vocals plays 0% of the time (in: from the start; out: never).
- **- Flim floor drops (kick and bass out 2 s or more while the rest plays):** 1.51 a minute: 2:15.2 for 3.5 s, 2:30.5 for 3.8 s, 2:38.2 for 4.2 s, 2:42.0 for 2.5 s.
- **- Flim brightness sweeps (0.7 octave or more):** mix up 0.9 oct 0:01.5 to 0:08.5; mix down 3.9 oct 0:28.5 to 0:34.5; mix up 1.3 oct 1:03.5 to 1:08.5; mix down 0.8 oct 1:47.0 to 1:52.0; mix down 1.3 oct 1:53.0 to 2:03.0; mix up 0.9 oct 2:12.5 to 2:18.0; other down 0.8 oct 0:34.5 to 0:40.0; other up 1.3 oct 0:40.5 to 0:47.0 (12 more in techniques.json).
- **- Flim echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Flim pumping locked to the kick:** under 1.5 dB; none found.
- **- Flim tape wobble and speed:** other wobbles about 11 cents at 1.4 Hz; other speed moves up to 16 cents in 4 s.
- **- Flim stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Come To Daddy (Little Lord Faulteroy Mix) sections:** 10 boundaries at 0:11.0, 0:44.0, 0:57.0, 1:17.0, 1:31.0, 2:04.0, 2:40.0, 2:58.0, 3:25.0, 3:48.0; section lengths median 20 s (range 2 to 36). Reliable for sections of 10 s or more.
- **- Come To Daddy (Little Lord Faulteroy Mix) stem entries and exits:** drums plays 96% of the time (in: 0:07.0; out: 3:48.0); bass plays 82% of the time (in: 0:09.5, 2:02.5; out: 1:35.5, 3:46.0); other plays 87% of the time (in: 0:19.0, 0:42.0, 2:50.0, 2:59.0; out: 0:14.5, 0:30.5, 2:44.0, 2:53.0); vocals plays 61% of the time (in: 0:58.0, 2:02.5, 2:58.5; out: 1:47.5, 2:43.5).
- **- Come To Daddy (Little Lord Faulteroy Mix) floor drops (kick and bass out 2 s or more while the rest plays):** 0.58 a minute: 2:21.0 for 2.2 s, 2:29.0 for 2.2 s.
- **- Come To Daddy (Little Lord Faulteroy Mix) brightness sweeps (0.7 octave or more):** mix down 3.5 oct 0:00.0 to 0:11.5; mix up 0.9 oct 0:39.5 to 0:45.0; mix up 2.1 oct 1:29.0 to 1:38.0; mix down 1.4 oct 1:46.0 to 1:51.0; mix down 1.6 oct 1:58.0 to 2:08.5; mix down 1.4 oct 2:21.0 to 2:26.0; mix up 1.4 oct 2:55.0 to 3:00.5; mix up 1.5 oct 3:14.0 to 3:22.5 (20 more in techniques.json).
- **- Come To Daddy (Little Lord Faulteroy Mix) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Come To Daddy (Little Lord Faulteroy Mix) pumping locked to the kick:** other dips 1.5 dB at the kick (peak 55 ms after, kick every 0.26 s); bass dips 2.9 dB at the kick (peak 90 ms after, kick every 0.26 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Come To Daddy (Little Lord Faulteroy Mix) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Come To Daddy (Little Lord Faulteroy Mix) stereo movement:** vocals pan range 0.30.
- **- Bucephalus Bouncing Ball sections:** 17 boundaries at 0:12.0, 0:22.0, 0:32.0, 0:57.0, 1:21.0, 1:32.0, 1:56.0, 2:11.0, 2:45.0, 3:03.0, 3:32.0, 3:50.0; section lengths median 18 s (range 10 to 36). Reliable for sections of 10 s or more.
- **- Bucephalus Bouncing Ball stem entries and exits:** drums plays 99% of the time (in: from the start; out: 5:41.0); bass plays 36% of the time (in: 0:20.5, 2:45.5, 3:35.5, 3:58.0, 4:04.0; out: 1:21.0, 2:51.0, 3:45.0, 4:01.0, 4:12.5); other plays 76% of the time (in: 0:11.5, 0:19.5, 0:44.0, 1:06.0, 1:31.0; out: 0:14.0, 0:32.0, 1:00.0, 1:23.0, 3:04.0); vocals plays 9% of the time (in: 2:26.0, 3:36.5, 4:01.5, 4:29.0, 4:34.0; out: 2:29.0, 3:43.0, 4:04.0, 4:31.5, 4:37.5).
- **- Bucephalus Bouncing Ball floor drops (kick and bass out 2 s or more while the rest plays):** 0.39 a minute: 3:20.0 for 2.2 s, 3:22.8 for 2.2 s.
- **- Bucephalus Bouncing Ball brightness sweeps (0.7 octave or more):** mix down 2.7 oct 0:03.5 to 0:11.5; mix up 3.0 oct 0:12.0 to 0:17.0; mix down 1.7 oct 0:17.5 to 0:25.5; mix down 1.2 oct 1:00.0 to 1:05.5; mix up 1.8 oct 1:05.5 to 1:10.5; mix down 2.7 oct 1:30.0 to 1:40.0; mix up 0.8 oct 1:40.5 to 1:45.5; mix up 2.3 oct 1:54.0 to 2:00.0 (55 more in techniques.json).
- **- Bucephalus Bouncing Ball echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Bucephalus Bouncing Ball pumping locked to the kick:** other dips 2.2 dB at the kick (peak 160 ms after, kick every 0.34 s); bass dips 3.5 dB at the kick (peak 314 ms after, kick every 0.34 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Bucephalus Bouncing Ball tape wobble and speed:** other wobbles about 4 cents at 2.3 Hz; other speed moves up to 8 cents in 4 s.
- **- Bucephalus Bouncing Ball stereo movement:** vocals pan range 0.27.
- **- To Cure A Weakling Child (Contour Regard) sections:** 13 boundaries at 0:21.0, 0:32.0, 0:48.0, 0:58.0, 1:22.0, 1:44.0, 2:38.0, 3:03.0, 3:30.0, 3:57.0, 4:09.0, 4:36.0; section lengths median 23 s (range 10 to 54). Reliable for sections of 10 s or more.
- **- To Cure A Weakling Child (Contour Regard) stem entries and exits:** drums plays 82% of the time (in: 0:19.0, 0:36.0, 1:37.5, 4:07.0; out: 0:31.5, 1:22.5, 3:56.5, 5:03.0); bass plays 82% of the time (in: 0:11.5, 0:18.0, 0:30.5, 0:47.0, 0:59.0; out: 0:07.0, 0:15.0, 0:24.5, 0:39.5, 0:53.5); other plays 86% of the time (in: 0:21.5, 0:29.0, 1:17.5; out: 0:16.0, 0:25.0, 0:50.0, 5:04.0); vocals plays 34% of the time (in: 0:08.0, 0:48.5, 1:32.0, 2:20.5, 3:03.0; out: 0:36.5, 1:21.0, 1:41.5, 2:23.0, 3:11.5).
- **- To Cure A Weakling Child (Contour Regard) floor drops (kick and bass out 2 s or more while the rest plays):** 2.15 a minute: 0:15.2 for 3.5 s, 0:22.5 for 2.0 s, 0:28.5 for 3.0 s, 0:34.5 for 2.2 s, 0:38.8 for 3.5 s, 1:32.2 for 2.5 s, 1:39.2 for 4.5 s, 3:55.8 for 3.8 s.
- **- To Cure A Weakling Child (Contour Regard) brightness sweeps (0.7 octave or more):** mix up 2.0 oct 0:14.5 to 0:21.5; mix down 3.5 oct 0:29.0 to 0:34.0; mix up 1.6 oct 0:40.5 to 0:45.5; mix up 2.2 oct 0:46.5 to 0:52.5; mix down 2.0 oct 0:54.5 to 1:01.5; mix up 1.1 oct 1:19.0 to 1:30.0; mix down 1.3 oct 1:30.0 to 1:36.5; mix up 1.0 oct 1:37.0 to 1:44.0 (48 more in techniques.json).
- **- To Cure A Weakling Child (Contour Regard) echo times:** drums: 574 ms (+8.2 dB, 1 later repeats).
- **- To Cure A Weakling Child (Contour Regard) pumping locked to the kick:** under 1.5 dB; none found.
- **- To Cure A Weakling Child (Contour Regard) tape wobble and speed:** other wobbles about 9 cents at 2.6 Hz; other speed moves up to 12 cents in 4 s.
- **- To Cure A Weakling Child (Contour Regard) stereo movement:** vocals pan range 0.34.
- **- Funny Little Man sections:** 13 boundaries at 0:02.0, 0:32.0, 0:53.0, 1:07.0, 1:18.0, 1:45.0, 2:03.0, 2:18.0, 2:33.0, 2:47.0, 3:18.0, 3:30.0; section lengths median 15 s (range 2 to 31). Reliable for sections of 10 s or more.
- **- Funny Little Man stem entries and exits:** drums plays 89% of the time (in: from the start; out: 3:31.5); bass plays 87% of the time (in: 1:54.0, 3:00.0, 3:22.5, 3:48.5; out: 1:51.5, 2:57.5, 3:18.5, 3:31.5, 3:53.5); other plays 88% of the time (in: from the start; out: 3:31.0); vocals plays 75% of the time (in: 0:08.0, 3:33.5; out: 2:47.0, 3:54.0).
- **- Funny Little Man floor drops (kick and bass out 2 s or more while the rest plays):** 0.56 a minute: 3:33.8 for 10.0 s, 3:43.2 for 2.5 s.
- **- Funny Little Man brightness sweeps (0.7 octave or more):** mix up 0.8 oct 0:48.0 to 0:56.0; mix down 2.2 oct 1:28.0 to 1:40.0; mix up 1.4 oct 1:40.5 to 1:46.0; mix up 0.9 oct 1:49.0 to 1:55.0; mix down 2.4 oct 2:01.0 to 2:08.5; mix down 1.2 oct 2:56.5 to 3:06.5; mix down 2.1 oct 3:19.0 to 3:24.0; mix up 3.2 oct 3:30.5 to 3:36.5 (24 more in techniques.json).
- **- Funny Little Man echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Funny Little Man pumping locked to the kick:** other dips 2.9 dB at the kick (peak 215 ms after, kick every 0.44 s); bass dips 5.3 dB at the kick (peak 215 ms after, kick every 0.44 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Funny Little Man tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Funny Little Man stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Come To Daddy (Mummy Mix) sections:** 10 boundaries at 0:03.0, 0:51.0, 1:06.0, 1:22.0, 1:46.0, 2:34.0, 3:00.0, 3:12.0, 4:10.0, 4:20.0; section lengths median 16 s (range 3 to 58). Reliable for sections of 10 s or more.
- **- Come To Daddy (Mummy Mix) stem entries and exits:** drums plays 92% of the time (in: 0:02.0, 1:05.0, 4:08.5; out: 0:52.5, 4:06.0, 4:19.5); bass plays 83% of the time (in: 0:20.0, 0:30.0, 0:49.5; out: 0:03.5, 0:25.0, 0:40.0, 4:12.5); other plays 82% of the time (in: 0:22.5, 0:40.5, 1:08.0, 2:04.0; out: 0:35.5, 1:03.0, 1:53.5, 4:20.5); vocals plays 20% of the time (in: 0:25.5, 1:02.0, 1:22.0, 1:37.5, 1:51.0; out: 0:05.5, 0:29.0, 1:11.5, 1:24.5, 1:44.5).
- **- Come To Daddy (Mummy Mix) floor drops (kick and bass out 2 s or more while the rest plays):** 0.25 a minute: 4:05.5 for 3.0 s.
- **- Come To Daddy (Mummy Mix) brightness sweeps (0.7 octave or more):** mix up 3.0 oct 0:00.0 to 0:09.5; mix down 1.5 oct 0:09.5 to 0:16.0; mix up 2.5 oct 0:37.0 to 0:44.0; mix down 5.3 oct 0:44.0 to 0:54.0; mix down 1.5 oct 1:00.0 to 1:05.5; mix down 1.4 oct 1:09.5 to 1:16.5; mix up 3.7 oct 1:16.5 to 1:21.5; mix down 1.7 oct 1:27.0 to 1:33.0 (47 more in techniques.json).
- **- Come To Daddy (Mummy Mix) echo times:** drums: 190 ms (+3.8 dB, 3 later repeats).
- **- Come To Daddy (Mummy Mix) pumping locked to the kick:** under 1.5 dB; none found.
- **- Come To Daddy (Mummy Mix) tape wobble and speed:** other wobbles about 8 cents at 4.0 Hz; bass wobbles about 23 cents at 2.3 Hz.
- **- Come To Daddy (Mummy Mix) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- IZ-US sections:** 8 boundaries at 0:08.0, 0:33.0, 0:49.0, 1:20.0, 1:50.0, 2:12.0, 2:28.0, 2:50.0; section lengths median 22 s (range 7 to 31). Reliable for sections of 10 s or more.
- **- IZ-US stem entries and exits:** drums plays 92% of the time (in: 0:03.0, 2:32.5; out: 2:29.5, 2:50.0); bass plays 87% of the time (in: 0:07.0, 1:10.0, 2:33.0; out: 1:06.5, 2:29.0, 2:49.5); other plays 97% of the time (in: 0:03.0; out: 2:54.5); vocals plays 54% of the time (in: 0:17.5, 1:36.5, 1:45.0, 2:04.0, 2:20.0; out: 0:04.0, 0:54.5, 1:41.5, 1:54.0, 2:14.0).
- **- IZ-US floor drops (kick and bass out 2 s or more while the rest plays):** 0.38 a minute: 2:28.5 for 4.5 s.
- **- IZ-US brightness sweeps (0.7 octave or more):** mix up 2.8 oct 0:00.0 to 0:11.0; mix up 2.0 oct 0:14.5 to 0:20.0; mix up 1.7 oct 0:26.5 to 0:36.0; mix down 3.3 oct 0:44.0 to 0:53.5; mix up 1.2 oct 0:53.5 to 0:58.5; mix down 0.9 oct 0:58.5 to 1:06.5; mix up 1.4 oct 1:07.0 to 1:18.0; mix down 1.1 oct 1:18.5 to 1:23.5 (26 more in techniques.json).
- **- IZ-US echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- IZ-US pumping locked to the kick:** bass dips 3.5 dB at the kick (peak 215 ms after, kick every 0.30 s). The tool reads about 70% of the true depth, so this is a floor.
- **- IZ-US tape wobble and speed:** other speed moves up to 8 cents in 4 s.
- **- IZ-US stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Come To Daddy (Pappy Mix) meter:** about 108 BPM (could be 54 or 216; the tool cannot tell the beat level), bar length unclear (best guess 12, score 0.15); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Come To Daddy (Pappy Mix) key and mode:** G locrian (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights C 0.11, C# 0.10, D# 0.09, F 0.09, E 0.08.
- **- Come To Daddy (Pappy Mix) chords:** 29 changes a minute (19 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 1.0 to 3.6 s); 25 distinct chords; most time on C#maj7 31%, Cmaj7 14%, D#maj7 10%, F5 9%. The old counter in this same run said 10; Ears 1's 2-s counter said 5.  54% of the changes land on a beat (chance would be 54%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Come To Daddy (Pappy Mix) bass:** root-note movement / mixed; 0.31 notes a second; most time on G 0.27, F 0.15, B 0.13, E 0.10; steps 18%, thirds 9%, fourths and fifths 19%, octaves 1%, repeats 42%.
- **- Come To Daddy (Pappy Mix) top line (from the 'other' stem; read by ear before trusting):** 602 notes, range 26 semitones (10th to 90th percentile); steps 25%, thirds 17%, fourths and fifths 12%, leaps 30%, repeats 16%; median interval 4 semitones; 50% of moves go up; phrases of about 9 notes, arch 50%, rising 23%, falling 13%, flat or wavy 13%. Reliable only when the line sits clearly above its accompaniment.
- **- Come To Daddy (Pappy Mix) repetition:** 39 bars of 6.7 s; strongest repeat distances 1 bars (0.44), 13 bars (0.06), 19 bars (-0.13); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Flim meter:** about 74 BPM (could be 37 or 148; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.20); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Flim key and mode:** D# lydian (key signature margin 0.020); pitch-class weights F 0.15, D# 0.14, D 0.13, A# 0.13, G 0.09.
- **- Flim chords:** 40 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.6 to 2.5 s); 27 distinct chords; most time on A# 16%, D#5 13%, A#maj7 9%, Gmin7 8%. The old counter in this same run said 17; Ears 1's 2-s counter said 8.  22% of the changes land on a beat (chance would be 37%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Flim bass:** root-note movement / mixed; 0.96 notes a second; most time on B 0.20, D# 0.14, A 0.11, D 0.11; steps 27%, thirds 15%, fourths and fifths 18%, octaves 2%, repeats 28%.
- **- Flim top line (from the 'other' stem; read by ear before trusting):** 330 notes, range 19 semitones (10th to 90th percentile); steps 14%, thirds 18%, fourths and fifths 22%, leaps 26%, repeats 20%; median interval 4 semitones; 54% of moves go up; phrases of about 8 notes, arch 47%, rising 26%, falling 11%, flat or wavy 16%. Reliable only when the line sits clearly above its accompaniment.
- **- Flim repetition:** 54 bars of 3.2 s; strongest repeat distances 26 bars (0.52), 2 bars (0.38), 4 bars (0.27); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Come To Daddy (Little Lord Faulteroy Mix) meter:** about 120 BPM (could be 60 or 240; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Come To Daddy (Little Lord Faulteroy Mix) key and mode:** G mixolydian (low confidence: the key signature margin is 0.005, so read this as a guess); pitch-class weights C 0.13, E 0.13, G 0.10, F 0.09, F# 0.08.
- **- Come To Daddy (Little Lord Faulteroy Mix) chords:** 41 changes a minute (16 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.7 to 2.2 s); 38 distinct chords; most time on G#5 10%, C5 10%, Fmaj7 9%, C#maj7 8%. The old counter in this same run said 21; Ears 1's 2-s counter said 15.  65% of the changes land on a beat (chance would be 60%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Come To Daddy (Little Lord Faulteroy Mix) bass:** root-note movement / mixed; 0.93 notes a second; most time on G 0.67, E 0.18, F# 0.11, G# 0.02; steps 6%, thirds 2%, fourths and fifths 1%, octaves 7%, repeats 64%.
- **- Come To Daddy (Little Lord Faulteroy Mix) top line (from the 'other' stem; read by ear before trusting):** 331 notes, range 14 semitones (10th to 90th percentile); steps 15%, thirds 17%, fourths and fifths 25%, leaps 19%, repeats 23%; median interval 4 semitones; 55% of moves go up; phrases of about 6 notes, arch 29%, rising 35%, falling 24%, flat or wavy 12%. Reliable only when the line sits clearly above its accompaniment.
- **- Come To Daddy (Little Lord Faulteroy Mix) repetition:** 115 bars of 2.0 s; strongest repeat distances 4 bars (0.53), 8 bars (0.36), 1 bars (0.32); 11% of bars near-duplicate an earlier bar.
- **- Bucephalus Bouncing Ball meter:** about 112 BPM (could be 56 or 224; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.03); swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:3, 5:4, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Bucephalus Bouncing Ball key and mode:** A aeolian (minor) (low confidence: the key signature margin is 0.002, so read this as a guess); pitch-class weights C 0.13, F 0.12, G 0.12, D 0.11, E 0.09.
- **- Bucephalus Bouncing Ball chords:** 23 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 0.7 to 4.9 s); 35 distinct chords; most time on Fmaj7 22%, C#maj7 18%, Amin 7%, G5 6%. The old counter in this same run said 7; Ears 1's 2-s counter said 2.  53% of the changes land on a beat (chance would be 56%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Bucephalus Bouncing Ball bass:** root-note movement / mixed; 0.24 notes a second; most time on A 0.66, C 0.14, B 0.08, G 0.05; steps 7%, thirds 29%, fourths and fifths 1%, octaves 0%, repeats 57%.
- **- Bucephalus Bouncing Ball top line (from the 'other' stem; read by ear before trusting):** 589 notes, range 17 semitones (10th to 90th percentile); steps 20%, thirds 16%, fourths and fifths 19%, leaps 30%, repeats 16%; median interval 4 semitones; 49% of moves go up; phrases of about 7 notes, arch 29%, rising 19%, falling 39%, flat or wavy 13%. Reliable only when the line sits clearly above its accompaniment.
- **- Bucephalus Bouncing Ball repetition:** 80 bars of 4.3 s; strongest repeat distances 1 bars (0.64), 8 bars (0.29), 32 bars (-0.25); 11% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- To Cure A Weakling Child (Contour Regard) meter:** about 81 BPM (could be 40 or 162; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.75 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- To Cure A Weakling Child (Contour Regard) key and mode:** C# ionian (major) (key signature margin 0.027); pitch-class weights C# 0.25, F 0.13, G# 0.10, D# 0.10, C 0.09.
- **- To Cure A Weakling Child (Contour Regard) chords:** 28 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.6 s (10th to 90th percentile 0.7 to 3.9 s); 29 distinct chords; most time on C#maj7 25%, C#sus2 16%, C#5 15%, F#5 9%. The old counter in this same run said 14; Ears 1's 2-s counter said 8.  44% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- To Cure A Weakling Child (Contour Regard) bass:** root-note movement / mixed; 0.69 notes a second; most time on C# 0.56, F# 0.22, F 0.10, G# 0.09; steps 11%, thirds 10%, fourths and fifths 18%, octaves 3%, repeats 50%.
- **- To Cure A Weakling Child (Contour Regard) top line (from the 'other' stem; read by ear before trusting):** 437 notes, range 7 semitones (10th to 90th percentile); steps 32%, thirds 25%, fourths and fifths 18%, leaps 9%, repeats 15%; median interval 3 semitones; 52% of moves go up; phrases of about 27 notes, arch 36%, rising 27%, falling 18%, flat or wavy 18%. Reliable only when the line sits clearly above its accompaniment.
- **- To Cure A Weakling Child (Contour Regard) repetition:** 209 bars of 1.5 s; strongest repeat distances 1 bars (0.58), 9 bars (0.37), 18 bars (0.07); 15% of bars near-duplicate an earlier bar.
- **- Funny Little Man meter:** about 133 BPM (could be 67 or 266; the tool cannot tell the beat level), bar length unclear (best guess 7, score 0.00); straight eighths; no cross-rhythm claim.
- **- Funny Little Man key and mode:** G phrygian (low confidence: the key signature margin is 0.000, so read this as a guess); pitch-class weights F 0.10, D 0.10, D# 0.10, C 0.09, G 0.09.
- **- Funny Little Man chords:** 58 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.4 to 1.8 s); 41 distinct chords; most time on Fmaj7 18%, G#maj7 17%, D#maj7 9%, A#maj7 6%. The old counter in this same run said 17; Ears 1's 2-s counter said 2.  68% of the changes land on a beat (chance would be 67%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Funny Little Man bass:** root-note movement / mixed; 0.67 notes a second; most time on G 0.33, F 0.32, D# 0.12, G# 0.06; steps 20%, thirds 9%, fourths and fifths 16%, octaves 8%, repeats 23%.
- **- Funny Little Man top line (from the 'other' stem; read by ear before trusting):** 610 notes, range 20 semitones (10th to 90th percentile); steps 20%, thirds 15%, fourths and fifths 11%, leaps 44%, repeats 10%; median interval 5 semitones; 49% of moves go up; phrases of about 14 notes, arch 57%, rising 7%, falling 20%, flat or wavy 15%. Reliable only when the line sits clearly above its accompaniment.
- **- Funny Little Man repetition:** 75 bars of 3.2 s; strongest repeat distances 1 bars (0.32), 18 bars (0.24), 9 bars (0.23); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Come To Daddy (Mummy Mix) meter:** about 79 BPM (could be 40 or 159; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.13); swung: off-beat at 0.75 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Come To Daddy (Mummy Mix) key and mode:** F phrygian (key signature margin 0.021); pitch-class weights F 0.14, C# 0.12, C 0.09, F# 0.09, A# 0.09.
- **- Come To Daddy (Mummy Mix) chords:** 34 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 1.2 s (10th to 90th percentile 0.6 to 3.7 s); 43 distinct chords; most time on F#5 10%, Cmaj7 10%, C#maj7 8%, F5 7%. The old counter in this same run said 14; Ears 1's 2-s counter said 9.  40% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Come To Daddy (Mummy Mix) bass:** root-note movement / mixed; 0.68 notes a second; most time on F 0.20, B 0.17, C# 0.14, F# 0.11; steps 13%, thirds 5%, fourths and fifths 17%, octaves 2%, repeats 46%.
- **- Come To Daddy (Mummy Mix) top line (from the 'other' stem; read by ear before trusting):** 336 notes, range 39 semitones (10th to 90th percentile); steps 15%, thirds 10%, fourths and fifths 21%, leaps 36%, repeats 18%; median interval 6 semitones; 52% of moves go up; phrases of about 8 notes, arch 27%, rising 20%, falling 33%, flat or wavy 20%. Reliable only when the line sits clearly above its accompaniment.
- **- Come To Daddy (Mummy Mix) repetition:** 175 bars of 1.5 s; strongest repeat distances 1 bars (0.53), 10 bars (0.31), 21 bars (0.12); 14% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- IZ-US meter:** about 60 BPM (could be 30 or 119; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.75 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- IZ-US key and mode:** D# dorian (low confidence: the key signature margin is 0.009, so read this as a guess); pitch-class weights D# 0.14, C# 0.14, A# 0.12, F 0.10, G# 0.10.
- **- IZ-US chords:** 42 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.2 s (10th to 90th percentile 0.7 to 2.4 s); 28 distinct chords; most time on C#maj7 20%, G#sus2 17%, D#5 15%, D#min7 10%. The old counter in this same run said 21; Ears 1's 2-s counter said 19.  15% of the changes land on a beat (chance would be 30%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- IZ-US bass:** root-note movement / mixed; 0.42 notes a second; most time on D# 0.68, A# 0.27, D 0.02, F 0.01; steps 18%, thirds 1%, fourths and fifths 8%, octaves 0%, repeats 64%.
- **- IZ-US top line (from the 'other' stem; read by ear before trusting):** 277 notes, range 12 semitones (10th to 90th percentile); steps 18%, thirds 29%, fourths and fifths 21%, leaps 15%, repeats 17%; median interval 3 semitones; 52% of moves go up; phrases of about 14 notes, arch 36%, rising 7%, falling 29%, flat or wavy 29%. Reliable only when the line sits clearly above its accompaniment.
- **- IZ-US repetition:** 87 bars of 2.0 s; strongest repeat distances 8 bars (0.38), 4 bars (0.38), 12 bars (0.31); 15% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Come To Daddy (Pappy Mix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -13 (corr 0.98); low_120_500 -13 (corr 0.95); mid_500_2k -14 (corr 0.93); pres_2k_5k -9 (corr 0.77); air_gt5k -4 (corr 0.47); over time (2-s windows) 10th/50th/90th percentile -11/-9/-6 dB.
- **- Come To Daddy (Pappy Mix) by part:** drums: 59% of the power, width -7 dB, pan -0.04, mono loss 0.8 dB, widest in air_gt5k (-3 dB); bass: 14% of the power, width -13 dB, pan +0.39, mono loss 0.2 dB, widest in sub_lt120 (-12 dB); other: 22% of the power, width -13 dB, pan +0.19, mono loss 0.2 dB, widest in sub_lt120 (-12 dB); vocals: 5% of the power, width -12 dB, pan +0.00, mono loss 0.2 dB, widest in low_120_500 (-11 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Flim mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.98); low_120_500 -15 (corr 0.93); mid_500_2k -8 (corr 0.70); pres_2k_5k -25 (corr 0.99); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -16/-11/-8 dB.
- **- Flim by part:** drums: 52% of the power, width -25 dB, pan -0.04, mono loss 0.0 dB, widest in low_120_500 (-24 dB); bass: 21% of the power, width -16 dB, pan -0.16, mono loss 0.1 dB, widest in sub_lt120 (-17 dB); other: 27% of the power, width -9 dB, pan +0.01, mono loss 0.5 dB, widest in mid_500_2k (-7 dB); vocals: 0% of the power, width -25 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-24 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Come To Daddy (Little Lord Faulteroy Mix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 0.99); low_120_500 -17 (corr 0.97); mid_500_2k -13 (corr 0.91); pres_2k_5k -1 (corr 0.17); air_gt5k 9 (corr -0.80); over time (2-s windows) 10th/50th/90th percentile -15/-10/-7 dB.
- **- Come To Daddy (Little Lord Faulteroy Mix) by part:** drums: 27% of the power, width -9 dB, pan +0.06, mono loss 0.5 dB, widest in low_120_500 (-25 dB); bass: 48% of the power, width -25 dB, pan -0.06, mono loss 0.0 dB, widest in sub_lt120 (-25 dB); other: 9% of the power, width -17 dB, pan +0.07, mono loss 0.1 dB, widest in mid_500_2k (-15 dB); vocals: 15% of the power, width -12 dB, pan +0.10, mono loss 0.3 dB, widest in mid_500_2k (-11 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Bucephalus Bouncing Ball mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -22 (corr 0.99); low_120_500 -24 (corr 0.99); mid_500_2k -22 (corr 0.99); pres_2k_5k -18 (corr 0.97); air_gt5k -18 (corr 0.97); over time (2-s windows) 10th/50th/90th percentile -27/-24/-19 dB.
- **- Bucephalus Bouncing Ball by part:** drums: 72% of the power, width -21 dB, pan -0.04, mono loss 0.0 dB, widest in pres_2k_5k (-19 dB); bass: 13% of the power, width -21 dB, pan -0.11, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); other: 15% of the power, width -24 dB, pan +0.01, mono loss 0.0 dB, widest in mid_500_2k (-25 dB); vocals: 0% of the power, width -19 dB, pan -0.02, mono loss 0.1 dB, widest in mid_500_2k (-17 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- To Cure A Weakling Child (Contour Regard) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -19 (corr 0.98); low_120_500 -16 (corr 0.95); mid_500_2k -13 (corr 0.90); pres_2k_5k -6 (corr 0.61); air_gt5k -2 (corr 0.27); over time (2-s windows) 10th/50th/90th percentile -24/-11/-7 dB.
- **- To Cure A Weakling Child (Contour Regard) by part:** drums: 39% of the power, width -12 dB, pan +0.02, mono loss 0.3 dB, widest in low_120_500 (-18 dB); bass: 28% of the power, width -19 dB, pan +0.12, mono loss 0.1 dB, widest in low_120_500 (-16 dB); other: 31% of the power, width -14 dB, pan +0.00, mono loss 0.2 dB, widest in mid_500_2k (-13 dB); vocals: 2% of the power, width -20 dB, pan +0.03, mono loss 0.0 dB, widest in mid_500_2k (-18 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Funny Little Man mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -22 (corr 0.99); low_120_500 -28 (corr 1.00); mid_500_2k -25 (corr 0.99); pres_2k_5k -25 (corr 0.99); air_gt5k -18 (corr 0.97); over time (2-s windows) 10th/50th/90th percentile -28/-27/-17 dB.
- **- Funny Little Man by part:** drums: 72% of the power, width -23 dB, pan -0.05, mono loss 0.0 dB, widest in sub_lt120 (-22 dB); bass: 14% of the power, width -28 dB, pan -0.02, mono loss 0.0 dB, widest in sub_lt120 (-27 dB); other: 8% of the power, width -26 dB, pan -0.03, mono loss 0.0 dB, widest in mid_500_2k (-25 dB); vocals: 7% of the power, width -24 dB, pan -0.04, mono loss 0.0 dB, widest in mid_500_2k (-25 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Come To Daddy (Mummy Mix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 1.00); low_120_500 -23 (corr 0.99); mid_500_2k -5 (corr 0.55); pres_2k_5k 7 (corr -0.65); air_gt5k -4 (corr 0.46); over time (2-s windows) 10th/50th/90th percentile -10/-6/-1 dB.
- **- Come To Daddy (Mummy Mix) by part:** drums: 27% of the power, width -8 dB, pan -0.03, mono loss 0.6 dB, widest in air_gt5k (-5 dB); bass: 64% of the power, width -26 dB, pan +0.04, mono loss 0.0 dB, widest in sub_lt120 (-26 dB); other: 9% of the power, width -5 dB, pan -0.11, mono loss 1.3 dB, widest in pres_2k_5k (5 dB); vocals: 0% of the power, width -4 dB, pan -0.15, mono loss 1.5 dB, widest in pres_2k_5k (8 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- IZ-US mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.98); low_120_500 -18 (corr 0.97); mid_500_2k -13 (corr 0.91); pres_2k_5k -6 (corr 0.62); air_gt5k -11 (corr 0.86); over time (2-s windows) 10th/50th/90th percentile -23/-22/-9 dB.
- **- IZ-US by part:** drums: 28% of the power, width -14 dB, pan +0.05, mono loss 0.2 dB, widest in low_120_500 (-17 dB); bass: 45% of the power, width -23 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-23 dB); other: 22% of the power, width -17 dB, pan -0.12, mono loss 0.1 dB, widest in mid_500_2k (-15 dB); vocals: 4% of the power, width -25 dB, pan -0.08, mono loss 0.0 dB, widest in mid_500_2k (-22 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Come To Daddy (Pappy Mix): 108 BPM, 19 settled chords a minute, 30% of energy above 2 kHz, width -9 dB; - Flim: 74 BPM, 17 settled chords a minute, 3% of energy above 2 kHz, width -14 dB; - Come To Daddy (Little Lord Faulteroy Mix): 120 BPM, 16 settled chords a minute, 4% of energy above 2 kHz, width -14 dB; - Bucephalus Bouncing Ball: 112 BPM, 14 settled chords a minute, 14% of energy above 2 kHz, width -21 dB; - To Cure A Weakling Child (Contour Regard): 81 BPM, 15 settled chords a minute, 7% of energy above 2 kHz, width -14 dB; - Funny Little Man: 133 BPM, 10 settled chords a minute, 2% of energy above 2 kHz, width -24 dB; - Come To Daddy (Mummy Mix): 79 BPM, 13 settled chords a minute, 10% of energy above 2 kHz, width -12 dB; - IZ-US: 60 BPM, 14 settled chords a minute, 4% of energy above 2 kHz, width -17 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: - Come To Daddy (Pappy Mix): 30% of energy above 2 kHz (bright or harsh).

### For later
- - Flim, other group `other-1` (166 notes): around C#2, mixed or noisy partials, slow swell, falls 11 dB/s, centered; hear it at 2:48.7, 2:42.5. **[JUDGMENT]** why it waits.
- - Come To Daddy (Little Lord Faulteroy Mix), bass group `bass-1` (75 notes): around G1, bell- or metal-like (partials off whole multiples), slow swell, falls 9 dB/s, centered; hear it at 0:24.3, 2:56.1. **[JUDGMENT]** why it waits.
- - Flim, other group `other-2` (185 notes): around A#2, bell- or metal-like (partials off whole multiples), soft attack, falls 18 dB/s, centered; hear it at 2:40.2, 1:37.8. **[JUDGMENT]** why it waits.
- - Come To Daddy (Little Lord Faulteroy Mix), drums group `drums-1` (384 notes): low thump, quick attack, falls 233 dB/s, centered; hear it at 2:57.5, 2:49.6. **[JUDGMENT]** why it waits.
- - To Cure A Weakling Child (Contour Regard), bass group `bass-1` (182 notes): around C#2, harmonic (string/reed/pad-like), soft attack, falls 19 dB/s, centered; hear it at 1:11.7, 3:22.2. **[JUDGMENT]** why it waits.
- - Bucephalus Bouncing Ball, drums group `drums-2` (203 notes): low thump, soft attack, falls 70 dB/s, centered; hear it at 3:31.8, 3:32.0. **[JUDGMENT]** why it waits.
- - IZ-US, bass group `bass-1` (62 notes): around D1, bell- or metal-like (partials off whole multiples), soft attack, falls 15 dB/s, centered; hear it at 2:19.1, 2:38.8. **[JUDGMENT]** why it waits.
- - Funny Little Man, drums group `drums-2` (196 notes): mid snap, quick attack, falls 607 dB/s, centered; hear it at 0:55.9, 2:59.5. **[JUDGMENT]** why it waits.
