## Kyle Jameson - View From Above (draft card from Ears 3 tools, 2026-11-02)

How it was made: 12 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: Skywriting; The Dreams Remain The Same; Your Amber Eyes; Uncharted Spaces. Typical track: Skywriting. Least like the rest: The Dreams Remain The Same, Your Amber Eyes, Uncharted Spaces.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Skywriting**: share of power drums 52%, bass 27%, other 21%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 123 BPM is one and a half times the drum-grid beat of 82.1 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **The Dreams Remain The Same**: share of power drums 6%, bass 7%, other 87%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 112 BPM is half of the drum-grid beat of 224.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Your Amber Eyes**: share of power drums 1%, bass 29%, other 69%, vocals 0%.
  - vocals stem holds 0.3%: bleed on an instrumental, not a voice.
- **Uncharted Spaces**: share of power drums 20%, bass 14%, other 62%, vocals 3%.
  - vocals stem holds 3.1%: bleed on an instrumental, not a voice.
  - meter tool 77 BPM agrees with the drum-grid beat of 76.0 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 77 to 123 BPM (octave-uncertain); keys A aeolian, G ionian, F lydian, C aeolian; mix width -6 to -1 dB; chord changes 16 to 35 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Uncharted Spaces: other group `other-1` (500 notes, 66% of the track's note energy)
- In synth terms: around C2, mixed or noisy partials, slow swell, falls 8 dB/s, centered.
- Hear it at: 6:28.9 (C#1, 0.64 s, +48 dB alone), 6:29.7 (C#1, 0.72 s, +47 dB alone), 6:28.8 (C#1, 0.38 s, +47 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 66 (35 to 132) Hz; attack 269 (58 to 768) ms; decay -8 (-49 to 0) dB/s
  - brightness at the start 480 (260 to 895) Hz; slope over the note 0.00 (-0.37 to 0.35) octaves
  - harmonic share 0.70 (0.28 to 0.90); partials off whole multiples 45 (20 to 100) cents
  - vibrato 0 (0 to 14) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.3 (-6.7 to -2.2) dB; pan 0.07 (-0.12 to 0.21); left-right correlation 0.16 (-0.01 to 0.33)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. The Dreams Remain The Same: other group `other-1` (372 notes, 63% of the track's note energy)
- In synth terms: around C#2, mixed or noisy partials, slow swell, falls 9 dB/s, centered.
- Hear it at: 1:51.4 (A2, 0.88 s, +54 dB alone), 1:58.1 (F#2, 0.57 s, +54 dB alone), 1:27.8 (A#2, 1.22 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 71 (56 to 112) Hz; attack 201 (45 to 499) ms; decay -9 (-32 to 2) dB/s
  - brightness at the start 342 (221 to 469) Hz; slope over the note 0.00 (-0.27 to 0.45) octaves
  - harmonic share 0.75 (0.33 to 0.96); partials off whole multiples 49 (16 to 103) cents
  - vibrato 0 (0 to 8) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-4.0 to -2.1) dB; pan 0.11 (-0.10 to 0.33); left-right correlation 0.14 (-0.01 to 0.30)
- Group quality: weak (silhouette 0.18, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. Your Amber Eyes: other group `other-1` (423 notes, 45% of the track's note energy)
- In synth terms: around D#2, mixed or noisy partials, soft attack, falls 15 dB/s, centered.
- Hear it at: 2:18.4 (F2, 0.22 s, +30 dB alone), 3:40.9 (F1, 0.52 s, +28 dB alone), 3:41.5 (C2, 0.36 s, +25 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 76 (43 to 98) Hz; attack 112 (26 to 255) ms; decay -15 (-53 to -1) dB/s
  - brightness at the start 558 (376 to 794) Hz; slope over the note 0.00 (-0.40 to 0.21) octaves
  - harmonic share 0.67 (0.26 to 0.92); partials off whole multiples 40 (17 to 79) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.6 (-4.6 to -2.5) dB; pan 0.12 (-0.04 to 0.31); left-right correlation 0.09 (-0.13 to 0.29)
- Group quality: weak (silhouette 0.19, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. Your Amber Eyes: bass group `bass-1` (460 notes, 34% of the track's note energy)
- In synth terms: around F2, harmonic (string/reed/pad-like), soft attack, falls 26 dB/s, centered.
- Hear it at: 1:26.0 (F2, 0.2 s, +2 dB alone), 1:17.8 (F2, 0.2 s, +2 dB alone), 2:37.4 (F2, 0.18 s, +2 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 87 (73 to 124) Hz; attack 110 (9 to 243) ms; decay -26 (-483 to 4) dB/s
  - brightness at the start 117 (93 to 194) Hz; slope over the note -0.02 (-0.68 to 0.19) octaves
  - harmonic share 0.99 (0.92 to 1.00); partials off whole multiples 16 (4 to 57) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.1 (-9.0 to -4.1) dB; pan -0.02 (-0.10 to 0.07); left-right correlation 0.97 (0.87 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S5. Skywriting: other group `other-1` (499 notes, 29% of the track's note energy)
- In synth terms: around A2, mixed or noisy partials, slow swell, falls 13 dB/s, centered.
- Hear it at: 3:33.9 (A2, 0.12 s, +20 dB alone), 4:09.6 (E2, 0.75 s, +9 dB alone), 3:49.4 (D3, 0.21 s, +10 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 111 (58 to 264) Hz; attack 170 (46 to 395) ms; decay -13 (-46 to -1) dB/s
  - brightness at the start 642 (446 to 919) Hz; slope over the note 0.00 (-0.26 to 0.35) octaves
  - harmonic share 0.75 (0.29 to 0.94); partials off whole multiples 45 (17 to 121) cents
  - vibrato 0 (0 to 8) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.6 (-8.9 to -4.0) dB; pan -0.00 (-0.12 to 0.12); left-right correlation 0.39 (0.11 to 0.57)
- Group quality: weak (silhouette 0.18, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. Skywriting: drums group `drums-1` (367 notes, 27% of the track's note energy)
- In synth terms: low thump, quick attack, falls 601 dB/s, gets brighter over the note, leans left (-0.17).
- Hear it at: 4:21.6 (A1, 0.23 s, +10 dB alone), 2:03.5 (G#1, 0.24 s, +9 dB alone), 0:49.8 (?, 0.26 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 50 (31 to 56) Hz; attack 35 (35 to 36) ms; decay -601 (-652 to -513) dB/s
  - brightness at the start 200 (114 to 408) Hz; slope over the note 0.36 (-1.37 to 1.66) octaves
  - harmonic share 0.48 (0.09 to 0.99); partials off whole multiples 110 (43 to 197) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.8 (-4.0 to -1.6) dB; pan -0.17 (-0.20 to -0.11); left-right correlation 0.96 (0.72 to 0.97)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S7. The Dreams Remain The Same: other group `other-2` (128 notes, 24% of the track's note energy)
- In synth terms: around C1, mixed or noisy partials, slow swell, falls 17 dB/s, centered.
- Hear it at: 2:00.2 (F#1, 0.9 s, +54 dB alone), 1:04.6 (C1, 0.54 s, +53 dB alone), 1:05.4 (C1, 0.87 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 34 (33 to 50) Hz; attack 258 (106 to 538) ms; decay -17 (-51 to 0) dB/s
  - brightness at the start 339 (264 to 461) Hz; slope over the note 0.00 (-0.32 to 0.43) octaves
  - harmonic share 0.84 (0.48 to 0.98); partials off whole multiples 20 (7 to 56) cents
  - vibrato 0 (0 to 7) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-3.9 to -2.1) dB; pan 0.14 (-0.06 to 0.36); left-right correlation 0.10 (-0.04 to 0.28)
- Group quality: weak (silhouette 0.18, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S8. Uncharted Spaces: drums group `drums-1` (451 notes, 13% of the track's note energy)
- In synth terms: low thump, quick attack, falls 125 dB/s, leans left (-0.28).
- Hear it at: 5:38.2 (C1, 0.22 s, +6 dB alone), 5:52.3 (C1, 0.18 s, +5 dB alone), 4:04.1 (B0, 0.41 s, +4 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 33 (31 to 68) Hz; attack 35 (19 to 94) ms; decay -125 (-200 to -61) dB/s
  - brightness at the start 116 (90 to 206) Hz; slope over the note 0.00 (-0.25 to 0.60) octaves
  - harmonic share 0.18 (0.07 to 0.72); partials off whole multiples 138 (73 to 216) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.4 (-11.1 to -3.6) dB; pan -0.28 (-0.32 to -0.13); left-right correlation 0.38 (-0.21 to 0.67)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Skywriting sections:** 18 boundaries at 0:03.0, 0:42.0, 1:05.0, 1:18.0, 1:45.0, 2:06.0, 2:23.0, 2:38.0, 3:00.0, 3:24.0, 3:45.0, 3:56.0; section lengths median 18 s (range 3 to 39). Reliable for sections of 10 s or more.
- **Skywriting stem entries and exits:** drums plays 96% of the time (in: 4:20.5; out: 4:10.5, 5:54.0); bass plays 96% of the time (in: 4:21.0; out: 4:13.0, 5:53.5); other plays 98% of the time (in: 0:01.5; out: 5:52.5); vocals plays 5% of the time (in: 1:09.5, 1:56.0, 3:46.0, 5:29.0; out: 1:13.0, 2:03.0, 3:50.0, 5:33.5).
- **Skywriting floor drops (kick and bass out 2 s or more while the rest plays):** 0.37 a minute: 4:11.8 for 3.2 s, 4:14.8 for 6.2 s.
- **Skywriting brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:15.0 to 0:21.0; mix up 1.2 oct 0:54.5 to 1:00.5; mix up 2.6 oct 1:04.5 to 1:09.5; mix down 0.7 oct 1:17.5 to 1:24.5; mix up 1.2 oct 1:33.5 to 1:41.0; mix down 1.6 oct 1:46.0 to 1:51.0; mix down 1.1 oct 1:55.5 to 2:01.5; mix down 1.9 oct 2:51.0 to 2:56.0 (25 more in techniques.json).
- **Skywriting echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Skywriting pumping locked to the kick:** bass dips 4.9 dB at the kick (peak 215 ms after, kick every 0.25 s). The tool reads about 70% of the true depth, so this is a floor.
- **Skywriting tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Skywriting stereo movement:** other pan range 0.26; vocals pan range 0.44.
- **The Dreams Remain The Same sections:** 19 boundaries at 0:41.0, 0:58.0, 1:19.0, 1:33.0, 2:02.0, 2:15.0, 2:28.0, 2:40.0, 2:50.0, 3:06.0, 3:20.0, 3:42.0; section lengths median 16 s (range 10 to 41). Reliable for sections of 10 s or more.
- **The Dreams Remain The Same stem entries and exits:** drums plays 46% of the time (in: 0:03.0, 0:14.5, 0:47.5, 1:12.0, 2:47.5; out: 0:07.5, 0:18.5, 0:50.0, 1:18.5, 2:50.0); bass plays 26% of the time (in: 1:13.5, 2:55.0, 3:13.5, 3:48.0, 4:21.0; out: 1:17.5, 3:09.5, 3:35.0, 4:08.0, 4:23.5); other plays 96% of the time (in: 0:06.0; out: 6:00.0); vocals plays 2% of the time (in: 5:33.0; out: 5:41.5).
- **The Dreams Remain The Same floor drops:** low end too sparse to say (on in under 75% of the track).
- **The Dreams Remain The Same brightness sweeps (0.7 octave or more):** mix up 1.7 oct 0:02.0 to 0:09.0; mix up 1.1 oct 0:44.5 to 0:50.5; mix down 0.9 oct 0:57.5 to 1:09.0; mix up 1.0 oct 1:15.0 to 1:20.5; mix up 0.9 oct 2:06.5 to 2:11.5; mix down 1.1 oct 2:14.5 to 2:31.5; mix up 1.2 oct 2:32.0 to 2:41.0; mix down 0.8 oct 2:41.5 to 2:52.5 (35 more in techniques.json).
- **The Dreams Remain The Same echo times:** drums: 264 ms (+11.8 dB, 3 later repeats).
- **The Dreams Remain The Same pumping locked to the kick:** bass dips 1.5 dB at the kick (peak 175 ms after, kick every 0.30 s). The tool reads about 70% of the true depth, so this is a floor.
- **The Dreams Remain The Same tape wobble and speed:** bass wobbles about 18 cents at 1.1 Hz.
- **The Dreams Remain The Same stereo movement:** drums pan range 0.30; bass pan range 0.99; other pan range 0.46; vocals pan range 0.60.
- **Your Amber Eyes sections:** 14 boundaries at 0:03.0, 0:30.0, 0:41.0, 1:08.0, 1:25.0, 1:41.0, 1:59.0, 2:16.0, 2:43.0, 3:04.0, 3:30.0, 3:47.0; section lengths median 17 s (range 3 to 28). Reliable for sections of 10 s or more.
- **Your Amber Eyes stem entries and exits:** drums plays 84% of the time (in: 4:28.5; out: 3:49.5, 4:42.5); bass plays 81% of the time (in: from the start; out: 3:54.0); other plays 82% of the time (in: 0:01.5, 4:32.0; out: 3:54.0, 4:35.0); vocals plays 21% of the time (in: 2:01.5, 2:15.0, 2:49.5, 2:55.5, 3:18.5; out: 2:05.0, 2:17.5, 2:52.0, 3:11.0, 3:27.0).
- **Your Amber Eyes floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Your Amber Eyes brightness sweeps (0.7 octave or more):** mix up 0.9 oct 0:22.0 to 0:30.5; mix down 1.3 oct 0:48.5 to 0:57.0; mix up 1.0 oct 0:57.5 to 1:07.0; mix down 0.7 oct 1:16.0 to 1:21.0; mix up 0.8 oct 1:21.0 to 1:26.5; mix up 1.0 oct 1:47.5 to 1:53.5; mix down 2.1 oct 2:00.0 to 2:05.0; mix up 1.6 oct 2:05.0 to 2:10.0 (21 more in techniques.json).
- **Your Amber Eyes echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Your Amber Eyes pumping locked to the kick:** bass dips 3.8 dB at the kick (peak 170 ms after, kick every 0.38 s). The tool reads about 70% of the true depth, so this is a floor.
- **Your Amber Eyes tape wobble and speed:** other wobbles about 8 cents at 0.8 Hz.
- **Your Amber Eyes stereo movement:** drums pan range 0.52; other pan range 0.45; vocals pan range 0.54.
- **Your Amber Eyes builds:** 4:19.0 to 4:41.0.
- **Uncharted Spaces sections:** 19 boundaries at 0:03.0, 0:22.0, 0:37.0, 0:51.0, 1:28.0, 1:42.0, 1:59.0, 2:28.0, 3:52.0, 4:05.0, 4:18.0, 4:29.0; section lengths median 16 s (range 3 to 84). Reliable for sections of 10 s or more.
- **Uncharted Spaces stem entries and exits:** drums plays 73% of the time (in: 0:36.5, 0:46.5, 1:03.0, 1:25.0, 1:30.0; out: 0:40.5, 0:49.0, 1:12.5, 1:27.5, 1:36.0); bass plays 40% of the time (in: 0:30.5, 1:45.5, 1:56.5, 2:31.5, 3:12.5; out: 0:53.0, 1:49.5, 2:16.5, 3:09.0, 3:52.5); other plays 99% of the time (in: from the start; out: never); vocals plays 23% of the time (in: 0:05.0, 0:16.5, 0:58.0, 1:56.5, 2:32.0; out: 0:11.0, 0:23.0, 1:05.0, 2:04.5, 2:50.5).
- **Uncharted Spaces floor drops:** low end too sparse to say (on in under 75% of the track).
- **Uncharted Spaces brightness sweeps (0.7 octave or more):** mix up 1.5 oct 0:14.0 to 0:20.0; mix down 1.6 oct 0:20.5 to 0:25.5; mix down 1.0 oct 0:37.0 to 0:43.0; mix up 0.9 oct 0:45.0 to 0:53.5; mix up 1.2 oct 2:22.5 to 2:29.5; mix up 1.2 oct 2:38.5 to 2:44.0; mix up 1.4 oct 2:48.5 to 2:56.5; mix down 1.5 oct 2:57.0 to 3:02.5 (49 more in techniques.json).
- **Uncharted Spaces echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Uncharted Spaces pumping locked to the kick:** under 1.5 dB; none found.
- **Uncharted Spaces tape wobble and speed:** other wobbles about 16 cents at 3.8 Hz; bass wobbles about 19 cents at 1.1 Hz; bass speed moves up to 7 cents in 4 s.
- **Uncharted Spaces stereo movement:** drums pan range 0.43; bass pan range 0.77; other pan range 0.44; vocals pan range 0.52.
- **Uncharted Spaces builds:** 0:20.0 to 0:44.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Skywriting meter:** about 123 BPM (could be 62 or 246; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.27); straight eighths; no cross-rhythm claim.
- **Skywriting key and mode:** A aeolian (minor) (low confidence: the key signature margin is 0.017, so read this as a guess); pitch-class weights A 0.12, G 0.11, E 0.11, D 0.11, C 0.09.
- **Skywriting chords:** 35 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.6 to 3.1 s); 35 distinct chords; most time on Asus2 13%, D5 9%, C5 8%, A#sus2 8%. The old counter in this same run said 18; Ears 1's 2-s counter said 12.  59% of the changes land on a beat (chance would be 62%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Skywriting bass:** root-note movement / mixed; 1.18 notes a second; most time on A 0.30, G 0.15, A# 0.15, D 0.12; steps 12%, thirds 7%, fourths and fifths 26%, octaves 19%, repeats 22%.
- **Skywriting top line (from the 'other' stem; read by ear before trusting):** 915 notes, range 17 semitones (10th to 90th percentile); steps 20%, thirds 9%, fourths and fifths 27%, leaps 24%, repeats 19%; median interval 5 semitones; 50% of moves go up; phrases of about 12 notes, arch 46%, rising 21%, falling 21%, flat or wavy 12%. Reliable only when the line sits clearly above its accompaniment.
- **Skywriting repetition:** 92 bars of 3.9 s; strongest repeat distances 1 bars (0.45), 31 bars (-0.01), 19 bars (-0.03); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **The Dreams Remain The Same meter:** about 112 BPM (could be 56 or 223; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim.
- **The Dreams Remain The Same key and mode:** G ionian (major) (low confidence: the key signature margin is 0.005, so read this as a guess); pitch-class weights D 0.13, C 0.12, G 0.11, C# 0.11, D# 0.08.
- **The Dreams Remain The Same chords:** 23 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.8 to 4.5 s); 39 distinct chords; most time on C5 13%, G5 9%, Csus2 9%, Gsus2 8%. The old counter in this same run said 9; Ears 1's 2-s counter said 9.  62% of the changes land on a beat (chance would be 56%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **The Dreams Remain The Same bass:** root-note movement / mixed; 0.19 notes a second; most time on G 0.36, C 0.18, D# 0.16, B 0.09; steps 4%, thirds 1%, fourths and fifths 12%, octaves 0%, repeats 72%.
- **The Dreams Remain The Same top line (from the 'other' stem; read by ear before trusting):** 957 notes, range 10 semitones (10th to 90th percentile); steps 20%, thirds 15%, fourths and fifths 37%, leaps 10%, repeats 18%; median interval 4 semitones; 51% of moves go up; phrases of about 8 notes, arch 42%, rising 21%, falling 14%, flat or wavy 23%. Reliable only when the line sits clearly above its accompaniment.
- **The Dreams Remain The Same repetition:** 85 bars of 4.3 s; strongest repeat distances 1 bars (0.31), 25 bars (0.19), 3 bars (0.09); 0% of bars near-duplicate an earlier bar.
- **Your Amber Eyes meter:** about 78 BPM (could be 39 or 156; the tool cannot tell the beat level), 3 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Your Amber Eyes key and mode:** F lydian (key signature margin 0.049); pitch-class weights E 0.14, F 0.14, D 0.12, C 0.11, A 0.08.
- **Your Amber Eyes chords:** 24 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 0.8 to 4.2 s); 28 distinct chords; most time on Fmaj7 37%, Dmaj7 11%, Cmaj7 6%, D5 5%. The old counter in this same run said 15; Ears 1's 2-s counter said 14.  65% of the changes land on a beat (chance would be 39%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Your Amber Eyes bass:** root-note movement / mixed; 1.49 notes a second; most time on F 0.39, E 0.20, D 0.18, C 0.11; steps 11%, thirds 3%, fourths and fifths 5%, octaves 0%, repeats 78%.
- **Your Amber Eyes top line (from the 'other' stem; read by ear before trusting):** 729 notes, range 13 semitones (10th to 90th percentile); steps 13%, thirds 12%, fourths and fifths 26%, leaps 30%, repeats 20%; median interval 5 semitones; 49% of moves go up; phrases of about 18 notes, arch 58%, rising 8%, falling 25%, flat or wavy 8%. Reliable only when the line sits clearly above its accompaniment.
- **Your Amber Eyes repetition:** 125 bars of 2.3 s; strongest repeat distances 4 bars (0.46), 2 bars (0.40), 8 bars (0.31); 7% of bars near-duplicate an earlier bar.
- **Uncharted Spaces meter:** about 77 BPM (could be 38 or 153; the tool cannot tell the beat level), 3 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Uncharted Spaces key and mode:** C aeolian (minor) (low confidence: the key signature margin is 0.007, so read this as a guess); pitch-class weights C 0.20, F 0.14, G 0.10, A# 0.10, D# 0.09.
- **Uncharted Spaces chords:** 16 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 2.6 s (10th to 90th percentile 0.8 to 7.3 s); 25 distinct chords; most time on F5 21%, Fmin7 15%, C5 14%, F#maj7 10%. The old counter in this same run said 9; Ears 1's 2-s counter said 7.  29% of the changes land on a beat (chance would be 38%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Uncharted Spaces bass:** root-note movement / mixed; 0.35 notes a second; most time on C 0.53, G 0.18, F# 0.09, A# 0.06; steps 6%, thirds 4%, fourths and fifths 4%, octaves 4%, repeats 81%.
- **Uncharted Spaces top line (from the 'other' stem; read by ear before trusting):** 1091 notes, range 16 semitones (10th to 90th percentile); steps 12%, thirds 5%, fourths and fifths 33%, leaps 31%, repeats 19%; median interval 5 semitones; 53% of moves go up; phrases of about 8 notes, arch 38%, rising 19%, falling 27%, flat or wavy 15%. Reliable only when the line sits clearly above its accompaniment.
- **Uncharted Spaces repetition:** 176 bars of 2.4 s; strongest repeat distances 1 bars (0.53), 20 bars (0.12); 0% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Skywriting mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -9 (corr 0.90); low_120_500 -4 (corr 0.40); mid_500_2k -3 (corr 0.36); pres_2k_5k -4 (corr 0.45); air_gt5k -8 (corr 0.70); over time (2-s windows) 10th/50th/90th percentile -5/-4/-2 dB.
- **Skywriting by part:** drums: 47% of the power, width -9 dB, pan -0.16, mono loss 0.5 dB, widest in low_120_500 (-4 dB); bass: 27% of the power, width -7 dB, pan -0.71, mono loss 0.8 dB, widest in sub_lt120 (-6 dB); other: 26% of the power, width -3 dB, pan -0.03, mono loss 1.8 dB, widest in low_120_500 (-3 dB); vocals: 0% of the power, width -6 dB, pan -0.32, mono loss 1.0 dB, widest in mid_500_2k (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **The Dreams Remain The Same mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -2 (corr 0.18); low_120_500 -0 (corr 0.03); mid_500_2k -3 (corr 0.39); pres_2k_5k -2 (corr 0.24); air_gt5k -2 (corr 0.24); over time (2-s windows) 10th/50th/90th percentile -2/-1/0 dB.
- **The Dreams Remain The Same by part:** drums: 7% of the power, width 1 dB, pan -0.10, mono loss 3.5 dB, widest in sub_lt120 (1 dB); bass: 6% of the power, width -2 dB, pan +0.48, mono loss 2.0 dB, widest in sub_lt120 (-2 dB); other: 87% of the power, width -1 dB, pan +0.21, mono loss 2.5 dB, widest in low_120_500 (-0 dB); vocals: 0% of the power, width -0 dB, pan +0.35, mono loss 2.9 dB, widest in pres_2k_5k (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Your Amber Eyes mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -5 (corr 0.52); low_120_500 -1 (corr 0.17); mid_500_2k -1 (corr 0.12); pres_2k_5k -1 (corr 0.14); air_gt5k -2 (corr 0.26); over time (2-s windows) 10th/50th/90th percentile -3/-1/-0 dB.
- **Your Amber Eyes by part:** drums: 1% of the power, width -1 dB, pan +0.44, mono loss 2.4 dB, widest in mid_500_2k (-0 dB); bass: 18% of the power, width -15 dB, pan -0.03, mono loss 0.1 dB, widest in low_120_500 (-13 dB); other: 80% of the power, width -0 dB, pan +0.25, mono loss 2.8 dB, widest in sub_lt120 (-0 dB); vocals: 0% of the power, width -2 dB, pan -0.29, mono loss 2.1 dB, widest in low_120_500 (-1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Uncharted Spaces mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -3 (corr 0.34); low_120_500 -1 (corr 0.11); mid_500_2k -3 (corr 0.30); pres_2k_5k -2 (corr 0.27); air_gt5k -4 (corr 0.47); over time (2-s windows) 10th/50th/90th percentile -3/-1/-0 dB.
- **Uncharted Spaces by part:** drums: 19% of the power, width -3 dB, pan -0.44, mono loss 1.8 dB, widest in sub_lt120 (-3 dB); bass: 12% of the power, width -4 dB, pan -0.55, mono loss 1.5 dB, widest in low_120_500 (-3 dB); other: 66% of the power, width -2 dB, pan +0.10, mono loss 2.3 dB, widest in low_120_500 (-1 dB); vocals: 3% of the power, width -3 dB, pan +0.41, mono loss 1.7 dB, widest in low_120_500 (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Skywriting: 123 BPM, 15 settled chords a minute, 2% of energy above 2 kHz, width -6 dB; The Dreams Remain The Same: 112 BPM, 14 settled chords a minute, 1% of energy above 2 kHz, width -1 dB; Your Amber Eyes: 78 BPM, 15 settled chords a minute, 2% of energy above 2 kHz, width -2 dB; Uncharted Spaces: 77 BPM, 11 settled chords a minute, 2% of energy above 2 kHz, width -2 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Skywriting, bass group `bass-1` (211 notes): around F#1, harmonic (string/reed/pad-like), quick attack, falls 11 dB/s, leans left (-0.44); hear it at 4:29.4, 2:40.9. **[JUDGMENT]** why it waits.
- Your Amber Eyes, other group `other-2` (77 notes): around C3, bell- or metal-like (partials off whole multiples), soft attack, falls 9 dB/s, leans right (+0.24); hear it at 3:42.0, 2:23.8. **[JUDGMENT]** why it waits.
- The Dreams Remain The Same, bass group `bass-1` (24 notes): around G1, harmonic (string/reed/pad-like), slow swell, falls 5 dB/s, leans right (+0.27); hear it at 5:41.8, 3:00.8. **[JUDGMENT]** why it waits.
- Skywriting, bass group `bass-2` (117 notes): around G2, harmonic (string/reed/pad-like), quick attack, falls 17 dB/s, leans left (-0.41); hear it at 0:43.2, 0:28.9. **[JUDGMENT]** why it waits.
- Uncharted Spaces, bass group `bass-1` (116 notes): around C2, harmonic (string/reed/pad-like), slow swell, falls 10 dB/s, leans left (-0.27); hear it at 0:44.8, 0:48.2. **[JUDGMENT]** why it waits.
- The Dreams Remain The Same, drums group `drums-1` (164 notes): low thump, quick attack, falls 84 dB/s, centered; hear it at 5:39.7, 3:50.4. **[JUDGMENT]** why it waits.
- Uncharted Spaces, vocals group `vocals-1` (214 notes): around G4, mixed or noisy partials, soft attack, falls 24 dB/s, centered; hear it at 5:42.3, 5:42.1. **[JUDGMENT]** why it waits.
- Uncharted Spaces, bass group `bass-2` (187 notes): around G1, harmonic (string/reed/pad-like), soft attack, falls 4 dB/s, leans left (-0.29); hear it at 2:10.5, 2:05.5. **[JUDGMENT]** why it waits.
- **Across The Heartland** (7:06.0, 152 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 23.10 (high, album median 8.75). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
