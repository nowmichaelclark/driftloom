## Steve Roach - Structures From Silence (draft card from Ears 3 tools, 2026-11-02)

How it was made: EP or short record (3 usable tracks): every track. Deep pass on: Reflections in Suspension; Quiet Friend; Structures From Silence. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Reflections in Suspension**: share of power drums 0%, bass 21%, other 74%, vocals 5%.
  - vocals stem holds 4.5%: bleed on an instrumental, not a voice.
- **Quiet Friend**: share of power drums 0%, bass 3%, other 97%, vocals 0%.
  - bass stem is thin (3.2%): bass notes, pumping and wobble are guesses.
  - vocals stem holds 0.3%: bleed on an instrumental, not a voice.
- **Structures From Silence**: share of power drums 0%, bass 0%, other 100%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 80 to 128 BPM (octave-uncertain); keys F# mixolydian, C# dorian, C lydian; mix width -2 to 0 dB; chord changes 10 to 21 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Structures From Silence: drums group `drums-1` (6 notes, 93% of the track's note energy)
- In synth terms: low thump, soft attack, falls 93 dB/s, gets brighter over the note, centered.
- Hear it at: 4:12.6 (C2, 1.0 s, -23 dB alone), 4:13.8 (A#1, 1.34 s, -33 dB alone), 4:12.5 (C1, 0.24 s, -34 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 47 (32 to 64) Hz; attack 55 (18 to 201) ms; decay -93 (-289 to -29) dB/s
  - brightness at the start 93 (72 to 180) Hz; slope over the note 0.73 (0.00 to 3.08) octaves
  - harmonic share 0.04 (0.03 to 0.70); partials off whole multiples 150 (65 to 238) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -40.2 (-53.1 to -28.0) dB; pan 0.11 (0.04 to 0.64); left-right correlation 0.40 (-0.72 to 0.68)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S2. Reflections in Suspension: other group `other-1` (500 notes, 73% of the track's note energy)
- In synth terms: around F#2, mixed or noisy partials, slow swell, falls 5 dB/s, centered.
- Hear it at: 5:11.8 (E2, 2.98 s, +54 dB alone), 11:16.6 (E2, 1.77 s, +55 dB alone), 5:19.6 (E2, 1.13 s, +53 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 93 (41 to 164) Hz; attack 417 (93 to 1908) ms; decay -5 (-24 to -0) dB/s
  - brightness at the start 483 (284 to 745) Hz; slope over the note 0.14 (-0.29 to 0.94) octaves
  - harmonic share 0.72 (0.33 to 0.97); partials off whole multiples 44 (13 to 121) cents
  - vibrato 2 (0 to 14) cents; detune beating 0.0 (0.0 to 0.4) Hz
  - level against the mix -4.3 (-6.1 to -2.8) dB; pan 0.01 (-0.08 to 0.11); left-right correlation -0.03 (-0.25 to 0.23)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. Quiet Friend: other group `other-1` (290 notes, 51% of the track's note energy)
- In synth terms: around G#2, mixed or noisy partials, slow swell, falls 9 dB/s, centered.
- Hear it at: 9:06.9 (F#2, 1.17 s, +74 dB alone), 9:02.0 (A2, 1.31 s, +70 dB alone), 8:58.7 (C#3, 0.51 s, +75 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 103 (64 to 165) Hz; attack 278 (75 to 903) ms; decay -9 (-44 to -1) dB/s
  - brightness at the start 431 (315 to 653) Hz; slope over the note 0.00 (-0.36 to 0.37) octaves
  - harmonic share 0.74 (0.24 to 0.93); partials off whole multiples 47 (15 to 122) cents
  - vibrato 0 (0 to 19) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.9 (-4.6 to -1.0) dB; pan -0.04 (-0.12 to 0.06); left-right correlation 0.45 (0.10 to 0.64)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. Quiet Friend: other group `other-2` (89 notes, 30% of the track's note energy)
- In synth terms: around C#1, mixed or noisy partials, slow swell, falls 4 dB/s, centered.
- Hear it at: 9:41.6 (C#1, 1.15 s, +72 dB alone), 10:07.5 (F#1, 1.47 s, +69 dB alone), 9:01.4 (F#1, 1.09 s, +71 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 35 (34 to 68) Hz; attack 418 (105 to 1764) ms; decay -4 (-14 to -0) dB/s
  - brightness at the start 309 (205 to 426) Hz; slope over the note 0.11 (-0.18 to 0.62) octaves
  - harmonic share 0.84 (0.40 to 0.98); partials off whole multiples 22 (10 to 67) cents
  - vibrato 6 (0 to 22) cents; detune beating 0.0 (0.0 to 0.7) Hz
  - level against the mix -1.9 (-3.0 to -1.2) dB; pan -0.02 (-0.11 to 0.06); left-right correlation 0.38 (0.05 to 0.57)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. Reflections in Suspension: bass group `bass-1` (241 notes, 18% of the track's note energy)
- In synth terms: around F#1, harmonic (string/reed/pad-like), slow swell, falls 1 dB/s, leans right (+0.17).
- Hear it at: 5:58.1 (G#1, 2.67 s, +0 dB alone), 2:05.0 (G#1, 6.64 s, -0 dB alone), 2:56.4 (G#1, 3.2 s, -1 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 47 (47 to 53) Hz; attack 251 (15 to 1448) ms; decay -1 (-24 to 1) dB/s
  - brightness at the start 144 (122 to 174) Hz; slope over the note 0.00 (-0.13 to 0.17) octaves
  - harmonic share 1.00 (0.99 to 1.00); partials off whole multiples 4 (2 to 11) cents
  - vibrato 0 (0 to 5) cents; detune beating 0.0 (0.0 to 0.3) Hz
  - level against the mix -7.8 (-11.0 to -5.1) dB; pan 0.17 (0.07 to 0.28); left-right correlation 0.77 (0.53 to 0.95)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. Structures From Silence: drums group `drums-2` (47 notes, 7% of the track's note energy)
- In synth terms: mid snap, slow swell, falls 2 dB/s, gets brighter over the note, centered.
- Hear it at: 26:26.3 (C1, 6.78 s, -57 dB alone), 7:12.7 (C1, 6.09 s, -57 dB alone), 23:59.2 (C#1, 6.79 s, -57 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 33 (33 to 57) Hz; attack 602 (105 to 1959) ms; decay -2 (-6 to -0) dB/s
  - brightness at the start 404 (308 to 587) Hz; slope over the note 0.48 (0.00 to 1.53) octaves
  - harmonic share 0.52 (0.13 to 0.81); partials off whole multiples 55 (28 to 150) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -59.1 (-60.4 to -56.6) dB; pan -0.01 (-0.06 to 0.02); left-right correlation -0.70 (-0.85 to -0.54)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Reflections in Suspension sections:** 45 boundaries at 1:31.0, 2:05.0, 2:16.0, 2:28.0, 2:51.0, 3:05.0, 3:23.0, 3:36.0, 3:50.0, 4:07.0, 4:32.0, 5:08.0; section lengths median 14 s (range 10 to 123). Reliable for sections of 10 s or more.
- **Reflections in Suspension stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 70% of the time (in: 1:28.0, 3:35.5, 3:58.0, 4:14.0, 4:40.0; out: 3:26.5, 3:52.5, 4:08.0, 4:25.5, 4:49.0); other plays 91% of the time (in: 0:53.5; out: 16:09.0); vocals plays 47% of the time (in: 0:28.5, 0:47.0, 1:04.5, 1:58.5, 2:17.0; out: 0:42.5, 0:54.0, 1:19.0, 2:12.0, 3:21.0).
- **Reflections in Suspension floor drops:** low end too sparse to say (on in under 75% of the track).
- **Reflections in Suspension brightness sweeps (0.7 octave or more):** mix up 1.0 oct 1:01.5 to 1:09.5; mix down 2.0 oct 1:09.5 to 1:22.0; mix down 1.0 oct 2:00.0 to 2:06.5; mix down 1.0 oct 2:50.0 to 2:57.5; mix down 0.8 oct 3:35.0 to 3:43.0; mix up 1.2 oct 4:56.0 to 5:01.5; mix down 1.1 oct 5:44.5 to 5:52.0; mix down 0.9 oct 5:56.0 to 6:01.0 (85 more in techniques.json).
- **Reflections in Suspension echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Reflections in Suspension pumping locked to the kick:** under 1.5 dB; none found.
- **Reflections in Suspension tape wobble and speed:** other wobbles about 8 cents at 1.7 Hz; bass wobbles about 6 cents at 1.7 Hz; bass speed moves up to 24 cents in 4 s.
- **Reflections in Suspension stereo movement:** bass pan range 0.34; other pan range 0.27.
- **Reflections in Suspension builds:** 0:00.0 to 0:59.0; 1:01.0 to 1:21.0; 1:26.0 to 1:50.0.
- **Quiet Friend sections:** 38 boundaries at 0:02.0, 1:39.0, 1:53.0, 2:09.0, 2:24.0, 2:52.0, 3:09.0, 3:31.0, 3:50.0, 4:03.0, 4:15.0, 4:34.0; section lengths median 16 s (range 2 to 97). Reliable for sections of 10 s or more.
- **Quiet Friend stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 40% of the time (in: 1:50.5, 2:31.5, 2:50.5, 3:12.5, 3:30.0; out: 1:59.5, 2:40.5, 2:58.0, 3:25.5, 3:39.0); other plays 94% of the time (in: 0:07.5, 0:28.5; out: 0:25.0, 12:47.5); vocals plays 4% of the time (in: 0:23.0, 1:43.5, 3:07.5, 3:25.5, 10:52.5; out: 0:08.0, 0:31.0, 1:47.0, 3:14.5, 3:31.5).
- **Quiet Friend floor drops:** low end too sparse to say (on in under 75% of the track).
- **Quiet Friend brightness sweeps (0.7 octave or more):** mix down 0.8 oct 2:19.5 to 2:29.5; mix up 1.2 oct 2:30.0 to 2:35.5; mix up 1.2 oct 2:49.5 to 2:55.0; mix down 1.0 oct 3:01.5 to 3:07.5; mix up 0.9 oct 3:15.5 to 3:22.5; mix up 0.8 oct 4:31.0 to 4:36.5; mix up 0.8 oct 4:52.0 to 4:58.5; mix down 2.1 oct 4:58.5 to 5:05.0 (48 more in techniques.json).
- **Quiet Friend echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Quiet Friend pumping locked to the kick:** bass dips 1.7 dB at the kick (peak 659 ms after, kick every 0.86 s). The tool reads about 70% of the true depth, so this is a floor.
- **Quiet Friend tape wobble and speed:** other wobbles about 15 cents at 3.6 Hz; bass wobbles about 14 cents at 1.2 Hz; bass speed moves up to 10 cents in 4 s.
- **Quiet Friend stereo movement:** drums pan range 0.27; other pan range 0.30; vocals pan range 1.04.
- **Structures From Silence sections:** 83 boundaries at 0:02.0, 0:30.0, 0:44.0, 1:18.0, 1:32.0, 1:48.0, 2:03.0, 2:24.0, 2:36.0, 2:46.0, 3:04.0, 3:38.0; section lengths median 17 s (range 2 to 75). Reliable for sections of 10 s or more.
- **Structures From Silence stem entries and exits:** drums plays 1% of the time (in: 4:10.5, 20:26.5; out: 4:15.5, 20:34.0); bass plays 0% of the time (in: from the start; out: never); other plays 99% of the time (in: 28:10.0; out: 28:07.0, 28:17.5); vocals plays 0% of the time (in: from the start; out: never).
- **Structures From Silence floor drops (kick and bass out 2 s or more while the rest plays):** 0.08 a minute: 12:13.5 for 3.0 s, 14:17.5 for 2.5 s.
- **Structures From Silence brightness sweeps (0.7 octave or more):** mix down 1.6 oct 0:42.0 to 0:59.0; mix up 1.7 oct 0:59.5 to 1:12.5; mix down 1.0 oct 1:55.0 to 2:05.5; mix down 1.4 oct 3:02.0 to 3:18.0; mix up 1.3 oct 3:19.0 to 3:32.5; mix up 0.7 oct 3:49.0 to 3:58.0; mix down 1.2 oct 4:14.0 to 4:25.5; mix up 0.7 oct 5:17.5 to 5:22.5 (264 more in techniques.json).
- **Structures From Silence echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Structures From Silence pumping locked to the kick:** bass dips 3.2 dB at the kick (peak 474 ms after, kick every 0.81 s). The tool reads about 70% of the true depth, so this is a floor.
- **Structures From Silence tape wobble and speed:** other wobbles about 16 cents at 1.8 Hz; other speed moves up to 26 cents in 4 s; bass wobbles about 13 cents at 3.4 Hz.
- **Structures From Silence stereo movement:** bass pan range 0.44, cycling every 13 s; other pan range 0.68, cycling every 16 s.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Reflections in Suspension meter:** about 80 BPM (could be 40 or 161; the tool cannot tell the beat level), bar length unclear (best guess 5, score 0.07); straight eighths; no cross-rhythm claim.
- **Reflections in Suspension key and mode:** F# mixolydian (low confidence: the key signature margin is 0.010, so read this as a guess); pitch-class weights B 0.18, D# 0.14, G# 0.13, F# 0.11, E 0.11.
- **Reflections in Suspension chords:** 21 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 0.7 to 4.9 s); 29 distinct chords; most time on B 21%, G#min 18%, Bsus2 13%, E5 10%. The old counter in this same run said 5; Ears 1's 2-s counter said 5.  41% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Reflections in Suspension bass:** root-note movement / mixed; 0.12 notes a second; most time on F# 0.47, G# 0.36, B 0.13, D# 0.03; steps 21%, thirds 2%, fourths and fifths 11%, octaves 3%, repeats 52%.
- **Reflections in Suspension top line (from the 'other' stem; read by ear before trusting):** 2038 notes, range 12 semitones (10th to 90th percentile); steps 8%, thirds 27%, fourths and fifths 21%, leaps 28%, repeats 15%; median interval 4 semitones; 52% of moves go up; phrases of about 13 notes, arch 32%, rising 37%, falling 15%, flat or wavy 15%. Reliable only when the line sits clearly above its accompaniment.
- **Reflections in Suspension repetition:** 270 bars of 3.7 s; strongest repeat distances 1 bars (0.56), 4 bars (0.43), 8 bars (0.34); 3% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Quiet Friend meter:** about 128 BPM (could be 64 or 256; the tool cannot tell the beat level), bar length unclear (best guess 6, score 0.05); no clear off-beat onsets; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 7:4), which means irregular timing, not a cross-rhythm claim.
- **Quiet Friend key and mode:** C# dorian (key signature margin 0.038); pitch-class weights C# 0.30, G# 0.23, D# 0.09, F# 0.07, E 0.07.
- **Quiet Friend chords:** 10 changes a minute (8 a minute are chords that last 1.5 s or more); median chord 3.9 s (10th to 90th percentile 1.1 to 11.2 s); 20 distinct chords; most time on C#5 44%, C#sus2 13%, C#min7 12%, C#min 6%. The old counter in this same run said 3; Ears 1's 2-s counter said 3.  71% of the changes land on a beat (chance would be 64%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Quiet Friend bass:** pedal (one note held or repeated); 0.36 notes a second; most time on C# 0.71, G# 0.28; steps 1%, thirds 1%, fourths and fifths 3%, octaves 7%, repeats 85%.
- **Quiet Friend top line (from the 'other' stem; read by ear before trusting):** 1821 notes, range 12 semitones (10th to 90th percentile); steps 4%, thirds 27%, fourths and fifths 30%, leaps 18%, repeats 21%; median interval 4 semitones; 51% of moves go up; phrases of about 11 notes, arch 16%, rising 35%, falling 19%, flat or wavy 29%. Reliable only when the line sits clearly above its accompaniment.
- **Quiet Friend repetition:** 285 bars of 2.8 s; strongest repeat distances 1 bars (0.64), 8 bars (0.34), 24 bars (0.18); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Structures From Silence meter:** about 102 BPM (could be 51 or 204; the tool cannot tell the beat level), bar length unclear (best guess 12, score 0.04); swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim.
- **Structures From Silence key and mode:** C lydian (key signature margin 0.030); pitch-class weights G 0.20, E 0.20, C 0.19, A 0.10, D 0.09.
- **Structures From Silence chords:** 11 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 4.2 s (10th to 90th percentile 1.2 to 11.0 s); 9 distinct chords; most time on C 52%, Amin7 24%, Cmaj7 8%, D 6%. The old counter in this same run said 3; Ears 1's 2-s counter said 4.  52% of the changes land on a beat (chance would be 51%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Structures From Silence top line (from the 'other' stem; read by ear before trusting):** 1552 notes, range 14 semitones (10th to 90th percentile); steps 16%, thirds 19%, fourths and fifths 22%, leaps 18%, repeats 25%; median interval 4 semitones; 50% of moves go up; phrases of about 27 notes, arch 33%, rising 11%, falling 9%, flat or wavy 47%. Reliable only when the line sits clearly above its accompaniment.
- **Structures From Silence repetition:** 85 bars of 7.0 s; strongest repeat distances 1 bars (0.45), 20 bars (0.44), 32 bars (-0.21); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Reflections in Suspension mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -4 (corr 0.55); low_120_500 0 (corr -0.02); mid_500_2k 0 (corr -0.02); pres_2k_5k -3 (corr 0.32); air_gt5k -3 (corr 0.42); over time (2-s windows) 10th/50th/90th percentile -1/0/1 dB.
- **Reflections in Suspension by part:** drums: 0% of the power, width 8 dB, pan +0.03, mono loss 8.8 dB, widest in sub_lt120 (11 dB); bass: 15% of the power, width -7 dB, pan +0.38, mono loss 0.8 dB, widest in low_120_500 (-6 dB); other: 82% of the power, width 0 dB, pan +0.09, mono loss 3.2 dB, widest in low_120_500 (1 dB); vocals: 3% of the power, width -5 dB, pan -0.01, mono loss 1.3 dB, widest in low_120_500 (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Quiet Friend mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -8 (corr 0.79); low_120_500 -1 (corr 0.12); mid_500_2k 0 (corr -0.03); pres_2k_5k -2 (corr 0.25); air_gt5k -2 (corr 0.21); over time (2-s windows) 10th/50th/90th percentile -5/-1/1 dB.
- **Quiet Friend by part:** drums: 0% of the power, width -1 dB, pan -0.07, mono loss 2.4 dB, widest in sub_lt120 (-1 dB); bass: 2% of the power, width -12 dB, pan -0.22, mono loss 0.2 dB, widest in sub_lt120 (-13 dB); other: 98% of the power, width -2 dB, pan -0.13, mono loss 2.2 dB, widest in mid_500_2k (0 dB); vocals: 0% of the power, width 1 dB, pan -0.88, mono loss 3.3 dB, widest in mid_500_2k (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Structures From Silence mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub 1 (corr -0.10); low_120_500 0 (corr -0.03); mid_500_2k -0 (corr 0.02); pres_2k_5k -0 (corr 0.03); air_gt5k -0 (corr 0.06); over time (2-s windows) 10th/50th/90th percentile -1/0/1 dB.
- **Structures From Silence by part:** drums: 0% of the power, width 5 dB, pan -0.30, mono loss 5.9 dB, widest in sub_lt120 (5 dB); bass: 0% of the power, width -4 dB, pan -0.04, mono loss 1.5 dB, widest in sub_lt120 (-0 dB); other: 100% of the power, width 0 dB, pan +0.11, mono loss 3.2 dB, widest in sub_lt120 (1 dB); vocals: 0% of the power, width -11 dB, pan -0.03, mono loss 0.3 dB, widest in sub_lt120 (-8 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Reflections in Suspension: 80 BPM, 11 settled chords a minute, 1% of energy above 2 kHz, width -1 dB; Quiet Friend: 128 BPM, 8 settled chords a minute, 0% of energy above 2 kHz, width -2 dB; Structures From Silence: 102 BPM, 9 settled chords a minute, 0% of energy above 2 kHz, width 0 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Quiet Friend, bass group `bass-1` (203 notes): around C#2, harmonic (string/reed/pad-like), slow swell, falls 20 dB/s, centered; hear it at 12:33.3, 12:44.1. **[JUDGMENT]** why it waits.
- Quiet Friend, bass group `bass-2` (161 notes): around C#1, harmonic (string/reed/pad-like), quick attack, falls 61 dB/s, centered; hear it at 12:55.8, 12:52.1. **[JUDGMENT]** why it waits.
- Reflections in Suspension, vocals group `vocals-1` (390 notes): around G#4, harmonic (string/reed/pad-like), soft attack, falls 57 dB/s, centered; hear it at 3:34.2, 13:34.1. **[JUDGMENT]** why it waits.
- Reflections in Suspension, bass group `bass-2` (45 notes): around D#2, harmonic (string/reed/pad-like), soft attack, falls 7 dB/s, leans right (+0.22); hear it at 15:16.4, 15:15.8. **[JUDGMENT]** why it waits.
- Quiet Friend, vocals group `vocals-1` (242 notes): around F#4, mixed or noisy partials, soft attack, falls 50 dB/s, leans left (-0.23); hear it at 0:04.1, 0:03.5. **[JUDGMENT]** why it waits.
