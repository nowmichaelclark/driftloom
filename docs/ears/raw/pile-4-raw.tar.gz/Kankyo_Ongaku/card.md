## Kankyo Ongaku (draft card from Ears 3 tools, 2026-11-02)

How it was made: 23 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: Park; Apple Star; Variation・III; Umi no Sunatsubu. Typical track: Park. Least like the rest: Apple Star, Variation・III, Umi no Sunatsubu.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Park**: share of power drums 1%, bass 0%, other 98%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.5%: bleed on an instrumental, not a voice.
- **Apple Star**: share of power drums 0%, bass 0%, other 97%, vocals 3%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 3.0%: bleed on an instrumental, not a voice.
- **Variation・III**: share of power drums 14%, bass 2%, other 83%, vocals 1%.
  - bass stem is thin (2.4%): bass notes, pumping and wobble are guesses.
  - vocals stem holds 0.7%: bleed on an instrumental, not a voice.
  - meter tool 109 BPM does not match the drum-grid beat of 235.3 BPM by a simple ratio: listen.
- **Umi no Sunatsubu**: share of power drums 11%, bass 1%, other 88%, vocals 0%.
  - bass stem is near empty (0.9%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 115 BPM agrees with the drum-grid beat of 114.9 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 54 to 115 BPM (octave-uncertain); keys G ionian, C aeolian, G dorian, D# ionian; mix width -5 to 1 dB; chord changes 12 to 32 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Variation・III: other group `other-1` (106 notes, 77% of the track's note energy)
- In synth terms: around A1, bell- or metal-like (partials off whole multiples), slow swell, falls 4 dB/s, centered.
- Hear it at: 3:21.0 (F2, 0.32 s, +62 dB alone), 3:20.7 (E1, 0.21 s, +58 dB alone), 3:21.1 (F3, 0.46 s, +60 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (34 to 99) Hz; attack 506 (95 to 1617) ms; decay -4 (-35 to 0) dB/s
  - brightness at the start 406 (253 to 866) Hz; slope over the note 0.00 (-0.77 to 0.74) octaves
  - harmonic share 0.48 (0.12 to 0.83); partials off whole multiples 69 (31 to 138) cents
  - vibrato 7 (0 to 25) cents; detune beating 0.0 (0.0 to 0.3) Hz
  - level against the mix -2.7 (-7.0 to -1.8) dB; pan 0.07 (-0.03 to 0.18); left-right correlation 0.24 (0.05 to 0.42)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. Park: other group `other-1` (260 notes, 76% of the track's note energy)
- In synth terms: around D2, mixed or noisy partials, slow swell, falls 11 dB/s, centered.
- Hear it at: 0:40.7 (F2, 0.34 s, +54 dB alone), 1:29.9 (G2, 0.28 s, +54 dB alone), 1:31.8 (F2, 0.36 s, +53 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 74 (55 to 99) Hz; attack 304 (85 to 738) ms; decay -11 (-43 to -1) dB/s
  - brightness at the start 311 (207 to 435) Hz; slope over the note 0.00 (-0.52 to 0.26) octaves
  - harmonic share 0.74 (0.13 to 0.96); partials off whole multiples 42 (13 to 107) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-2.3 to -0.7) dB; pan 0.01 (-0.15 to 0.14); left-right correlation 0.55 (0.30 to 0.78)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. Apple Star: other group `other-1` (378 notes, 68% of the track's note energy)
- In synth terms: around C#2, mixed or noisy partials, soft attack, falls 18 dB/s, centered.
- Hear it at: 1:01.1 (D2, 0.73 s, +50 dB alone), 0:31.7 (F2, 0.22 s, +52 dB alone), 0:44.0 (F2, 0.54 s, +51 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 71 (38 to 98) Hz; attack 116 (39 to 240) ms; decay -18 (-46 to -4) dB/s
  - brightness at the start 2129 (1356 to 2879) Hz; slope over the note -0.21 (-1.10 to 0.36) octaves
  - harmonic share 0.66 (0.26 to 0.96); partials off whole multiples 40 (15 to 98) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.2 (-4.2 to -2.2) dB; pan -0.14 (-0.29 to -0.03); left-right correlation -0.03 (-0.25 to 0.24)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. Umi no Sunatsubu: other group `other-1` (310 notes, 58% of the track's note energy)
- In synth terms: around C6, harmonic (string/reed/pad-like), quick attack, falls 104 dB/s, centered.
- Hear it at: 0:00.0 (D#6, 0.96 s, +46 dB alone), 0:56.3 (A#6, 0.13 s, +37 dB alone), 1:02.7 (A#5, 0.1 s, +29 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 1048 (312 to 1682) Hz; attack 23 (10 to 105) ms; decay -104 (-255 to -44) dB/s
  - brightness at the start 1952 (1250 to 2336) Hz; slope over the note 0.00 (-0.20 to 0.06) octaves
  - harmonic share 0.86 (0.09 to 0.97); partials off whole multiples 46 (0 to 269) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.8 (-4.9 to -1.0) dB; pan 0.00 (-0.03 to 0.56); left-right correlation 0.87 (-0.08 to 0.99)
- Group quality: weak (silhouette 0.25, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. Apple Star: other group `other-2` (122 notes, 26% of the track's note energy)
- In synth terms: around G#3, harmonic (string/reed/pad-like), slow swell, falls 21 dB/s, gets darker over the note, centered.
- Hear it at: 0:31.9 (G3, 0.34 s, +52 dB alone), 0:42.6 (G#3, 0.68 s, +50 dB alone), 2:47.8 (G3, 0.37 s, +51 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 202 (135 to 403) Hz; attack 164 (71 to 409) ms; decay -21 (-42 to -6) dB/s
  - brightness at the start 1997 (1011 to 2814) Hz; slope over the note -0.53 (-1.51 to 0.04) octaves
  - harmonic share 0.88 (0.44 to 0.98); partials off whole multiples 21 (8 to 87) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-3.8 to -2.0) dB; pan -0.12 (-0.24 to -0.02); left-right correlation 0.07 (-0.16 to 0.27)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. Park: other group `other-2` (87 notes, 20% of the track's note energy)
- In synth terms: around F#3, bell- or metal-like (partials off whole multiples), slow swell, falls 15 dB/s, centered.
- Hear it at: 1:44.1 (E3, 0.27 s, +54 dB alone), 1:22.0 (D4, 0.28 s, +52 dB alone), 0:45.1 (D4, 0.53 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 186 (165 to 295) Hz; attack 308 (97 to 639) ms; decay -15 (-58 to 1) dB/s
  - brightness at the start 298 (214 to 366) Hz; slope over the note 0.00 (-0.23 to 0.10) octaves
  - harmonic share 0.38 (0.07 to 0.95); partials off whole multiples 156 (10 to 315) cents
  - vibrato 0 (0 to 19) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-2.9 to -0.7) dB; pan 0.02 (-0.15 to 0.18); left-right correlation 0.60 (0.28 to 0.78)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. Umi no Sunatsubu: drums group `drums-1` (146 notes, 13% of the track's note energy)
- In synth terms: low thump, quick attack, falls 101 dB/s, centered.
- Hear it at: 0:40.6 (A#1, 0.25 s, +7 dB alone), 0:18.6 (C2, 0.22 s, +6 dB alone), 0:55.2 (G#1, 0.19 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (32 to 72) Hz; attack 36 (17 to 75) ms; decay -101 (-158 to -77) dB/s
  - brightness at the start 194 (157 to 235) Hz; slope over the note -0.24 (-0.75 to 0.03) octaves
  - harmonic share 0.14 (0.05 to 0.57); partials off whole multiples 203 (79 to 304) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.4 (-18.6 to -1.9) dB; pan 0.00 (-0.01 to 0.01); left-right correlation 0.99 (0.97 to 0.99)
- Group quality: weak (silhouette 0.22, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. Variation・III: other group `other-2` (16 notes, 9% of the track's note energy)
- In synth terms: around C#4, bell- or metal-like (partials off whole multiples), soft attack, falls 12 dB/s, centered.
- Hear it at: 3:10.6 (G6, 0.43 s, +47 dB alone), 3:10.5 (A#3, 0.13 s, +41 dB alone), 2:02.9 (G4, 2.09 s, +34 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 276 (139 to 1184) Hz; attack 136 (67 to 603) ms; decay -12 (-28 to -3) dB/s
  - brightness at the start 1454 (1331 to 1968) Hz; slope over the note -0.22 (-1.97 to 0.09) octaves
  - harmonic share 0.65 (0.14 to 0.91); partials off whole multiples 65 (13 to 276) cents
  - vibrato 3 (0 to 22) cents; detune beating 0.0 (0.0 to 0.4) Hz
  - level against the mix -3.4 (-14.0 to -2.2) dB; pan 0.11 (0.05 to 0.18); left-right correlation 0.02 (-0.23 to 0.21)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Park sections:** 10 boundaries at 0:02.0, 0:21.0, 0:54.0, 1:30.0, 1:40.0, 1:50.0, 2:42.0, 2:58.0, 3:22.0, 3:36.0; section lengths median 19 s (range 2 to 52). Reliable for sections of 10 s or more.
- **Park stem entries and exits:** drums plays 92% of the time (in: from the start; out: 3:46.5); bass plays 4% of the time (in: 1:33.5, 3:30.0; out: 1:37.5, 3:35.5); other plays 91% of the time (in: from the start; out: 3:43.0); vocals plays 4% of the time (in: 1:56.5, 3:18.5; out: 2:04.0, 3:22.0).
- **Park floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Park brightness sweeps (0.7 octave or more):** mix up 0.8 oct 0:10.0 to 0:15.5; mix down 1.1 oct 1:40.5 to 1:46.5; mix up 1.1 oct 1:47.0 to 1:56.0; mix down 1.5 oct 2:21.5 to 2:26.5; mix up 1.7 oct 2:36.5 to 2:45.5; mix down 1.3 oct 3:05.5 to 3:12.5; mix down 1.1 oct 3:16.5 to 3:24.0; mix up 1.0 oct 3:24.0 to 3:29.0 (16 more in techniques.json).
- **Park echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Park pumping locked to the kick:** bass dips 9.8 dB at the kick (peak 344 ms after, kick every 1.10 s). The tool reads about 70% of the true depth, so this is a floor.
- **Park tape wobble and speed:** other wobbles about 13 cents at 1.5 Hz.
- **Park stereo movement:** drums pan range 0.52; other pan range 0.37.
- **Apple Star sections:** 19 boundaries at 0:02.0, 0:21.0, 0:50.0, 1:05.0, 1:16.0, 1:36.0, 1:56.0, 2:13.0, 2:40.0, 2:56.0, 3:17.0, 3:30.0; section lengths median 17 s (range 2 to 45). Reliable for sections of 10 s or more.
- **Apple Star stem entries and exits:** drums plays 4% of the time (in: 0:12.0, 2:31.5, 3:42.0, 4:58.5; out: 0:14.5, 2:34.0, 3:48.5, 5:01.0); bass plays 3% of the time (in: 4:07.0, 4:17.5; out: 4:13.0, 4:24.0); other plays 95% of the time (in: from the start; out: 5:44.5); vocals plays 17% of the time (in: 1:27.0, 1:33.0, 1:55.0, 3:13.5, 4:10.5; out: 1:30.5, 1:37.0, 2:11.0, 3:21.0, 4:36.0).
- **Apple Star floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Apple Star brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:23.0 to 0:28.0; mix down 1.5 oct 0:28.0 to 0:33.0; mix up 1.5 oct 2:48.0 to 2:53.0; mix up 0.8 oct 3:37.0 to 3:42.0; mix down 1.0 oct 3:42.0 to 3:47.5; mix up 0.8 oct 4:05.0 to 4:10.0; other up 1.1 oct 0:23.0 to 0:28.0; other down 1.5 oct 0:28.0 to 0:33.0 (11 more in techniques.json).
- **Apple Star echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Apple Star pumping locked to the kick:** other dips 3.0 dB at the kick (peak 229 ms after, kick every 0.37 s); bass dips 3.4 dB at the kick (peak 220 ms after, kick every 0.37 s). The tool reads about 70% of the true depth, so this is a floor.
- **Apple Star tape wobble and speed:** other wobbles about 11 cents at 2.1 Hz.
- **Apple Star stereo movement:** bass pan range 0.12, cycling every 6 s; other pan range 0.17, cycling every 3 s.
- **Variation・III sections:** 11 boundaries at 0:04.0, 0:27.0, 0:37.0, 1:12.0, 1:23.0, 1:40.0, 2:01.0, 2:13.0, 2:24.0, 2:48.0, 3:00.0; section lengths median 14 s (range 4 to 36). Reliable for sections of 10 s or more.
- **Variation・III stem entries and exits:** drums plays 52% of the time (in: 0:06.5, 0:22.5, 0:30.5, 0:42.5, 1:04.0; out: 0:09.0, 0:25.0, 0:36.5, 1:01.0, 1:13.5); bass plays 19% of the time (in: 0:44.0, 1:03.0, 1:41.0, 1:51.0, 2:12.5; out: 0:47.0, 1:06.5, 1:44.0, 1:56.5, 2:20.5); other plays 88% of the time (in: 0:03.0; out: 3:13.5); vocals plays 11% of the time (in: 0:29.5, 1:12.0, 1:20.0, 2:22.0, 2:40.5; out: 0:33.5, 1:14.5, 1:22.5, 2:26.5, 2:45.0).
- **Variation・III floor drops:** low end too sparse to say (on in under 75% of the track).
- **Variation・III brightness sweeps (0.7 octave or more):** mix up 1.4 oct 0:12.0 to 0:20.5; mix up 1.5 oct 0:24.5 to 0:31.5; mix down 2.0 oct 0:31.5 to 0:38.5; mix down 1.3 oct 1:02.5 to 1:07.5; mix up 1.6 oct 1:08.0 to 1:13.0; mix down 1.4 oct 1:20.0 to 1:27.5; mix up 1.0 oct 1:36.5 to 1:41.5; mix up 1.0 oct 1:46.5 to 1:52.5 (35 more in techniques.json).
- **Variation・III echo times:** drums: 289 ms (+3.6 dB, 1 later repeats).
- **Variation・III pumping locked to the kick:** bass dips 4.6 dB at the kick (peak 489 ms after, kick every 0.53 s). The tool reads about 70% of the true depth, so this is a floor.
- **Variation・III tape wobble and speed:** other wobbles about 21 cents at 5.7 Hz.
- **Variation・III stereo movement:** drums pan range 0.78; other pan range 0.32; vocals pan range 0.45.
- **Umi no Sunatsubu sections:** 4 boundaries at 0:03.0, 0:21.0, 0:57.0, 1:07.0; section lengths median 10 s (range 3 to 36). Reliable for sections of 10 s or more.
- **Umi no Sunatsubu stem entries and exits:** drums plays 91% of the time (in: from the start; out: 1:06.5); bass plays 60% of the time (in: 0:05.5; out: 0:49.0); other plays 93% of the time (in: from the start; out: 1:07.0); vocals plays 0% of the time (in: from the start; out: never).
- **Umi no Sunatsubu floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Umi no Sunatsubu brightness sweeps (0.7 octave or more):** mix down 0.7 oct 1:04.5 to 1:10.5; other up 1.0 oct 0:00.0 to 0:07.5; other down 0.9 oct 0:19.0 to 0:27.0; other down 0.7 oct 0:53.0 to 1:01.5; other down 0.8 oct 1:04.5 to 1:10.0; bass down 2.7 oct 0:05.5 to 0:10.5; bass up 1.0 oct 0:11.0 to 0:21.0; bass down 0.8 oct 0:21.0 to 0:27.0 (2 more in techniques.json).
- **Umi no Sunatsubu echo times:** other: 728 ms (+5.4 dB, 1 later repeats).
- **Umi no Sunatsubu pumping locked to the kick:** other dips 5.5 dB at the kick (peak 120 ms after, kick every 0.33 s). The tool reads about 70% of the true depth, so this is a floor.
- **Umi no Sunatsubu tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Umi no Sunatsubu stereo movement:** other pan range 0.57.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Park meter:** about 54 BPM (could be 27 or 109; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.12); swung: off-beat at 0.62 of the beat (triplet feel); no cross-rhythm claim.
- **Park key and mode:** G ionian (major) (key signature margin 0.025); pitch-class weights G 0.23, D 0.20, F# 0.10, C 0.09, A 0.08.
- **Park chords:** 32 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.6 to 4.0 s); 21 distinct chords; most time on G5 19%, C5 13%, G 12%, Csus2 10%. The old counter in this same run said 12; Ears 1's 2-s counter said 12.  30% of the changes land on a beat (chance would be 27%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Park top line (from the 'other' stem; read by ear before trusting):** 513 notes, range 12 semitones (10th to 90th percentile); steps 2%, thirds 22%, fourths and fifths 36%, leaps 18%, repeats 22%; median interval 5 semitones; 50% of moves go up; phrases of about 10 notes, arch 52%, rising 16%, falling 16%, flat or wavy 16%. Reliable only when the line sits clearly above its accompaniment.
- **Park repetition:** 111 bars of 2.2 s; strongest repeat distances 1 bars (0.49), 4 bars (0.42), 11 bars (0.30); 1% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Apple Star meter:** about 78 BPM (could be 39 or 155; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.60 of the beat; no cross-rhythm claim.
- **Apple Star key and mode:** C aeolian (minor) (low confidence: the key signature margin is 0.008, so read this as a guess); pitch-class weights F 0.12, C 0.11, D 0.11, G 0.11, C# 0.11.
- **Apple Star chords:** 12 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 3.8 s (10th to 90th percentile 1.5 to 10.0 s); 12 distinct chords; most time on C#maj7 52%, G#maj7 11%, Dmin7 8%, Cmaj7 8%. The old counter in this same run said 3; Ears 1's 2-s counter said 3.  42% of the changes land on a beat (chance would be 39%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Apple Star bass:** pedal (one note held or repeated); 0.04 notes a second; most time on C# 0.73, B 0.14, E 0.08, C 0.05; steps 23%, thirds 15%, fourths and fifths 0%, octaves 0%, repeats 62%.
- **Apple Star top line (from the 'other' stem; read by ear before trusting):** 847 notes, range 17 semitones (10th to 90th percentile); steps 28%, thirds 6%, fourths and fifths 9%, leaps 25%, repeats 32%; median interval 1 semitones; 51% of moves go up; phrases of about 12 notes, arch 51%, rising 17%, falling 17%, flat or wavy 14%. Reliable only when the line sits clearly above its accompaniment.
- **Apple Star repetition:** 233 bars of 1.5 s; strongest repeat distances 1 bars (0.66), 13 bars (0.14), 20 bars (0.04); 4% of bars near-duplicate an earlier bar.
- **Variation・III meter:** about 109 BPM (could be 55 or 218; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.09); swung: off-beat at 0.78 of the beat; no cross-rhythm claim.
- **Variation・III key and mode:** G dorian (low confidence: the key signature margin is 0.005, so read this as a guess); fits G pentatonic; pitch-class weights G 0.15, E 0.14, F 0.13, D 0.12, A 0.12.
- **Variation・III chords:** 17 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 2.9 s (10th to 90th percentile 1.1 to 6.1 s); 19 distinct chords; most time on Emin7 22%, Fmaj7 19%, Gsus2 11%, G5 10%. The old counter in this same run said 8; Ears 1's 2-s counter said 7.  45% of the changes land on a beat (chance would be 55%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Variation・III bass:** root-note movement / mixed; 0.22 notes a second; most time on G 0.38, D 0.20, B 0.16, A 0.13; steps 9%, thirds 9%, fourths and fifths 9%, octaves 11%, repeats 43%.
- **Variation・III top line (from the 'other' stem; read by ear before trusting):** 337 notes, range 10 semitones (10th to 90th percentile); steps 17%, thirds 4%, fourths and fifths 37%, leaps 17%, repeats 25%; median interval 5 semitones; 50% of moves go up; phrases of about 9 notes, arch 11%, rising 11%, falling 33%, flat or wavy 44%. Reliable only when the line sits clearly above its accompaniment.
- **Variation・III repetition:** 196 bars of 1.1 s; strongest repeat distances 1 bars (0.59), 18 bars (0.30), 32 bars (0.07); 2% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Umi no Sunatsubu meter:** about 115 BPM (could be 57 or 230; the tool cannot tell the beat level), bar length unclear (best guess 3, score 0.10); swung: off-beat at 0.70 of the beat (triplet feel); no cross-rhythm claim.
- **Umi no Sunatsubu key and mode:** D# ionian (major) (low confidence: the key signature margin is 0.015, so read this as a guess); pitch-class weights D# 0.16, F 0.10, A# 0.10, C 0.09, D 0.09.
- **Umi no Sunatsubu chords:** 22 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.8 to 5.2 s); 11 distinct chords; most time on D#maj7 47%, G#7 15%, Fmin7 12%, Gmin7 7%. The old counter in this same run said 6; Ears 1's 2-s counter said 0.  31% of the changes land on a beat (chance would be 57%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Umi no Sunatsubu top line (from the 'other' stem; read by ear before trusting):** 166 notes, range 15 semitones (10th to 90th percentile); steps 19%, thirds 17%, fourths and fifths 24%, leaps 23%, repeats 16%; median interval 4 semitones; 51% of moves go up; phrases of about 12 notes, arch 50%, rising 20%, falling 20%, flat or wavy 10%. Reliable only when the line sits clearly above its accompaniment.
- **Umi no Sunatsubu repetition:** 46 bars of 1.6 s; strongest repeat distances 1 bars (0.27), 10 bars (0.08), 20 bars (0.01); 2% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Park mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -10 (corr 0.81); low_120_500 -5 (corr 0.51); mid_500_2k -4 (corr 0.39); pres_2k_5k 0 (corr -0.00); air_gt5k -0 (corr 0.02); over time (2-s windows) 10th/50th/90th percentile -7/-5/-3 dB.
- **Park by part:** drums: 1% of the power, width -0 dB, pan +0.14, mono loss 2.9 dB, widest in air_gt5k (-0 dB); bass: 0% of the power, width -35 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-36 dB); other: 98% of the power, width -5 dB, pan -0.02, mono loss 1.3 dB, widest in mid_500_2k (-4 dB); vocals: 0% of the power, width -4 dB, pan +0.23, mono loss 1.6 dB, widest in low_120_500 (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Apple Star mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub 4 (corr -0.48); low_120_500 1 (corr -0.09); mid_500_2k -2 (corr 0.28); pres_2k_5k -1 (corr 0.06); air_gt5k 1 (corr -0.15); over time (2-s windows) 10th/50th/90th percentile -1/-0/2 dB.
- **Apple Star by part:** drums: 0% of the power, width -0 dB, pan -0.20, mono loss 3.0 dB, widest in sub_lt120 (10 dB); bass: 0% of the power, width -15 dB, pan -0.02, mono loss 0.1 dB, widest in sub_lt120 (-17 dB); other: 98% of the power, width 1 dB, pan -0.25, mono loss 3.4 dB, widest in sub_lt120 (4 dB); vocals: 2% of the power, width -7 dB, pan -0.26, mono loss 0.8 dB, widest in pres_2k_5k (-6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Variation・III mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub 2 (corr -0.23); low_120_500 -3 (corr 0.29); mid_500_2k -1 (corr 0.13); pres_2k_5k 0 (corr -0.01); air_gt5k -0 (corr 0.05); over time (2-s windows) 10th/50th/90th percentile -3/-2/-1 dB.
- **Variation・III by part:** drums: 21% of the power, width 2 dB, pan -0.26, mono loss 4.0 dB, widest in sub_lt120 (4 dB); bass: 2% of the power, width -11 dB, pan -0.01, mono loss 0.3 dB, widest in low_120_500 (-10 dB); other: 77% of the power, width -2 dB, pan +0.14, mono loss 2.0 dB, widest in mid_500_2k (-1 dB); vocals: 1% of the power, width -0 dB, pan +0.23, mono loss 3.0 dB, widest in pres_2k_5k (0 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Umi no Sunatsubu mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -23 (corr 0.99); low_120_500 -18 (corr 0.97); mid_500_2k -1 (corr 0.14); pres_2k_5k -11 (corr 0.86); air_gt5k -0 (corr 0.08); over time (2-s windows) 10th/50th/90th percentile -19/-3/0 dB.
- **Umi no Sunatsubu by part:** drums: 7% of the power, width -18 dB, pan +0.00, mono loss 0.1 dB, widest in mid_500_2k (-12 dB); bass: 1% of the power, width -25 dB, pan +0.01, mono loss 0.0 dB, widest in low_120_500 (-25 dB); other: 92% of the power, width -2 dB, pan +0.50, mono loss 2.1 dB, widest in mid_500_2k (-1 dB); vocals: 0% of the power, width -20 dB, pan +0.02, mono loss 0.0 dB, widest in mid_500_2k (-20 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Park: 54 BPM, 15 settled chords a minute, 1% of energy above 2 kHz, width -5 dB; Apple Star: 78 BPM, 11 settled chords a minute, 34% of energy above 2 kHz, width 1 dB; Variation・III: 109 BPM, 14 settled chords a minute, 8% of energy above 2 kHz, width -2 dB; Umi no Sunatsubu: 115 BPM, 14 settled chords a minute, 14% of energy above 2 kHz, width -3 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: Apple Star: 34% of energy above 2 kHz (bright or harsh).

### For later
- Umi no Sunatsubu, other group `other-2` (60 notes): around C2, harmonic (string/reed/pad-like), quick attack, falls 148 dB/s, centered; hear it at 0:57.2, 0:23.2. **[JUDGMENT]** why it waits.
- Umi no Sunatsubu, drums group `drums-2` (129 notes): low thump, quick attack, falls 74 dB/s, gets darker over the note, centered; hear it at 0:02.9, 0:10.0. **[JUDGMENT]** why it waits.
- Apple Star, vocals group `vocals-1` (281 notes): around F4, harmonic (string/reed/pad-like), soft attack, falls 43 dB/s, centered; hear it at 4:22.1, 4:18.8. **[JUDGMENT]** why it waits.
- Variation・III, drums group `drums-1` (17 notes): low thump, quick attack, falls 35 dB/s, leans left (-0.16); hear it at 2:42.3, 2:16.9. **[JUDGMENT]** why it waits.
- Variation・III, bass group `bass-1` (23 notes): around D3, harmonic (string/reed/pad-like), soft attack, falls 18 dB/s, centered; hear it at 3:14.2, 2:15.5. **[JUDGMENT]** why it waits.
- Umi no Sunatsubu, bass group `bass-1` (231 notes): around F#1, bell- or metal-like (partials off whole multiples), quick attack, falls 237 dB/s, centered; hear it at 0:19.1, 0:19.4. **[JUDGMENT]** why it waits.
- **Nemureru Yoru (karaoke version)** (6:25.7, 129 BPM by the mix-level count): stands out for pitch bends a minute 33.75 (high, album median 3.26). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Loom** (5:23.3, 123 BPM by the mix-level count): stands out for pitch bends a minute 24.12 (high, album median 3.26). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Meet Me in the Sheep Meadow** (3:26.0, 103 BPM by the mix-level count): stands out for tail (dB a second) -15.90 (low, album median -2.90); width (side/mid dB) -14.60 (low, album median -4.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Seiko 3** (1:19.7, 136 BPM by the mix-level count): stands out for brightness sweep (octaves) 2.47 (high, album median 0.72). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **A Dream Sails Out to Sea - Scene 3** (6:47.5, 123 BPM by the mix-level count): stands out for brightness sweep (octaves) 1.76 (high, album median 0.72). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Glass Chattering** (5:56.5, 152 BPM by the mix-level count): stands out for width (side/mid dB) -13.70 (low, album median -4.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
