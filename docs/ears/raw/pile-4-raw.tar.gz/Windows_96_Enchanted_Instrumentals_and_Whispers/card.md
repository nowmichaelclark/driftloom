## Windows 96 - Enchanted Instrumentals and Whispers (draft card from Ears 3 tools, 2026-11-02)

How it was made: 12 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: - Lead; - Wasting Time; - Venus Aire; - Golden Triangle. Typical track: - Lead. Least like the rest: - Wasting Time, - Venus Aire, - Golden Triangle.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- Lead**: share of power drums 36%, bass 37%, other 25%, vocals 1%.
  - vocals stem holds 1.4%: bleed on an instrumental, not a voice.
  - meter tool 92 BPM agrees with the drum-grid beat of 92.3 BPM.
- **- Wasting Time**: share of power drums 35%, bass 12%, other 41%, vocals 12%.
  - meter tool 80 BPM agrees with the drum-grid beat of 79.5 BPM.
- **- Venus Aire**: share of power drums 40%, bass 39%, other 18%, vocals 3%.
  - vocals stem holds 3.0%: bleed on an instrumental, not a voice.
  - meter tool 64 BPM is three quarters of the drum-grid beat of 84.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Golden Triangle**: share of power drums 26%, bass 26%, other 44%, vocals 3%.
  - vocals stem holds 2.7%: bleed on an instrumental, not a voice.
  - meter tool 75 BPM agrees with the drum-grid beat of 74.9 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 64 to 92 BPM (octave-uncertain); keys A# aeolian, C# dorian, A aeolian, C# lydian; mix width -8 to -5 dB; chord changes 20 to 39 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Golden Triangle: other group `other-1` (438 notes, 54% of the track's note energy)
- In synth terms: around E2, harmonic (string/reed/pad-like), soft attack, falls 21 dB/s, centered.
- Hear it at: 0:01.2 (G#2, 0.4 s, +57 dB alone), 0:01.6 (G#2, 0.42 s, +56 dB alone), 0:02.9 (C#2, 0.35 s, +57 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 82 (63 to 116) Hz; attack 102 (25 to 287) ms; decay -21 (-46 to -4) dB/s
  - brightness at the start 431 (361 to 539) Hz; slope over the note 0.00 (-0.17 to 0.20) octaves
  - harmonic share 0.90 (0.40 to 0.97); partials off whole multiples 24 (12 to 70) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-7.0 to -0.8) dB; pan -0.05 (-0.18 to 0.06); left-right correlation 0.66 (0.44 to 0.77)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. - Wasting Time: other group `other-1` (377 notes, 38% of the track's note energy)
- In synth terms: around C#2, mixed or noisy partials, soft attack, falls 22 dB/s, centered.
- Hear it at: 2:39.8 (D1, 0.58 s, +46 dB alone), 0:00.0 (G#1, 1.49 s, +35 dB alone), 2:39.5 (E2, 0.58 s, +34 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 70 (35 to 84) Hz; attack 134 (33 to 498) ms; decay -22 (-76 to -3) dB/s
  - brightness at the start 470 (250 to 736) Hz; slope over the note 0.03 (-0.16 to 0.68) octaves
  - harmonic share 0.67 (0.24 to 0.95); partials off whole multiples 41 (15 to 125) cents
  - vibrato 0 (0 to 13) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.8 (-10.4 to -2.0) dB; pan -0.04 (-0.20 to 0.10); left-right correlation 0.07 (-0.31 to 0.77)
- Group quality: weak (silhouette 0.19, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. - Lead: other group `other-1` (359 notes, 36% of the track's note energy)
- In synth terms: around G#2, mixed or noisy partials, slow swell, falls 20 dB/s, centered.
- Hear it at: 0:05.1 (D#2, 1.41 s, +55 dB alone), 0:09.7 (D#2, 1.36 s, +53 dB alone), 0:00.7 (D#2, 0.97 s, +54 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 101 (59 to 194) Hz; attack 164 (48 to 465) ms; decay -20 (-86 to -3) dB/s
  - brightness at the start 828 (482 to 1124) Hz; slope over the note 0.00 (-0.30 to 0.27) octaves
  - harmonic share 0.64 (0.21 to 0.87); partials off whole multiples 51 (24 to 110) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.0 (-12.0 to -2.7) dB; pan -0.02 (-0.13 to 0.08); left-right correlation 0.43 (0.09 to 0.84)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. - Lead: bass group `bass-1` (174 notes, 25% of the track's note energy)
- In synth terms: around A#1, harmonic (string/reed/pad-like), quick attack, falls 29 dB/s, leans left (-0.16).
- Hear it at: 1:44.7 (C2, 1.04 s, +6 dB alone), 1:34.2 (C2, 0.34 s, +8 dB alone), 0:42.0 (C2, 1.06 s, +3 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 59 (39 to 70) Hz; attack 38 (23 to 161) ms; decay -29 (-40 to -11) dB/s
  - brightness at the start 117 (103 to 136) Hz; slope over the note -0.11 (-0.39 to 0.05) octaves
  - harmonic share 1.00 (0.95 to 1.00); partials off whole multiples 3 (1 to 29) cents
  - vibrato 0 (0 to 17) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.6 (-6.4 to -2.5) dB; pan -0.16 (-0.18 to -0.15); left-right correlation 0.99 (0.98 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S5. - Venus Aire: bass group `bass-1` (217 notes, 25% of the track's note energy)
- In synth terms: around F1, harmonic (string/reed/pad-like), soft attack, falls 30 dB/s, centered.
- Hear it at: 3:50.4 (F1, 0.72 s, +11 dB alone), 0:35.2 (F1, 0.85 s, +7 dB alone), 2:20.3 (F1, 0.77 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 44 (41 to 55) Hz; attack 68 (17 to 169) ms; decay -30 (-48 to -12) dB/s
  - brightness at the start 111 (100 to 146) Hz; slope over the note -0.07 (-0.32 to 0.17) octaves
  - harmonic share 1.00 (0.98 to 1.00); partials off whole multiples 4 (1 to 24) cents
  - vibrato 5 (0 to 13) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.6 (-12.0 to -2.4) dB; pan -0.02 (-0.05 to -0.01); left-right correlation 0.99 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. - Venus Aire: other group `other-1` (358 notes, 21% of the track's note energy)
- In synth terms: around G2, mixed or noisy partials, slow swell, falls 13 dB/s, centered.
- Hear it at: 3:30.6 (F3, 0.61 s, +18 dB alone), 3:36.0 (F3, 0.8 s, +18 dB alone), 3:31.5 (F2, 1.09 s, +13 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 98 (74 to 174) Hz; attack 209 (64 to 644) ms; decay -13 (-91 to -1) dB/s
  - brightness at the start 1055 (597 to 1590) Hz; slope over the note 0.00 (-0.44 to 0.18) octaves
  - harmonic share 0.78 (0.38 to 0.97); partials off whole multiples 33 (13 to 71) cents
  - vibrato 0 (0 to 12) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.7 (-11.7 to -3.4) dB; pan -0.12 (-0.30 to 0.05); left-right correlation 0.48 (0.22 to 0.74)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. - Wasting Time: drums group `drums-1` (208 notes, 16% of the track's note energy)
- In synth terms: low thump, quick attack, falls 305 dB/s, gets brighter over the note, centered.
- Hear it at: 2:46.8 (?, 0.21 s, +8 dB alone), 2:42.5 (?, 0.22 s, +7 dB alone), 2:45.0 (?, 0.19 s, +5 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 41 (37 to 60) Hz; attack 13 (13 to 16) ms; decay -305 (-328 to -282) dB/s
  - brightness at the start 84 (77 to 97) Hz; slope over the note 0.92 (0.17 to 3.06) octaves
  - harmonic share 0.71 (0.11 to 0.76); partials off whole multiples 138 (96 to 257) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-3.7 to -1.8) dB; pan 0.09 (0.07 to 0.11); left-right correlation 0.94 (0.93 to 0.95)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. - Golden Triangle: bass group `bass-1` (69 notes, 14% of the track's note energy)
- In synth terms: around D#2, harmonic (string/reed/pad-like), soft attack, falls 8 dB/s, centered.
- Hear it at: 0:21.6 (D#2, 1.64 s, -0 dB alone), 2:20.4 (D#2, 0.41 s, +3 dB alone), 2:11.5 (F#2, 1.69 s, -2 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 78 (65 to 95) Hz; attack 93 (20 to 580) ms; decay -8 (-39 to -3) dB/s
  - brightness at the start 98 (80 to 124) Hz; slope over the note -0.00 (-0.24 to 0.31) octaves
  - harmonic share 1.00 (0.97 to 1.00); partials off whole multiples 6 (1 to 20) cents
  - vibrato 1 (0 to 10) cents; detune beating 0.0 (0.0 to 0.3) Hz
  - level against the mix -5.6 (-13.2 to -3.3) dB; pan 0.08 (-0.06 to 0.15); left-right correlation 0.99 (0.87 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- Lead sections:** 10 boundaries at 0:02.0, 0:21.0, 0:44.0, 1:04.0, 1:14.0, 1:29.0, 1:45.0, 1:56.0, 2:08.0, 2:26.0; section lengths median 15 s (range 2 to 23). Reliable for sections of 10 s or more.
- **- Lead stem entries and exits:** drums plays 77% of the time (in: 0:19.0, 1:13.0; out: 1:03.5, 2:26.5); bass plays 88% of the time (in: 0:12.0; out: 2:26.5); other plays 97% of the time (in: from the start; out: 2:27.5); vocals plays 37% of the time (in: 0:21.0, 0:28.5, 1:08.0, 2:17.0; out: 0:24.0, 0:40.0, 1:42.0, 2:24.5).
- **- Lead floor drops (kick and bass out 2 s or more while the rest plays):** 0.44 a minute: 0:07.5 for 6.5 s.
- **- Lead brightness sweeps (0.7 octave or more):** mix down 1.4 oct 0:11.5 to 0:19.0; mix up 0.9 oct 0:19.0 to 0:24.0; mix down 1.6 oct 1:44.0 to 1:49.0; mix up 1.4 oct 2:23.5 to 2:30.0; other down 0.7 oct 0:12.5 to 0:17.5; other up 1.3 oct 0:18.0 to 0:28.5; other down 0.9 oct 1:04.5 to 1:12.5; bass up 1.3 oct 0:40.0 to 0:45.0 (6 more in techniques.json).
- **- Lead echo times:** drums: 648 ms (+24.4 dB, 2 later repeats).
- **- Lead pumping locked to the kick:** other dips 6.4 dB at the kick (peak 30 ms after, kick every 0.65 s); bass dips 6.3 dB at the kick (peak 304 ms after, kick every 0.65 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Lead tape wobble and speed:** bass speed moves up to 10 cents in 4 s.
- **- Lead stereo movement:** vocals pan range 0.30.
- **- Lead builds:** 0:08.0 to 0:28.0.
- **- Wasting Time sections:** 12 boundaries at 0:02.0, 0:25.0, 0:45.0, 1:13.0, 1:30.0, 1:42.0, 2:01.0, 2:36.0, 2:48.0, 3:11.0, 3:31.0, 3:42.0; section lengths median 19 s (range 2 to 35). Reliable for sections of 10 s or more.
- **- Wasting Time stem entries and exits:** drums plays 81% of the time (in: 0:23.5, 1:35.0, 2:04.5, 2:41.5; out: 1:30.0, 2:01.0, 2:36.5, 3:50.5); bass plays 67% of the time (in: 0:23.5, 1:05.5, 2:23.5, 2:47.5, 2:59.5; out: 1:00.0, 1:59.0, 2:40.0, 2:57.0, 3:02.0); other plays 96% of the time (in: from the start; out: 3:49.0); vocals plays 59% of the time (in: 0:29.5, 0:41.5, 0:53.5, 1:04.0, 1:35.5; out: 0:25.0, 0:32.0, 0:50.5, 0:56.5, 1:30.5).
- **- Wasting Time floor drops (kick and bass out 2 s or more while the rest plays):** 1.40 a minute: 0:11.8 for 12.2 s, 1:33.2 for 2.2 s, 2:00.2 for 5.2 s, 2:06.2 for 5.0 s, 2:38.2 for 3.8 s.
- **- Wasting Time brightness sweeps (0.7 octave or more):** mix up 0.8 oct 0:10.5 to 0:15.5; mix down 1.5 oct 0:20.5 to 0:29.0; mix up 1.2 oct 1:29.0 to 1:34.5; mix down 1.1 oct 1:34.5 to 1:44.0; mix up 0.9 oct 2:04.0 to 2:14.5; mix down 1.7 oct 2:19.0 to 2:28.5; mix down 2.3 oct 3:45.5 to 3:55.5; other up 1.2 oct 0:21.0 to 0:31.0 (18 more in techniques.json).
- **- Wasting Time echo times:** drums: 384 ms (+22.1 dB, 3 later repeats).
- **- Wasting Time pumping locked to the kick:** other dips 6.8 dB at the kick (peak 35 ms after, kick every 0.56 s); bass dips 16.6 dB at the kick (peak 544 ms after, kick every 0.56 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Wasting Time tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Wasting Time stereo movement:** drums pan range 0.14, cycling every 3 s; bass pan range 0.28; other pan range 0.30.
- **- Venus Aire sections:** 14 boundaries at 0:02.0, 1:00.0, 1:31.0, 1:46.0, 2:07.0, 2:22.0, 2:32.0, 2:45.0, 3:01.0, 3:16.0, 3:30.0, 3:53.0; section lengths median 15 s (range 2 to 58). Reliable for sections of 10 s or more.
- **- Venus Aire stem entries and exits:** drums plays 86% of the time (in: 0:29.5, 4:07.0; out: 4:00.5, 4:43.0); bass plays 94% of the time (in: 3:36.0; out: 3:30.0, 4:38.5); other plays 99% of the time (in: from the start; out: 4:47.0); vocals plays 46% of the time (in: 1:00.5, 1:57.0, 3:12.0, 3:27.0, 3:59.0; out: 1:29.0, 2:58.0, 3:23.5, 3:31.0, 4:28.0).
- **- Venus Aire floor drops (kick and bass out 2 s or more while the rest plays):** 0.23 a minute: 4:28.0 for 2.2 s.
- **- Venus Aire brightness sweeps (0.7 octave or more):** mix down 1.1 oct 0:29.5 to 0:34.5; mix down 1.1 oct 0:44.5 to 0:50.5; mix down 2.3 oct 0:56.0 to 1:05.5; mix up 0.8 oct 1:05.5 to 1:11.0; mix down 2.3 oct 1:56.0 to 2:05.0; mix up 1.7 oct 2:05.0 to 2:12.5; mix down 0.8 oct 2:13.0 to 2:20.0; mix up 1.4 oct 2:20.5 to 2:29.5 (23 more in techniques.json).
- **- Venus Aire echo times:** drums: 484 ms (+11.0 dB, 2 later repeats).
- **- Venus Aire pumping locked to the kick:** other dips 3.2 dB at the kick (peak 30 ms after, kick every 0.46 s); bass dips 3.6 dB at the kick (peak 0 ms after, kick every 0.46 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Venus Aire tape wobble and speed:** other wobbles about 5 cents at 6.4 Hz; bass wobbles about 8 cents at 0.6 Hz; bass speed moves up to 20 cents in 4 s.
- **- Venus Aire stereo movement:** drums pan range 0.45, cycling every 4 s; bass pan range 0.28; other pan range 0.40, cycling every 7 s; vocals pan range 0.34.
- **- Golden Triangle sections:** 7 boundaries at 0:02.0, 0:51.0, 1:07.0, 1:18.0, 1:45.0, 1:59.0, 2:37.0; section lengths median 15 s (range 2 to 49). Reliable for sections of 10 s or more.
- **- Golden Triangle stem entries and exits:** drums plays 42% of the time (in: 1:16.5, 1:58.0; out: 1:44.0, 2:37.5); bass plays 86% of the time (in: 0:03.5, 1:15.5, 1:50.0, 1:58.0; out: 1:06.5, 1:47.0, 1:53.5, 2:38.0); other plays 99% of the time (in: from the start; out: 2:38.0); vocals plays 30% of the time (in: 0:23.0, 0:50.0, 1:40.5, 1:48.5; out: 0:36.5, 0:54.5, 1:45.0, 2:14.5).
- **- Golden Triangle floor drops (kick and bass out 2 s or more while the rest plays):** 2.10 a minute: 0:25.5 for 4.2 s, 0:36.8 for 2.5 s, 1:05.0 for 11.5 s, 1:46.0 for 5.0 s, 1:52.5 for 6.2 s.
- **- Golden Triangle brightness sweeps (0.7 octave or more):** mix up 0.9 oct 1:13.0 to 1:20.5; mix down 1.9 oct 2:29.0 to 2:36.0; other up 1.0 oct 1:39.5 to 1:44.5; other down 0.8 oct 1:45.0 to 1:52.5; other up 1.4 oct 1:53.5 to 2:01.5; other down 0.8 oct 2:08.0 to 2:14.0; other up 0.7 oct 2:24.0 to 2:29.0; other down 0.8 oct 2:29.5 to 2:38.0 (9 more in techniques.json).
- **- Golden Triangle echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Golden Triangle pumping locked to the kick:** other dips 1.9 dB at the kick (peak 35 ms after, kick every 0.39 s); bass dips 1.7 dB at the kick (peak 379 ms after, kick every 0.39 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Golden Triangle tape wobble and speed:** other wobbles about 14 cents at 3.8 Hz; bass wobbles about 6 cents at 0.3 Hz; bass speed moves up to 12 cents in 4 s.
- **- Golden Triangle stereo movement:** bass pan range 0.28; other pan range 0.26.
- **- Golden Triangle builds:** 1:12.0 to 1:36.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Lead meter:** about 92 BPM (could be 46 or 184; the tool cannot tell the beat level), bar length unclear (best guess 6, score 0.01); no clear off-beat onsets; no cross-rhythm claim.
- **- Lead key and mode:** A# aeolian (minor) (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights A# 0.13, C# 0.13, D# 0.13, F# 0.12, G# 0.10.
- **- Lead chords:** 30 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 1.4 s (10th to 90th percentile 0.5 to 4.7 s); 21 distinct chords; most time on D#min7 25%, A#5 18%, C#5 12%, G#sus2 8%. The old counter in this same run said 21; Ears 1's 2-s counter said 20.  55% of the changes land on a beat (chance would be 46%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Lead bass:** root-note movement / mixed; 1.99 notes a second; most time on A# 0.27, C# 0.18, D# 0.17, G# 0.14; steps 15%, thirds 7%, fourths and fifths 5%, octaves 0%, repeats 70%.
- **- Lead top line (from the 'other' stem; read by ear before trusting):** 371 notes, range 26 semitones (10th to 90th percentile); steps 11%, thirds 18%, fourths and fifths 16%, leaps 39%, repeats 16%; median interval 6 semitones; 47% of moves go up; phrases of about 8 notes, arch 40%, rising 5%, falling 45%, flat or wavy 10%. Reliable only when the line sits clearly above its accompaniment.
- **- Lead repetition:** 39 bars of 3.9 s; strongest repeat distances 16 bars (0.36), 1 bars (0.33), 19 bars (0.13); 5% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Wasting Time meter:** about 80 BPM (could be 40 or 160; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.56 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Wasting Time key and mode:** C# dorian (key signature margin 0.022); pitch-class weights C# 0.16, G# 0.12, D# 0.11, B 0.10, E 0.10.
- **- Wasting Time chords:** 39 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 1.4 s (10th to 90th percentile 0.7 to 2.7 s); 25 distinct chords; most time on C#min7 26%, G#min7 11%, D#min7 10%, C#5 10%. The old counter in this same run said 22; Ears 1's 2-s counter said 20.  40% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Wasting Time bass:** root-note movement / mixed; 0.84 notes a second; most time on C# 0.47, G# 0.41, D# 0.11; steps 10%, thirds 0%, fourths and fifths 25%, octaves 0%, repeats 63%.
- **- Wasting Time top line (from the 'other' stem; read by ear before trusting):** 535 notes, range 13 semitones (10th to 90th percentile); steps 22%, thirds 33%, fourths and fifths 15%, leaps 13%, repeats 17%; median interval 3 semitones; 50% of moves go up; phrases of about 8 notes, arch 43%, rising 18%, falling 21%, flat or wavy 18%. Reliable only when the line sits clearly above its accompaniment.
- **- Wasting Time repetition:** 79 bars of 3.0 s; strongest repeat distances 2 bars (0.48), 4 bars (0.29), 6 bars (0.10); 9% of bars near-duplicate an earlier bar.
- **- Venus Aire meter:** about 64 BPM (could be 32 or 128; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.75 of the beat; no cross-rhythm claim.
- **- Venus Aire key and mode:** A aeolian (minor) (key signature margin 0.033); pitch-class weights E 0.17, A 0.15, G 0.12, F 0.11, D 0.11.
- **- Venus Aire chords:** 20 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 3.0 s (10th to 90th percentile 0.7 to 7.0 s); 18 distinct chords; most time on E5 21%, Fmaj7 17%, A5 16%, F5 13%. The old counter in this same run said 13; Ears 1's 2-s counter said 12.  33% of the changes land on a beat (chance would be 32%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Venus Aire bass:** root-note movement / mixed; 1.06 notes a second; most time on F 0.27, A 0.24, E 0.24, D 0.16; steps 7%, thirds 4%, fourths and fifths 6%, octaves 26%, repeats 53%.
- **- Venus Aire top line (from the 'other' stem; read by ear before trusting):** 710 notes, range 26 semitones (10th to 90th percentile); steps 8%, thirds 10%, fourths and fifths 17%, leaps 41%, repeats 24%; median interval 7 semitones; 50% of moves go up; phrases of about 11 notes, arch 33%, rising 33%, falling 21%, flat or wavy 12%. Reliable only when the line sits clearly above its accompaniment.
- **- Venus Aire repetition:** 76 bars of 3.8 s; strongest repeat distances 4 bars (0.48), 24 bars (0.27), 16 bars (0.21); 15% of bars near-duplicate an earlier bar.
- **- Golden Triangle meter:** about 75 BPM (could be 37 or 150; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Golden Triangle key and mode:** C# lydian (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights D# 0.15, G# 0.13, F 0.13, C# 0.09, C 0.08.
- **- Golden Triangle chords:** 39 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 1.4 s (10th to 90th percentile 0.5 to 2.6 s); 36 distinct chords; most time on C# 12%, G#5 11%, C#sus2 9%, B 9%. The old counter in this same run said 18; Ears 1's 2-s counter said 17.  45% of the changes land on a beat (chance would be 37%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Golden Triangle bass:** root-note movement / mixed; 0.93 notes a second; most time on C# 0.30, G# 0.22, A# 0.14, F# 0.10; steps 9%, thirds 7%, fourths and fifths 10%, octaves 3%, repeats 65%.
- **- Golden Triangle top line (from the 'other' stem; read by ear before trusting):** 392 notes, range 11 semitones (10th to 90th percentile); steps 22%, thirds 17%, fourths and fifths 21%, leaps 14%, repeats 26%; median interval 3 semitones; 53% of moves go up; phrases of about 12 notes, arch 37%, rising 11%, falling 15%, flat or wavy 37%. Reliable only when the line sits clearly above its accompaniment.
- **- Golden Triangle repetition:** 99 bars of 1.6 s; strongest repeat distances 1 bars (0.53), 4 bars (0.39), 16 bars (0.08); 3% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Lead mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -16 (corr 0.95); low_120_500 -7 (corr 0.70); mid_500_2k -4 (corr 0.42); pres_2k_5k -2 (corr 0.27); air_gt5k -1 (corr 0.10); over time (2-s windows) 10th/50th/90th percentile -10/-5/-3 dB.
- **- Lead by part:** drums: 33% of the power, width -14 dB, pan +0.12, mono loss 0.2 dB, widest in low_120_500 (-11 dB); bass: 34% of the power, width -14 dB, pan -0.32, mono loss 0.2 dB, widest in low_120_500 (-13 dB); other: 31% of the power, width -4 dB, pan -0.03, mono loss 1.5 dB, widest in mid_500_2k (-4 dB); vocals: 2% of the power, width -3 dB, pan -0.08, mono loss 1.7 dB, widest in mid_500_2k (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Wasting Time mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -10 (corr 0.85); low_120_500 -4 (corr 0.48); mid_500_2k -4 (corr 0.41); pres_2k_5k -3 (corr 0.31); air_gt5k -2 (corr 0.28); over time (2-s windows) 10th/50th/90th percentile -9/-3/-0 dB.
- **- Wasting Time by part:** drums: 29% of the power, width -12 dB, pan +0.13, mono loss 0.3 dB, widest in low_120_500 (-11 dB); bass: 10% of the power, width -10 dB, pan -0.53, mono loss 0.4 dB, widest in low_120_500 (-10 dB); other: 51% of the power, width -2 dB, pan -0.09, mono loss 2.0 dB, widest in mid_500_2k (-2 dB); vocals: 10% of the power, width -13 dB, pan -0.03, mono loss 0.2 dB, widest in mid_500_2k (-12 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Venus Aire mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -13 (corr 0.92); low_120_500 -5 (corr 0.50); mid_500_2k -4 (corr 0.46); pres_2k_5k -4 (corr 0.40); air_gt5k -0 (corr 0.01); over time (2-s windows) 10th/50th/90th percentile -8/-5/-1 dB.
- **- Venus Aire by part:** drums: 38% of the power, width -10 dB, pan -0.15, mono loss 0.4 dB, widest in low_120_500 (-10 dB); bass: 34% of the power, width -19 dB, pan -0.09, mono loss 0.1 dB, widest in low_120_500 (-17 dB); other: 23% of the power, width -3 dB, pan -0.24, mono loss 1.6 dB, widest in low_120_500 (1 dB); vocals: 4% of the power, width -1 dB, pan +0.12, mono loss 2.3 dB, widest in mid_500_2k (-1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Golden Triangle mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -14 (corr 0.94); low_120_500 -7 (corr 0.66); mid_500_2k -6 (corr 0.62); pres_2k_5k -5 (corr 0.54); air_gt5k -7 (corr 0.73); over time (2-s windows) 10th/50th/90th percentile -9/-7/-5 dB.
- **- Golden Triangle by part:** drums: 26% of the power, width -10 dB, pan +0.00, mono loss 0.4 dB, widest in low_120_500 (-7 dB); bass: 24% of the power, width -15 dB, pan +0.14, mono loss 0.1 dB, widest in sub_lt120 (-15 dB); other: 48% of the power, width -6 dB, pan -0.10, mono loss 0.9 dB, widest in mid_500_2k (-6 dB); vocals: 3% of the power, width -11 dB, pan +0.14, mono loss 0.3 dB, widest in mid_500_2k (-11 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Lead: 92 BPM, 13 settled chords a minute, 2% of energy above 2 kHz, width -8 dB; - Wasting Time: 80 BPM, 17 settled chords a minute, 3% of energy above 2 kHz, width -5 dB; - Venus Aire: 64 BPM, 13 settled chords a minute, 5% of energy above 2 kHz, width -8 dB; - Golden Triangle: 75 BPM, 17 settled chords a minute, 2% of energy above 2 kHz, width -8 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- - Lead, drums group `drums-1` (179 notes): low thump, quick attack, falls 204 dB/s, gets brighter over the note, centered; hear it at 2:25.4, 1:14.3. **[JUDGMENT]** why it waits.
- - Venus Aire, drums group `drums-1` (196 notes): low thump, quick attack, falls 260 dB/s, gets brighter over the note, centered; hear it at 4:30.9, 2:13.8. **[JUDGMENT]** why it waits.
- - Wasting Time, bass group `bass-1` (216 notes): around C#2, harmonic (string/reed/pad-like), soft attack, falls 72 dB/s, leans left (-0.28); hear it at 2:24.0, 2:36.0. **[JUDGMENT]** why it waits.
- - Venus Aire, bass group `bass-2` (85 notes): around E2, harmonic (string/reed/pad-like), soft attack, falls 36 dB/s, centered; hear it at 3:52.8, 0:04.0. **[JUDGMENT]** why it waits.
- - Wasting Time, vocals group `vocals-1` (216 notes): around B3, mixed or noisy partials, slow swell, falls 45 dB/s, centered; hear it at 1:07.5, 0:04.2. **[JUDGMENT]** why it waits.
- - Venus Aire, drums group `drums-2` (135 notes): mid snap, quick attack, falls 52 dB/s, gets darker over the note, leans left (-0.19); hear it at 3:33.0, 1:59.3. **[JUDGMENT]** why it waits.
- - Golden Triangle, drums group `drums-1` (136 notes): mid snap, quick attack, falls 156 dB/s, gets darker over the note, centered; hear it at 2:01.6, 2:11.2. **[JUDGMENT]** why it waits.
- - Wasting Time, other group `other-2` (123 notes): around C#3, bell- or metal-like (partials off whole multiples), soft attack, falls 28 dB/s, centered; hear it at 1:01.6, 0:52.6. **[JUDGMENT]** why it waits.
- **- Bonita Camisa** (3:18.9, 129 BPM by the mix-level count): stands out for repetition 0.54 (high, album median 0.46). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Illyuziya** (2:46.2, 89 BPM by the mix-level count): stands out for pitch bends a minute 2.89 (low, album median 8.60). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
