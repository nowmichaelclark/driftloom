import sys; sys.path.insert(0,'/home/kruu-mikey/driftloom/tools/ears')
import split, soundfile as sf, numpy as np
split.CHUNK_S, split.OVERLAP_S = 30, 5
print(split.demucs_split_chunked(sys.argv[1], sys.argv[2]+'/chunk', 70.0))
sr=44100
for st in ('drums','bass','other','vocals'):
    x,_=sf.read(sys.argv[2]+'/chunk/'+st+'.wav'); y,_=sf.read(sys.argv[2]+'/whole/'+st+'.wav')
    n=min(len(x),len(y)); d=x[:n]-y[:n]
    def r(a,b): 
        s=slice(int(a*sr),int(b*sr)); return 10*np.log10((d[s]**2).mean()/((y[s]**2).mean()+1e-12)+1e-12)
    print(st, len(x), len(y), 'whole %.1f | near seams (24-31, 49-56 s) %.1f %.1f | away (5-20 s) %.1f'%(r(0,70), r(24,31), r(49,56), r(5,20)))
