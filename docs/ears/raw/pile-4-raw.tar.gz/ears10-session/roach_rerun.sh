#!/bin/bash
# Ears 10: Roach again after the chain, one stage per process (memory is freed between stages)
export TMPDIR=~/ears10/tmp
cd ~/ears10
until grep -q CHAINDONE deep_chain.log; do sleep 30; done
T=/home/kruu-mikey/driftloom/tools/ears
A="Steve Roach - Structures From Silence"
S=$(date +%s)
echo "$(date +%T) START $A (rerun)"
for st in split events techniques theory space check; do
  python3 -P $T/album.py "audio/$A" work --stages $st || echo "FAILED $st"
done
python3 -P $T/album.py "audio/$A" work --stages card || echo "FAILED card"
echo "$(date +%T) END $A $(( $(date +%s) - S )) s"
echo RERUNDONE
