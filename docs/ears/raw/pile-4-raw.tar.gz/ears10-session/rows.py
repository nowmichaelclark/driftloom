import json, sys
d = json.load(open(sys.argv[1] + "/pick.json"))
print("track | s | LUFS | LRA | cent | width | tail | pulse | chg/min | sweep | arc | rep | d60/10 | tune | 2k+")
for r in d["rows"]:
    if "error" in r or "skip" in r: print(r.get("track"), "SKIP"); continue
    d6 = r.get("drift60"); d1 = r.get("drift10")
    hi = (r.get("pres_2k_5k") or 0) + (r.get("air_gt5k") or 0)
    print(" | ".join(str(x) for x in [r["track"][:28], r["seconds"], r["lufs"], r.get("lra"), r.get("centroid_hz"), r.get("width_db"), r.get("tail_db_per_s"), r.get("pulse"), r.get("chord_changes_per_min"), r.get("sweep_oct"), r.get("arc_db"), r.get("repeat"), round(d6/d1,2) if d6 and d1 else None, r.get("tuning_cents"), round(hi,3)]))
