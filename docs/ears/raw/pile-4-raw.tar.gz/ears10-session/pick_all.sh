#!/bin/bash
# Ears 10: the picker on every album (resumes: album.py skips a pick.json that exists)
export TMPDIR=~/ears10/tmp
cd ~/ears10
T=/home/kruu-mikey/driftloom/tools/ears
for A in "Steve Roach - Structures From Silence" "Kankyo Ongaku" "Kyle Jameson - View From Above" "2814 - Birth of a New Day" "Windows 96 - Enchanted Instrumentals and Whispers" "Solar Fields - Mirrors Edge"; do
  W=2
  [ "$A" = "Steve Roach - Structures From Silence" ] && W=1
  python3 -P $T/album.py "audio/$A" work --stages pick --workers $W || echo "FAILED $A"
done
echo ALLDONE
