#!/bin/bash
# Ears 10: deep pass per album, then longform.py on the deep-pass tracks and every track of 8 minutes or more.
# Resumes from the cache: album.py skips finished stages, longform skips finished files.
export TMPDIR=~/ears10/tmp
cd ~/ears10
T=/home/kruu-mikey/driftloom/tools/ears
for A in "$@"; do
  S=$(date +%s)
  echo "$(date +%T) START $A"
  python3 -P $T/album.py "audio/$A" work --workers 2 || echo "FAILED album $A"
  python3 -P ~/ears10/lf_album.py "audio/$A" work || echo "FAILED longform $A"
  echo "$(date +%T) END $A $(( $(date +%s) - S )) s"
done
echo CHAINDONE
