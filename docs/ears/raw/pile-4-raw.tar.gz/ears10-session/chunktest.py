import sys; sys.path.insert(0,'/home/kruu-mikey/driftloom/tools/ears')
import split, soundfile as sf, numpy as np
split.CHUNK_S, split.OVERLAP_S = 30, 5
a=split.split(sys.argv[1], sys.argv[2]+'/chunk', mode='demucs'); print(a)
# reference: whole clip in one piece (seconds given bypasses chunking)
b=split.split(sys.argv[1], sys.argv[2]+'/whole', mode='demucs', seconds=70); print(b)
for st in ('drums','bass','other','vocals'):
    x,_=sf.read(sys.argv[2]+'/chunk/'+st+'.wav'); y,_=sf.read(sys.argv[2]+'/whole/'+st+'.wav')
    n=min(len(x),len(y)); d=x[:n]-y[:n]
    print(st, len(x), len(y), 'diff/whole dB %.1f'%(10*np.log10((d**2).mean()/((y[:n]**2).mean()+1e-12)+1e-12)))
