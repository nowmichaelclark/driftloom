import json, sys, glob, os
for f in sorted(glob.glob(sys.argv[1] + "/longform/*.json")):
    d = json.load(open(f)); L, B = d["level"], d["brightness"]
    print("==", os.path.basename(f)[:-5], d["minutes"], "min")
    print("  level p10/p90 %s/%s range %s; swells %d at %s depth %s spacing %s period %s (ac %s)" % (L["p10_db"], L["p90_db"], L["range_db"], L["swells"], L["swell_peaks_s"], L["swell_depths_db"], L["swell_spacing_s"], L["period_s"], L["period_ac"]))
    print("  bright median %s range %s oct; swells %d at %s depth %s spacing %s period %s (ac %s)" % (B["median_hz"], B["range_oct"], B["swells"], B["swell_peaks_s"], B["swell_depths_oct"], B["swell_spacing_s"], B["period_s"], B["period_ac"]))
    print("  width", d["width"], "change", d["change_rate"])
    print("  sections", d["sections"], "returns", d["returns"])
    print("  travel", d["travel"], "harmony", d["harmony"])
    if len(sys.argv) > 2:
        for r in d["timeline_per_min"]["rows"]: print("   ", r)
