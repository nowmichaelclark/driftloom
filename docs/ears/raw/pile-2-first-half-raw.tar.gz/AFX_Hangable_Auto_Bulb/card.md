## AFX - Hangable Auto Bulb (draft card from Ears 3 tools, 2026-10-18)

How it was made: 9 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: - Children Talking; - Get a Baby; - Every Day. Typical track: - Children Talking. Least like the rest: - Get a Baby, - Every Day.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 80 to 112 BPM (octave-uncertain); keys G locrian, E aeolian, E lydian; mix width -29 to -14 dB; chord changes 33 to 41 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Children Talking: bass group `bass-1` (358 notes, 38% of the track's note energy)
- In synth terms: around C#1, bell- or metal-like (partials off whole multiples), soft attack, falls 37 dB/s, centered.
- Hear it at: 5:12.8 (G#1, 1.53 s, +42 dB alone), 5:13.6 (G1, 4.72 s, +32 dB alone), 4:52.9 (C1, 4.73 s, +14 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 35 (31 to 49) Hz; attack 72 (17 to 293) ms; decay -37 (-146 to -2) dB/s
  - brightness at the start 114 (76 to 150) Hz; slope over the note 0.00 (-0.30 to 1.63) octaves
  - harmonic share 0.34 (0.04 to 0.99); partials off whole multiples 125 (20 to 208) cents
  - vibrato 0 (0 to 18) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.5 (-14.9 to -2.1) dB; pan -0.00 (-0.00 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S2. - Get a Baby: bass group `bass-1` (208 notes, 35% of the track's note energy)
- In synth terms: around D1, harmonic (string/reed/pad-like), quick attack, falls 15 dB/s, centered.
- Hear it at: 2:15.7 (C1, 0.6 s, +11 dB alone), 2:16.3 (?, 0.3 s, +10 dB alone), 2:15.0 (C1, 0.63 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 37 (31 to 42) Hz; attack 38 (19 to 111) ms; decay -15 (-73 to -5) dB/s
  - brightness at the start 101 (88 to 120) Hz; slope over the note 0.04 (-0.18 to 1.52) octaves
  - harmonic share 1.00 (0.92 to 1.00); partials off whole multiples 9 (3 to 49) cents
  - vibrato 0 (0 to 27) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.7 (-7.0 to -1.8) dB; pan -0.01 (-0.02 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S3. - Every Day: other group `other-1` (331 notes, 27% of the track's note energy)
- In synth terms: around F#2, mixed or noisy partials, soft attack, falls 15 dB/s, centered.
- Hear it at: 2:40.1 (F#2, 0.18 s, +27 dB alone), 2:39.8 (F#2, 0.23 s, +22 dB alone), 2:39.7 (F#2, 0.21 s, +21 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 93 (78 to 185) Hz; attack 110 (39 to 383) ms; decay -15 (-47 to -2) dB/s
  - brightness at the start 598 (402 to 870) Hz; slope over the note 0.00 (-0.30 to 0.31) octaves
  - harmonic share 0.69 (0.32 to 0.98); partials off whole multiples 57 (11 to 136) cents
  - vibrato 0 (0 to 1) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.5 (-7.0 to -2.3) dB; pan -0.03 (-0.11 to 0.05); left-right correlation 0.82 (0.72 to 0.90)
- Group quality: weak (silhouette 0.19, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

#### S4. - Every Day: vocals group `vocals-1` (339 notes, 19% of the track's note energy)
- In synth terms: around D4, mixed or noisy partials, soft attack, falls 67 dB/s, centered.
- Hear it at: 2:38.0 (D4, 0.36 s, +7 dB alone), 0:43.7 (A#3, 1.28 s, +3 dB alone), 0:32.2 (A#3, 1.06 s, +4 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 286 (233 to 343) Hz; attack 86 (28 to 279) ms; decay -67 (-305 to -19) dB/s
  - brightness at the start 828 (555 to 989) Hz; slope over the note 0.00 (-0.60 to 0.53) octaves
  - harmonic share 0.82 (0.11 to 0.98); partials off whole multiples 33 (5 to 119) cents
  - vibrato 0 (0 to 13) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.8 (-18.1 to -3.1) dB; pan -0.01 (-0.02 to 0.01); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs), not on the raw mix.

#### S5. - Get a Baby: drums group `drums-1` (231 notes, 16% of the track's note energy)
- In synth terms: low thump, quick attack, falls 277 dB/s, centered.
- Hear it at: 0:44.1 (?, 0.19 s, +16 dB alone), 0:31.0 (?, 0.21 s, +16 dB alone), 0:57.1 (?, 0.18 s, +15 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 41 (32 to 55) Hz; attack 25 (16 to 46) ms; decay -277 (-513 to -121) dB/s
  - brightness at the start 179 (106 to 280) Hz; slope over the note 0.13 (0.00 to 1.74) octaves
  - harmonic share 0.50 (0.14 to 0.93); partials off whole multiples 140 (37 to 254) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.8 (-7.4 to -0.7) dB; pan -0.00 (-0.02 to 0.06); left-right correlation 0.99 (0.89 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S6. - Children Talking: drums group `drums-1` (145 notes, 15% of the track's note energy)
- In synth terms: mid snap, quick attack, falls 34 dB/s, centered.
- Hear it at: 2:08.4 (C#2, 0.1 s, +23 dB alone), 4:08.3 (D1, 0.4 s, +22 dB alone), 4:35.0 (C1, 0.21 s, +23 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 52 (32 to 68) Hz; attack 36 (15 to 145) ms; decay -34 (-70 to -4) dB/s
  - brightness at the start 496 (176 to 1848) Hz; slope over the note -0.02 (-2.68 to 0.65) octaves
  - harmonic share 0.33 (0.08 to 0.89); partials off whole multiples 170 (82 to 286) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-1.9 to -0.1) dB; pan -0.01 (-0.02 to 0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

### Techniques
- **- Children Talking sections:** 15 boundaries at 0:19.0, 0:39.0, 1:34.0, 1:47.0, 2:09.0, 2:27.0, 2:41.0, 2:51.0, 3:08.0, 3:36.0, 3:49.0, 4:31.0; section lengths median 18 s (range 3 to 55). Reliable for sections of 10 s or more.
- **- Children Talking stem entries and exits:** drums plays 95% of the time (in: 4:58.0; out: 4:53.5, 5:13.0); bass plays 71% of the time (in: 0:19.5, 1:51.0, 3:29.0, 4:41.0; out: 1:47.5, 3:09.0, 3:54.5, 5:18.5); other plays 93% of the time (in: 0:02.5, 0:22.5, 3:10.5, 3:42.0; out: 0:19.5, 3:07.5, 3:39.5, 5:12.0); vocals plays 64% of the time (in: 0:09.5, 0:18.5, 0:36.0, 1:00.5, 1:12.0; out: 0:14.5, 0:33.5, 0:57.5, 1:09.5, 1:54.0).
- **- Children Talking floor drops (kick and bass out 2 s or more while the rest plays):** 0.21 a minute: 1:47.8 for 2.0 s.
- **- Children Talking brightness sweeps (0.7 octave or more):** mix up 1.8 oct 0:00.0 to 0:08.0; mix up 2.2 oct 0:43.0 to 0:48.5; mix down 2.4 oct 0:52.0 to 0:57.5; mix down 3.2 oct 1:06.0 to 1:16.5; mix up 2.7 oct 1:16.5 to 1:23.0; mix up 1.2 oct 1:27.5 to 1:33.0; mix up 1.7 oct 1:42.5 to 1:49.0; mix down 4.6 oct 1:49.0 to 1:54.5 (57 more in techniques.json).
- **- Children Talking echo times:** other: 559 ms (+5.3 dB, 1 later repeats).
- **- Children Talking pumping locked to the kick:** other dips 3.6 dB at the kick (peak 155 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Children Talking tape wobble and speed:** bass wobbles about 13 cents at 0.7 Hz.
- **- Children Talking stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Children Talking builds:** 1:44.0 to 2:09.0.
- **- Get a Baby sections:** 6 boundaries at 0:09.0, 0:53.0, 1:06.0, 1:21.0, 1:32.0, 2:18.0; section lengths median 13 s (range 9 to 46). Reliable for sections of 10 s or more.
- **- Get a Baby stem entries and exits:** drums plays 95% of the time (in: from the start; out: 2:20.5); bass plays 94% of the time (in: from the start; out: 2:18.5); other plays 96% of the time (in: from the start; out: 2:21.5); vocals plays 57% of the time (in: 0:06.0, 0:19.0, 1:21.5, 1:33.0; out: 0:13.5, 0:52.5, 1:28.5, 2:09.5).
- **- Get a Baby floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Get a Baby brightness sweeps (0.7 octave or more):** mix up 2.5 oct 0:00.0 to 0:08.5; mix down 1.9 oct 0:34.0 to 0:39.0; mix down 2.0 oct 0:49.5 to 0:54.5; mix down 0.8 oct 1:07.5 to 1:12.5; mix up 1.6 oct 1:13.0 to 1:21.5; mix up 0.7 oct 1:27.5 to 1:33.5; mix up 2.8 oct 2:15.5 to 2:22.0; other down 1.0 oct 0:07.0 to 0:14.0 (15 more in techniques.json).
- **- Get a Baby echo times:** drums: 414 ms (+11.5 dB, 2 later repeats).
- **- Get a Baby pumping locked to the kick:** bass dips 2.9 dB at the kick (peak 299 ms after, kick every 0.30 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Get a Baby tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Get a Baby stereo movement:** other pan range 0.65.
- **- Every Day sections:** 10 boundaries at 0:02.0, 0:26.0, 0:46.0, 1:00.0, 1:25.0, 1:44.0, 2:29.0, 2:53.0, 3:08.0, 3:37.0; section lengths median 20 s (range 2 to 45). Reliable for sections of 10 s or more.
- **- Every Day stem entries and exits:** drums plays 86% of the time (in: 0:56.5, 2:39.5; out: 0:47.0, 2:29.5, 3:38.5); bass plays 89% of the time (in: 0:39.5, 2:51.5, 3:14.0; out: 0:36.5, 2:48.0, 3:11.0, 3:34.0); other plays 96% of the time (in: from the start; out: 3:40.5); vocals plays 75% of the time (in: 0:22.0; out: 3:14.5).
- **- Every Day floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Every Day brightness sweeps (0.7 octave or more):** mix up 1.7 oct 0:05.5 to 0:14.5; mix up 1.6 oct 0:18.5 to 0:24.0; mix up 2.4 oct 0:29.0 to 0:35.5; mix down 1.8 oct 0:36.0 to 0:50.5; mix up 1.3 oct 0:56.5 to 1:03.0; mix down 0.9 oct 1:19.5 to 1:27.0; mix up 0.9 oct 2:01.5 to 2:07.0; mix down 0.8 oct 2:07.0 to 2:12.0 (14 more in techniques.json).
- **- Every Day echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Every Day pumping locked to the kick:** bass dips 5.8 dB at the kick (peak 165 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Every Day tape wobble and speed:** other wobbles about 5 cents at 0.3 Hz.
- **- Every Day stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Children Talking meter:** about 80 BPM (could be 40 or 161; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.22); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Children Talking key and mode:** G locrian (low confidence: the key signature margin is 0.015, so read this as a guess); pitch-class weights C# 0.12, C 0.11, D 0.10, F 0.09, G 0.08.
- **- Children Talking chords:** 34 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.4 s (10th to 90th percentile 0.6 to 3.4 s); 37 distinct chords; most time on C#maj7 19%, Fmaj7 11%, Dmaj7 8%, D#maj7 8%. The old counter in this same run said 7; Ears 1's 2-s counter said 4.  35% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Children Talking bass:** root-note movement / mixed; 0.37 notes a second; most time on G 0.48, C# 0.23, C 0.11, G# 0.11; steps 25%, thirds 6%, fourths and fifths 10%, octaves 1%, repeats 54%.
- **- Children Talking top line (from the 'other' stem; read by ear before trusting):** 713 notes, range 20 semitones (10th to 90th percentile); steps 30%, thirds 20%, fourths and fifths 17%, leaps 23%, repeats 10%; median interval 3 semitones; 51% of moves go up; phrases of about 9 notes, arch 40%, rising 19%, falling 29%, flat or wavy 12%. Reliable only when the line sits clearly above its accompaniment.
- **- Children Talking repetition:** 108 bars of 3.0 s; strongest repeat distances 1 bars (0.56), 29 bars (0.08), 24 bars (0.02); 3% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Get a Baby meter:** about 98 BPM (could be 49 or 196; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.26); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Get a Baby key and mode:** E aeolian (minor) (low confidence: the key signature margin is 0.010, so read this as a guess); pitch-class weights D 0.16, C 0.14, B 0.13, C# 0.09, E 0.08.
- **- Get a Baby chords:** 41 changes a minute (20 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.7 to 1.9 s); 29 distinct chords; most time on C5 14%, E5 11%, Emin7 10%, D5 9%. The old counter in this same run said 27; Ears 1's 2-s counter said 26.  46% of the changes land on a beat (chance would be 49%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Get a Baby bass:** root-note movement / mixed; 1.61 notes a second; most time on E 0.27, B 0.23, C 0.22, D 0.18; steps 20%, thirds 3%, fourths and fifths 12%, octaves 0%, repeats 64%.
- **- Get a Baby top line (from the 'other' stem; read by ear before trusting):** 252 notes, range 15 semitones (10th to 90th percentile); steps 14%, thirds 23%, fourths and fifths 19%, leaps 29%, repeats 16%; median interval 4 semitones; 51% of moves go up; phrases of about 5 notes, arch 38%, rising 0%, falling 38%, flat or wavy 23%. Reliable only when the line sits clearly above its accompaniment.
- **- Get a Baby repetition:** 30 bars of 4.9 s; strongest repeat distances 1 bars (0.39), 11 bars (-0.06), 15 bars (-0.07); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Every Day meter:** about 112 BPM (could be 56 or 224; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.07); swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Every Day key and mode:** E lydian (low confidence: the key signature margin is 0.004, so read this as a guess); pitch-class weights C# 0.18, D# 0.15, A# 0.12, D 0.10, G# 0.09.
- **- Every Day chords:** 33 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 1.6 s (10th to 90th percentile 0.7 to 3.3 s); 24 distinct chords; most time on D#min7 25%, C#sus2 25%, D#maj7 13%, A#dim 10%. The old counter in this same run said 17; Ears 1's 2-s counter said 15.  52% of the changes land on a beat (chance would be 56%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Every Day bass:** root-note movement / mixed; 0.28 notes a second; most time on E 0.47, G# 0.32, F# 0.12, D# 0.07; steps 22%, thirds 6%, fourths and fifths 8%, octaves 3%, repeats 43%.
- **- Every Day top line (from the 'other' stem; read by ear before trusting):** 451 notes, range 12 semitones (10th to 90th percentile); steps 20%, thirds 18%, fourths and fifths 21%, leaps 8%, repeats 32%; median interval 2 semitones; 56% of moves go up; phrases of about 8 notes, arch 29%, rising 6%, falling 24%, flat or wavy 41%. Reliable only when the line sits clearly above its accompaniment.
- **- Every Day repetition:** 107 bars of 2.1 s; strongest repeat distances 3 bars (0.41), 5 bars (0.40), 8 bars (0.27); 1% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Children Talking mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -31 (corr 1.00); low_120_500 -28 (corr 1.00); mid_500_2k -26 (corr 1.00); pres_2k_5k -26 (corr 1.00); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -29/-27/-25 dB.
- **- Children Talking by part:** drums: 60% of the power, width -27 dB, pan -0.02, mono loss 0.0 dB, widest in low_120_500 (-27 dB); bass: 31% of the power, width -39 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-39 dB); other: 2% of the power, width -26 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-24 dB); vocals: 8% of the power, width -31 dB, pan -0.02, mono loss 0.0 dB, widest in pres_2k_5k (-29 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Get a Baby mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 0.99); low_120_500 -11 (corr 0.86); mid_500_2k -11 (corr 0.86); pres_2k_5k -15 (corr 0.94); air_gt5k -17 (corr 0.96); over time (2-s windows) 10th/50th/90th percentile -17/-13/-9 dB.
- **- Get a Baby by part:** drums: 30% of the power, width -17 dB, pan +0.01, mono loss 0.1 dB, widest in low_120_500 (-15 dB); bass: 38% of the power, width -31 dB, pan -0.02, mono loss 0.0 dB, widest in sub_lt120 (-32 dB); other: 14% of the power, width -6 dB, pan -0.02, mono loss 0.9 dB, widest in mid_500_2k (-4 dB); vocals: 18% of the power, width -22 dB, pan +0.04, mono loss 0.0 dB, widest in mid_500_2k (-22 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Every Day mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -27 (corr 1.00); low_120_500 -12 (corr 0.88); mid_500_2k -14 (corr 0.92); pres_2k_5k -16 (corr 0.97); air_gt5k -18 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -15/-13/-11 dB.
- **- Every Day by part:** drums: 28% of the power, width -18 dB, pan +0.10, mono loss 0.1 dB, widest in mid_500_2k (-16 dB); bass: 17% of the power, width -31 dB, pan +0.02, mono loss 0.0 dB, widest in sub_lt120 (-31 dB); other: 35% of the power, width -10 dB, pan -0.04, mono loss 0.4 dB, widest in low_120_500 (-10 dB); vocals: 20% of the power, width -26 dB, pan -0.02, mono loss 0.0 dB, widest in mid_500_2k (-26 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Children Talking: 80 BPM, 15 settled chords a minute, 12% of energy above 2 kHz, width -29 dB; - Get a Baby: 98 BPM, 20 settled chords a minute, 3% of energy above 2 kHz, width -15 dB; - Every Day: 112 BPM, 17 settled chords a minute, 10% of energy above 2 kHz, width -14 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- - Children Talking, vocals group `vocals-1` (354 notes): around D#3, mixed or noisy partials, soft attack, falls 77 dB/s, centered; hear it at 1:48.8, 0:01.5. **[JUDGMENT]** why it waits.
- - Every Day, other group `other-2` (169 notes): around C#4, mixed or noisy partials, soft attack, falls 16 dB/s, centered; hear it at 2:37.0, 3:31.0. **[JUDGMENT]** why it waits.
- - Children Talking, drums group `drums-2` (221 notes): mid snap, quick attack, falls 158 dB/s, centered; hear it at 1:56.7, 4:33.3. **[JUDGMENT]** why it waits.
- - Every Day, bass group `bass-1` (322 notes): around G#1, bell- or metal-like (partials off whole multiples), soft attack, falls 151 dB/s, centered; hear it at 0:01.1, 0:46.5. **[JUDGMENT]** why it waits.
- - Get a Baby, drums group `drums-2` (269 notes): mid snap, soft attack, falls 90 dB/s, centered; hear it at 1:09.1, 1:29.0. **[JUDGMENT]** why it waits.
- - Get a Baby, bass group `bass-2` (70 notes): around B1, harmonic (string/reed/pad-like), quick attack, falls 22 dB/s, centered; hear it at 0:57.3, 1:15.3. **[JUDGMENT]** why it waits.
- - Get a Baby, vocals group `vocals-1` (176 notes): around C4, mixed or noisy partials, soft attack, falls 80 dB/s, centered; hear it at 0:50.7, 0:30.3. **[JUDGMENT]** why it waits.
- - Get a Baby, other group `other-1` (112 notes): around G2, mixed or noisy partials, slow swell, falls 14 dB/s, centered; hear it at 2:18.0, 1:05.3. **[JUDGMENT]** why it waits.
- **- Bit** (0:11.1, 162 BPM by the mix-level count): stands out for wobble (cents) 8.31 (high, album median 4.12); repetition 0.23 (low, album median 0.48). Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- choirDrill** (4:12.0, 172 BPM by the mix-level count): stands out for width (side/mid dB) -21.50 (high, album median -32.45). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
