## Aphex Twin - Ventolin (draft card from Ears 3 tools, 2026-10-18)

How it was made: 14 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: Ventolin [crowsmengegus mix]; Ventolin [praze-an-beeble mix]; Ventolin [asthma beats mix]; hilow [ru,ec,+3]. Typical track: Ventolin [crowsmengegus mix]. Least like the rest: Ventolin [praze-an-beeble mix], Ventolin [asthma beats mix], hilow [ru,ec,+3].
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 68 to 90 BPM (octave-uncertain); keys C lydian, A lydian, D locrian, F dorian; mix width -31 to -10 dB; chord changes 26 to 42 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. hilow [ru,ec,+3]: bass group `bass-1` (176 notes, 49% of the track's note energy)
- In synth terms: around E2, harmonic (string/reed/pad-like), soft attack, falls 21 dB/s, centered.
- Hear it at: 0:20.4 (F2, 0.75 s, +22 dB alone), 1:05.2 (F2, 0.43 s, +22 dB alone), 1:16.0 (F2, 0.76 s, +21 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 83 (66 to 88) Hz; attack 52 (22 to 380) ms; decay -21 (-46 to -8) dB/s
  - brightness at the start 83 (70 to 90) Hz; slope over the note -0.00 (-0.03 to 0.13) octaves
  - harmonic share 1.00 (0.99 to 1.00); partials off whole multiples 3 (1 to 16) cents
  - vibrato 1 (0 to 13) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-3.3 to -0.2) dB; pan -0.05 (-0.06 to -0.03); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S2. Ventolin [crowsmengegus mix]: bass group `bass-1` (351 notes, 35% of the track's note energy)
- In synth terms: around C2, harmonic (string/reed/pad-like), soft attack, falls 48 dB/s, centered.
- Hear it at: 3:28.2 (C#2, 1.11 s, +10 dB alone), 4:30.9 (C#2, 1.94 s, +9 dB alone), 3:27.3 (D2, 0.85 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 66 (55 to 74) Hz; attack 51 (28 to 116) ms; decay -48 (-68 to -13) dB/s
  - brightness at the start 77 (69 to 91) Hz; slope over the note 0.02 (-0.13 to 0.43) octaves
  - harmonic share 1.00 (0.97 to 1.00); partials off whole multiples 8 (1 to 55) cents
  - vibrato 0 (0 to 26) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-6.7 to -1.0) dB; pan 0.03 (0.01 to 0.07); left-right correlation 0.99 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S3. Ventolin [praze-an-beeble mix]: vocals group `vocals-1` (233 notes, 30% of the track's note energy)
- In synth terms: around D#3, bell- or metal-like (partials off whole multiples), soft attack, falls 311 dB/s, centered.
- Hear it at: 3:20.0 (G3, 0.32 s, +49 dB alone), 3:19.4 (G3, 0.45 s, +48 dB alone), 3:18.8 (F2, 0.96 s, +48 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 154 (48 to 315) Hz; attack 48 (16 to 222) ms; decay -311 (-981 to -22) dB/s
  - brightness at the start 666 (267 to 1384) Hz; slope over the note 0.00 (-0.57 to 0.77) octaves
  - harmonic share 0.42 (0.12 to 0.97); partials off whole multiples 65 (15 to 136) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.0 (-4.4 to -0.0) dB; pan -0.05 (-0.06 to -0.03); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs), not on the raw mix.

#### S4. Ventolin [praze-an-beeble mix]: drums group `drums-1` (309 notes, 27% of the track's note energy)
- In synth terms: high tick, quick attack, falls 123 dB/s, centered.
- Hear it at: 0:10.4 (G1, 0.26 s, +39 dB alone), 0:11.2 (A1, 0.16 s, +37 dB alone), 0:11.3 (A1, 0.22 s, +32 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 52 (37 to 741) Hz; attack 30 (12 to 84) ms; decay -123 (-372 to -36) dB/s
  - brightness at the start 2777 (1212 to 3868) Hz; slope over the note -0.24 (-1.80 to 0.07) octaves
  - harmonic share 0.74 (0.18 to 0.99); partials off whole multiples 64 (12 to 145) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.9 (-8.5 to -0.3) dB; pan -0.07 (-0.16 to 0.21); left-right correlation 0.89 (0.75 to 0.97)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S5. Ventolin [asthma beats mix]: other group `other-1` (250 notes, 25% of the track's note energy)
- In synth terms: around B2, bell- or metal-like (partials off whole multiples), soft attack, falls 13 dB/s, centered.
- Hear it at: 0:56.5 (A#2, 0.26 s, +11 dB alone), 1:13.6 (D3, 0.12 s, +12 dB alone), 0:55.1 (D#2, 0.48 s, +10 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 123 (77 to 312) Hz; attack 125 (22 to 312) ms; decay -13 (-134 to 0) dB/s
  - brightness at the start 542 (431 to 825) Hz; slope over the note 0.00 (-0.09 to 0.68) octaves
  - harmonic share 0.41 (0.11 to 0.80); partials off whole multiples 79 (30 to 137) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.9 (-28.3 to -1.2) dB; pan -0.01 (-0.04 to -0.00); left-right correlation 1.00 (0.95 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

#### S6. hilow [ru,ec,+3]: bass group `bass-2` (104 notes, 24% of the track's note energy)
- In synth terms: around A#1, harmonic (string/reed/pad-like), slow swell, falls 50 dB/s, centered.
- Hear it at: 0:15.6 (A1, 0.51 s, +23 dB alone), 0:18.4 (A#1, 0.47 s, +22 dB alone), 0:07.3 (A#1, 0.51 s, +19 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 58 (54 to 59) Hz; attack 186 (43 to 295) ms; decay -50 (-126 to -22) dB/s
  - brightness at the start 69 (66 to 78) Hz; slope over the note 0.01 (-0.08 to 0.55) octaves
  - harmonic share 1.00 (0.91 to 1.00); partials off whole multiples 10 (3 to 169) cents
  - vibrato 0 (0 to 12) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.5 (-3.6 to -0.2) dB; pan -0.02 (-0.04 to 0.01); left-right correlation 0.97 (0.96 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S7. Ventolin [asthma beats mix]: drums group `drums-1` (307 notes, 23% of the track's note energy)
- In synth terms: high tick, quick attack, falls 212 dB/s, centered.
- Hear it at: 0:29.5 (C#2, 0.21 s, +22 dB alone), 0:30.0 (E2, 0.15 s, +22 dB alone), 0:28.9 (A#1, 0.51 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 57 (36 to 1212) Hz; attack 12 (9 to 40) ms; decay -212 (-266 to -144) dB/s
  - brightness at the start 4849 (1777 to 6766) Hz; slope over the note 0.00 (-0.44 to 0.65) octaves
  - harmonic share 0.77 (0.20 to 1.00); partials off whole multiples 47 (4 to 154) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -9.8 (-18.9 to -0.8) dB; pan -0.01 (-0.03 to -0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S8. Ventolin [crowsmengegus mix]: other group `other-1` (360 notes, 15% of the track's note energy)
- In synth terms: around C3, mixed or noisy partials, soft attack, falls 15 dB/s, centered.
- Hear it at: 1:15.8 (D#3, 0.22 s, +34 dB alone), 1:22.0 (D#3, 0.36 s, +32 dB alone), 1:15.5 (D3, 0.11 s, +32 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 130 (81 to 165) Hz; attack 135 (33 to 356) ms; decay -15 (-45 to -1) dB/s
  - brightness at the start 680 (424 to 1364) Hz; slope over the note 0.00 (-0.40 to 0.36) octaves
  - harmonic share 0.80 (0.32 to 0.96); partials off whole multiples 29 (12 to 89) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.1 (-8.4 to -1.1) dB; pan 0.03 (-0.10 to 0.07); left-right correlation 0.91 (0.49 to 1.00)
- Group quality: weak (silhouette 0.21, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

### Techniques
- **Ventolin [crowsmengegus mix] sections:** 14 boundaries at 0:08.0, 0:34.0, 0:54.0, 1:10.0, 1:28.0, 1:38.0, 3:02.0, 3:30.0, 4:05.0, 4:33.0, 5:02.0, 5:14.0; section lengths median 20 s (range 2 to 84). Reliable for sections of 10 s or more.
- **Ventolin [crowsmengegus mix] stem entries and exits:** drums plays 74% of the time (in: 0:07.5, 0:31.5, 1:16.0, 1:26.5, 1:43.0; out: 0:28.5, 1:12.0, 1:20.0, 1:37.5, 3:52.5); bass plays 82% of the time (in: 0:07.0, 1:42.5; out: 1:38.0, 5:02.0); other plays 88% of the time (in: 0:05.5, 1:42.5, 5:30.0; out: 1:39.0, 5:11.5, 5:37.0); vocals plays 34% of the time (in: 0:07.5, 1:16.0, 1:27.5, 5:13.0; out: 1:11.5, 1:21.0, 1:38.5).
- **Ventolin [crowsmengegus mix] floor drops (kick and bass out 2 s or more while the rest plays):** 1.71 a minute: 0:21.8 for 3.2 s, 0:27.0 for 4.8 s, 1:13.5 for 3.0 s, 1:18.8 for 4.0 s, 1:24.5 for 2.5 s, 1:30.0 for 2.8 s, 4:44.5 for 2.5 s, 5:03.8 for 6.2 s.
- **Ventolin [crowsmengegus mix] brightness sweeps (0.7 octave or more):** mix up 3.6 oct 0:00.0 to 0:11.0; mix up 2.3 oct 0:42.5 to 0:48.5; mix down 0.7 oct 0:48.5 to 0:54.0; mix up 1.9 oct 1:14.0 to 1:20.0; mix down 1.5 oct 1:20.0 to 1:26.0; mix up 2.0 oct 1:26.0 to 1:31.0; mix down 3.2 oct 1:37.5 to 1:43.5; mix down 1.7 oct 2:57.0 to 3:04.0 (21 more in techniques.json).
- **Ventolin [crowsmengegus mix] echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Ventolin [crowsmengegus mix] pumping locked to the kick:** bass dips 3.8 dB at the kick (peak 434 ms after, kick every 0.44 s). The tool reads about 70% of the true depth, so this is a floor.
- **Ventolin [crowsmengegus mix] tape wobble and speed:** other wobbles about 8 cents at 1.0 Hz; bass wobbles about 12 cents at 0.7 Hz.
- **Ventolin [crowsmengegus mix] stereo movement:** bass pan range 0.06, cycling every 2 s; vocals pan range 0.26.
- **Ventolin [praze-an-beeble mix] sections:** 11 boundaries at 0:02.0, 0:19.0, 0:34.0, 0:46.0, 1:34.0, 1:47.0, 1:59.0, 2:12.0, 2:26.0, 2:36.0, 2:59.0; section lengths median 14 s (range 2 to 48). Reliable for sections of 10 s or more.
- **Ventolin [praze-an-beeble mix] stem entries and exits:** drums plays 75% of the time (in: 2:22.0, 2:48.5, 2:56.0; out: 2:19.5, 2:25.0, 2:53.5, 3:00.5); bass plays 2% of the time (in: 1:20.0; out: 1:23.5); other plays 85% of the time (in: 0:06.5, 2:35.5, 3:06.5; out: 2:21.5, 3:00.5, 3:17.0); vocals plays 35% of the time (in: 1:53.5, 2:13.5, 3:04.0; out: 2:00.0, 2:59.5).
- **Ventolin [praze-an-beeble mix] floor drops:** low end too sparse to say (on in under 75% of the track).
- **Ventolin [praze-an-beeble mix] brightness sweeps (0.7 octave or more):** mix up 2.9 oct 0:08.0 to 0:15.5; mix down 1.5 oct 0:15.5 to 0:21.0; mix up 1.4 oct 0:21.0 to 0:26.5; mix down 0.8 oct 0:26.5 to 0:32.5; mix up 1.0 oct 0:32.5 to 0:37.5; mix up 2.4 oct 0:41.5 to 0:49.0; mix up 2.4 oct 1:14.5 to 1:22.0; mix up 1.2 oct 1:26.0 to 1:33.5 (40 more in techniques.json).
- **Ventolin [praze-an-beeble mix] echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Ventolin [praze-an-beeble mix] pumping locked to the kick:** other dips 6.7 dB at the kick (peak 519 ms after, kick every 0.66 s); bass dips 2.4 dB at the kick (peak 264 ms after, kick every 0.66 s). The tool reads about 70% of the true depth, so this is a floor.
- **Ventolin [praze-an-beeble mix] tape wobble and speed:** bass wobbles about 5 cents at 0.8 Hz.
- **Ventolin [praze-an-beeble mix] stereo movement:** drums pan range 0.46; other pan range 0.27.
- **Ventolin [asthma beats mix] sections:** 5 boundaries at 0:05.0, 0:28.0, 0:48.0, 1:25.0, 1:35.0; section lengths median 15 s (range 5 to 37). Reliable for sections of 10 s or more.
- **Ventolin [asthma beats mix] stem entries and exits:** drums plays 95% of the time (in: from the start; out: 1:36.5); bass plays 95% of the time (in: from the start; out: 1:36.5); other plays 64% of the time (in: 0:04.0, 0:46.0; out: 0:27.5, 1:26.5); vocals plays 63% of the time (in: 0:08.0, 0:44.5, 0:50.5; out: 0:31.5, 0:47.5, 1:27.5).
- **Ventolin [asthma beats mix] floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Ventolin [asthma beats mix] brightness sweeps (0.7 octave or more):** mix down 4.2 oct 0:30.0 to 0:35.5; mix up 2.8 oct 0:35.5 to 0:41.5; mix down 1.0 oct 1:19.0 to 1:26.0; mix up 3.7 oct 1:31.0 to 1:39.5; other up 1.1 oct 0:00.5 to 0:08.5; other up 2.6 oct 0:23.5 to 0:30.0; other down 2.4 oct 0:30.0 to 0:35.5; other up 3.2 oct 0:36.0 to 0:42.0 (6 more in techniques.json).
- **Ventolin [asthma beats mix] echo times:** other: 180 ms (+4.5 dB, 2 later repeats); drums: 664 ms (+21.4 dB, 1 later repeats).
- **Ventolin [asthma beats mix] pumping locked to the kick:** other dips 2.1 dB at the kick (peak 454 ms after, kick every 0.49 s); bass dips 4.2 dB at the kick (peak 150 ms after, kick every 0.49 s). The tool reads about 70% of the true depth, so this is a floor.
- **Ventolin [asthma beats mix] tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Ventolin [asthma beats mix] stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **hilow [ru,ec,+3] sections:** 7 boundaries at 0:02.0, 0:20.0, 0:54.0, 1:23.0, 1:42.0, 2:00.0, 2:47.0; section lengths median 18 s (range 2 to 47). Reliable for sections of 10 s or more.
- **hilow [ru,ec,+3] stem entries and exits:** drums plays 87% of the time (in: 0:27.0, 1:06.0, 1:13.5; out: 0:18.5, 1:02.5, 1:11.0, 2:48.0); bass plays 96% of the time (in: from the start; out: 2:48.0); other plays 97% of the time (in: from the start; out: 2:50.0); vocals plays 1% of the time (in: 1:33.0; out: 1:35.5).
- **hilow [ru,ec,+3] floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **hilow [ru,ec,+3] brightness sweeps (0.7 octave or more):** mix down 1.2 oct 0:11.0 to 0:17.0; mix up 1.8 oct 0:17.5 to 0:24.5; mix down 0.9 oct 0:37.5 to 0:44.5; mix up 1.0 oct 1:57.5 to 2:02.5; mix down 2.3 oct 2:25.0 to 2:32.0; other down 2.0 oct 0:00.0 to 0:07.5; other up 1.5 oct 0:51.5 to 0:57.5; other down 2.2 oct 1:15.0 to 1:22.0 (6 more in techniques.json).
- **hilow [ru,ec,+3] echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **hilow [ru,ec,+3] pumping locked to the kick:** bass dips 3.4 dB at the kick (peak 0 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **hilow [ru,ec,+3] tape wobble and speed:** other wobbles about 16 cents at 0.4 Hz.
- **hilow [ru,ec,+3] stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Ventolin [crowsmengegus mix] meter:** about 68 BPM (could be 34 or 136; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (5:3, 5:4, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Ventolin [crowsmengegus mix] key and mode:** C lydian (low confidence: the key signature margin is 0.011, so read this as a guess); pitch-class weights C 0.17, D 0.14, C# 0.10, A 0.09, B 0.08.
- **Ventolin [crowsmengegus mix] chords:** 38 changes a minute (8 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.6 to 2.7 s); 44 distinct chords; most time on A#7 22%, Csus2 21%, Amin 7%, E5 5%. The old counter in this same run said 9; Ears 1's 2-s counter said 6.  35% of the changes land on a beat (chance would be 34%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Ventolin [crowsmengegus mix] bass:** root-note movement / mixed; 1.03 notes a second; most time on C 0.23, D 0.21, A 0.18, B 0.11; steps 37%, thirds 26%, fourths and fifths 22%, octaves 0%, repeats 13%.
- **Ventolin [crowsmengegus mix] top line (from the 'other' stem; read by ear before trusting):** 779 notes, range 13 semitones (10th to 90th percentile); steps 28%, thirds 15%, fourths and fifths 26%, leaps 8%, repeats 22%; median interval 2 semitones; 53% of moves go up; phrases of about 8 notes, arch 24%, rising 9%, falling 3%, flat or wavy 64%. Reliable only when the line sits clearly above its accompaniment.
- **Ventolin [crowsmengegus mix] repetition:** 49 bars of 7.1 s; strongest repeat distances 1 bars (0.70), 19 bars (-0.07); 4% of bars near-duplicate an earlier bar.
- **Ventolin [praze-an-beeble mix] meter:** about 86 BPM (could be 43 or 172; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.26); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Ventolin [praze-an-beeble mix] key and mode:** A lydian (low confidence: the key signature margin is 0.001, so read this as a guess); pitch-class weights C# 0.09, D# 0.09, F# 0.09, D 0.09, G 0.09.
- **Ventolin [praze-an-beeble mix] chords:** 39 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.2 s (10th to 90th percentile 0.6 to 2.7 s); 39 distinct chords; most time on Emaj7 12%, C#maj7 7%, F#maj7 7%, F#sus2 6%. The old counter in this same run said 11; Ears 1's 2-s counter said 9.  56% of the changes land on a beat (chance would be 43%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Ventolin [praze-an-beeble mix] bass:** root-note movement / mixed; 0.10 notes a second; most time on A 0.52, C 0.44, G 0.03; steps 0%, thirds 32%, fourths and fifths 0%, octaves 0%, repeats 53%.
- **Ventolin [praze-an-beeble mix] top line (from the 'other' stem; read by ear before trusting):** 393 notes, range 24 semitones (10th to 90th percentile); steps 20%, thirds 12%, fourths and fifths 16%, leaps 40%, repeats 12%; median interval 5 semitones; 52% of moves go up; phrases of about 8 notes, arch 52%, rising 33%, falling 10%, flat or wavy 5%. Reliable only when the line sits clearly above its accompaniment.
- **Ventolin [praze-an-beeble mix] repetition:** 72 bars of 2.8 s; strongest repeat distances 4 bars (0.49), 8 bars (0.38), 1 bars (0.33); 17% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Ventolin [asthma beats mix] meter:** about 90 BPM (could be 45 or 181; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.75 of the beat; no cross-rhythm claim.
- **Ventolin [asthma beats mix] key and mode:** D locrian (low confidence: the key signature margin is 0.005, so read this as a guess); pitch-class weights D 0.10, C 0.09, C# 0.09, G 0.09, D# 0.09.
- **Ventolin [asthma beats mix] chords:** 26 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.7 s (10th to 90th percentile 0.9 to 3.9 s); 18 distinct chords; most time on C#maj7 34%, F#min7 19%, G#maj7 9%, Dmaj7 6%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  45% of the changes land on a beat (chance would be 45%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Ventolin [asthma beats mix] top line (from the 'other' stem; read by ear before trusting):** 196 notes, range 10 semitones (10th to 90th percentile); steps 11%, thirds 16%, fourths and fifths 28%, leaps 23%, repeats 22%; median interval 5 semitones; 49% of moves go up; phrases of about 98 notes, arch 100%, rising 0%, falling 0%, flat or wavy 0%. Reliable only when the line sits clearly above its accompaniment.
- **Ventolin [asthma beats mix] repetition:** 75 bars of 1.3 s; strongest repeat distances 1 bars (0.57), 32 bars (0.24), 8 bars (0.18); 32% of bars near-duplicate an earlier bar.
- **hilow [ru,ec,+3] meter:** about 86 BPM (could be 43 or 173; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.75 of the beat; no cross-rhythm claim.
- **hilow [ru,ec,+3] key and mode:** F dorian (low confidence: the key signature margin is 0.017, so read this as a guess); fits F pentatonic; pitch-class weights F 0.18, D 0.17, D# 0.13, E 0.10, C 0.09.
- **hilow [ru,ec,+3] chords:** 42 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 1.0 to 1.9 s); 20 distinct chords; most time on F5 24%, D5 13%, G#5 12%, A# 12%. The old counter in this same run said 29; Ears 1's 2-s counter said 24.  33% of the changes land on a beat (chance would be 43%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **hilow [ru,ec,+3] bass:** root-note movement / mixed; 1.43 notes a second; most time on F 0.20, D 0.18, D# 0.16, A 0.14; steps 16%, thirds 13%, fourths and fifths 16%, octaves 0%, repeats 45%.
- **hilow [ru,ec,+3] top line (from the 'other' stem; read by ear before trusting):** 334 notes, range 11 semitones (10th to 90th percentile); steps 18%, thirds 19%, fourths and fifths 20%, leaps 24%, repeats 19%; median interval 3 semitones; 54% of moves go up; phrases of about 6 notes, arch 57%, rising 26%, falling 0%, flat or wavy 17%. Reliable only when the line sits clearly above its accompaniment.
- **hilow [ru,ec,+3] repetition:** 63 bars of 2.8 s; strongest repeat distances 2 bars (0.59), 4 bars (0.48), 24 bars (0.32); 0% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Ventolin [crowsmengegus mix] mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -22 (corr 0.99); low_120_500 -9 (corr 0.78); mid_500_2k -14 (corr 0.93); pres_2k_5k -18 (corr 0.97); air_gt5k -19 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -28/-18/-7 dB.
- **Ventolin [crowsmengegus mix] by part:** drums: 24% of the power, width -21 dB, pan +0.07, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); bass: 43% of the power, width -23 dB, pan +0.07, mono loss 0.0 dB, widest in sub_lt120 (-23 dB); other: 26% of the power, width -9 dB, pan +0.00, mono loss 0.5 dB, widest in low_120_500 (-8 dB); vocals: 8% of the power, width -18 dB, pan +0.03, mono loss 0.1 dB, widest in pres_2k_5k (-17 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Ventolin [praze-an-beeble mix] mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -6 (corr 0.80); low_120_500 -15 (corr 0.94); mid_500_2k -10 (corr 0.83); pres_2k_5k -11 (corr 0.88); air_gt5k -12 (corr 0.95); over time (2-s windows) 10th/50th/90th percentile -25/-13/-9 dB.
- **Ventolin [praze-an-beeble mix] by part:** drums: 35% of the power, width -8 dB, pan +0.35, mono loss 0.6 dB, widest in sub_lt120 (-6 dB); bass: 0% of the power, width -11 dB, pan -0.02, mono loss 0.3 dB, widest in pres_2k_5k (-7 dB); other: 18% of the power, width -6 dB, pan +0.18, mono loss 1.0 dB, widest in low_120_500 (-3 dB); vocals: 47% of the power, width -22 dB, pan -0.10, mono loss 0.0 dB, widest in mid_500_2k (-25 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Ventolin [asthma beats mix] mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -33 (corr 1.00); low_120_500 -29 (corr 1.00); mid_500_2k -29 (corr 1.00); pres_2k_5k -29 (corr 1.00); air_gt5k -27 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -30/-29/-27 dB.
- **Ventolin [asthma beats mix] by part:** drums: 70% of the power, width -30 dB, pan -0.02, mono loss 0.0 dB, widest in low_120_500 (-27 dB); bass: 9% of the power, width -39 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-38 dB); other: 19% of the power, width -33 dB, pan -0.02, mono loss 0.0 dB, widest in low_120_500 (-33 dB); vocals: 1% of the power, width -33 dB, pan -0.01, mono loss 0.0 dB, widest in air_gt5k (-34 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **hilow [ru,ec,+3] mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.98); low_120_500 -10 (corr 0.83); mid_500_2k -11 (corr 0.85); pres_2k_5k -21 (corr 0.98); air_gt5k -25 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -14/-11/-7 dB.
- **hilow [ru,ec,+3] by part:** drums: 19% of the power, width -18 dB, pan +0.01, mono loss 0.1 dB, widest in sub_lt120 (-18 dB); bass: 71% of the power, width -21 dB, pan -0.09, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); other: 9% of the power, width -9 dB, pan -0.04, mono loss 0.5 dB, widest in low_120_500 (-9 dB); vocals: 0% of the power, width -4 dB, pan +0.16, mono loss 1.5 dB, widest in mid_500_2k (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Ventolin [crowsmengegus mix]: 68 BPM, 8 settled chords a minute, 6% of energy above 2 kHz, width -15 dB; Ventolin [praze-an-beeble mix]: 86 BPM, 15 settled chords a minute, 10% of energy above 2 kHz, width -10 dB; Ventolin [asthma beats mix]: 90 BPM, 14 settled chords a minute, 8% of energy above 2 kHz, width -31 dB; hilow [ru,ec,+3]: 86 BPM, 15 settled chords a minute, 1% of energy above 2 kHz, width -17 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Ventolin [praze-an-beeble mix], other group `other-1` (353 notes): around C3, mixed or noisy partials, quick attack, falls 94 dB/s, centered; hear it at 2:54.7, 0:30.7. **[JUDGMENT]** why it waits.
- Ventolin [asthma beats mix], drums group `drums-2` (88 notes): low thump, quick attack, falls 117 dB/s, gets brighter over the note, centered; hear it at 1:27.5, 0:01.4. **[JUDGMENT]** why it waits.
- Ventolin [asthma beats mix], bass group `bass-1` (332 notes): around D1, bell- or metal-like (partials off whole multiples), soft attack, falls 34 dB/s, centered; hear it at 0:38.7, 0:37.9. **[JUDGMENT]** why it waits.
- Ventolin [praze-an-beeble mix], drums group `drums-2` (191 notes): mid snap, quick attack, falls 48 dB/s, leans right (+0.21); hear it at 0:06.3, 0:06.2. **[JUDGMENT]** why it waits.
- hilow [ru,ec,+3], drums group `drums-1` (250 notes): low thump, soft attack, falls 164 dB/s, gets brighter over the note, centered; hear it at 0:32.4, 0:43.5. **[JUDGMENT]** why it waits.
- Ventolin [crowsmengegus mix], drums group `drums-1` (267 notes): low thump, soft attack, falls 230 dB/s, gets brighter over the note, centered; hear it at 4:07.5, 1:07.4. **[JUDGMENT]** why it waits.
- Ventolin [crowsmengegus mix], vocals group `vocals-1` (164 notes): around D#4, bell- or metal-like (partials off whole multiples), soft attack, falls 76 dB/s, centered; hear it at 5:44.8, 5:45.3. **[JUDGMENT]** why it waits.
- Ventolin [crowsmengegus mix], vocals group `vocals-2` (167 notes): around C#6, bell- or metal-like (partials off whole multiples), soft attack, falls 23 dB/s, centered; hear it at 5:21.4, 5:35.0. **[JUDGMENT]** why it waits.
