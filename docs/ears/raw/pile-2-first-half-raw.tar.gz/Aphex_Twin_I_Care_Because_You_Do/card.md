## Aphex Twin - I Care Because You Do (draft card from Ears 3 tools, 2026-10-18)

How it was made: 12 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: - Acrid Avid Jam Shred; - Start as You Mean to Go On; - Next Heap With; - Alberto Balsalm. Typical track: - Acrid Avid Jam Shred. Least like the rest: - Start as You Mean to Go On, - Next Heap With, - Alberto Balsalm.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 76 to 94 BPM (octave-uncertain); keys G phrygian, B aeolian, C ionian, D# ionian; mix width -19 to -5 dB; chord changes 25 to 43 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Start as You Mean to Go On: drums group `drums-1` (404 notes, 53% of the track's note energy)
- In synth terms: low thump, slow swell, falls 135 dB/s, centered.
- Hear it at: 1:49.8 (A#1, 0.28 s, +32 dB alone), 1:56.8 (B1, 0.26 s, +28 dB alone), 3:24.2 (B1, 0.5 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 60 (50 to 73) Hz; attack 165 (77 to 193) ms; decay -135 (-461 to -18) dB/s
  - brightness at the start 98 (73 to 116) Hz; slope over the note 0.00 (-0.25 to 0.87) octaves
  - harmonic share 0.56 (0.05 to 0.97); partials off whole multiples 203 (114 to 302) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.5 (-0.9 to -0.1) dB; pan 0.05 (0.02 to 0.08); left-right correlation 0.98 (0.96 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S2. - Next Heap With: other group `other-1` (192 notes, 38% of the track's note energy)
- In synth terms: around F2, mixed or noisy partials, slow swell, falls 13 dB/s, centered.
- Hear it at: 2:02.1 (A1, 1.21 s, +45 dB alone), 2:20.7 (E2, 0.97 s, +47 dB alone), 2:27.8 (F2, 1.05 s, +41 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 86 (50 to 137) Hz; attack 257 (115 to 807) ms; decay -13 (-45 to -3) dB/s
  - brightness at the start 331 (229 to 468) Hz; slope over the note 0.11 (-0.11 to 0.72) octaves
  - harmonic share 0.85 (0.32 to 0.98); partials off whole multiples 33 (12 to 116) cents
  - vibrato 0 (0 to 18) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.9 (-4.2 to -0.8) dB; pan 0.04 (-0.05 to 0.17); left-right correlation 0.42 (0.02 to 0.68)
- Group quality: weak (silhouette 0.19, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

#### S3. - Alberto Balsalm: other group `other-1` (500 notes, 38% of the track's note energy)
- In synth terms: around D#3, mixed or noisy partials, soft attack, falls 18 dB/s, leans right (+0.16).
- Hear it at: 2:11.2 (G3, 0.19 s, +41 dB alone), 2:11.0 (G3, 0.16 s, +38 dB alone), 4:46.9 (D3, 0.5 s, +32 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 158 (79 to 529) Hz; attack 96 (19 to 357) ms; decay -18 (-52 to -5) dB/s
  - brightness at the start 749 (383 to 1046) Hz; slope over the note -0.03 (-0.44 to 0.29) octaves
  - harmonic share 0.73 (0.20 to 0.98); partials off whole multiples 44 (9 to 125) cents
  - vibrato 0 (0 to 11) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.3 (-20.4 to -1.8) dB; pan 0.16 (0.01 to 0.30); left-right correlation 0.53 (0.28 to 0.89)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

#### S4. - Next Heap With: other group `other-2` (158 notes, 37% of the track's note energy)
- In synth terms: around A2, mixed or noisy partials, slow swell, falls 8 dB/s, centered.
- Hear it at: 2:00.2 (E2, 0.76 s, +47 dB alone), 2:18.4 (F2, 0.8 s, +43 dB alone), 2:01.2 (A1, 1.01 s, +45 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 108 (58 to 188) Hz; attack 403 (148 to 1230) ms; decay -8 (-20 to -1) dB/s
  - brightness at the start 624 (449 to 827) Hz; slope over the note 0.02 (-0.25 to 0.58) octaves
  - harmonic share 0.61 (0.24 to 0.93); partials off whole multiples 46 (17 to 118) cents
  - vibrato 2 (0 to 20) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.0 (-6.3 to -0.7) dB; pan -0.01 (-0.05 to 0.06); left-right correlation 0.34 (0.05 to 0.71)
- Group quality: weak (silhouette 0.19, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

#### S5. - Acrid Avid Jam Shred: drums group `drums-1` (312 notes, 32% of the track's note energy)
- In synth terms: low thump, quick attack, falls 39 dB/s, centered.
- Hear it at: 6:52.4 (F1, 0.35 s, +20 dB alone), 6:52.3 (G#1, 0.23 s, +20 dB alone), 1:26.2 (G#1, 0.23 s, +16 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 48 (43 to 52) Hz; attack 29 (12 to 46) ms; decay -39 (-60 to -12) dB/s
  - brightness at the start 181 (129 to 379) Hz; slope over the note -0.12 (-1.04 to 1.31) octaves
  - harmonic share 0.94 (0.27 to 0.98); partials off whole multiples 194 (94 to 329) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.7 (-1.3 to -0.4) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S6. - Alberto Balsalm: drums group `drums-1` (376 notes, 32% of the track's note energy)
- In synth terms: low thump, quick attack, falls 88 dB/s, centered.
- Hear it at: 3:57.8 (G1, 0.47 s, +37 dB alone), 3:35.9 (A1, 0.31 s, +36 dB alone), 3:57.7 (B1, 0.17 s, +37 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (54 to 62) Hz; attack 36 (29 to 65) ms; decay -88 (-230 to -23) dB/s
  - brightness at the start 101 (75 to 542) Hz; slope over the note 0.00 (-1.53 to 2.74) octaves
  - harmonic share 0.72 (0.37 to 0.94); partials off whole multiples 183 (73 to 295) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.7 (-3.1 to -0.1) dB; pan -0.05 (-0.09 to -0.02); left-right correlation 0.99 (0.94 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S7. - Acrid Avid Jam Shred: bass group `bass-1` (473 notes, 28% of the track's note energy)
- In synth terms: around G1, harmonic (string/reed/pad-like), soft attack, falls 32 dB/s, gets brighter over the note, centered.
- Hear it at: 3:03.9 (D#1, 0.68 s, +5 dB alone), 5:32.2 (E1, 1.4 s, -3 dB alone), 2:04.7 (F#1, 1.27 s, -3 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (41 to 49) Hz; attack 107 (41 to 311) ms; decay -32 (-68 to -6) dB/s
  - brightness at the start 103 (89 to 153) Hz; slope over the note 0.56 (-0.07 to 1.37) octaves
  - harmonic share 1.00 (0.10 to 1.00); partials off whole multiples 19 (2 to 212) cents
  - vibrato 2 (0 to 25) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.6 (-9.9 to -5.4) dB; pan 0.00 (-0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S8. - Start as You Mean to Go On: drums group `drums-2` (96 notes, 19% of the track's note energy)
- In synth terms: low thump, slow swell, falls 26 dB/s, gets darker over the note, centered.
- Hear it at: 1:26.6 (B1, 0.47 s, +28 dB alone), 2:03.2 (A#1, 0.47 s, +28 dB alone), 3:22.6 (A#1, 0.48 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 60 (59 to 62) Hz; attack 163 (141 to 189) ms; decay -26 (-40 to -10) dB/s
  - brightness at the start 159 (135 to 201) Hz; slope over the note -0.67 (-1.12 to 1.08) octaves
  - harmonic share 0.66 (0.48 to 0.81); partials off whole multiples 194 (156 to 310) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.5 (-0.8 to -0.1) dB; pan 0.05 (0.03 to 0.08); left-right correlation 0.97 (0.96 to 0.98)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

### Techniques
- **- Acrid Avid Jam Shred sections:** 20 boundaries at 0:11.0, 0:25.0, 0:47.0, 1:06.0, 1:27.0, 1:43.0, 2:10.0, 2:25.0, 2:38.0, 2:50.0, 3:46.0, 4:42.0; section lengths median 19 s (range 6 to 56). Reliable for sections of 10 s or more.
- **- Acrid Avid Jam Shred stem entries and exits:** drums plays 99% of the time (in: from the start; out: 7:33.0); bass plays 98% of the time (in: 3:17.0; out: 3:14.5, 7:32.5); other plays 99% of the time (in: from the start; out: 7:34.0); vocals plays 84% of the time (in: 0:36.0, 3:21.5, 3:33.0, 5:29.5; out: 3:02.5, 3:25.5, 5:25.5, 7:32.5).
- **- Acrid Avid Jam Shred floor drops (kick and bass out 2 s or more while the rest plays):** 0.29 a minute: 3:07.0 for 3.0 s, 3:12.2 for 3.8 s.
- **- Acrid Avid Jam Shred brightness sweeps (0.7 octave or more):** mix down 1.8 oct 0:00.0 to 0:06.5; mix down 1.1 oct 1:25.5 to 1:30.5; mix down 2.2 oct 2:12.5 to 2:17.5; mix up 2.0 oct 2:29.0 to 2:34.0; mix up 2.8 oct 2:51.5 to 3:01.0; mix down 0.7 oct 3:25.0 to 3:30.0; mix down 1.8 oct 3:33.0 to 3:40.5; mix up 2.6 oct 3:53.0 to 4:01.0 (37 more in techniques.json).
- **- Acrid Avid Jam Shred echo times:** other: 230 ms (+3.1 dB, 1 later repeats).
- **- Acrid Avid Jam Shred pumping locked to the kick:** other dips 4.1 dB at the kick (peak 344 ms after, kick every 0.37 s); bass dips 4.8 dB at the kick (peak 0 ms after, kick every 0.37 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Acrid Avid Jam Shred tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Acrid Avid Jam Shred stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Start as You Mean to Go On sections:** 18 boundaries at 0:02.0, 0:24.0, 0:34.0, 1:24.0, 1:41.0, 1:52.0, 2:05.0, 2:28.0, 2:46.0, 3:23.0, 3:55.0, 4:24.0; section lengths median 17 s (range 2 to 50). Reliable for sections of 10 s or more.
- **- Start as You Mean to Go On stem entries and exits:** drums plays 97% of the time (in: from the start; out: 5:53.0); bass plays 76% of the time (in: 0:03.5, 0:41.0, 0:49.5, 1:04.0, 1:17.0; out: 0:35.0, 0:45.0, 0:58.5, 1:07.0, 1:29.0); other plays 94% of the time (in: 1:59.5, 5:49.5; out: 1:56.5, 5:42.5, 5:54.5); vocals plays 93% of the time (in: 0:31.0, 3:20.5; out: 0:24.0, 3:16.5, 5:50.5).
- **- Start as You Mean to Go On floor drops (kick and bass out 2 s or more while the rest plays):** 0.18 a minute: 2:46.5 for 2.2 s.
- **- Start as You Mean to Go On brightness sweeps (0.7 octave or more):** mix up 1.6 oct 0:13.5 to 0:19.0; mix down 3.0 oct 0:19.0 to 0:29.5; mix up 2.7 oct 0:29.5 to 0:36.0; mix up 1.2 oct 0:57.5 to 1:05.0; mix down 1.7 oct 1:20.0 to 1:28.5; mix down 2.2 oct 1:42.0 to 1:51.0; mix up 3.0 oct 1:51.0 to 1:56.0; mix up 2.0 oct 2:05.0 to 2:15.5 (54 more in techniques.json).
- **- Start as You Mean to Go On echo times:** drums: 399 ms (+6.2 dB, 2 later repeats).
- **- Start as You Mean to Go On pumping locked to the kick:** other dips 1.8 dB at the kick (peak 30 ms after, kick every 0.35 s); bass dips 1.8 dB at the kick (peak 329 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Start as You Mean to Go On tape wobble and speed:** other wobbles about 12 cents at 0.4 Hz; bass wobbles about 10 cents at 1.2 Hz.
- **- Start as You Mean to Go On stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Next Heap With sections:** 10 boundaries at 0:02.0, 1:03.0, 1:15.0, 1:34.0, 1:53.0, 2:46.0, 2:56.0, 3:26.0, 4:14.0, 4:39.0; section lengths median 19 s (range 2 to 61). Reliable for sections of 10 s or more.
- **- Next Heap With stem entries and exits:** drums plays 21% of the time (in: 1:01.5, 1:12.0, 2:45.5, 3:25.5, 4:07.5; out: 1:08.0, 1:30.0, 2:53.5, 3:34.5, 4:10.0); bass plays 41% of the time (in: 1:32.5, 2:57.0; out: 1:03.0, 1:54.5, 3:27.0); other plays 98% of the time (in: from the start; out: 4:38.5); vocals plays 52% of the time (in: 0:02.5, 0:27.0, 0:49.5, 0:57.5, 1:20.0; out: 0:21.5, 0:31.5, 0:52.0, 1:16.5, 1:25.5).
- **- Next Heap With floor drops:** low end too sparse to say (on in under 75% of the track).
- **- Next Heap With brightness sweeps (0.7 octave or more):** mix down 1.3 oct 0:00.0 to 0:08.0; mix down 1.0 oct 0:12.5 to 0:17.5; mix up 1.2 oct 0:31.0 to 0:36.0; mix down 1.0 oct 0:43.0 to 0:48.5; mix down 0.9 oct 1:00.5 to 1:06.0; mix up 1.1 oct 1:31.5 to 1:37.0; mix down 0.7 oct 2:07.5 to 2:12.5; mix down 1.3 oct 2:41.0 to 2:51.0 (42 more in techniques.json).
- **- Next Heap With echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Next Heap With pumping locked to the kick:** under 1.5 dB; none found.
- **- Next Heap With tape wobble and speed:** bass wobbles about 13 cents at 1.4 Hz.
- **- Next Heap With stereo movement:** bass pan range 0.28.
- **- Alberto Balsalm sections:** 14 boundaries at 0:07.0, 0:17.0, 0:41.0, 1:03.0, 1:15.0, 1:51.0, 2:10.0, 2:26.0, 2:42.0, 3:27.0, 3:43.0, 4:07.0; section lengths median 19 s (range 7 to 45). Reliable for sections of 10 s or more.
- **- Alberto Balsalm stem entries and exits:** drums plays 84% of the time (in: 0:07.0, 2:20.0; out: 2:10.0, 4:39.0); bass plays 86% of the time (in: 0:07.0, 1:25.5, 2:00.5, 2:14.0, 3:10.0; out: 1:23.0, 1:52.5, 2:11.5, 3:07.0, 3:23.5); other plays 90% of the time (in: 0:10.0, 0:32.0, 3:37.0, 3:45.5; out: 0:24.5, 3:28.0, 3:42.5); vocals plays 4% of the time (in: 1:34.0, 2:50.5, 3:06.0, 3:21.0; out: 1:37.5, 2:54.0, 3:09.0, 3:24.5).
- **- Alberto Balsalm floor drops (kick and bass out 2 s or more while the rest plays):** 0.65 a minute: 2:09.5 for 6.0 s, 2:15.5 for 2.5 s, 4:44.5 for 4.2 s.
- **- Alberto Balsalm brightness sweeps (0.7 octave or more):** mix up 3.4 oct 0:04.0 to 0:10.0; mix up 1.5 oct 0:13.0 to 0:18.5; mix down 1.2 oct 0:18.5 to 0:24.5; mix up 1.1 oct 0:28.0 to 0:33.0; mix up 1.6 oct 0:37.0 to 0:44.5; mix down 1.4 oct 0:44.5 to 0:49.5; mix down 2.0 oct 0:52.5 to 1:00.0; mix up 4.1 oct 1:00.5 to 1:07.0 (44 more in techniques.json).
- **- Alberto Balsalm echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Alberto Balsalm pumping locked to the kick:** under 1.5 dB; none found.
- **- Alberto Balsalm tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Alberto Balsalm stereo movement:** bass pan range 0.34; other pan range 0.29.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Acrid Avid Jam Shred meter:** about 81 BPM (could be 40 or 162; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Acrid Avid Jam Shred key and mode:** G phrygian (key signature margin 0.051); pitch-class weights D# 0.13, F 0.12, G# 0.11, G 0.11, D 0.10.
- **- Acrid Avid Jam Shred chords:** 29 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.7 to 3.2 s); 32 distinct chords; most time on Dmin7 20%, Csus2 17%, D#maj7 9%, Fmin7 9%. The old counter in this same run said 2; Ears 1's 2-s counter said 2.  50% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Acrid Avid Jam Shred bass:** root-note movement / mixed; 1.15 notes a second; most time on G 0.76, F 0.09, A# 0.07, F# 0.07; steps 54%, thirds 3%, fourths and fifths 7%, octaves 2%, repeats 30%.
- **- Acrid Avid Jam Shred top line (from the 'other' stem; read by ear before trusting):** 573 notes, range 16 semitones (10th to 90th percentile); steps 8%, thirds 19%, fourths and fifths 16%, leaps 39%, repeats 17%; median interval 7 semitones; 46% of moves go up; phrases of about 8 notes, arch 53%, rising 12%, falling 15%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **- Acrid Avid Jam Shred repetition:** 77 bars of 5.9 s; strongest repeat distances 1 bars (0.79), 29 bars (-0.10), 22 bars (-0.13); 11% of bars near-duplicate an earlier bar.
- **- Start as You Mean to Go On meter:** about 76 BPM (could be 38 or 151; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.62 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (4:3, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Start as You Mean to Go On key and mode:** B aeolian (minor) (low confidence: the key signature margin is 0.009, so read this as a guess); pitch-class weights G 0.18, D 0.14, A 0.12, B 0.09, E 0.08.
- **- Start as You Mean to Go On chords:** 25 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.7 to 4.0 s); 28 distinct chords; most time on C#maj7 22%, Gsus2 18%, Gmaj7 18%, G5 10%. The old counter in this same run said 9; Ears 1's 2-s counter said 0.  31% of the changes land on a beat (chance would be 38%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Start as You Mean to Go On bass:** root-note movement / mixed; 0.58 notes a second; most time on B 0.47, A# 0.29, C 0.08, G# 0.07; steps 48%, thirds 10%, fourths and fifths 1%, octaves 0%, repeats 41%.
- **- Start as You Mean to Go On top line (from the 'other' stem; read by ear before trusting):** 689 notes, range 21 semitones (10th to 90th percentile); steps 8%, thirds 15%, fourths and fifths 33%, leaps 19%, repeats 26%; median interval 5 semitones; 50% of moves go up; phrases of about 49 notes, arch 36%, rising 9%, falling 27%, flat or wavy 27%. Reliable only when the line sits clearly above its accompaniment.
- **- Start as You Mean to Go On repetition:** 114 bars of 3.2 s; strongest repeat distances 2 bars (0.61), 4 bars (0.42), 6 bars (0.27); 3% of bars near-duplicate an earlier bar.
- **- Next Heap With meter:** about 77 BPM (could be 39 or 155; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.09); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim.
- **- Next Heap With key and mode:** C ionian (major) (key signature margin 0.042); pitch-class weights E 0.17, A 0.12, C 0.11, F 0.09, C# 0.09.
- **- Next Heap With chords:** 29 changes a minute (20 a minute are chords that last 1.5 s or more); median chord 1.9 s (10th to 90th percentile 0.9 to 3.4 s); 26 distinct chords; most time on C#maj7 13%, A5 10%, C#min7 9%, E5 9%. The old counter in this same run said 20; Ears 1's 2-s counter said 21.  38% of the changes land on a beat (chance would be 39%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Next Heap With bass:** root-note movement / mixed; 0.53 notes a second; most time on C 0.64, A 0.17, C# 0.11, F 0.05; steps 14%, thirds 15%, fourths and fifths 2%, octaves 4%, repeats 48%.
- **- Next Heap With top line (from the 'other' stem; read by ear before trusting):** 613 notes, range 12 semitones (10th to 90th percentile); steps 19%, thirds 8%, fourths and fifths 33%, leaps 18%, repeats 22%; median interval 5 semitones; 50% of moves go up; phrases of about 8 notes, arch 26%, rising 48%, falling 9%, flat or wavy 17%. Reliable only when the line sits clearly above its accompaniment.
- **- Next Heap With repetition:** 91 bars of 3.1 s; strongest repeat distances 3 bars (0.46), 1 bars (0.36), 30 bars (0.19); 1% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Alberto Balsalm meter:** about 94 BPM (could be 47 or 188; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Alberto Balsalm key and mode:** D# ionian (major) (low confidence: the key signature margin is 0.008, so read this as a guess); pitch-class weights D# 0.13, A# 0.11, D 0.11, G 0.10, C 0.09.
- **- Alberto Balsalm chords:** 43 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.7 to 2.4 s); 33 distinct chords; most time on D#maj7 20%, D#5 8%, G#maj7 7%, A#maj7 7%. The old counter in this same run said 23; Ears 1's 2-s counter said 20.  43% of the changes land on a beat (chance would be 47%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Alberto Balsalm bass:** root-note movement / mixed; 1.05 notes a second; most time on D# 0.24, G 0.24, A# 0.14, D 0.13; steps 23%, thirds 9%, fourths and fifths 24%, octaves 5%, repeats 29%.
- **- Alberto Balsalm top line (from the 'other' stem; read by ear before trusting):** 657 notes, range 23 semitones (10th to 90th percentile); steps 20%, thirds 12%, fourths and fifths 19%, leaps 37%, repeats 13%; median interval 5 semitones; 48% of moves go up; phrases of about 12 notes, arch 44%, rising 22%, falling 19%, flat or wavy 15%. Reliable only when the line sits clearly above its accompaniment.
- **- Alberto Balsalm repetition:** 60 bars of 5.1 s; strongest repeat distances 1 bars (0.42), 3 bars (0.39), 18 bars (0.12); 3% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Acrid Avid Jam Shred mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -26 (corr 0.99); low_120_500 -12 (corr 0.89); mid_500_2k -12 (corr 0.89); pres_2k_5k -19 (corr 0.97); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -30/-21/-9 dB.
- **- Acrid Avid Jam Shred by part:** drums: 75% of the power, width -28 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-24 dB); bass: 16% of the power, width -38 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-39 dB); other: 8% of the power, width -7 dB, pan -0.01, mono loss 0.8 dB, widest in low_120_500 (-5 dB); vocals: 1% of the power, width -18 dB, pan +0.02, mono loss 0.1 dB, widest in mid_500_2k (-17 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Start as You Mean to Go On mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -17 (corr 0.96); low_120_500 -5 (corr 0.54); mid_500_2k -2 (corr 0.23); pres_2k_5k -8 (corr 0.71); air_gt5k -12 (corr 0.89); over time (2-s windows) 10th/50th/90th percentile -20/-4/-2 dB.
- **- Start as You Mean to Go On by part:** drums: 83% of the power, width -17 dB, pan +0.10, mono loss 0.1 dB, widest in sub_lt120 (-17 dB); bass: 2% of the power, width -19 dB, pan +0.02, mono loss 0.0 dB, widest in sub_lt120 (-19 dB); other: 14% of the power, width -0 dB, pan -0.12, mono loss 2.9 dB, widest in low_120_500 (1 dB); vocals: 1% of the power, width -26 dB, pan -0.01, mono loss 0.0 dB, widest in pres_2k_5k (-25 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Next Heap With mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -7 (corr 0.70); low_120_500 -4 (corr 0.40); mid_500_2k -6 (corr 0.62); pres_2k_5k -3 (corr 0.36); air_gt5k -5 (corr 0.53); over time (2-s windows) 10th/50th/90th percentile -7/-4/-1 dB.
- **- Next Heap With by part:** drums: 0% of the power, width -3 dB, pan -0.02, mono loss 1.6 dB, widest in pres_2k_5k (-2 dB); bass: 10% of the power, width -11 dB, pan -0.13, mono loss 0.3 dB, widest in low_120_500 (-11 dB); other: 82% of the power, width -4 dB, pan +0.05, mono loss 1.5 dB, widest in low_120_500 (-3 dB); vocals: 8% of the power, width -9 dB, pan +0.04, mono loss 0.5 dB, widest in low_120_500 (-9 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Alberto Balsalm mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -13 (corr 0.93); low_120_500 -9 (corr 0.77); mid_500_2k -5 (corr 0.55); pres_2k_5k -15 (corr 0.94); air_gt5k -28 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -13/-7/-5 dB.
- **- Alberto Balsalm by part:** drums: 50% of the power, width -18 dB, pan -0.09, mono loss 0.1 dB, widest in sub_lt120 (-19 dB); bass: 15% of the power, width -8 dB, pan -0.17, mono loss 0.6 dB, widest in low_120_500 (-7 dB); other: 35% of the power, width -4 dB, pan +0.35, mono loss 1.4 dB, widest in mid_500_2k (-4 dB); vocals: 0% of the power, width -18 dB, pan +0.07, mono loss 0.1 dB, widest in low_120_500 (-19 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Acrid Avid Jam Shred: 81 BPM, 12 settled chords a minute, 3% of energy above 2 kHz, width -19 dB; - Start as You Mean to Go On: 76 BPM, 14 settled chords a minute, 2% of energy above 2 kHz, width -10 dB; - Next Heap With: 77 BPM, 20 settled chords a minute, 1% of energy above 2 kHz, width -5 dB; - Alberto Balsalm: 94 BPM, 11 settled chords a minute, 3% of energy above 2 kHz, width -9 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- - Alberto Balsalm, bass group `bass-1` (177 notes): around D#2, harmonic (string/reed/pad-like), soft attack, falls 17 dB/s, vibrato about 13 cents at 3.3 Hz, centered; hear it at 5:04.8, 5:06.1. **[JUDGMENT]** why it waits.
- - Acrid Avid Jam Shred, drums group `drums-2` (188 notes): low thump, soft attack, falls 54 dB/s, centered; hear it at 4:47.8, 4:36.0. **[JUDGMENT]** why it waits.
- - Next Heap With, bass group `bass-1` (315 notes): around C2, harmonic (string/reed/pad-like), soft attack, falls 17 dB/s, centered; hear it at 0:37.0, 0:45.7. **[JUDGMENT]** why it waits.
- - Start as You Mean to Go On, other group `other-1` (163 notes): around G3, mixed or noisy partials, slow swell, falls 3 dB/s, centered; hear it at 2:47.1, 2:47.4. **[JUDGMENT]** why it waits.
- - Start as You Mean to Go On, bass group `bass-1` (325 notes): around A1, bell- or metal-like (partials off whole multiples), soft attack, falls 69 dB/s, centered; hear it at 5:51.1, 1:37.9. **[JUDGMENT]** why it waits.
- - Acrid Avid Jam Shred, other group `other-1` (145 notes): around G2, mixed or noisy partials, slow swell, falls 13 dB/s, centered; hear it at 2:58.3, 3:48.0. **[JUDGMENT]** why it waits.
- - Acrid Avid Jam Shred, other group `other-2` (233 notes): around G3, mixed or noisy partials, soft attack, falls 164 dB/s, centered; hear it at 7:08.4, 6:35.9. **[JUDGMENT]** why it waits.
- - Alberto Balsalm, drums group `drums-2` (124 notes): mid snap, quick attack, falls 233 dB/s, gets darker over the note, centered; hear it at 3:58.4, 0:41.8. **[JUDGMENT]** why it waits.
