## Aphex Twin - Donkey Rhubarb (draft card from Ears 3 tools, 2026-10-18)

How it was made: EP or short record (5 usable tracks): every track. Deep pass on: Donkey Rhubarb; Vaz Deferenz; Icct Hedral (Philip Glass Orchestration); Pancake Lizard. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 70 to 140 BPM (octave-uncertain); keys G aeolian, G# mixolydian, F phrygian, G mixolydian; mix width -28 to -4 dB; chord changes 4 to 40 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Vaz Deferenz: drums group `drums-1` (401 notes, 59% of the track's note energy)
- In synth terms: low thump, soft attack, falls 46 dB/s, centered.
- Hear it at: 5:22.2 (A1, 0.41 s, +19 dB alone), 5:19.6 (F#1, 0.41 s, +18 dB alone), 5:20.4 (A1, 0.43 s, +16 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 55 (46 to 60) Hz; attack 148 (62 to 244) ms; decay -46 (-141 to -17) dB/s
  - brightness at the start 92 (69 to 170) Hz; slope over the note 0.00 (-0.22 to 1.98) octaves
  - harmonic share 0.92 (0.03 to 0.99); partials off whole multiples 194 (72 to 324) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-0.8 to -0.2) dB; pan -0.03 (-0.04 to -0.02); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S2. Icct Hedral (Philip Glass Orchestration): other group `other-1` (388 notes, 46% of the track's note energy)
- In synth terms: around G#2, mixed or noisy partials, soft attack, falls 21 dB/s, centered.
- Hear it at: 0:12.3 (D3, 1.25 s, +46 dB alone), 7:35.2 (G2, 0.26 s, +47 dB alone), 7:47.2 (G#2, 0.19 s, +45 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 105 (58 to 174) Hz; attack 127 (57 to 412) ms; decay -21 (-69 to -2) dB/s
  - brightness at the start 632 (386 to 1099) Hz; slope over the note 0.00 (-0.43 to 0.26) octaves
  - harmonic share 0.76 (0.24 to 0.98); partials off whole multiples 38 (13 to 89) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.3 (-4.4 to -1.2) dB; pan 0.04 (-0.10 to 0.16); left-right correlation 0.41 (0.20 to 0.60)
- Group quality: weak (silhouette 0.21, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

#### S3. Icct Hedral (Philip Glass Orchestration): bass group `bass-1` (392 notes, 34% of the track's note energy)
- In synth terms: around A1, harmonic (string/reed/pad-like), soft attack, falls 27 dB/s, centered.
- Hear it at: 7:03.6 (F1, 0.43 s, +7 dB alone), 7:09.0 (F1, 0.3 s, +8 dB alone), 7:09.1 (F1, 1.24 s, +5 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 55 (33 to 86) Hz; attack 54 (23 to 282) ms; decay -27 (-71 to -4) dB/s
  - brightness at the start 97 (83 to 117) Hz; slope over the note 0.00 (-0.22 to 0.39) octaves
  - harmonic share 0.97 (0.12 to 1.00); partials off whole multiples 27 (7 to 147) cents
  - vibrato 0 (0 to 30) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.7 (-10.6 to -2.4) dB; pan -0.00 (-0.10 to 0.10); left-right correlation 0.86 (0.71 to 0.95)
- Group quality: weak (silhouette 0.16, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S4. Donkey Rhubarb: drums group `drums-1` (217 notes, 28% of the track's note energy)
- In synth terms: low thump, quick attack, falls 128 dB/s, gets brighter over the note, centered.
- Hear it at: 2:26.3 (G1, 0.32 s, +25 dB alone), 5:30.6 (E2, 0.13 s, +24 dB alone), 3:14.2 (G1, 0.36 s, +19 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 50 (44 to 51) Hz; attack 33 (23 to 55) ms; decay -128 (-145 to -110) dB/s
  - brightness at the start 111 (69 to 205) Hz; slope over the note 1.15 (0.00 to 2.83) octaves
  - harmonic share 0.98 (0.17 to 1.00); partials off whole multiples 169 (55 to 303) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.7 (-1.0 to -0.4) dB; pan -0.02 (-0.04 to -0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S5. Pancake Lizard: other group `other-1` (446 notes, 27% of the track's note energy)
- In synth terms: around F2, bell- or metal-like (partials off whole multiples), soft attack, falls 43 dB/s, centered.
- Hear it at: 2:27.1 (C3, 0.24 s, +33 dB alone), 2:27.4 (C3, 0.57 s, +21 dB alone), 2:25.3 (C3, 0.54 s, +20 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 86 (38 to 218) Hz; attack 96 (49 to 250) ms; decay -43 (-137 to -10) dB/s
  - brightness at the start 484 (259 to 942) Hz; slope over the note -0.14 (-1.39 to 0.38) octaves
  - harmonic share 0.67 (0.14 to 0.96); partials off whole multiples 65 (18 to 156) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.0 (-16.8 to -1.2) dB; pan 0.04 (-0.17 to 0.31); left-right correlation 0.82 (0.59 to 0.97)
- Group quality: weak (silhouette 0.15, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

#### S6. Donkey Rhubarb: drums group `drums-2` (283 notes, 23% of the track's note energy)
- In synth terms: low thump, quick attack, falls 74 dB/s, centered.
- Hear it at: 5:07.1 (G1, 0.21 s, +29 dB alone), 5:33.2 (B1, 0.11 s, +29 dB alone), 5:07.1 (A#1, 0.13 s, +29 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 53 (45 to 61) Hz; attack 39 (23 to 58) ms; decay -74 (-106 to -29) dB/s
  - brightness at the start 199 (114 to 340) Hz; slope over the note 0.00 (0.00 to 1.22) octaves
  - harmonic share 0.74 (0.32 to 0.97); partials off whole multiples 167 (43 to 321) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-0.8 to -0.1) dB; pan -0.02 (-0.05 to -0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S7. Pancake Lizard: bass group `bass-1` (103 notes, 19% of the track's note energy)
- In synth terms: around G1, harmonic (string/reed/pad-like), slow swell, falls 5 dB/s, leans left (-0.15).
- Hear it at: 1:11.7 (F1, 0.27 s, +24 dB alone), 1:11.6 (F1, 0.24 s, +24 dB alone), 1:16.9 (G1, 0.17 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (44 to 62) Hz; attack 356 (153 to 760) ms; decay -5 (-15 to 1) dB/s
  - brightness at the start 108 (99 to 134) Hz; slope over the note 0.00 (-0.08 to 0.24) octaves
  - harmonic share 1.00 (0.99 to 1.00); partials off whole multiples 10 (2 to 20) cents
  - vibrato 0 (0 to 7) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.0 (-7.8 to -1.4) dB; pan -0.15 (-0.20 to 0.26); left-right correlation 0.99 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S8. Vaz Deferenz: other group `other-1` (213 notes, 8% of the track's note energy)
- In synth terms: around C3, mixed or noisy partials, soft attack, falls 41 dB/s, leans right (+0.18).
- Hear it at: 4:27.6 (C3, 0.22 s, +24 dB alone), 4:27.6 (C3, 0.28 s, +22 dB alone), 4:26.8 (C#4, 0.23 s, +17 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 131 (95 to 245) Hz; attack 55 (15 to 189) ms; decay -41 (-152 to -5) dB/s
  - brightness at the start 1487 (1019 to 2342) Hz; slope over the note 0.00 (-0.31 to 0.45) octaves
  - harmonic share 0.51 (0.26 to 0.83); partials off whole multiples 60 (23 to 87) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.6 (-13.5 to -1.8) dB; pan 0.18 (-0.15 to 0.22); left-right correlation 0.98 (0.95 to 0.99)
- Group quality: weak (silhouette 0.20, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs), not on the raw mix.

### Techniques
- **Donkey Rhubarb sections:** 13 boundaries at 0:02.0, 0:43.0, 1:16.0, 1:44.0, 2:27.0, 3:27.0, 3:55.0, 4:16.0, 4:27.0, 4:51.0, 5:08.0, 5:23.0; section lengths median 25 s (range 2 to 60). Reliable for sections of 10 s or more.
- **Donkey Rhubarb stem entries and exits:** drums plays 93% of the time (in: from the start; out: 5:43.0); bass plays 85% of the time (in: 4:52.0, 5:05.0, 5:14.5; out: 4:42.5, 4:54.5, 5:07.5, 5:40.5); other plays 96% of the time (in: 5:15.0; out: 5:12.5, 5:55.5); vocals plays 92% of the time (in: 5:20.0; out: 5:16.5, 5:42.5).
- **Donkey Rhubarb floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Donkey Rhubarb brightness sweeps (0.7 octave or more):** mix up 1.1 oct 0:25.0 to 0:33.0; mix down 3.1 oct 2:15.5 to 2:26.0; mix down 2.1 oct 2:52.0 to 2:59.5; mix up 2.3 oct 2:59.5 to 3:11.0; mix down 0.8 oct 3:46.0 to 3:53.5; mix down 1.7 oct 4:09.5 to 4:14.5; mix up 1.6 oct 4:26.0 to 4:35.0; mix down 2.2 oct 4:35.0 to 4:43.5 (16 more in techniques.json).
- **Donkey Rhubarb echo times:** drums: 434 ms (+9.8 dB, 2 later repeats).
- **Donkey Rhubarb pumping locked to the kick:** other dips 7.3 dB at the kick (peak 180 ms after, kick every 0.43 s); bass dips 9.8 dB at the kick (peak 364 ms after, kick every 0.43 s). The tool reads about 70% of the true depth, so this is a floor.
- **Donkey Rhubarb tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Donkey Rhubarb stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Vaz Deferenz sections:** 16 boundaries at 0:02.0, 0:24.0, 0:44.0, 1:26.0, 1:43.0, 2:18.0, 2:40.0, 2:50.0, 3:30.0, 3:42.0, 3:55.0, 4:15.0; section lengths median 20 s (range 2 to 42). Reliable for sections of 10 s or more.
- **Vaz Deferenz stem entries and exits:** drums plays 97% of the time (in: 0:05.0; out: 5:43.5); bass plays 95% of the time (in: 0:01.5, 0:09.0, 3:14.5; out: 0:06.0, 3:12.0, 5:39.0); other plays 97% of the time (in: from the start; out: 5:42.0); vocals plays 92% of the time (in: 0:22.5; out: 5:45.0).
- **Vaz Deferenz floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Vaz Deferenz brightness sweeps (0.7 octave or more):** mix down 3.5 oct 0:20.5 to 0:29.0; mix up 0.8 oct 1:34.5 to 1:41.5; mix up 2.5 oct 1:53.0 to 2:00.5; mix down 2.6 oct 2:13.5 to 2:20.0; mix up 1.7 oct 2:46.5 to 2:54.5; mix up 2.0 oct 3:04.5 to 3:13.0; mix down 1.4 oct 3:38.0 to 3:44.0; mix down 2.0 oct 3:48.0 to 3:53.5 (32 more in techniques.json).
- **Vaz Deferenz echo times:** other: 444 ms (+8.9 dB, 2 later repeats).
- **Vaz Deferenz pumping locked to the kick:** other dips 3.2 dB at the kick (peak 294 ms after, kick every 0.32 s); bass dips 3.8 dB at the kick (peak 200 ms after, kick every 0.32 s). The tool reads about 70% of the true depth, so this is a floor.
- **Vaz Deferenz tape wobble and speed:** other wobbles about 15 cents at 2.4 Hz.
- **Vaz Deferenz stereo movement:** other pan range 0.38, cycling every 50 s.
- **Vaz Deferenz builds:** 0:00.0 to 0:28.0.
- **Icct Hedral (Philip Glass Orchestration) sections:** 12 boundaries at 0:40.0, 1:34.0, 1:45.0, 2:06.0, 2:36.0, 3:42.0, 4:03.0, 4:16.0, 4:57.0, 5:25.0, 7:26.0, 7:54.0; section lengths median 28 s (range 6 to 121). Reliable for sections of 10 s or more.
- **Icct Hedral (Philip Glass Orchestration) stem entries and exits:** drums plays 44% of the time (in: 2:13.5, 2:48.5, 4:18.5, 5:27.5, 7:01.0; out: 2:17.0, 3:41.5, 4:58.0, 6:56.5, 7:26.0); bass plays 48% of the time (in: 0:59.5, 1:13.5, 2:09.0, 2:35.0, 4:48.0; out: 1:02.0, 1:18.0, 2:26.0, 3:43.0, 4:54.0); other plays 98% of the time (in: 0:02.0; out: 7:54.5); vocals plays 38% of the time (in: 1:02.0, 1:37.5, 2:26.5, 5:24.0, 5:59.5; out: 1:35.0, 2:10.5, 2:32.5, 5:48.0, 6:10.0).
- **Icct Hedral (Philip Glass Orchestration) floor drops:** low end too sparse to say (on in under 75% of the track).
- **Icct Hedral (Philip Glass Orchestration) brightness sweeps (0.7 octave or more):** mix up 1.0 oct 2:47.5 to 2:53.5; mix up 1.2 oct 3:04.5 to 3:13.5; mix down 0.9 oct 3:14.0 to 3:19.0; mix down 1.4 oct 3:26.5 to 3:36.0; mix up 1.2 oct 3:36.5 to 3:42.0; mix down 0.8 oct 3:56.5 to 4:02.5; mix down 1.0 oct 5:10.5 to 5:15.5; mix up 1.0 oct 5:16.0 to 5:21.5 (29 more in techniques.json).
- **Icct Hedral (Philip Glass Orchestration) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Icct Hedral (Philip Glass Orchestration) pumping locked to the kick:** bass dips 3.7 dB at the kick (peak 409 ms after, kick every 0.45 s). The tool reads about 70% of the true depth, so this is a floor.
- **Icct Hedral (Philip Glass Orchestration) tape wobble and speed:** bass wobbles about 10 cents at 0.5 Hz.
- **Icct Hedral (Philip Glass Orchestration) stereo movement:** drums pan range 0.30; bass pan range 0.28; vocals pan range 0.29.
- **Icct Hedral (Philip Glass Orchestration) builds:** 5:11.0 to 5:39.0.
- **Pancake Lizard sections:** 11 boundaries at 0:02.0, 0:14.0, 0:27.0, 1:14.0, 1:38.0, 2:01.0, 2:13.0, 2:33.0, 2:44.0, 3:01.0, 3:34.0; section lengths median 18 s (range 2 to 57). Reliable for sections of 10 s or more.
- **Pancake Lizard stem entries and exits:** drums plays 79% of the time (in: from the start; out: 3:35.0); bass plays 73% of the time (in: 2:27.5, 4:02.0; out: 1:38.0, 3:57.0, 4:12.5); other plays 98% of the time (in: from the start; out: 4:25.5); vocals plays 25% of the time (in: 0:32.0, 1:38.0, 2:05.0; out: 1:07.0, 2:01.5, 2:13.5).
- **Pancake Lizard floor drops (kick and bass out 2 s or more while the rest plays):** 0.49 a minute: 3:56.0 for 9.0 s, 4:08.5 for 9.0 s.
- **Pancake Lizard brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:00.0 to 0:05.5; mix up 2.2 oct 0:08.0 to 0:15.5; mix down 3.0 oct 0:15.5 to 0:24.0; mix up 4.0 oct 0:24.0 to 0:36.0; mix down 3.1 oct 0:36.0 to 0:41.0; mix up 2.7 oct 0:50.0 to 0:57.5; mix down 3.6 oct 0:57.5 to 1:08.5; mix up 1.7 oct 1:08.5 to 1:17.0 (37 more in techniques.json).
- **Pancake Lizard echo times:** other: 514 ms (+3.1 dB, 2 later repeats).
- **Pancake Lizard pumping locked to the kick:** other dips 3.0 dB at the kick (peak 239 ms after, kick every 0.45 s). The tool reads about 70% of the true depth, so this is a floor.
- **Pancake Lizard tape wobble and speed:** other wobbles about 6 cents at 6.5 Hz; bass wobbles about 11 cents at 1.2 Hz; bass speed moves up to 14 cents in 4 s.
- **Pancake Lizard stereo movement:** bass pan range 0.46; other pan range 0.45.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Donkey Rhubarb meter:** about 140 BPM (could be 70 or 280; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.12); swung: off-beat at 0.63 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (4:3, 5:2, 5:3, 5:4), which means irregular timing, not a cross-rhythm claim.
- **Donkey Rhubarb key and mode:** G aeolian (minor) (low confidence: the key signature margin is 0.008, so read this as a guess); pitch-class weights F 0.12, D# 0.11, D 0.10, G 0.09, E 0.09.
- **Donkey Rhubarb chords:** 24 changes a minute (18 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 1.3 to 4.4 s); 16 distinct chords; most time on F7 34%, G7 22%, Dmin7 9%, Fmaj7 9%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  76% of the changes land on a beat (chance would be 70%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Donkey Rhubarb bass:** root-note movement / mixed; 0.10 notes a second; most time on G 0.30, G# 0.25, A# 0.25, A 0.12; steps 58%, thirds 19%, fourths and fifths 0%, octaves 0%, repeats 17%.
- **Donkey Rhubarb top line (from the 'other' stem; read by ear before trusting):** 958 notes, range 18 semitones (10th to 90th percentile); steps 11%, thirds 9%, fourths and fifths 21%, leaps 47%, repeats 13%; median interval 7 semitones; 49% of moves go up; phrases of about 63 notes, arch 27%, rising 27%, falling 9%, flat or wavy 36%. Reliable only when the line sits clearly above its accompaniment.
- **Donkey Rhubarb repetition:** 214 bars of 1.7 s; strongest repeat distances 2 bars (0.66), 4 bars (0.63), 6 bars (0.46); 20% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Vaz Deferenz meter:** about 70 BPM (could be 35 or 140; the tool cannot tell the beat level), bar length unclear (best guess 3, score 0.01); swung: off-beat at 0.62 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Vaz Deferenz key and mode:** G# mixolydian (low confidence: the key signature margin is 0.001, so read this as a guess); pitch-class weights C# 0.14, F 0.09, C 0.09, D 0.08, G# 0.08.
- **Vaz Deferenz chords:** 4 changes a minute (4 a minute are chords that last 1.5 s or more); median chord 5.2 s (10th to 90th percentile 2.0 to 30.8 s); 9 distinct chords; most time on C#maj7 76%, F#maj7 15%, Dmin7 2%, A#min7 2%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  24% of the changes land on a beat (chance would be 35%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Vaz Deferenz bass:** root-note movement / mixed; 0.04 notes a second; most time on G# 0.65, A 0.21, G 0.14; steps 67%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 33%.
- **Vaz Deferenz top line (from the 'other' stem; read by ear before trusting):** 828 notes, range 20 semitones (10th to 90th percentile); steps 4%, thirds 3%, fourths and fifths 18%, leaps 48%, repeats 27%; median interval 6 semitones; 52% of moves go up; phrases of about 7 notes, arch 40%, rising 28%, falling 15%, flat or wavy 17%. Reliable only when the line sits clearly above its accompaniment.
- **Vaz Deferenz repetition:** 136 bars of 2.6 s; strongest repeat distances 1 bars (0.77), 24 bars (0.03); 3% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Icct Hedral (Philip Glass Orchestration) meter:** about 94 BPM (could be 47 or 188; the tool cannot tell the beat level), bar length unclear (best guess 5, score 0.21); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim.
- **Icct Hedral (Philip Glass Orchestration) key and mode:** F phrygian (key signature margin 0.021); pitch-class weights F 0.13, A 0.11, G# 0.11, C 0.10, F# 0.10.
- **Icct Hedral (Philip Glass Orchestration) chords:** 40 changes a minute (19 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.7 to 2.0 s); 46 distinct chords; most time on F5 13%, Dmaj7 12%, Ddim 11%, Amaj7 8%. The old counter in this same run said 26; Ears 1's 2-s counter said 25.  43% of the changes land on a beat (chance would be 47%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Icct Hedral (Philip Glass Orchestration) bass:** root-note movement / mixed; 0.83 notes a second; most time on F# 0.29, F 0.26, A 0.18, C 0.18; steps 9%, thirds 12%, fourths and fifths 15%, octaves 6%, repeats 43%.
- **Icct Hedral (Philip Glass Orchestration) top line (from the 'other' stem; read by ear before trusting):** 1181 notes, range 13 semitones (10th to 90th percentile); steps 9%, thirds 16%, fourths and fifths 21%, leaps 28%, repeats 27%; median interval 4 semitones; 50% of moves go up; phrases of about 14 notes, arch 56%, rising 12%, falling 23%, flat or wavy 9%. Reliable only when the line sits clearly above its accompaniment.
- **Icct Hedral (Philip Glass Orchestration) repetition:** 150 bars of 3.2 s; strongest repeat distances 2 bars (0.65), 4 bars (0.48), 6 bars (0.32); 5% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Pancake Lizard meter:** about 117 BPM (could be 58 or 234; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim.
- **Pancake Lizard key and mode:** G mixolydian (key signature margin 0.049); pitch-class weights G 0.17, C 0.15, F 0.11, A 0.11, B 0.10.
- **Pancake Lizard chords:** 31 changes a minute (23 a minute are chords that last 1.5 s or more); median chord 1.9 s (10th to 90th percentile 0.7 to 3.8 s); 27 distinct chords; most time on G5 17%, C5 17%, B5 13%, F5 10%. The old counter in this same run said 23; Ears 1's 2-s counter said 20.  74% of the changes land on a beat (chance would be 58%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Pancake Lizard bass:** root-note movement / mixed; 0.73 notes a second; most time on G 0.38, F 0.19, C 0.16, B 0.16; steps 15%, thirds 13%, fourths and fifths 24%, octaves 4%, repeats 36%.
- **Pancake Lizard top line (from the 'other' stem; read by ear before trusting):** 596 notes, range 17 semitones (10th to 90th percentile); steps 8%, thirds 8%, fourths and fifths 16%, leaps 36%, repeats 32%; median interval 5 semitones; 51% of moves go up; phrases of about 12 notes, arch 52%, rising 8%, falling 20%, flat or wavy 20%. Reliable only when the line sits clearly above its accompaniment.
- **Pancake Lizard repetition:** 132 bars of 2.1 s; strongest repeat distances 8 bars (0.50), 1 bars (0.45), 4 bars (0.44); 23% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Donkey Rhubarb mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -28 (corr 1.00); low_120_500 -26 (corr 1.00); mid_500_2k -31 (corr 1.00); pres_2k_5k -29 (corr 1.00); air_gt5k -30 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -32/-29/-26 dB.
- **Donkey Rhubarb by part:** drums: 76% of the power, width -27 dB, pan -0.05, mono loss 0.0 dB, widest in low_120_500 (-24 dB); bass: 5% of the power, width -30 dB, pan -0.04, mono loss 0.0 dB, widest in sub_lt120 (-31 dB); other: 11% of the power, width -33 dB, pan +0.01, mono loss 0.0 dB, widest in pres_2k_5k (-31 dB); vocals: 8% of the power, width -34 dB, pan +0.00, mono loss 0.0 dB, widest in mid_500_2k (-34 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Vaz Deferenz mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -24 (corr 0.99); low_120_500 -18 (corr 0.97); mid_500_2k -13 (corr 0.92); pres_2k_5k -16 (corr 0.96); air_gt5k -23 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -18/-17/-14 dB.
- **Vaz Deferenz by part:** drums: 83% of the power, width -23 dB, pan -0.05, mono loss 0.0 dB, widest in sub_lt120 (-24 dB); bass: 2% of the power, width -21 dB, pan -0.06, mono loss 0.0 dB, widest in low_120_500 (-19 dB); other: 8% of the power, width -13 dB, pan +0.18, mono loss 0.2 dB, widest in mid_500_2k (-12 dB); vocals: 7% of the power, width -35 dB, pan +0.01, mono loss 0.0 dB, widest in low_120_500 (-33 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Icct Hedral (Philip Glass Orchestration) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -7 (corr 0.69); low_120_500 -4 (corr 0.44); mid_500_2k -3 (corr 0.36); pres_2k_5k -4 (corr 0.43); air_gt5k -4 (corr 0.43); over time (2-s windows) 10th/50th/90th percentile -5/-4/-2 dB.
- **Icct Hedral (Philip Glass Orchestration) by part:** drums: 1% of the power, width -8 dB, pan +0.01, mono loss 0.7 dB, widest in sub_lt120 (-8 dB); bass: 21% of the power, width -9 dB, pan -0.01, mono loss 0.5 dB, widest in sub_lt120 (-9 dB); other: 73% of the power, width -3 dB, pan +0.08, mono loss 1.7 dB, widest in mid_500_2k (-3 dB); vocals: 5% of the power, width -3 dB, pan +0.31, mono loss 1.8 dB, widest in mid_500_2k (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Pancake Lizard mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -17 (corr 0.96); low_120_500 -12 (corr 0.90); mid_500_2k -12 (corr 0.87); pres_2k_5k -12 (corr 0.90); air_gt5k -24 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -20/-12/-10 dB.
- **Pancake Lizard by part:** drums: 20% of the power, width -17 dB, pan +0.03, mono loss 0.1 dB, widest in mid_500_2k (-15 dB); bass: 53% of the power, width -17 dB, pan -0.13, mono loss 0.1 dB, widest in low_120_500 (-15 dB); other: 24% of the power, width -10 dB, pan -0.01, mono loss 0.4 dB, widest in low_120_500 (-9 dB); vocals: 2% of the power, width -36 dB, pan +0.01, mono loss 0.0 dB, widest in pres_2k_5k (-36 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Donkey Rhubarb: 140 BPM, 18 settled chords a minute, 11% of energy above 2 kHz, width -28 dB; Vaz Deferenz: 70 BPM, 4 settled chords a minute, 12% of energy above 2 kHz, width -20 dB; Icct Hedral (Philip Glass Orchestration): 94 BPM, 19 settled chords a minute, 4% of energy above 2 kHz, width -4 dB; Pancake Lizard: 117 BPM, 23 settled chords a minute, 5% of energy above 2 kHz, width -14 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Donkey Rhubarb, other group `other-1` (445 notes): around F3, mixed or noisy partials, soft attack, falls 31 dB/s, centered; hear it at 3:32.8, 3:53.4. **[JUDGMENT]** why it waits.
- Donkey Rhubarb, bass group `bass-1` (436 notes): around G#1, bell- or metal-like (partials off whole multiples), quick attack, falls 273 dB/s, gets brighter over the note, centered; hear it at 5:16.9, 5:20.3. **[JUDGMENT]** why it waits.
- Pancake Lizard, drums group `drums-1` (182 notes): low thump, quick attack, falls 103 dB/s, gets brighter over the note, centered; hear it at 2:42.8, 1:41.5. **[JUDGMENT]** why it waits.
- Pancake Lizard, bass group `bass-2` (36 notes): around C2, harmonic (string/reed/pad-like), slow swell, falls 8 dB/s, centered; hear it at 0:54.6, 1:02.1. **[JUDGMENT]** why it waits.
- Icct Hedral (Philip Glass Orchestration), other group `other-2` (112 notes): around C#4, bell- or metal-like (partials off whole multiples), soft attack, falls 28 dB/s, centered; hear it at 0:23.9, 7:41.6. **[JUDGMENT]** why it waits.
- Donkey Rhubarb, vocals group `vocals-1` (439 notes): around B2, bell- or metal-like (partials off whole multiples), quick attack, falls 428 dB/s, centered; hear it at 5:38.7, 5:13.0. **[JUDGMENT]** why it waits.
- Icct Hedral (Philip Glass Orchestration), vocals group `vocals-1` (469 notes): around D4, mixed or noisy partials, soft attack, falls 21 dB/s, centered; hear it at 6:58.2, 6:58.1. **[JUDGMENT]** why it waits.
- Vaz Deferenz, vocals group `vocals-1` (415 notes): around C#3, bell- or metal-like (partials off whole multiples), quick attack, falls 773 dB/s, centered; hear it at 5:44.0, 3:48.4. **[JUDGMENT]** why it waits.
