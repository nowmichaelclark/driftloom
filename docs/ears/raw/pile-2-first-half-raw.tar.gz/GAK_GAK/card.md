## GAK - GAK (draft card from Ears 3 tools, 2026-10-18)

How it was made: 9 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: 01. GAK 1; 02. GAK 2; 03. GAK 3. Typical track: 01. GAK 1. Least like the rest: 02. GAK 2, 03. GAK 3.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 81 to 126 BPM (octave-uncertain); keys D locrian, B locrian, G lydian; mix width -29 to -20 dB; chord changes 45 to 84 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 02. GAK 2: drums group `drums-1` (456 notes, 50% of the track's note energy)
- In synth terms: low thump, quick attack, falls 216 dB/s, gets brighter over the note, centered.
- Hear it at: 6:11.6 (A1, 0.34 s, +44 dB alone), 6:09.6 (A1, 0.34 s, +44 dB alone), 6:09.1 (A1, 0.35 s, +44 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 54 (41 to 56) Hz; attack 20 (6 to 46) ms; decay -216 (-303 to -178) dB/s
  - brightness at the start 72 (67 to 90) Hz; slope over the note 0.46 (0.01 to 2.06) octaves
  - harmonic share 0.94 (0.22 to 0.99); partials off whole multiples 164 (70 to 265) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.1 (-1.1 to -0.0) dB; pan -0.02 (-0.03 to -0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S2. 01. GAK 1: bass group `bass-1` (277 notes, 36% of the track's note energy)
- In synth terms: around C#2, harmonic (string/reed/pad-like), quick attack, falls 49 dB/s, centered.
- Hear it at: 0:51.5 (A#1, 0.11 s, +20 dB alone), 6:18.6 (A1, 0.13 s, +18 dB alone), 1:47.1 (?, 0.12 s, +17 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 68 (54 to 74) Hz; attack 35 (19 to 123) ms; decay -49 (-118 to -10) dB/s
  - brightness at the start 76 (70 to 95) Hz; slope over the note 0.00 (-0.17 to 0.18) octaves
  - harmonic share 0.99 (0.92 to 1.00); partials off whole multiples 53 (5 to 141) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.9 (-1.5 to -0.3) dB; pan 0.01 (-0.01 to 0.05); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S3. 03. GAK 3: vocals group `vocals-1` (500 notes, 31% of the track's note energy)
- In synth terms: around A4, mixed or noisy partials, soft attack, falls 392 dB/s, centered.
- Hear it at: 0:23.5 (?, 0.26 s, +19 dB alone), 1:38.5 (?, 0.11 s, +19 dB alone), 0:24.0 (?, 0.24 s, +17 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 428 (152 to 1596) Hz; attack 131 (20 to 152) ms; decay -392 (-802 to -48) dB/s
  - brightness at the start 8133 (8021 to 8212) Hz; slope over the note 0.00 (0.00 to 0.03) octaves
  - harmonic share 0.76 (0.22 to 0.97); partials off whole multiples 22 (7 to 70) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.9 (-5.3 to -0.4) dB; pan -0.04 (-0.07 to -0.03); left-right correlation 0.99 (0.89 to 1.00)
- Group quality: weak (silhouette 0.00, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs), not on the raw mix.

#### S4. 01. GAK 1: drums group `drums-1` (391 notes, 25% of the track's note energy)
- In synth terms: low thump, quick attack, falls 294 dB/s, centered.
- Hear it at: 1:33.0 (A#1, 0.17 s, +33 dB alone), 1:33.1 (B0, 0.22 s, +31 dB alone), 4:16.1 (A#1, 0.14 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 54 (39 to 61) Hz; attack 16 (7 to 33) ms; decay -294 (-415 to -112) dB/s
  - brightness at the start 142 (106 to 222) Hz; slope over the note 0.01 (-0.23 to 0.83) octaves
  - harmonic share 0.71 (0.11 to 0.91); partials off whole multiples 130 (49 to 231) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.2 (-3.2 to -0.7) dB; pan 0.02 (-0.00 to 0.06); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S5. 02. GAK 2: bass group `bass-1` (315 notes, 25% of the track's note energy)
- In synth terms: around E2, bell- or metal-like (partials off whole multiples), quick attack, falls 117 dB/s, centered.
- Hear it at: 0:00.6 (E2, 0.12 s, +39 dB alone), 0:00.0 (E2, 0.62 s, +25 dB alone), 4:22.6 (E2, 0.12 s, +25 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 82 (73 to 86) Hz; attack 23 (16 to 35) ms; decay -117 (-154 to -66) dB/s
  - brightness at the start 87 (83 to 93) Hz; slope over the note 0.00 (-0.03 to 0.23) octaves
  - harmonic share 0.98 (0.95 to 1.00); partials off whole multiples 71 (38 to 131) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-4.8 to -0.1) dB; pan -0.01 (-0.02 to -0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S6. 03. GAK 3: drums group `drums-1` (265 notes, 13% of the track's note energy)
- In synth terms: low thump, quick attack, falls 157 dB/s, centered.
- Hear it at: 2:53.9 (A#1, 0.12 s, +11 dB alone), 4:07.7 (A#1, 0.15 s, +12 dB alone), 3:43.0 (B1, 0.13 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (44 to 63) Hz; attack 20 (10 to 35) ms; decay -157 (-348 to -100) dB/s
  - brightness at the start 171 (111 to 255) Hz; slope over the note 0.00 (-0.49 to 2.20) octaves
  - harmonic share 0.77 (0.18 to 0.95); partials off whole multiples 100 (46 to 211) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.4 (-5.9 to -0.9) dB; pan -0.01 (-0.03 to 0.00); left-right correlation 0.99 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

### Techniques
- **01. GAK 1 sections:** 17 boundaries at 0:03.0, 0:53.0, 1:41.0, 2:02.0, 2:18.0, 2:29.0, 3:05.0, 3:39.0, 3:55.0, 4:18.0, 4:46.0, 5:07.0; section lengths median 20 s (range 3 to 50). Reliable for sections of 10 s or more.
- **01. GAK 1 stem entries and exits:** drums plays 96% of the time (in: 2:08.5, 5:03.0; out: 2:02.5, 4:59.0, 6:34.5); bass plays 99% of the time (in: from the start; out: 6:34.0); other plays 57% of the time (in: 0:58.5, 1:59.0, 5:38.0; out: 1:02.5, 5:32.5, 5:47.0); vocals plays 19% of the time (in: 1:00.5, 1:08.5, 1:24.5, 3:24.0, 4:03.0; out: 1:03.0, 1:11.0, 1:31.0, 3:56.0, 4:05.5).
- **01. GAK 1 floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **01. GAK 1 brightness sweeps (0.7 octave or more):** mix down 1.4 oct 0:19.0 to 0:27.0; mix up 1.1 oct 1:19.0 to 1:26.0; mix down 0.8 oct 1:26.5 to 1:32.0; mix up 1.4 oct 1:32.5 to 1:42.5; mix down 1.8 oct 1:42.5 to 1:54.5; mix up 2.3 oct 1:54.5 to 2:05.5; mix down 1.8 oct 2:06.0 to 2:13.0; mix up 1.0 oct 2:14.5 to 2:19.5 (46 more in techniques.json).
- **01. GAK 1 echo times:** other: 374 ms (+3.6 dB, 3 later repeats); drums: 249 ms (+9.5 dB, 4 later repeats).
- **01. GAK 1 pumping locked to the kick:** bass dips 2.7 dB at the kick (peak 110 ms after, kick every 0.26 s). The tool reads about 70% of the true depth, so this is a floor.
- **01. GAK 1 tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **01. GAK 1 stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **02. GAK 2 sections:** 13 boundaries at 0:08.0, 0:29.0, 1:05.0, 1:36.0, 2:41.0, 3:15.0, 3:25.0, 3:41.0, 3:51.0, 4:19.0, 4:51.0, 5:25.0; section lengths median 29 s (range 8 to 65). Reliable for sections of 10 s or more.
- **02. GAK 2 stem entries and exits:** drums plays 99% of the time (in: from the start; out: 6:13.5); bass plays 97% of the time (in: from the start; out: 6:05.5); other plays 84% of the time (in: 0:28.5, 3:16.5, 4:08.5, 4:35.5; out: 3:12.5, 4:01.5, 4:26.5, 6:07.0); vocals plays 5% of the time (in: 1:51.0, 2:32.0, 3:40.0, 3:55.5, 5:17.5; out: 1:54.5, 2:34.5, 3:43.0, 3:59.0, 5:24.0).
- **02. GAK 2 floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **02. GAK 2 brightness sweeps (0.7 octave or more):** mix up 1.5 oct 0:07.0 to 0:15.5; mix down 1.0 oct 0:16.0 to 0:23.0; mix up 2.5 oct 0:30.5 to 0:40.5; mix up 1.3 oct 0:41.0 to 0:46.5; mix down 3.0 oct 0:47.0 to 1:02.0; mix up 3.4 oct 1:02.5 to 1:21.0; mix down 2.3 oct 1:28.0 to 1:36.0; mix up 1.1 oct 1:36.0 to 1:41.0 (61 more in techniques.json).
- **02. GAK 2 echo times:** drums: 494 ms (+20.8 dB, 1 later repeats).
- **02. GAK 2 pumping locked to the kick:** other dips 2.5 dB at the kick (peak 354 ms after, kick every 0.49 s); bass dips 18.6 dB at the kick (peak 105 ms after, kick every 0.49 s). The tool reads about 70% of the true depth, so this is a floor.
- **02. GAK 2 tape wobble and speed:** bass wobbles about 7 cents at 0.4 Hz.
- **02. GAK 2 stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **03. GAK 3 sections:** 17 boundaries at 0:03.0, 0:13.0, 0:24.0, 0:44.0, 1:13.0, 1:29.0, 2:25.0, 2:37.0, 3:07.0, 3:21.0, 3:35.0, 3:50.0; section lengths median 15 s (range 3 to 56). Reliable for sections of 10 s or more.
- **03. GAK 3 stem entries and exits:** drums plays 98% of the time (in: from the start; out: 5:21.5); bass plays 99% of the time (in: from the start; out: 5:22.5); other plays 70% of the time (in: 0:33.0, 0:40.5, 1:05.0, 1:37.5, 3:28.0; out: 0:36.5, 0:43.0, 1:08.5, 3:25.5, 4:13.0); vocals plays 96% of the time (in: 3:57.0; out: 3:51.0, 5:20.5).
- **03. GAK 3 floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **03. GAK 3 brightness sweeps (0.7 octave or more):** mix down 4.2 oct 0:02.0 to 0:07.5; mix down 3.4 oct 0:12.0 to 0:17.5; mix up 3.4 oct 0:17.5 to 0:22.5; mix down 1.9 oct 0:22.5 to 0:28.0; mix up 1.1 oct 0:28.0 to 0:33.5; mix up 4.1 oct 0:38.0 to 0:43.0; mix down 3.0 oct 0:43.0 to 0:48.0; mix up 2.4 oct 0:48.0 to 0:53.0 (39 more in techniques.json).
- **03. GAK 3 echo times:** other: 479 ms (+4.1 dB, 3 later repeats); drums: 474 ms (+11.6 dB, 2 later repeats).
- **03. GAK 3 pumping locked to the kick:** other dips 23.6 dB at the kick (peak 205 ms after, kick every 0.29 s); bass dips 2.5 dB at the kick (peak 195 ms after, kick every 0.29 s). The tool reads about 70% of the true depth, so this is a floor.
- **03. GAK 3 tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **03. GAK 3 stereo movement:** bass pan range 0.07, cycling every 48 s.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **01. GAK 1 meter:** about 81 BPM (could be 40 or 161; the tool cannot tell the beat level), 8 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **01. GAK 1 key and mode:** D locrian (low confidence: the key signature margin is 0.004, so read this as a guess); pitch-class weights D 0.21, C# 0.19, D# 0.13, C 0.11, E 0.07.
- **01. GAK 1 chords:** 45 changes a minute (8 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.6 to 2.9 s); 27 distinct chords; most time on Dmaj7 34%, C#maj7 17%, C#sus2 9%, F#maj7 9%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  42% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **01. GAK 1 bass:** root-note movement / mixed; 1.10 notes a second; most time on B 0.32, D 0.26, A 0.21, A# 0.16; steps 20%, thirds 14%, fourths and fifths 13%, octaves 0%, repeats 40%.
- **01. GAK 1 top line (from the 'other' stem; read by ear before trusting):** 848 notes, range 16 semitones (10th to 90th percentile); steps 22%, thirds 20%, fourths and fifths 33%, leaps 16%, repeats 9%; median interval 4 semitones; 54% of moves go up; phrases of about 19 notes, arch 33%, rising 11%, falling 11%, flat or wavy 44%. Reliable only when the line sits clearly above its accompaniment.
- **01. GAK 1 repetition:** 67 bars of 6.0 s; strongest repeat distances 1 bars (0.73), 14 bars (-0.00); 9% of bars near-duplicate an earlier bar.
- **02. GAK 2 meter:** about 81 BPM (could be 40 or 161; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **02. GAK 2 key and mode:** B locrian (low confidence: the key signature margin is 0.005, so read this as a guess); fits B minor pentatonic; pitch-class weights E 0.21, F 0.15, D# 0.13, D 0.12, C# 0.10.
- **02. GAK 2 chords:** 56 changes a minute (7 a minute are chords that last 1.5 s or more); median chord 0.7 s (10th to 90th percentile 0.5 to 1.6 s); 15 distinct chords; most time on Fmaj7 50%, Dsus2 18%, Emaj7 7%, Dmaj7 6%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  50% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **02. GAK 2 bass:** root-note movement / mixed; 1.89 notes a second; most time on B 0.31, D 0.21, E 0.20, F 0.19; steps 27%, thirds 26%, fourths and fifths 43%, octaves 0%, repeats 3%.
- **02. GAK 2 top line (from the 'other' stem; read by ear before trusting):** 834 notes, range 16 semitones (10th to 90th percentile); steps 15%, thirds 22%, fourths and fifths 8%, leaps 38%, repeats 16%; median interval 4 semitones; 51% of moves go up; phrases of about 7 notes, arch 36%, rising 18%, falling 25%, flat or wavy 20%. Reliable only when the line sits clearly above its accompaniment.
- **02. GAK 2 repetition:** 253 bars of 1.5 s; strongest repeat distances 3 bars (0.47), 8 bars (0.46), 1 bars (0.45); 1% of bars near-duplicate an earlier bar.
- **03. GAK 3 meter:** about 126 BPM (could be 63 or 252; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **03. GAK 3 key and mode:** G lydian (low confidence: the key signature margin is 0.010, so read this as a guess); pitch-class weights G 0.15, F# 0.13, C# 0.09, F 0.09, C 0.08.
- **03. GAK 3 chords:** 84 changes a minute (3 a minute are chords that last 1.5 s or more); median chord 0.6 s (10th to 90th percentile 0.4 to 1.2 s); 34 distinct chords; most time on C#maj7 18%, Gmaj7 15%, Bmaj7 13%, F#maj7 13%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  37% of the changes land on a beat (chance would be 63%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **03. GAK 3 bass:** root-note movement / mixed; 1.49 notes a second; most time on G 0.39, A# 0.27, B 0.10, A 0.07; steps 19%, thirds 15%, fourths and fifths 8%, octaves 8%, repeats 8%.
- **03. GAK 3 top line (from the 'other' stem; read by ear before trusting):** 522 notes, range 26 semitones (10th to 90th percentile); steps 39%, thirds 12%, fourths and fifths 4%, leaps 39%, repeats 7%; median interval 3 semitones; 49% of moves go up; phrases of about 5 notes, arch 14%, rising 43%, falling 21%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **03. GAK 3 repetition:** 171 bars of 1.9 s; strongest repeat distances 1 bars (0.61), 4 bars (0.50), 8 bars (0.33); 1% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **01. GAK 1 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 0.99); low_120_500 -17 (corr 0.96); mid_500_2k -13 (corr 0.91); pres_2k_5k -10 (corr 0.82); air_gt5k -7 (corr 0.67); over time (2-s windows) 10th/50th/90th percentile -23/-19/-13 dB.
- **01. GAK 1 by part:** drums: 35% of the power, width -22 dB, pan +0.06, mono loss 0.0 dB, widest in low_120_500 (-22 dB); bass: 62% of the power, width -27 dB, pan +0.02, mono loss 0.0 dB, widest in sub_lt120 (-29 dB); other: 3% of the power, width -13 dB, pan -0.04, mono loss 0.2 dB, widest in mid_500_2k (-13 dB); vocals: 0% of the power, width -10 dB, pan +0.01, mono loss 0.5 dB, widest in mid_500_2k (-8 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **02. GAK 2 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -31 (corr 1.00); low_120_500 -25 (corr 0.99); mid_500_2k -19 (corr 0.98); pres_2k_5k -19 (corr 0.99); air_gt5k -16 (corr 0.97); over time (2-s windows) 10th/50th/90th percentile -27/-23/-20 dB.
- **02. GAK 2 by part:** drums: 68% of the power, width -29 dB, pan -0.04, mono loss 0.0 dB, widest in sub_lt120 (-30 dB); bass: 31% of the power, width -33 dB, pan -0.02, mono loss 0.0 dB, widest in sub_lt120 (-34 dB); other: 1% of the power, width -14 dB, pan -0.08, mono loss 0.2 dB, widest in low_120_500 (-14 dB); vocals: 0% of the power, width -15 dB, pan -0.08, mono loss 0.1 dB, widest in air_gt5k (-13 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **03. GAK 3 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 0.99); low_120_500 -22 (corr 0.99); mid_500_2k -19 (corr 0.97); pres_2k_5k -18 (corr 0.97); air_gt5k -16 (corr 0.96); over time (2-s windows) 10th/50th/90th percentile -22/-18/-14 dB.
- **03. GAK 3 by part:** drums: 29% of the power, width -22 dB, pan -0.02, mono loss 0.0 dB, widest in low_120_500 (-21 dB); bass: 35% of the power, width -26 dB, pan +0.05, mono loss 0.0 dB, widest in sub_lt120 (-27 dB); other: 1% of the power, width -16 dB, pan -0.03, mono loss 0.1 dB, widest in mid_500_2k (-17 dB); vocals: 35% of the power, width -16 dB, pan -0.09, mono loss 0.1 dB, widest in air_gt5k (-16 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 01. GAK 1: 81 BPM, 8 settled chords a minute, 0% of energy above 2 kHz, width -22 dB; 02. GAK 2: 81 BPM, 7 settled chords a minute, 1% of energy above 2 kHz, width -29 dB; 03. GAK 3: 126 BPM, 3 settled chords a minute, 32% of energy above 2 kHz, width -20 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: 03. GAK 3: 32% of energy above 2 kHz (bright or harsh).

### For later
- 01. GAK 1, bass group `bass-2` (205 notes): around C1, bell- or metal-like (partials off whole multiples), quick attack, falls 70 dB/s, centered; hear it at 1:56.5, 0:54.7. **[JUDGMENT]** why it waits.
- 02. GAK 2, bass group `bass-2` (97 notes): around B1, bell- or metal-like (partials off whole multiples), soft attack, falls 112 dB/s, centered; hear it at 0:13.6, 0:00.8. **[JUDGMENT]** why it waits.
- 03. GAK 3, bass group `bass-1` (137 notes): around G1, harmonic (string/reed/pad-like), odd harmonics stronger (square/clarinet-like), soft attack, falls 36 dB/s, centered; hear it at 3:52.7, 5:19.9. **[JUDGMENT]** why it waits.
- 03. GAK 3, drums group `drums-2` (173 notes): low thump, quick attack, falls 89 dB/s, centered; hear it at 3:42.0, 2:11.9. **[JUDGMENT]** why it waits.
- 03. GAK 3, bass group `bass-2` (123 notes): around A#1, harmonic (string/reed/pad-like), quick attack, falls 36 dB/s, centered; hear it at 5:20.7, 5:19.9. **[JUDGMENT]** why it waits.
- 01. GAK 1, drums group `drums-2` (109 notes): low thump, quick attack, falls 37 dB/s, gets darker over the note, centered; hear it at 6:31.5, 6:31.4. **[JUDGMENT]** why it waits.
- 02. GAK 2, drums group `drums-2` (44 notes): low thump, quick attack, falls 249 dB/s, centered; hear it at 0:24.3, 1:55.6. **[JUDGMENT]** why it waits.
- 01. GAK 1, other group `other-1` (183 notes): around C#3, mixed or noisy partials, soft attack, falls 41 dB/s, gets darker over the note, centered; hear it at 5:03.4, 4:57.4. **[JUDGMENT]** why it waits.
- **08. gak6 e,+3** (5:25.2, 129 BPM by the mix-level count): stands out for wobble (cents) 8.45 (high, album median 6.76); brightness sweep (octaves) 2.14 (high, album median 0.67). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **04. GAK 4** (6:04.4, 118 BPM by the mix-level count): stands out for brightness sweep (octaves) 3.13 (high, album median 0.67). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **07. gak5 e,+3** (1:38.0, 118 BPM by the mix-level count): stands out for repetition 0.44 (low, album median 0.70); wobble (cents) 5.50 (low, album median 6.76). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
