## Aphex Twin - Analogue Bubblebath 4 (draft card from Ears 3 tools, 2026-10-18)

How it was made: EP or short record (4 usable tracks): every track. Deep pass on: Untitled; Cuckoo; Untitled; Untitled. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 69 to 133 BPM (octave-uncertain); keys E phrygian, D aeolian, G phrygian, F# lydian; mix width -28 to -20 dB; chord changes 8 to 31 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Cuckoo: drums group `drums-1` (423 notes, 55% of the track's note energy)
- In synth terms: low thump, quick attack, falls 181 dB/s, gets brighter over the note, centered.
- Hear it at: 4:35.0 (B1, 0.36 s, +37 dB alone), 4:43.7 (C2, 0.29 s, +36 dB alone), 1:05.9 (C2, 0.39 s, +34 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 65 (64 to 65) Hz; attack 38 (28 to 44) ms; decay -181 (-189 to -164) dB/s
  - brightness at the start 72 (70 to 81) Hz; slope over the note 0.63 (0.06 to 2.47) octaves
  - harmonic share 0.99 (0.98 to 1.00); partials off whole multiples 145 (31 to 268) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.2 (-0.4 to -0.0) dB; pan 0.01 (-0.01 to 0.02); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S2. Untitled: bass group `bass-1` (409 notes, 44% of the track's note energy)
- In synth terms: around A1, harmonic (string/reed/pad-like), slow swell, falls 14 dB/s, centered.
- Hear it at: 1:18.8 (A1, 0.25 s, +13 dB alone), 1:18.9 (G#1, 0.4 s, +12 dB alone), 2:10.6 (A1, 0.36 s, +10 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 55 (53 to 56) Hz; attack 202 (61 to 373) ms; decay -14 (-72 to 5) dB/s
  - brightness at the start 71 (67 to 97) Hz; slope over the note -0.01 (-0.10 to 0.01) octaves
  - harmonic share 1.00 (0.50 to 1.00); partials off whole multiples 54 (8 to 181) cents
  - vibrato 0 (0 to 21) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.1 (-5.5 to -1.2) dB; pan 0.00 (-0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S3. Untitled: drums group `drums-1` (356 notes, 37% of the track's note energy)
- In synth terms: low thump, soft attack, falls 18 dB/s, centered.
- Hear it at: 0:24.3 (A1, 0.29 s, +8 dB alone), 1:17.9 (A1, 0.18 s, +8 dB alone), 0:55.4 (A1, 0.29 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 54 (42 to 63) Hz; attack 49 (16 to 166) ms; decay -18 (-64 to 9) dB/s
  - brightness at the start 101 (75 to 137) Hz; slope over the note 0.00 (-0.29 to 0.20) octaves
  - harmonic share 0.81 (0.06 to 0.98); partials off whole multiples 234 (143 to 367) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-1.8 to -0.9) dB; pan 0.01 (-0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S4. Untitled: drums group `drums-1` (490 notes, 35% of the track's note energy)
- In synth terms: low thump, soft attack, falls 23 dB/s, centered.
- Hear it at: 0:15.6 (A1, 0.32 s, +34 dB alone), 6:02.8 (B1, 0.1 s, +14 dB alone), 0:24.9 (A1, 0.22 s, +13 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (54 to 62) Hz; attack 52 (17 to 141) ms; decay -23 (-53 to -9) dB/s
  - brightness at the start 68 (65 to 100) Hz; slope over the note 0.00 (-0.05 to 0.06) octaves
  - harmonic share 1.00 (0.56 to 1.00); partials off whole multiples 135 (37 to 229) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-2.0 to -0.8) dB; pan -0.00 (-0.01 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S5. Untitled: drums group `drums-1` (235 notes, 33% of the track's note energy)
- In synth terms: low thump, soft attack, falls 27 dB/s, gets brighter over the note, centered.
- Hear it at: 3:20.6 (G1, 0.24 s, +22 dB alone), 0:04.5 (G1, 0.45 s, +20 dB alone), 3:23.9 (G1, 0.24 s, +20 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (48 to 54) Hz; attack 55 (46 to 139) ms; decay -27 (-61 to -3) dB/s
  - brightness at the start 101 (82 to 155) Hz; slope over the note 0.35 (-0.38 to 1.58) octaves
  - harmonic share 0.98 (0.40 to 0.99); partials off whole multiples 190 (114 to 325) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.2 (-0.6 to -0.1) dB; pan -0.01 (-0.02 to -0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S6. Untitled: drums group `drums-2` (176 notes, 29% of the track's note energy)
- In synth terms: low thump, slow swell, falls 98 dB/s, gets brighter over the note, centered.
- Hear it at: 0:18.6 (G1, 0.23 s, +22 dB alone), 3:22.7 (G1, 0.39 s, +19 dB alone), 0:34.9 (G1, 0.39 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (33 to 49) Hz; attack 183 (139 to 196) ms; decay -98 (-132 to -65) dB/s
  - brightness at the start 100 (79 to 159) Hz; slope over the note 0.37 (-0.09 to 2.52) octaves
  - harmonic share 0.95 (0.05 to 0.99); partials off whole multiples 259 (139 to 376) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-0.9 to -0.1) dB; pan -0.01 (-0.02 to -0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs), not on the raw mix.

#### S7. Untitled: bass group `bass-1` (467 notes, 25% of the track's note energy)
- In synth terms: around D1, bell- or metal-like (partials off whole multiples), soft attack, falls 35 dB/s, centered.
- Hear it at: 4:15.7 (D1, 0.07 s, +2 dB alone), 1:50.0 (B0, 0.08 s, +1 dB alone), 3:44.2 (?, 0.19 s, -1 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 37 (32 to 39) Hz; attack 94 (16 to 190) ms; decay -35 (-185 to 11) dB/s
  - brightness at the start 103 (87 to 141) Hz; slope over the note 0.00 (-0.13 to 0.29) octaves
  - harmonic share 0.24 (0.09 to 0.49); partials off whole multiples 201 (93 to 306) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.3 (-6.2 to -4.3) dB; pan 0.00 (-0.00 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs), not on the raw mix.

#### S8. Cuckoo: vocals group `vocals-1` (348 notes, 10% of the track's note energy)
- In synth terms: around G3, harmonic (string/reed/pad-like), soft attack, falls 50 dB/s, centered.
- Hear it at: 4:11.9 (G4, 0.23 s, +31 dB alone), 2:02.5 (?, 0.08 s, +28 dB alone), 4:11.7 (F3, 0.21 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 192 (105 to 378) Hz; attack 60 (19 to 230) ms; decay -50 (-116 to -15) dB/s
  - brightness at the start 990 (411 to 2779) Hz; slope over the note 0.00 (-0.74 to 1.28) octaves
  - harmonic share 0.87 (0.29 to 0.99); partials off whole multiples 25 (9 to 94) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -11.9 (-16.0 to -0.9) dB; pan 0.02 (-0.11 to 0.05); left-right correlation 0.88 (0.64 to 0.98)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs), not on the raw mix.

### Techniques
- **Untitled sections:** 18 boundaries at 0:18.0, 0:37.0, 1:12.0, 1:23.0, 1:38.0, 2:03.0, 2:35.0, 2:53.0, 3:09.0, 3:21.0, 3:35.0, 3:47.0; section lengths median 18 s (range 2 to 39). Reliable for sections of 10 s or more.
- **Untitled stem entries and exits:** drums plays 96% of the time (in: 0:15.5; out: never); bass plays 96% of the time (in: 0:15.5; out: never); other plays 96% of the time (in: 0:15.5; out: never); vocals plays 82% of the time (in: 0:34.0, 1:05.5, 1:22.0; out: 0:37.0, 1:18.0, 6:19.0).
- **Untitled floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Untitled brightness sweeps (0.7 octave or more):** mix down 1.2 oct 0:57.0 to 1:02.0; mix down 1.2 oct 1:15.0 to 1:20.5; mix up 2.7 oct 1:20.5 to 1:25.5; mix down 1.6 oct 1:26.0 to 1:31.0; mix up 1.1 oct 4:03.5 to 4:11.0; mix down 2.2 oct 4:45.0 to 4:50.5; mix down 1.2 oct 5:52.5 to 5:57.5; other down 1.3 oct 0:13.5 to 0:25.0 (17 more in techniques.json).
- **Untitled echo times:** other: 664 ms (+6.4 dB, 1 later repeats).
- **Untitled pumping locked to the kick:** other dips 5.9 dB at the kick (peak 85 ms after, kick every 0.39 s); bass dips 3.1 dB at the kick (peak 319 ms after, kick every 0.39 s). The tool reads about 70% of the true depth, so this is a floor.
- **Untitled tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Untitled stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Cuckoo sections:** 16 boundaries at 0:01.0, 0:11.0, 0:32.0, 1:15.0, 1:34.0, 2:01.0, 2:14.0, 2:44.0, 2:55.0, 3:31.0, 4:07.0, 4:19.0; section lengths median 19 s (range 1 to 43). Reliable for sections of 10 s or more.
- **Cuckoo stem entries and exits:** drums plays 91% of the time (in: 0:09.0, 0:30.0, 4:13.0; out: 0:24.0, 4:07.0, 5:52.5); bass plays 81% of the time (in: 0:30.0, 4:35.0; out: 4:06.0, 5:52.5); other plays 63% of the time (in: 0:16.0, 1:14.5, 1:31.0, 1:42.5, 1:57.0; out: 0:11.0, 1:10.5, 1:20.5, 1:33.5, 1:46.0); vocals plays 85% of the time (in: 0:30.0, 1:06.5, 5:02.0; out: 0:18.5, 1:00.0, 4:35.0, 5:55.0).
- **Cuckoo floor drops (kick and bass out 2 s or more while the rest plays):** 0.37 a minute: 0:18.2 for 12.2 s, 4:06.5 for 7.0 s.
- **Cuckoo brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:08.0 to 0:13.5; mix down 4.0 oct 0:25.0 to 0:35.5; mix down 0.9 oct 2:56.5 to 3:05.5; mix up 2.2 oct 3:05.5 to 3:17.0; mix up 2.3 oct 4:02.5 to 4:10.0; mix down 2.3 oct 4:10.0 to 4:19.5; mix up 2.0 oct 5:35.0 to 5:40.5; mix down 2.3 oct 5:40.5 to 5:48.5 (32 more in techniques.json).
- **Cuckoo echo times:** drums: 439 ms (+12.3 dB, 2 later repeats).
- **Cuckoo pumping locked to the kick:** other dips 1.8 dB at the kick (peak 175 ms after, kick every 0.43 s); bass dips 17.8 dB at the kick (peak 339 ms after, kick every 0.43 s). The tool reads about 70% of the true depth, so this is a floor.
- **Cuckoo tape wobble and speed:** bass wobbles about 4 cents at 1.6 Hz.
- **Cuckoo stereo movement:** other pan range 0.29.
- **Cuckoo builds:** 0:15.0 to 0:36.0.
- **Untitled sections:** 14 boundaries at 0:03.0, 0:29.0, 0:56.0, 1:07.0, 1:20.0, 1:33.0, 1:57.0, 2:08.0, 2:25.0, 2:49.0, 2:59.0, 3:32.0; section lengths median 17 s (range 3 to 52). Reliable for sections of 10 s or more.
- **Untitled stem entries and exits:** drums plays 97% of the time (in: 2:04.5, 2:55.0; out: 2:01.0, 2:50.5, 5:06.0); bass plays 74% of the time (in: 1:11.5, 1:38.5, 2:44.5, 3:02.5, 3:24.5; out: 0:32.5, 1:25.5, 2:41.5, 2:58.5, 3:10.0); other plays 98% of the time (in: 0:03.5; out: 5:06.0); vocals plays 91% of the time (in: 0:27.0; out: 5:06.0).
- **Untitled floor drops (kick and bass out 2 s or more while the rest plays):** 0.43 a minute: 1:59.8 for 6.8 s, 2:49.0 for 7.0 s.
- **Untitled brightness sweeps (0.7 octave or more):** mix down 3.4 oct 0:00.0 to 0:05.0; mix up 0.9 oct 0:24.0 to 0:31.5; mix up 3.3 oct 0:35.0 to 0:47.0; mix down 3.0 oct 1:08.0 to 1:13.5; mix down 2.1 oct 1:22.0 to 1:31.5; mix down 1.0 oct 1:49.0 to 1:56.0; mix up 3.5 oct 1:56.0 to 2:03.0; mix down 3.2 oct 2:03.0 to 2:09.0 (43 more in techniques.json).
- **Untitled echo times:** other: 175 ms (+4.5 dB, 4 later repeats).
- **Untitled pumping locked to the kick:** other dips 3.2 dB at the kick (peak 155 ms after, kick every 0.41 s); bass dips 6.8 dB at the kick (peak 279 ms after, kick every 0.41 s). The tool reads about 70% of the true depth, so this is a floor.
- **Untitled tape wobble and speed:** bass wobbles about 10 cents at 2.4 Hz.
- **Untitled stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Untitled sections:** 20 boundaries at 0:24.0, 0:59.0, 1:12.0, 1:42.0, 2:05.0, 2:29.0, 2:51.0, 3:09.0, 3:24.0, 3:44.0, 4:02.0, 4:14.0; section lengths median 20 s (range 5 to 77). Reliable for sections of 10 s or more.
- **Untitled stem entries and exits:** drums plays 95% of the time (in: 4:20.5, 4:38.5; out: 4:15.0, 4:26.5, 8:16.0); bass plays 95% of the time (in: 0:21.5; out: 8:16.0); other plays 76% of the time (in: 1:10.5; out: 7:30.0); vocals plays 0% of the time (in: from the start; out: never).
- **Untitled floor drops (kick and bass out 2 s or more while the rest plays):** 0.53 a minute: 4:13.5 for 4.0 s, 4:22.0 for 2.8 s, 4:25.0 for 3.5 s, 4:30.2 for 9.0 s.
- **Untitled brightness sweeps (0.7 octave or more):** mix down 2.9 oct 0:02.0 to 0:10.5; mix down 5.4 oct 0:20.0 to 0:28.0; mix up 1.5 oct 0:35.0 to 0:41.5; mix down 1.5 oct 0:41.5 to 0:46.5; mix up 1.8 oct 1:05.0 to 1:12.5; mix down 1.1 oct 1:21.0 to 1:29.0; mix up 0.7 oct 1:29.5 to 1:35.5; mix down 1.5 oct 2:12.0 to 2:20.5 (44 more in techniques.json).
- **Untitled echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Untitled pumping locked to the kick:** other dips 3.6 dB at the kick (peak 190 ms after, kick every 0.47 s); bass dips 5.7 dB at the kick (peak 469 ms after, kick every 0.47 s). The tool reads about 70% of the true depth, so this is a floor.
- **Untitled tape wobble and speed:** other speed moves up to 11 cents in 4 s.
- **Untitled stereo movement:** other pan range 0.30.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Untitled meter:** about 93 BPM (could be 46 or 185; the tool cannot tell the beat level), 8 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:3, 5:4, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Untitled key and mode:** E phrygian (low confidence: the key signature margin is 0.001, so read this as a guess); pitch-class weights E 0.14, F 0.12, F# 0.10, D# 0.10, C 0.08.
- **Untitled chords:** 17 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 0.7 to 9.5 s); 31 distinct chords; most time on Fmaj7 66%, F#maj7 4%, Emaj7 4%, Esus2 4%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  47% of the changes land on a beat (chance would be 46%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Untitled top line (from the 'other' stem; read by ear before trusting):** 598 notes, range 28 semitones (10th to 90th percentile); steps 22%, thirds 21%, fourths and fifths 11%, leaps 34%, repeats 12%; median interval 4 semitones; 49% of moves go up; phrases of about 5 notes, arch 42%, rising 12%, falling 25%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **Untitled repetition:** 73 bars of 5.2 s; strongest repeat distances 2 bars (0.65), 4 bars (0.58), 6 bars (0.50); 1% of bars near-duplicate an earlier bar.
- **Cuckoo meter:** about 69 BPM (could be 34 or 138; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.19); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Cuckoo key and mode:** D aeolian (minor) (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights D 0.12, C# 0.12, C 0.11, G 0.10, E 0.09.
- **Cuckoo chords:** 31 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 1.6 s (10th to 90th percentile 0.7 to 3.8 s); 31 distinct chords; most time on Dmaj7 32%, Csus2 13%, Fmaj7 11%, Cmaj7 7%. The old counter in this same run said 14; Ears 1's 2-s counter said 16.  19% of the changes land on a beat (chance would be 34%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Cuckoo bass:** root-note movement / mixed; 1.10 notes a second; most time on D 0.42, C 0.14, C# 0.12, F 0.11; steps 26%, thirds 14%, fourths and fifths 21%, octaves 0%, repeats 35%.
- **Cuckoo top line (from the 'other' stem; read by ear before trusting):** 722 notes, range 34 semitones (10th to 90th percentile); steps 31%, thirds 18%, fourths and fifths 10%, leaps 22%, repeats 18%; median interval 3 semitones; 52% of moves go up; phrases of about 12 notes, arch 23%, rising 5%, falling 32%, flat or wavy 41%. Reliable only when the line sits clearly above its accompaniment.
- **Cuckoo repetition:** 104 bars of 3.5 s; strongest repeat distances 1 bars (0.54), 4 bars (0.34), 8 bars (0.13); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Untitled meter:** about 73 BPM (could be 36 or 146; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.04); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Untitled key and mode:** G phrygian (low confidence: the key signature margin is 0.008, so read this as a guess); pitch-class weights D 0.13, D# 0.11, C# 0.10, E 0.08, F 0.08.
- **Untitled chords:** 8 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 4.3 s (10th to 90th percentile 0.9 to 18.4 s); 16 distinct chords; most time on Dmaj7 26%, Bmaj7 19%, Emin7 14%, Emaj7 12%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  40% of the changes land on a beat (chance would be 36%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Untitled bass:** pedal (one note held or repeated); 0.49 notes a second; most time on G 0.70, D 0.13, B 0.08, G# 0.04; steps 10%, thirds 13%, fourths and fifths 5%, octaves 0%, repeats 70%.
- **Untitled top line (from the 'other' stem; read by ear before trusting):** 544 notes, range 22 semitones (10th to 90th percentile); steps 17%, thirds 17%, fourths and fifths 14%, leaps 30%, repeats 22%; median interval 4 semitones; 52% of moves go up; phrases of about 5 notes, arch 30%, rising 9%, falling 30%, flat or wavy 30%. Reliable only when the line sits clearly above its accompaniment.
- **Untitled repetition:** 93 bars of 3.3 s; strongest repeat distances 1 bars (0.69), 27 bars (-0.05); 10% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Untitled meter:** about 133 BPM (could be 66 or 266; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.56 of the beat; no cross-rhythm claim; many unrelated periodicities found (4:3, 5:2, 5:3, 5:4), which means irregular timing, not a cross-rhythm claim.
- **Untitled key and mode:** F# lydian (key signature margin 0.101); pitch-class weights C 0.16, F# 0.15, C# 0.12, G# 0.09, A# 0.09.
- **Untitled chords:** 16 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 3.6 s (10th to 90th percentile 1.1 to 3.7 s); 22 distinct chords; most time on C#maj7 54%, F#7 29%, F# 2%, G#7 2%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  22% of the changes land on a beat (chance would be 66%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Untitled bass:** root-note movement / mixed; 1.88 notes a second; most time on A 0.67, B 0.29, A# 0.03; steps 24%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 75%.
- **Untitled top line (from the 'other' stem; read by ear before trusting):** 1025 notes, range 10 semitones (10th to 90th percentile); steps 8%, thirds 43%, fourths and fifths 17%, leaps 12%, repeats 20%; median interval 3 semitones; 52% of moves go up; phrases of about 20 notes, arch 36%, rising 8%, falling 20%, flat or wavy 36%. Reliable only when the line sits clearly above its accompaniment.
- **Untitled repetition:** 277 bars of 1.8 s; strongest repeat distances 4 bars (0.68), 1 bars (0.63), 8 bars (0.59); 20% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Untitled mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -35 (corr 1.00); low_120_500 -18 (corr 0.97); mid_500_2k -20 (corr 0.98); pres_2k_5k -21 (corr 0.99); air_gt5k -22 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -30/-26/-13 dB.
- **Untitled by part:** drums: 69% of the power, width -30 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-32 dB); bass: 24% of the power, width -35 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-38 dB); other: 2% of the power, width -14 dB, pan -0.01, mono loss 0.2 dB, widest in low_120_500 (-7 dB); vocals: 5% of the power, width -21 dB, pan -0.02, mono loss 0.0 dB, widest in mid_500_2k (-20 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Cuckoo mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -31 (corr 1.00); low_120_500 -16 (corr 0.95); mid_500_2k -8 (corr 0.74); pres_2k_5k -7 (corr 0.68); air_gt5k -6 (corr 0.60); over time (2-s windows) 10th/50th/90th percentile -15/-12/-8 dB.
- **Cuckoo by part:** drums: 91% of the power, width -24 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-31 dB); bass: 4% of the power, width -34 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-35 dB); other: 1% of the power, width -6 dB, pan -0.07, mono loss 0.9 dB, widest in mid_500_2k (-5 dB); vocals: 4% of the power, width -10 dB, pan -0.01, mono loss 0.5 dB, widest in pres_2k_5k (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Untitled mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -31 (corr 1.00); low_120_500 -21 (corr 0.98); mid_500_2k -15 (corr 0.94); pres_2k_5k -14 (corr 0.92); air_gt5k -16 (corr 0.95); over time (2-s windows) 10th/50th/90th percentile -28/-24/-12 dB.
- **Untitled by part:** drums: 89% of the power, width -26 dB, pan -0.02, mono loss 0.0 dB, widest in low_120_500 (-23 dB); bass: 2% of the power, width -27 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-33 dB); other: 4% of the power, width -19 dB, pan -0.01, mono loss 0.0 dB, widest in mid_500_2k (-20 dB); vocals: 5% of the power, width -16 dB, pan -0.01, mono loss 0.1 dB, widest in mid_500_2k (-12 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Untitled mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -35 (corr 1.00); low_120_500 -8 (corr 0.74); mid_500_2k -7 (corr 0.70); pres_2k_5k -11 (corr 0.87); air_gt5k -15 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -18/-8/-6 dB.
- **Untitled by part:** drums: 59% of the power, width -30 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-32 dB); bass: 37% of the power, width -37 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-37 dB); other: 4% of the power, width -6 dB, pan -0.29, mono loss 1.0 dB, widest in low_120_500 (-6 dB); vocals: 0% of the power, width -14 dB, pan -0.02, mono loss 0.2 dB, widest in air_gt5k (-12 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Untitled: 93 BPM, 10 settled chords a minute, 3% of energy above 2 kHz, width -28 dB; Cuckoo: 69 BPM, 17 settled chords a minute, 2% of energy above 2 kHz, width -20 dB; Untitled: 73 BPM, 6 settled chords a minute, 5% of energy above 2 kHz, width -23 dB; Untitled: 133 BPM, 14 settled chords a minute, 0% of energy above 2 kHz, width -23 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Untitled, drums group `drums-2` (144 notes): low thump, soft attack, falls 38 dB/s, centered; hear it at 6:18.5, 6:19.7. **[JUDGMENT]** why it waits.
- Untitled, vocals group `vocals-1` (81 notes): around A#5, harmonic (string/reed/pad-like), slow swell, falls 19 dB/s, centered; hear it at 1:23.3, 4:43.6. **[JUDGMENT]** why it waits.
- Untitled, vocals group `vocals-1` (371 notes): around F2, mixed or noisy partials, soft attack, falls 54 dB/s, centered; hear it at 2:03.3, 2:03.1. **[JUDGMENT]** why it waits.
- Untitled, bass group `bass-2` (91 notes): around B1, bell- or metal-like (partials off whole multiples), soft attack, falls 7 dB/s, centered; hear it at 7:45.6, 1:14.0. **[JUDGMENT]** why it waits.
- Untitled, other group `other-1` (270 notes): around F#3, bell- or metal-like (partials off whole multiples), soft attack, falls 24 dB/s, leans left (-0.15); hear it at 4:34.6, 4:33.3. **[JUDGMENT]** why it waits.
- Cuckoo, other group `other-1` (401 notes): around A3, bell- or metal-like (partials off whole multiples), soft attack, falls 35 dB/s, centered; hear it at 0:24.8, 0:24.5. **[JUDGMENT]** why it waits.
- Cuckoo, vocals group `vocals-2` (152 notes): around G5, bell- or metal-like (partials off whole multiples), soft attack, falls 60 dB/s, centered; hear it at 4:12.8, 4:13.1. **[JUDGMENT]** why it waits.
- Untitled, vocals group `vocals-2` (76 notes): around A5, bell- or metal-like (partials off whole multiples), soft attack, falls 17 dB/s, centered; hear it at 4:09.1, 1:57.8. **[JUDGMENT]** why it waits.
- **Untitled** (0:27.6, 118 BPM by the mix-level count): stands out for pulse strength 0.08 (low, album median 0.79); repetition 0.12 (low, album median 0.54). Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
