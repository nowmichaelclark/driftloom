| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| padWow-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| padWow-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | sketch |
| padWow-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| padWow-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | sketch |
| padWow-undertow45-none | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
| padWow-undertow45-with | dun-roar (corpus 20261009 #45) | 982035031 | wash | sketch |
| padWow-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | - | - |
| padWow-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | - | sketch |
