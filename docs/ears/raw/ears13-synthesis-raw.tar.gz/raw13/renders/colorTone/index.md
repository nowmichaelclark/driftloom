| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| colorTone-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | organ, lateFloor | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | organ, lateFloor | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-vapor4-none | so-rou (corpus 20261009 #4) | 2541830973 | organ, wash, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-vapor4-with | so-rou (corpus 20261009 #4) | 2541830973 | organ, wash, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-tide39-none | broan-bro (corpus 20261009 #39) | 2339303565 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-tide39-with | broan-bro (corpus 20261009 #39) | 2339303565 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
