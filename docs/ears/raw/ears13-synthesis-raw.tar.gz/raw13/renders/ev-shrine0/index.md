| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | organ, lateFloor | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| everything-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | organ, lateFloor | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
