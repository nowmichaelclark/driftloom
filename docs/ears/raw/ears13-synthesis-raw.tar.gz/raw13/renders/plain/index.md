| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| plain-38 | thei-rour (corpus 20261009 #38) | 2996131148 | floorDrop:shapes | - |
| plain-62 | muith-sei (corpus 20261009 #62) | 3904986567 | - | - |
| plain-71 | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| plain-69 | thar-noan (corpus 20261009 #69) | 1781115328 | glass | - |
| plain-0 | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| plain-45 | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
