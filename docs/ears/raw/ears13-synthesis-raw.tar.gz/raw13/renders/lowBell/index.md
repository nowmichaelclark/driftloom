| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| lowBell-haven38-none | thei-rour (corpus 20261009 #38) | 2996131148 | organ, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| lowBell-haven38-with | thei-rour (corpus 20261009 #38) | 2996131148 | organ, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| lowBell-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| lowBell-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| lowBell-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| lowBell-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| lowBell-dust69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| lowBell-dust69-with | thar-noan (corpus 20261009 #69) | 1781115328 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
