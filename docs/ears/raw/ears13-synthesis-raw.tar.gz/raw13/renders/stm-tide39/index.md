| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything-tide39-none-mono | broan-bro (corpus 20261009 #39) | 2339303565 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| everything-tide39-with-mono | broan-bro (corpus 20261009 #39) | 2339303565 | glass, organ, subDuck | force organ=on, force subDuck=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, pin sub_duck.depth=14, pin sub_duck.recover=0.6, sketch |
