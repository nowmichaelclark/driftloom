| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything-grove62-none-mono | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| everything-grove62-with-mono | muith-sei (corpus 20261009 #62) | 3904986567 | organ, subDuck | force organ=on, force subDuck=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, pin sub_duck.depth=14, pin sub_duck.recover=0.6, sketch |
