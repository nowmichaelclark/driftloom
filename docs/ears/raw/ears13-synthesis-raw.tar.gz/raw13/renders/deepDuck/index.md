| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| deepDuck-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | - | force subDuck=today |
| deepDuck-grove62-approved | muith-sei (corpus 20261009 #62) | 3904986567 | subDuck | force subDuck=on |
| deepDuck-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | subDuck | force subDuck=on, pin sub_duck.depth=14, pin sub_duck.recover=0.6 |
| deepDuck-undertow45-none | dun-roar (corpus 20261009 #45) | 982035031 | wash | force subDuck=today |
| deepDuck-undertow45-approved | dun-roar (corpus 20261009 #45) | 982035031 | wash, subDuck | force subDuck=on |
| deepDuck-undertow45-with | dun-roar (corpus 20261009 #45) | 982035031 | wash, subDuck | force subDuck=on, pin sub_duck.depth=14, pin sub_duck.recover=0.6 |
| deepDuck-halcyon48-none | sai-ro (corpus 20261009 #48) | 3000370218 | - | force subDuck=today |
| deepDuck-halcyon48-approved | sai-ro (corpus 20261009 #48) | 3000370218 | subDuck | force subDuck=on |
| deepDuck-halcyon48-with | sai-ro (corpus 20261009 #48) | 3000370218 | subDuck | force subDuck=on, pin sub_duck.depth=14, pin sub_duck.recover=0.6 |
| deepDuck-dust69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass | force subDuck=today |
| deepDuck-dust69-approved | thar-noan (corpus 20261009 #69) | 1781115328 | glass, subDuck | force subDuck=on |
| deepDuck-dust69-with | thar-noan (corpus 20261009 #69) | 1781115328 | glass, subDuck | force subDuck=on, pin sub_duck.depth=14, pin sub_duck.recover=0.6 |
