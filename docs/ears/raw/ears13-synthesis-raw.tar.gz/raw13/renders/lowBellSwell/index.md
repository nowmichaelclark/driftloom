| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| lowBell-haven38-swell | thei-rour (corpus 20261009 #38) | 2996131148 | organ, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| lowBell-grove62-swell | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| lowBell-thaw71-swell | meisk-thoa (corpus 20261009 #71) | 1204220801 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| lowBell-dust69-swell | thar-noan (corpus 20261009 #69) | 1781115328 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
