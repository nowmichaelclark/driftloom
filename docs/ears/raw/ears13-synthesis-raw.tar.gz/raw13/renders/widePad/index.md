| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| widePad-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| widePad-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | sketch |
| widePad-shrine0-mono | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| widePad-shrine0-monowith | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | sketch |
| widePad-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| widePad-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | sketch |
| widePad-thaw71-mono | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| widePad-thaw71-monowith | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | sketch |
| widePad-undertow45-none | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
| widePad-undertow45-with | dun-roar (corpus 20261009 #45) | 982035031 | wash | sketch |
| widePad-undertow45-mono | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
| widePad-undertow45-monowith | dun-roar (corpus 20261009 #45) | 982035031 | wash | sketch |
| widePad-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | - | - |
| widePad-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | - | sketch |
| widePad-grove62-mono | muith-sei (corpus 20261009 #62) | 3904986567 | - | - |
| widePad-grove62-monowith | muith-sei (corpus 20261009 #62) | 3904986567 | - | sketch |
