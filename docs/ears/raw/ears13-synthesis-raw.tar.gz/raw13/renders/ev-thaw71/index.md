| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| everything-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | organ, padSweep | force organ=on, force padSweep=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, pin pad_sweep.lo=380, pin pad_sweep.oct=4.2, pin pad_sweep.period=16, pin pad_sweep.q=1, sketch |
