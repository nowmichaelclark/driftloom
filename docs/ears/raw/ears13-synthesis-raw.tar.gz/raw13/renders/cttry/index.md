| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| colorTone-l0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | organ, lateFloor | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | organ, lateFloor | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l45-none | dun-roar (corpus 20261009 #45) | 982035031 | organ, wash | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l45-with | dun-roar (corpus 20261009 #45) | 982035031 | organ, wash | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l62-none | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l62-with | muith-sei (corpus 20261009 #62) | 3904986567 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l69-with | thar-noan (corpus 20261009 #69) | 1781115328 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l8-none | risk-gluim (corpus 20261009 #8) | 1437476548 | organ, pedalBass | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l8-with | risk-gluim (corpus 20261009 #8) | 1437476548 | organ, pedalBass | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l47-none | sheith-sith (corpus 20261009 #47) | 3194185058 | organ, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l47-with | sheith-sith (corpus 20261009 #47) | 3194185058 | organ, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l61-none | rail-te (corpus 20261009 #61) | 2837207586 | organ, tunedKick:short, lateFloor, pedalBass | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l61-with | rail-te (corpus 20261009 #61) | 2837207586 | organ, tunedKick:short, lateFloor, pedalBass | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l4-none | so-rou (corpus 20261009 #4) | 2541830973 | organ, wash, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l4-with | so-rou (corpus 20261009 #4) | 2541830973 | organ, wash, floorDrop:shapes | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
| colorTone-l39-none | broan-bro (corpus 20261009 #39) | 2339303565 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0 |
| colorTone-l39-with | broan-bro (corpus 20261009 #39) | 2339303565 | glass, organ | force organ=on, pin organ.level=0, pin organ.verb=0, pin organ.dry=0, sketch |
