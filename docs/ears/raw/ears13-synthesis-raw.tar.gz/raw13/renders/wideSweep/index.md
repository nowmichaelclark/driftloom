| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| wideSweep-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | - | force padSweep=today |
| wideSweep-grove62-approved | muith-sei (corpus 20261009 #62) | 3904986567 | padSweep | force padSweep=on |
| wideSweep-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | padSweep | force padSweep=on, pin pad_sweep.lo=380, pin pad_sweep.oct=4.2, pin pad_sweep.period=16, pin pad_sweep.q=1 |
| wideSweep-grove62-fast | muith-sei (corpus 20261009 #62) | 3904986567 | padSweep | force padSweep=on, pin pad_sweep.lo=550, pin pad_sweep.oct=2.6, pin pad_sweep.period=6.5, pin pad_sweep.q=0.9 |
| wideSweep-undertow45-none | dun-roar (corpus 20261009 #45) | 982035031 | wash | force padSweep=today |
| wideSweep-undertow45-approved | dun-roar (corpus 20261009 #45) | 982035031 | wash, padSweep | force padSweep=on |
| wideSweep-undertow45-with | dun-roar (corpus 20261009 #45) | 982035031 | wash, padSweep | force padSweep=on, pin pad_sweep.lo=380, pin pad_sweep.oct=4.2, pin pad_sweep.period=16, pin pad_sweep.q=1 |
| wideSweep-undertow45-fast | dun-roar (corpus 20261009 #45) | 982035031 | wash, padSweep | force padSweep=on, pin pad_sweep.lo=550, pin pad_sweep.oct=2.6, pin pad_sweep.period=6.5, pin pad_sweep.q=0.9 |
| wideSweep-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | force padSweep=today |
| wideSweep-shrine0-approved | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor, padSweep | force padSweep=on |
| wideSweep-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor, padSweep | force padSweep=on, pin pad_sweep.lo=380, pin pad_sweep.oct=4.2, pin pad_sweep.period=16, pin pad_sweep.q=1 |
| wideSweep-shrine0-fast | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor, padSweep | force padSweep=on, pin pad_sweep.lo=550, pin pad_sweep.oct=2.6, pin pad_sweep.period=6.5, pin pad_sweep.q=0.9 |
| wideSweep-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | force padSweep=today |
| wideSweep-thaw71-approved | meisk-thoa (corpus 20261009 #71) | 1204220801 | padSweep | force padSweep=on |
| wideSweep-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | padSweep | force padSweep=on, pin pad_sweep.lo=380, pin pad_sweep.oct=4.2, pin pad_sweep.period=16, pin pad_sweep.q=1 |
| wideSweep-thaw71-fast | meisk-thoa (corpus 20261009 #71) | 1204220801 | padSweep | force padSweep=on, pin pad_sweep.lo=550, pin pad_sweep.oct=2.6, pin pad_sweep.period=6.5, pin pad_sweep.q=0.9 |
