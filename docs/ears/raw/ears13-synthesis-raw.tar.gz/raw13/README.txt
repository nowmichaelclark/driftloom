Ears 13 (the second synthesis, 2026-11-08): the measurements behind docs/ears/batch-6.md. No audio.
meas/       ab-*.txt (ab.py: loudness change, the part by ear, its loudest 3 s, bands), sketch_check-*.json,
            low_guard-*.json, stereo_guard.json (the sampler, mono against stereo, with and without)
renders/    each render set's clips.mjs index (what each loop drew, the levers, the hashes), ab.json, r2index.json
            (the adapter's render2-style index); plain/ is the six loops without anything (the silent-organ check)
jobs/       every job list; scan.json is tools/ears/scan.mjs over corpus 20261009 (80 loops)
clips-timestamps.json   where each loop starts in each clip
The sketches, the job maker, ab.py, make_clips.py and the clip plan are in tools/ears/sketches/ears13/.
