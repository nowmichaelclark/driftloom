| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| twang-thaw71-slow | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | set chords.RETUNE=1, sketch |
