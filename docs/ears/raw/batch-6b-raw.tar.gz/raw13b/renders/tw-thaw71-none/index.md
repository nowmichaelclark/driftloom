| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| twang-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | set chords.RETUNE=1 |
