| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything13b-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | set chords.RETUNE=1 |
| everything13b-thaw71-mononone | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | set chords.RETUNE=1 |
| everything13b-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | set chords.RETUNE=1, set master.CENTS=-20, sketch |
| everything13b-thaw71-monowith | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | set chords.RETUNE=1, set master.CENTS=-20, sketch |
