| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| widePad-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| widePad-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| widePad-shrine0-mono | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| widePad-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| widePad-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| widePad-thaw71-mono | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| widePad-undertow45-none | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
| widePad-undertow45-with | dun-roar (corpus 20261009 #45) | 982035031 | wash | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| widePad-undertow45-mono | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
| widePad-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | - | - |
| widePad-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | - | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| widePad-grove62-mono | muith-sei (corpus 20261009 #62) | 3904986567 | - | - |
