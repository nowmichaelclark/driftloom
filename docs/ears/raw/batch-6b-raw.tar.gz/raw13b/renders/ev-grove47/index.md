| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything13b-grove47-none | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1 |
| everything13b-grove47-mononone | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1 |
| everything13b-grove47-with | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes, dottedPulse:pulse | force floorDrop=shapes, force dottedPulse=pulse, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
| everything13b-grove47-monowith | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes, dottedPulse:pulse | force floorDrop=shapes, force dottedPulse=pulse, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
