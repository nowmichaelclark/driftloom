| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| twang-shrine13-none | num-tosk (corpus 20261009 #13) | 1093900230 | lateFloor | set chords.RETUNE=1 |
