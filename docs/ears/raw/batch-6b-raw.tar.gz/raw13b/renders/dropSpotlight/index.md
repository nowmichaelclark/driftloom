| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| dropSpotlight-dust9-none | le-ra (corpus 20261009 #9) | 68879422 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1 |
| dropSpotlight-dust9-with | le-ra (corpus 20261009 #9) | 68879422 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
| dropSpotlight-glade21-none | muir-fo (corpus 20261009 #21) | 84379636 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1 |
| dropSpotlight-glade21-with | muir-fo (corpus 20261009 #21) | 84379636 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
| dropSpotlight-tide39-none | broan-bro (corpus 20261009 #39) | 2339303565 | glass, floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1 |
| dropSpotlight-tide39-with | broan-bro (corpus 20261009 #39) | 2339303565 | glass, floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
| dropSpotlight-grove47-none | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1 |
| dropSpotlight-grove47-with | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
