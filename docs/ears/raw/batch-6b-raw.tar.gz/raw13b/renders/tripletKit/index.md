| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| tripletKit-dust69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass | - |
| tripletKit-dust69-with | thar-noan (corpus 20261009 #69) | 1781115328 | glass, tripletKit | force tripletKit=on |
| tripletKit-bloom74-none | hu-wuisk (corpus 20261009 #74) | 3645131671 | organ, floorDrop:shapes | - |
| tripletKit-bloom74-with | hu-wuisk (corpus 20261009 #74) | 3645131671 | organ, floorDrop:shapes, tripletKit | force tripletKit=on |
| tripletKit-tide52-none | fui-yoask (corpus 20261009 #52) | 664990823 | - | - |
| tripletKit-tide52-with | fui-yoask (corpus 20261009 #52) | 664990823 | tripletKit | force tripletKit=on |
| tripletKit-undertow75-none | visk-duin (corpus 20261009 #75) | 1368141601 | arc, subDuck, floorDrop:shapes | - |
| tripletKit-undertow75-with | visk-duin (corpus 20261009 #75) | 1368141601 | arc, subDuck, floorDrop:shapes, tripletKit | force tripletKit=on |
