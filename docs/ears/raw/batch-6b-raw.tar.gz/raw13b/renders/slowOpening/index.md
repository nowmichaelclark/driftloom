| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| slowOpening-dust69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass | force lateFloor=today |
| slowOpening-dust69-approved | thar-noan (corpus 20261009 #69) | 1781115328 | glass, lateFloor | force lateFloor=on |
| slowOpening-dust69-with | thar-noan (corpus 20261009 #69) | 1781115328 | glass, lateFloor | force lateFloor=on, set latefloor.SECONDS_MAX=90, set latefloor.FADE=12 |
| slowOpening-tide39-none | broan-bro (corpus 20261009 #39) | 2339303565 | glass | force lateFloor=today |
| slowOpening-tide39-approved | broan-bro (corpus 20261009 #39) | 2339303565 | glass, lateFloor | force lateFloor=on |
| slowOpening-tide39-with | broan-bro (corpus 20261009 #39) | 2339303565 | glass, lateFloor | force lateFloor=on, set latefloor.SECONDS_MAX=90, set latefloor.FADE=12 |
| slowOpening-dust49-none | weith-yo (corpus 20261009 #49) | 1148156092 | organ | force lateFloor=today |
| slowOpening-dust49-approved | weith-yo (corpus 20261009 #49) | 1148156092 | organ, lateFloor | force lateFloor=on |
| slowOpening-dust49-with | weith-yo (corpus 20261009 #49) | 1148156092 | organ, lateFloor | force lateFloor=on, set latefloor.SECONDS_MAX=90, set latefloor.FADE=12 |
