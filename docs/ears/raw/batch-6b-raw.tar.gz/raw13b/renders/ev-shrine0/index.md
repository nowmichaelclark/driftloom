| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything13b-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| everything13b-shrine0-mononone | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| everything13b-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor, planingSevenths | force planingSevenths=on, space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| everything13b-shrine0-monowith | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor, planingSevenths | force planingSevenths=on |
