| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| dottedPulse-undertow45-none | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
| dottedPulse-undertow45-pulse | dun-roar (corpus 20261009 #45) | 982035031 | wash, dottedPulse:pulse | force dottedPulse=pulse |
| dottedPulse-undertow45-kick332 | dun-roar (corpus 20261009 #45) | 982035031 | wash, dottedPulse:kick332 | force dottedPulse=kick332 |
| dottedPulse-dust69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass | - |
| dottedPulse-dust69-pulse | thar-noan (corpus 20261009 #69) | 1781115328 | glass, dottedPulse:pulse | force dottedPulse=pulse |
| dottedPulse-dust69-kick332 | thar-noan (corpus 20261009 #69) | 1781115328 | glass, dottedPulse:kick332 | force dottedPulse=kick332 |
| dottedPulse-grove47-none | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes | - |
| dottedPulse-grove47-pulse | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes, dottedPulse:pulse | force dottedPulse=pulse |
| dottedPulse-grove47-kick332 | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes, dottedPulse:kick332 | force dottedPulse=kick332 |
| dottedPulse-undertow1-none | sith-fai (corpus 20261009 #1) | 1794724683 | lateFloor | - |
| dottedPulse-undertow1-pulse | sith-fai (corpus 20261009 #1) | 1794724683 | lateFloor, dottedPulse:pulse | force dottedPulse=pulse |
| dottedPulse-undertow1-kick332 | sith-fai (corpus 20261009 #1) | 1794724683 | lateFloor, dottedPulse:kick332 | force dottedPulse=kick332 |
