| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| tuningOffset-vapor4-none | so-rou (corpus 20261009 #4) | 2541830973 | wash, floorDrop:shapes | - |
| tuningOffset-vapor4-with | so-rou (corpus 20261009 #4) | 2541830973 | wash, floorDrop:shapes | set master.CENTS=-32 |
| tuningOffset-dust69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass | - |
| tuningOffset-dust69-with | thar-noan (corpus 20261009 #69) | 1781115328 | glass | set master.CENTS=18 |
| tuningOffset-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| tuningOffset-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | set master.CENTS=-24 |
| tuningOffset-haven38-none | thei-rour (corpus 20261009 #38) | 2996131148 | floorDrop:shapes | - |
| tuningOffset-haven38-with | thei-rour (corpus 20261009 #38) | 2996131148 | floorDrop:shapes | set master.CENTS=27 |
