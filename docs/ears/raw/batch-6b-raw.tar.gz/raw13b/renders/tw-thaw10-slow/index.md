| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| twang-thaw10-slow | doan-kaith (corpus 20261009 #10) | 1877895177 | - | set chords.RETUNE=1, sketch |
