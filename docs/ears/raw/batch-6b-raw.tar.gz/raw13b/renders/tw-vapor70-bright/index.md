| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| twang-vapor70-bright | toth-fom (corpus 20261009 #70) | 156456753 | floorDrop:shapes | set chords.RETUNE=1, sketch |
