| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| dropSpotlight-dust9-swell | le-ra (corpus 20261009 #9) | 68879422 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
| dropSpotlight-glade21-swell | muir-fo (corpus 20261009 #21) | 84379636 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
| dropSpotlight-tide39-swell | broan-bro (corpus 20261009 #39) | 2339303565 | glass, floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
| dropSpotlight-grove47-swell | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes | force floorDrop=shapes, set chords.RETUNE=1, route sketch=drums, route sketch.1=bass, sketch |
