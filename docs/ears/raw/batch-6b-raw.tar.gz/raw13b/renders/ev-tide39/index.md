| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything13b-tide39-none | broan-bro (corpus 20261009 #39) | 2339303565 | glass | force lateFloor=today |
| everything13b-tide39-mononone | broan-bro (corpus 20261009 #39) | 2339303565 | glass | force lateFloor=today |
| everything13b-tide39-with | broan-bro (corpus 20261009 #39) | 2339303565 | glass, lateFloor | force lateFloor=on, set latefloor.SECONDS_MAX=90, set latefloor.FADE=12 |
| everything13b-tide39-monowith | broan-bro (corpus 20261009 #39) | 2339303565 | glass, lateFloor | force lateFloor=on, set latefloor.SECONDS_MAX=90, set latefloor.FADE=12 |
