| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| planingSevenths-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| planingSevenths-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor, planingSevenths | force planingSevenths=on |
| planingSevenths-tide39-none | broan-bro (corpus 20261009 #39) | 2339303565 | glass | - |
| planingSevenths-tide39-with | broan-bro (corpus 20261009 #39) | 2339303565 | glass, planingSevenths | force planingSevenths=on |
| planingSevenths-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| planingSevenths-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | planingSevenths | force planingSevenths=on |
| planingSevenths-grove47-none | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes | - |
| planingSevenths-grove47-with | sheith-sith (corpus 20261009 #47) | 3194185058 | floorDrop:shapes, planingSevenths | force planingSevenths=on |
