| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| everything13b-dust69-none | thar-noan (corpus 20261009 #69) | 1781115328 | glass | - |
| everything13b-dust69-mononone | thar-noan (corpus 20261009 #69) | 1781115328 | glass | - |
| everything13b-dust69-with | thar-noan (corpus 20261009 #69) | 1781115328 | glass, tripletKit | force tripletKit=on, set master.CENTS=18 |
| everything13b-dust69-monowith | thar-noan (corpus 20261009 #69) | 1781115328 | glass, tripletKit | force tripletKit=on, set master.CENTS=18 |
