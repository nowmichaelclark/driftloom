| clip | loop | seed | drew | levers |
|---|---|---|---|---|
| widePadStem-shrine0-none | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | - |
| widePadStem-shrine0-with | gluith-vuisk (corpus 20261009 #0) | 1068550449 | lateFloor | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| widePadStem-thaw71-none | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | - |
| widePadStem-thaw71-with | meisk-thoa (corpus 20261009 #71) | 1204220801 | - | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| widePadStem-undertow45-none | dun-roar (corpus 20261009 #45) | 982035031 | wash | - |
| widePadStem-undertow45-with | dun-roar (corpus 20261009 #45) | 982035031 | wash | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
| widePadStem-grove62-none | muith-sei (corpus 20261009 #62) | 3904986567 | - | - |
| widePadStem-grove62-with | muith-sei (corpus 20261009 #62) | 3904986567 | - | space spread-chords=1.4, space spread-max=2, space spread-cutoff=250, space ceiling-busy=-4, space ceiling-sparse=-5, space ceiling-very-sparse=-7 |
