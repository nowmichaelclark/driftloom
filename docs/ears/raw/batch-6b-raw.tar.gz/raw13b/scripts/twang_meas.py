"""twang's own yardsticks from the part alone (render minus the loop without it):
its tremolo (the strongest rate of its level's swing, 0.5 to 8 Hz, and its depth),
the pick's brightness against the tail (spectral centroid, 90th percentile of 20 ms
frames against the median), and its register (the share of its energy by band)."""
import sys, numpy as np, soundfile as sf
from scipy.signal import hilbert, butter, sosfiltfilt, sosfilt
for a_path, b_path in zip(sys.argv[1::2], sys.argv[2::2]):
    a, r = sf.read(a_path, always_2d=True); b, _ = sf.read(b_path, always_2d=True)
    n = min(len(a), len(b)); p = (b[:n] - a[:n]).mean(axis=1)
    env = np.abs(hilbert(p)); env = sosfiltfilt(butter(2, 12, fs=r, output='sos'), env)
    e = env[::r // 200]; fs = 200
    on = e > e.max() * 0.05
    x = np.log(e[on] + 1e-9); x = x - x.mean()
    F = np.abs(np.fft.rfft(x * np.hanning(len(x)), 16 * len(x))); f = np.fft.rfftfreq(16 * len(x), 1 / fs)
    band = (f > 0.5) & (f < 8); fpk = f[band][np.argmax(F[band])]
    # depth: envelope band-passed around the rate, against its smooth level
    bp = sosfiltfilt(butter(2, [fpk * 0.7, fpk * 1.4], 'band', fs=fs, output='sos'), e)
    lo = sosfiltfilt(butter(2, fpk * 0.4, fs=fs, output='sos'), e)
    depth = np.median((2 * np.abs(hilbert(bp)) / (lo + np.abs(hilbert(bp)) + 1e-12))[on])
    w = int(0.02 * r); cs = []; es = []
    for i in range(0, n - w, w):
        X = np.abs(np.fft.rfft(p[i:i + w] * np.hanning(w))); fr = np.fft.rfftfreq(w, 1 / r)
        s2 = np.sum(X ** 2)
        if s2 > 0: cs.append(np.sum(fr * X ** 2) / s2); es.append(s2)
    cs, es = np.array(cs), np.array(es); keep = es > es.max() * 1e-3
    tot = np.sum(p ** 2)
    sh = lambda lo, hi: 100 * np.sum(sosfilt(butter(4, [lo, hi], 'band', fs=r, output='sos'), p) ** 2) / tot
    print(f"{b_path.split('/')[-1][:-4]:28} tremolo {fpk:4.2f} Hz depth {depth:4.2f}  centroid pick {np.percentile(cs[keep], 90):5.0f} Hz tail {np.median(cs[keep]):5.0f} Hz  energy 60-250 {sh(60,250):3.0f}% 250-1k {sh(250,1000):3.0f}% 1-4k {sh(1000,4000):3.0f}%")
