"""dottedPulse's yardstick: the strongest repeat of the drum onsets (weighted by velocity), in beats."""
import sys, glob, os, numpy as np
sys.path.insert(0, os.path.dirname(__file__)); import calls
BPM = {'undertow45': 129, 'dust69': 76, 'grove47': 105, 'undertow1': 94}
for f in sorted(glob.glob(sys.argv[1] + '/*.calls')):
    name = os.path.basename(f)[:-6]; loop = name.split('-')[1]; beat = 60 / BPM[loop]
    n = calls.notes(f)
    for what, sel in [('all', lambda x: x[1] == 4), ('kick', lambda x: (x[0] == 24 and x[6] == 0) or x[0] == 29), ('rim', lambda x: x[0] == 24 and x[6] == 4)]:
        ts = [(x[2], x[5]) for x in n if sel(x)]
        if len(ts) < 4: continue
        res = beat / 12; L = int(max(t for t, _ in ts) / res) + 2
        s = np.zeros(L)
        for t, v in ts: s[int(round(t / res))] += v
        lags = np.arange(6, 49)  # 0.5 to 4 beats in twelfths
        ac = np.array([np.dot(s[:-l], s[l:]) for l in lags]) / np.dot(s, s)
        top = sorted(zip(ac, lags / 12), reverse=True)[:3]
        a15 = ac[list(lags).index(18)]; a1 = ac[list(lags).index(12)]
        print(f'{name:28} {what:5} n {len(ts):4}  repeat at 1 beat {a1:.2f}  at 1.5 {a15:.2f}  strongest ' + ', '.join(f'{b:.2f}b {a:.2f}' for a, b in top))
