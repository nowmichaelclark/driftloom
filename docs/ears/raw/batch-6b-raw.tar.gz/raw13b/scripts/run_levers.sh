cd /home/user/driftloom
run() { node tools/clips.mjs /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/jobs/$1.json /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/r/$1 --bin /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/dl-veil > /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/r/$1.log 2>&1; echo done $1 >> /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/r/progress; }
(run tripletKit; run widePad; run planingSevenths) &
(run dottedPulse; run widePadStem; run tuningOffset) &
(run slowOpening) &
wait
echo ALL >> /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/r/progress
