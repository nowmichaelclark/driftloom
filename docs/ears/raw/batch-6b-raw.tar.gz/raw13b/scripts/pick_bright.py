"""The pick's brightness: the part's centroid and share above 1 kHz in the 30 ms after each pick (an energy jump of 6 dB from one 10 ms frame to the next), against 0.5 to 1 s after it."""
import sys, numpy as np, soundfile as sf
for a_path, b_path in zip(sys.argv[1::2], sys.argv[2::2]):
    a, r = sf.read(a_path, always_2d=True); b, _ = sf.read(b_path, always_2d=True)
    n = min(len(a), len(b)); p = (b[:n] - a[:n]).mean(axis=1)
    w = int(0.01 * r); E = np.array([np.sum(p[i:i + w] ** 2) for i in range(0, n - w, w)])
    on = [k for k in range(1, len(E)) if E[k] > 4 * E[k - 1] and E[k] > E.max() * 1e-3]
    def spec(i0, i1):
        X = np.abs(np.fft.rfft(p[i0:i1] * np.hanning(i1 - i0))) ** 2; f = np.fft.rfftfreq(i1 - i0, 1 / r)
        return np.sum(f * X) / np.sum(X), np.sum(X[f > 1000]) / np.sum(X)
    P = [spec(k * w, k * w + 3 * w) for k in on if k * w + int(1.0 * r) < n]
    T = [spec(k * w + int(0.5 * r), k * w + int(1.0 * r)) for k in on if k * w + int(1.0 * r) < n]
    P, T = np.array(P), np.array(T)
    print(f"{b_path.split('/')[-1][:-4]:28} picks {len(P):3}  first 30 ms: centroid {np.median(P[:,0]):5.0f} Hz, above 1 kHz {100*np.median(P[:,1]):4.1f}%   0.5-1 s on: {np.median(T[:,0]):5.0f} Hz, {100*np.median(T[:,1]):4.1f}%")
