import sys, soundfile as sf, numpy as np
from scipy.signal import butter, sosfilt
for f in sys.argv[1:]:
    x, r = sf.read(f, always_2d=True)
    h = butter(4, 250, 'high', fs=r, output='sos')
    m, s = sosfilt(h, (x[:,0]+x[:,1])/2), sosfilt(h, (x[:,0]-x[:,1])/2)
    print(f, round(10*np.log10(np.sum(s**2)/np.sum(m**2)), 1))
