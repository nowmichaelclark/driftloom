"""tripletKit's yardstick from the note lists: where the non-kick drum hits fall in the beat."""
import sys, glob, os, numpy as np
sys.path.insert(0, os.path.dirname(__file__)); import calls
BPM = {'grove62': 89, 'dust49': 81, 'tide52': 92, 'glade21': 115, 'bloom74': 87, 'undertow75': 118, 'dust9': 80, 'halcyon17': 109, 'dust32': 91, 'undertow1': 94, 'undertow45': 129, 'dust69': 76, 'tide39': 122, 'grove47': 105}
for f in sorted(glob.glob(sys.argv[1] + '/*.calls')):
    name = os.path.basename(f)[:-6]; loop = name.split('-')[1]
    n = calls.notes(f)
    kicks = [x[2] for x in n if (x[0] == 24 and x[6] == 0) or x[0] == 29]
    other = [x[2] for x in n if x[1] == 4 and not ((x[0] == 24 and x[6] == 0) or x[0] == 29) and x[5] > 0.01]
    beat = 60 / BPM[loop]
    # the grid's origin: the first kick
    t0 = min(kicks) if kicks else 0.05
    ph = lambda ts: (((np.array(ts) - t0) / beat) % 1.0)
    p = ph(other); k = ph(kicks)
    near = lambda p, c: np.mean(np.minimum(abs(p - c), 1 - abs(p - c)) < 1 / 24) if len(p) else 0
    thirds = near(p, 1 / 3) + near(p, 2 / 3)
    on = near(p, 0.0); eighth = near(p, 0.5); sixteenths = near(p, .25) + near(p, .75)
    kon = near(k, 0.0)
    print(f'{name:28} hits {len(p):4}  on beat {on*100:4.0f}%  thirds {thirds*100:4.0f}%  8th {eighth*100:4.0f}%  16ths {sixteenths*100:4.0f}%   kicks {len(k)} on beat {kon*100:4.0f}%')
