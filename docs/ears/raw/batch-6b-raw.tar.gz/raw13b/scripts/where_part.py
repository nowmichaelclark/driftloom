"""Where a part sounds: the part (with - none) level per 0.5 s against the loop's, and the drop windows."""
import sys, json, numpy as np, soundfile as sf
d, cand = sys.argv[1], sys.argv[2]
gaps = json.loads(sys.argv[3])
for loop, g in gaps.items():
    a, r = sf.read(f'{d}/{cand}-{loop}-none.wav', always_2d=True)
    for tag in sys.argv[4:]:
        b, _ = sf.read(f'{d}/{cand}-{loop}-{tag}.wav', always_2d=True)
        p = (b - a).mean(axis=1); w = r // 2
        e = np.array([np.sum(p[i:i+w]**2) for i in range(0, len(p)-w, w)])
        on = e > e.max() * 1e-3
        t = np.arange(len(e)) * 0.5
        inside = np.zeros(len(e), bool)
        for s0, ln in g:
            inside |= (t >= s0) & (t < s0 + ln + 2.0)
        print(loop, tag, 'part energy inside drops (+2 s ring) %.1f%%' % (100*e[inside].sum()/e.sum()),
              'sounding windows', ''.join('#' if x else '.' for x in on))
