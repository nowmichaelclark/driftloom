"""Read dlrender --calls: numbers are plain or x<16 hex> (f64 bits)."""
import struct, sys
def num(t):
    if t.startswith('x'):
        return struct.unpack('>d', bytes.fromhex(t[1:].rjust(16, '0')))[0]
    return float(t)
def read(path):
    out = []
    for line in open(path):
        p = line.split()
        if not p: continue
        out.append((p[0], [num(t) for t in p[1:]]))
    return out
def notes(path):
    """(voice, channel, time, midi, dur, vel, parts, extra...)"""
    return [x for k, x in read(path) if k == 'note']
if __name__ == '__main__':
    for k, x in read(sys.argv[1])[:int(sys.argv[2]) if len(sys.argv) > 2 else 40]:
        print(k, ' '.join(f'{v:.4g}' for v in x))
