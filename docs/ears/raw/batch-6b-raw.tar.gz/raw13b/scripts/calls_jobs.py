"""Run each clips.mjs job again through dlrender with --calls (the note lists)."""
import json, subprocess, sys, os, tempfile, glob, shutil
jobs, out, binp = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(out, exist_ok=True)
for j in json.load(open(jobs)):
    s, i = j['corpus']
    a = ['--corpus', f'{s}:{i+1}', '--pick', str(i), '--seconds', str(j.get('seconds', 30)), '--wander', str(j.get('wander', 1)), '--choices']
    if j.get('layout', 2) == 2: a.append('--stereo')
    if j.get('request'): a += ['--request', j['request']]
    for k, v in j.get('force', {}).items(): a += ['--force', f'{k}={v}']
    for k, v in j.get('set', {}).items(): a += ['--set', f'{k}={v}']
    for k, v in j.get('space', {}).items(): a += ['--space', f'{k}={v}']
    for k, v in j.get('route', {}).items(): a += ['--route', f'{k}={v}']
    if j.get('sketch'): a.append('--sketch')
    t = tempfile.mkdtemp(dir=out); c = tempfile.mkdtemp(dir=out)
    subprocess.run([binp] + a + ['--wav', t, '--calls', c], check=True, capture_output=True)
    shutil.move(glob.glob(c + '/*.calls')[0], f"{out}/{j['name']}.calls")
    shutil.rmtree(t); shutil.rmtree(c)
    print(j['name'])
