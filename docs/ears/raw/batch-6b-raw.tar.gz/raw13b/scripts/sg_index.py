"""A stereo_guard index from a clips.mjs folder: the tag 'mono' (a one-channel render, written again as two) against each stereo tag."""
import json, os, sys, soundfile as sf, numpy as np
d = sys.argv[1]; mono_tag = sys.argv[2] if len(sys.argv) > 2 else 'mono'
rows = []
for r in json.load(open(os.path.join(d, 'index.json'))):
    cand, loop, tag = r['name'].rsplit('-', 2)
    f = r['name'] + '.wav'
    if r['layout'] == 'mono':
        x, sr = sf.read(os.path.join(d, f), always_2d=True)
        f = r['name'] + '.2ch.wav'; sf.write(os.path.join(d, f), np.repeat(x[:, :1], 2, axis=1), sr, subtype='FLOAT'); tag = 'mono'
    rows.append({'pick': r['corpus'][1], 'tag': tag, 'file': f, 'lead': loop, 'space': r.get('space', {}), 'ms': 1, 'refused': 0})
json.dump(rows, open(os.path.join(d, 'sgindex.json'), 'w'), indent=1)
