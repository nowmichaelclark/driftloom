cd /home/user/driftloom
for lb in vapor70:53 thaw10:67 shrine13:45 thaw71:58; do l=${lb%%:*}; b=${lb##*:}
  for v in soft slow bright; do
    python3 -P tools/ears/sketches/ears13/twang/variant.py $v $b >/dev/null
    (cd core && cargo build --release --locked --features sketch --example dlrender >/dev/null 2>&1)
    cp core/target/release/examples/dlrender /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/dl-tw-$l-$v
    python3 -c "import json;j=json.load(open('/tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/jobs/twang-$l.json'));json.dump([x for x in j if x['name'].endswith('-'+'$v')],open('/tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/jobs/tw-$l-$v.json','w'))"
    node tools/clips.mjs /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/jobs/tw-$l-$v.json /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/r/tw-$l-$v --bin /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/dl-tw-$l-$v >/dev/null &
  done
  python3 -c "import json;j=json.load(open('/tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/jobs/twang-$l.json'));json.dump([x for x in j if x['name'].endswith('-none')],open('/tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/jobs/tw-$l-none.json','w'))"
  node tools/clips.mjs /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/jobs/tw-$l-none.json /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/r/tw-$l-none --bin /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/dl-veil >/dev/null &
done
wait; echo TWDONE > /tmp/claude-0/-home-user-driftloom/ee1cc323-888a-5a0d-a2d3-c305d3903062/scratchpad/r/twprogress
