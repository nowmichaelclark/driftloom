"""planingSevenths' yardstick: chord time on major sevenths, root moves, and the tune's rubs against the chord."""
import sys, glob, os, numpy as np
sys.path.insert(0, os.path.dirname(__file__)); import calls
for f in sorted(glob.glob(sys.argv[1] + '/*.calls')):
    name = os.path.basename(f)[:-6]
    rows = calls.read(f)
    ch = [(x[1], [int(m) for m in x[2:] if not np.isnan(m)]) for k, x in rows if k == 'retune']
    mel = [(x[2], x[2] + x[4], int(x[3])) for k, x in rows if k == 'note' and x[1] == 0 and x[5] > 0.01]
    end = max([t for t, _ in ch] + [e for _, e, _ in mel])
    maj7 = tot = 0.0; moves = []; roots = []
    rub = mtot = 0.0
    for i, (t, c) in enumerate(ch):
        t1 = ch[i + 1][0] if i + 1 < len(ch) else end
        pcs = {m % 12 for m in c}
        is7 = any({r, (r + 4) % 12, (r + 7) % 12, (r + 11) % 12} <= pcs for r in pcs)
        maj7 += (t1 - t) * is7; tot += t1 - t
        roots.append(next((r for r in sorted(pcs) if {r, (r + 4) % 12, (r + 7) % 12, (r + 11) % 12} <= pcs), None))
        if i and roots[-1] is not None and roots[-2] is not None: moves.append((roots[-1] - roots[-2]) % 12)
        for a, b, m in mel:
            o = max(0, min(b, t1) - max(a, t))
            if o <= 0: continue
            mtot += o
            p = m % 12
            if p not in pcs and any((p - q) % 12 == 1 for q in pcs): rub += o
    mv = {}
    for m in moves: mv[min(m, 12 - m)] = mv.get(min(m, 12 - m), 0) + 1
    print(f'{name:28} chords {len(ch):3}  maj7 time {100*maj7/tot:5.1f}%  root moves (semitones:count) {dict(sorted(mv.items()))}  tune a semitone over a chord tone {100*rub/max(mtot,1e-9):5.1f}% of its time')
