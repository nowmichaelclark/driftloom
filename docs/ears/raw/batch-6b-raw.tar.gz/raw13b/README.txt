Ears 13b (2026-11-08): the measurements behind batch 6's Ears 13b sections (docs/ears/batch-6.md). No audio.
meas/       ab-*.txt (ab.py: loudness change, the part by ear, its loudest 3 s, bands), sketch_check-*, low_guard-*,
            stereo_guard-sampler-{none,with}.json and sg-widePad.json (mono against stereo), twang_meas.txt (tremolo,
            centroid, bands), kit-twang.txt, lever-cost.txt (render time with and without, best of 5), steals.txt (the
            budget's steals and notes per render, from the note lists), make_clips.txt
renders/    each render set's clips.mjs index (what each loop drew, the levers, the hashes), ab.json, r2index.json,
            sgindex.json; twang/ and everything13b/ are the merged sets the clips were made from
jobs/       every job list (make_jobs_13b.py's, plus the per-build splits tw-*.json and planing-calls.json)
calls/      dlrender --calls note lists: tripletKit, dottedPulse, slowOpening, planing (with chords.RETUNE=1 for the
            chords), tk9 (tripletKit on eighth-note kits: dust #9, dust #32, halcyon #17)
scripts/    calls.py (reads a note list), calls_jobs.py (a job list again with --calls), grid.py (hits on the beat's thirds),
            repeat.py (the strongest repeat of the drum onsets), planing.py (major sevenths, root moves, the tune's rubs),
            where_part.py (where dropSpotlight sounds against the drops), twang_meas.py, pick_bright.py, sg_index.py
            (a stereo_guard index from a clips folder), sm.py (side/mid above 250 Hz), run_levers.sh, build_twang.sh
scan/       meters.txt (each corpus loop's tempo, steps a bar and kit, from dlgen --show), corpus80-choices.json (what each
            of the 80 corpus loops draws)
clips-timestamps.json   where each loop starts in each clip
The sketches, the job maker and the clip plan are in tools/ears/sketches/ears13/.
