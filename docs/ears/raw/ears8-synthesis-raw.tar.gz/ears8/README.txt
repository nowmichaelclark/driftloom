Ears 8 (2026-10-18), the first synthesis: the measurements behind docs/ears/batch-5.md. No audio.
renders-index.json      render2.mjs index of every final render (the last pass of each wins): per render the
                        sketch draws (ears8: each load's draws and every floor drop), refused and asked notes
                        per voice, meta (meta.e8pedal for the pedal bass), chord changes, render time
final-sketch_check.*    sketch_check.py on every render against its loop's 'none'
final-low_guard.*       low_guard.py, the same pairs: low-end shares, loudness, the part's level by ear
stereo_guard-*.json     stereo_guard.py on 4 loops in the approved baseline (room3 0.64 + ens3 0.5, ceiling),
                        with every candidate on and with none; their indexes beside them
records-kick_check.txt  kick_check.py on Ears 7's Demucs stems of the records (kick note and fall, the bass
                        around the kick, note rise times)
clips.json              the seq_clips.py plan for ~/ears8/clips (segment files, starts, lengths); timestamps
corpus-rates.json       how often each sketch's 'on' draw fires on the 80-loop corpus (seed 20261009)
corpus-bass-styles.txt  each corpus loop's bass style, and what pedalBass 'on' draws
scan.json               scan.mjs of the corpus
jobs*.json, st-*.json   the render2.mjs job lists, pass by pass (passes 3 to 8 re-rendered after fixes to the
                        sketch; renders-index.json holds the final ones)
The sketch: tools/ears/sketches/ears8-sketch.patch. Renders and stems stayed in ~/ears8/work on Mikey's computer.
work/                   Ears 8's scratch folder, kept when ~/ears8 was deleted (2026-10-18): the helper scripts
                        (make_jobs.py writes the job lists, run*.sh ran render2.mjs in two or three processes,
                        merge.py and verify.py checked the passes, clip_plan.py planned the clips, rates.mjs and
                        styles.mjs measured the corpus, dropcheck.mjs and pedalcheck.mjs checked the floor drops
                        and the pedal bass, stemsplit.py split stem WAVs), every render log, the selection
                        checks (sc-sel, lg-sel, sc2), the smoke and null tests, the diagnostic render index
                        (diag/) and the final index with the tuned-kick fits (fin/). They expect the old
                        ~/ears8 paths; read them for the method, don't run them as is.
