#!/bin/bash
export PLAYWRIGHT_ROOT=~/ears8/pw/node_modules
cd ~/ears8/work
R=/home/kruu-mikey/driftloom/tools/ears/render2.mjs
for i in 0 1; do node $R ~/ears8/sk r4 jobs4-$i.json > log4-$i.txt 2>&1 & done
wait
echo ALLDONE4
