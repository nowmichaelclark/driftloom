"""Split a render2 stems WAV into drums.wav and bass.wav in OUTDIR (for kick_check.py)."""
import json, sys, glob, os
import soundfile as sf
wav, outdir = sys.argv[1], sys.argv[2]
name = os.path.basename(wav).replace('-stems.wav', '.wav')
names = None
for f in glob.glob(os.path.join(os.path.dirname(os.path.realpath(wav)), 'index-*.json')) + glob.glob(os.path.join(os.path.dirname(wav), 'index*.json')):
    for r in json.load(open(f)):
        if r.get('file') == name and r.get('stemNames'):
            names = r['stemNames']
x, sr = sf.read(wav)
os.makedirs(outdir, exist_ok=True)
for l in ('drums', 'bass'):
    sf.write(os.path.join(outdir, l + '.wav'), x[:, names.index(l)], sr)
