import path from 'node:path';
import { pathToFileURL } from 'node:url';
const at = (f) => pathToFileURL(path.resolve(process.argv[2], f)).href;
const { newSpec, render, drift } = await import(at('js/generator.js'));
const { Rng } = await import(at('js/rng.js'));
const master = new Rng(20261009);
const specs = Array.from({ length: 80 }, () => newSpec(master.seed32()));
for (const i of [69, 38, 8, 65]) {
  const spec = specs[i];
  globalThis.PROTO = {}; const a = render(spec);
  globalThis.PROTO = { pedalBass: 'force' }; const b = render(spec);
  const same = (l) => JSON.stringify(a.tracks[l]) === JSON.stringify(b.tracks[l]);
  const diffs = ['drums', 'chords', 'melody', 'texture'].filter((l) => !same(l));
  let dpass = 0;
  for (let pass = 1; pass <= 6; pass++) {
    const seed = (((spec.seed ^ 0x5eed1e55) >>> 0) + Math.imul(pass, 0x9e3779b1)) >>> 0;
    const pa = drift(a, new Rng(seed), 1), pb = drift(b, new Rng(seed), 1);
    if (['drums', 'chords', 'melody', 'texture'].some((l) => JSON.stringify(pa.tracks[l]) !== JSON.stringify(pb.tracks[l]))) dpass++;
  }
  console.log(i, 'base layers differing:', diffs.join(',') || 'none', '| drift passes with other layers differing:', dpass, '/6', '| bass events', a.tracks.bass.length, '->', b.tracks.bass.length);
}
