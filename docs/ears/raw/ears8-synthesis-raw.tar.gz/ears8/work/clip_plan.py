"""Ears 8 clip plan for seq_clips.py: one clip per candidate and loop, without first."""
import glob, json

idx = []
for f in ['fin/index.json']:
    idx += json.load(open(f))
by = {}
for r in idx:
    by.setdefault(r['pick'], {})[r['tag']] = r
name = lambda p: f"{by[p]['none']['lead']}{p}"
clips = []


def clip(cand, p, segs):
    clips.append({'name': f'{cand}-{name(p)}-' + '-'.join(lab for lab, *_ in segs),
                  'segments': [{'file': by[p][tag]['file'], 'label': f'{name(p)} {lab}', 'start': st, 'seconds': sec}
                               for lab, tag, st, sec in segs]})


def drops(p, tag):
    return [d for d in (by[p][tag].get('ears8') or []) if 'kind' in d]


for p in (62, 45, 69, 48):
    clip('01-tunedKick', p, [('without', 'none', 30, 20), ('with-short', 'tk-short', 30, 20), ('with-long', 'tk-long', 30, 20)])
for p in (21, 45, 48, 69):
    secs = next((d['lateFloor']['secs'] for d in by[p]['late']['ears8'] if 'lateFloor' in d), 20)
    ln = min(85, secs + 15)
    clip('02-lateFloor', p, [('without', 'none', 0, ln), ('with', 'late', 0, ln)])
for p in (62, 23, 45, 21):
    segs = [('without', 'none', None, 0)]
    first = None
    for lab, tag in (('approved', 'fd-on'), ('with-stagger', 'fd-stagger'), ('with-stutter', 'fd-stutter'), ('with-long', 'fd-long')):
        ds = [d for d in drops(p, tag) if d['kind'] != 'single' or tag == 'fd-on']
        if not ds:
            continue
        d = ds[0]
        t = (d['at'] if isinstance(d['at'], (int, float)) else 0.05) + d['bar'] * d['barSec']
        segs.append((lab, tag, max(0, t - 6), min(32, d['len'] * d['barSec'] * (3 if d['kind'] == 'stutter' else 1) + 14)))
        first = first if first is not None else max(0, t - 6)
    segs[0] = ('without', 'none', first or 0, segs[1][3] if len(segs) > 1 else 20)
    clip('03-floorDrop', p, segs)
for p in (69, 8, 38, 65):
    clip('04-pedalBass', p, [('without', 'none', 20, 25), ('with', 'pedal', 20, 25)])
for p in (62, 45, 48):
    clip('05-subDuck', p, [('without', 'none', 30, 20), ('with', 'duck', 30, 20)])
for p in (62, 45, 0, 71):
    clip('06-padSweep', p, [('without', 'none', 20, 40), ('with', 'sweep', 20, 40)])
for p in (0, 38):
    clip('07-echoTime', p, [('without', 'none', 30, 20), ('with-1beat', 'echo-1', 30, 20), ('with-halfbeat', 'echo-half', 30, 20)])
for p in (62, 45, 21, 38):
    clip('00-everything', p, [('without', 'none', 0, 45), ('with-all-as-drawn', 'all-on', 0, 45)])
json.dump({'clips': clips}, open('clips.json', 'w'), indent=1)
for c in clips:
    print(c['name'], [(s['start'], s['seconds']) for s in c['segments']])
