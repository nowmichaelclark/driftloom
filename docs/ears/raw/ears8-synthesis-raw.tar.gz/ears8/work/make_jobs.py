"""Ears 8 render jobs: every candidate against the same loop without it, 90 s, stems on.
Writes jobs-<k>.json split in K parts for parallel render2.mjs runs."""
import json, sys

SECS = 90
K = int(sys.argv[1]) if len(sys.argv) > 1 else 4
jobs = []
def job(pick, tag, proto=None, **kw):
    j = {'pick': pick, 'seconds': SECS, 'tag': tag, 'stems': True}
    if proto:
        j['proto'] = proto
    j.update(kw)
    jobs.append(j)

loops = [62, 45, 69, 12, 21, 48, 8, 38, 65, 0, 71, 23]
for p in loops:
    job(p, 'none')
# 1. tunedKick: short (today's length) and long boom, on four drum loops
for p in (62, 45, 69, 12):
    job(p, 'tk-short', {'tunedKick': 'short'})
    job(p, 'tk-long', {'tunedKick': 'long'})
# 2. lateFloor: each entry order once, the length drawn
for p, order in ((21, 'kitFirst'), (45, 'together'), (48, 'bassFirst'), (69, 'kitFirst')):
    job(p, 'late', {'lateFloor': order})
# 3. floorDrop: Ears 1's approved recipe, and each new shape, at the same passes
for p in (62, 23, 45, 21):
    job(p, 'fd-on', {'floorDrop': 'on', 'floorDropRate': 0.5})
    for shape in ('stagger', 'stutter', 'long'):
        job(p, 'fd-' + shape, {'floorDrop': shape, 'floorDropRate': 0.5})
# 4. pedalBass: two drum loops, two without
for p, kind in ((69, 'force'), (8, 'force'), (38, 'half'), (65, 'force')):
    job(p, 'pedal', {'pedalBass': kind})
# 5. subDuck
for p in (62, 45, 48, 12):
    job(p, 'duck', {'subDuck': 'force'})
# 6. padSweep: sustained chord voices
for p in (62, 45, 0, 71):
    job(p, 'sweep', {'padSweep': 'force'})
# 7. echoTime: one beat and half a beat
for p in (0, 38):
    job(p, 'echo-1', {'echoTime': 1})
    job(p, 'echo-half', {'echoTime': 0.5})
# 8. everything at its 'on' draw (as the corpus would get it), and a load partway through
ON = {'tunedKick': 'on', 'subDuck': 'on', 'lateFloor': 'on', 'padSweep': 'on', 'echoTime': 'on', 'pedalBass': 'on', 'floorDrop': 'plus'}
for p in (62, 45, 21, 38):
    job(p, 'all-on', ON)
ALL = {'tunedKick': 'long', 'subDuck': 'force', 'lateFloor': 'force', 'padSweep': 'force', 'pedalBass': 'force', 'floorDrop': 'plus'}
job(62, 'all-then', ALL, then=45, thenAt=45)
job(62, 'none-then', None, then=45, thenAt=45)

parts = [jobs[i::K] for i in range(K)]
for i, part in enumerate(parts):
    json.dump({'seed': 20261009, 'n': 80, 'jobs': part}, open(f'jobs-{i}.json', 'w'), indent=1)
print(len(jobs), 'jobs in', K, 'parts')
