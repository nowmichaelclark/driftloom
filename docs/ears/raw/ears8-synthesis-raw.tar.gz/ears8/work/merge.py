"""Merge render2 indexes from several folders into one folder of links (later folders win)."""
import json, glob, os, sys
out = sys.argv[1]; dirs = sys.argv[2:]
os.makedirs(out, exist_ok=True)
best = {}
for d in dirs:
    for f in sorted(glob.glob(f'{d}/index-*.json')):
        for r in json.load(open(f)):
            if os.path.exists(f'{d}/{r["file"]}'):
                best[(r['pick'], r['tag'])] = (d, r)
idx = []
for (p, t), (d, r) in sorted(best.items()):
    for suf in ('', '-stems'):
        src = os.path.abspath(f'{d}/{r["file"].replace(".wav", suf + ".wav")}')
        dst = f'{out}/{r["file"].replace(".wav", suf + ".wav")}'
        if os.path.exists(src):
            if os.path.lexists(dst): os.remove(dst)
            os.symlink(src, dst)
    idx.append(r)
json.dump(idx, open(f'{out}/index.json', 'w'), indent=1)
print(len(idx), 'renders in', out)
