#!/bin/bash
# Ears 8, second pass: three render processes (the machine has 7.6 GB), then the stereo jobs on two.
export PLAYWRIGHT_ROOT=~/ears8/pw/node_modules
cd ~/ears8/work
R=/home/kruu-mikey/driftloom/tools/ears/render2.mjs
for i in 0 1 2; do node $R ~/ears8/sk r jobs2-$i.json > log2-$i.txt 2>&1 & done
wait
for i in 0 1; do node $R ~/ears8/sk st st-$i.json > stlog-$i.txt 2>&1 & done
wait
echo ALLDONE
