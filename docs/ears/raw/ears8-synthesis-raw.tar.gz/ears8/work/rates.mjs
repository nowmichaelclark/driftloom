import path from 'node:path';
import { pathToFileURL } from 'node:url';
const at = (f) => pathToFileURL(path.resolve(process.argv[2], f)).href;
const { newSpec, render, drift } = await import(at('js/generator.js'));
const { Rng } = await import(at('js/rng.js'));
const master = new Rng(20261009);
const c = { loops: 80, kick: 0, tkShort: 0, tkLong: 0, duck: 0, late: 0, sweep: 0, pedal: 0, echo: {}, drops: {}, passes: 0, notes: {} };
const SUST = ['pad', 'softpad', 'moogpad', 'analogpad', 'accordion', 'organ', 'choir', 'vowel', 'hum'];
for (let i = 0; i < 80; i++) {
  const spec = newSpec(master.seed32());
  globalThis.PROTO = { pedalBass: 'on', floorDrop: 'plus' };
  const b = render(spec);
  const has = (l, f = () => true) => (b.tracks[l] || []).some((e) => e.vel && f(e));
  const kick = has('drums', (e) => e.inst === 'kick' || e.inst === 'softkick');
  if (kick) {
    c.kick++;
    const r = new Rng(((spec.seed ^ 0x7c1d) >>> 0) || 1);
    const pc = ((spec.root % 12) + 12) % 12; const use = pc >= 3 && pc <= 6 ? (pc + 7) % 12 : pc;
    const midi = 24 + use + (use < 7 ? 12 : 0); c.notes[midi] = (c.notes[midi] || 0) + 1;
    r.weighted([['short', 50], ['long', 50]]) === 'short' ? c.tkShort++ : c.tkLong++;
    if (has('bass') && new Rng(((spec.seed ^ 0x5dc4) >>> 0) || 1).chance(0.5)) c.duck++;
  }
  if ((has('drums') || has('bass')) && (has('chords') || has('melody') || has('texture')) && new Rng(((spec.seed ^ 0x1a7e) >>> 0) || 1).chance(0.3)) c.late++;
  if ((b.tracks.chords || []).some((e) => e.vel && SUST.includes(e.voice)) && new Rng(((spec.seed ^ 0x5e3e) >>> 0) || 1).chance(0.3)) c.sweep++;
  if (b.meta.bassStyle === 'pedal') c.pedal++;
  const fr = new Rng(((spec.seed ^ 0xec40) >>> 0) || 1).weighted([[0.75, 45], [1, 25], [0.5, 15], [2 / 3, 15]]).toFixed(2);
  c.echo[fr] = (c.echo[fr] || 0) + 1;
  for (let pass = 1; pass <= 20; pass++) {
    c.passes++;
    const seed = (((spec.seed ^ 0x5eed1e55) >>> 0) + Math.imul(pass, 0x9e3779b1)) >>> 0;
    const p = drift(b, new Rng(seed || 1), 1);
    if (p.e8Drop) c.drops[p.e8Drop.kind] = (c.drops[p.e8Drop.kind] || 0) + 1;
  }
}
console.log(JSON.stringify(c));
