#!/bin/bash
export PLAYWRIGHT_ROOT=~/ears8/pw/node_modules
cd ~/ears8/work
while pgrep -f "jobs99-" > /dev/null; do sleep 10; done
R=/home/kruu-mikey/driftloom/tools/ears/render2.mjs
for i in 0 1; do node $R ~/ears8/sk r6 jobs6-$i.json > log6-$i.txt 2>&1 & done
wait
echo ALLDONE6
