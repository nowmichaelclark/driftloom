import path from 'node:path';
import { pathToFileURL } from 'node:url';
const at = (f) => pathToFileURL(path.resolve(process.argv[2], f)).href;
const { newSpec, render, drift } = await import(at('js/generator.js'));
const { Rng } = await import(at('js/rng.js'));
const master = new Rng(20261009);
const specs = Array.from({ length: 80 }, () => newSpec(master.seed32()));
globalThis.PROTO = { floorDrop: 'stutter', floorDropRate: 0.5 };
for (const i of [62, 21]) {
  const spec = specs[i]; const base = render(spec);
  const out = [];
  for (let pass = 0; pass < 6; pass++) {
    const seed = (((spec.seed ^ 0x5eed1e55) >>> 0) + Math.imul(pass, 0x9e3779b1)) >>> 0;
    const p = drift(base, new Rng(seed || 1), 1);
    out.push(p.e8Drop ? `${pass}:${p.e8Drop.kind}@${p.e8Drop.bar}` : `${pass}:-`);
  }
  console.log(i, out.join(' '));
}
for (const rate of [0.1, 0.35, 0.5]) {
  globalThis.PROTO = { floorDrop: 'on', floorDropRate: rate };
  let n = 0, hit = 0;
  for (const i of [62, 21, 45, 23, 8, 69]) {
    const spec = specs[i]; const base = render(spec);
    for (let pass = 0; pass < 300; pass++) {
      const seed = (((spec.seed ^ 0x5eed1e55) >>> 0) + Math.imul(pass, 0x9e3779b1)) >>> 0;
      const p = drift(base, new Rng(seed || 1), 1); n++; if (p.e8Drop) hit++;
    }
  }
  console.log('rate', rate, 'drops per pass', (hit / n).toFixed(3));
}
