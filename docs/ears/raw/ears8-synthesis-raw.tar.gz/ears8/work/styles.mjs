import path from 'node:path';
import { pathToFileURL } from 'node:url';
const at = (f) => pathToFileURL(path.resolve(process.argv[2], f)).href;
const { newSpec, render } = await import(at('js/generator.js'));
const { Rng } = await import(at('js/rng.js'));
const master = new Rng(20261009);
const rows = [];
for (let i = 0; i < 80; i++) {
  const spec = newSpec(master.seed32());
  globalThis.PROTO = {};
  const a = render(spec);
  globalThis.PROTO = { pedalBass: 'on' };
  const b = render(spec);
  const kicks = (a.tracks.drums || []).filter((e) => e.vel && (e.inst === 'kick' || e.inst === 'softkick')).length;
  rows.push(`${i} ${a.meta.bassStyle}->${b.meta.bassStyle} ${b.meta.e8pedal ? JSON.stringify(b.meta.e8pedal) : ''} kicks=${kicks} scale=${spec.scale} root=${spec.root} metre=${spec.metre || ''}`);
}
console.log(rows.join('\n'));
