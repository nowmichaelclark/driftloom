#!/bin/bash
export PLAYWRIGHT_ROOT=~/ears8/pw/node_modules
cd ~/ears8/work
while pgrep -f "jobs8-" > /dev/null; do sleep 10; done
R=/home/kruu-mikey/driftloom/tools/ears/render2.mjs
for i in 0 1; do node $R ~/ears8/sk st9 jobs9-$i.json > log9-$i.txt 2>&1 & done
wait
echo ALLDONE9
