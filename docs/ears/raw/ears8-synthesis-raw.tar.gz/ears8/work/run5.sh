#!/bin/bash
export PLAYWRIGHT_ROOT=~/ears8/pw/node_modules
cd ~/ears8/work
while pgrep -f "jobs4-" > /dev/null; do sleep 10; done
R=/home/kruu-mikey/driftloom/tools/ears/render2.mjs
for i in 0 1; do node $R ~/ears8/sk r5 jobs5-$i.json > log5-$i.txt 2>&1 & done
wait
echo ALLDONE5
