#!/bin/bash
# Ears 8: render every job part in parallel into ~/ears8/work/r
export PLAYWRIGHT_ROOT=~/ears8/pw/node_modules
cd ~/ears8/work
for i in 0 1 2 3 4 5; do
  node /home/kruu-mikey/driftloom/tools/ears/render2.mjs ~/ears8/sk r jobs-$i.json > log-$i.txt 2>&1 &
done
wait
echo ALLDONE
