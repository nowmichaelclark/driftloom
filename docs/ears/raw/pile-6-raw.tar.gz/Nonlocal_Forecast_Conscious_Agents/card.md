## Nonlocal Forecast - Conscious Agents (draft card from Ears 3 tools, 2026-11-07)

How it was made: EP or short record (1 usable tracks): every track. Deep pass on: Nonlocal Forecast - Conscious Agents. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Nonlocal Forecast - Conscious Agents**: share of power drums 25%, bass 44%, other 31%, vocals 0%.
  - vocals stem holds 0.4%: bleed on an instrumental, not a voice.
  - meter tool 80 BPM is three quarters of the drum-grid beat of 107.7 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 80 BPM (octave-uncertain); keys E ionian; mix width -8 to -8 dB; chord changes 29 to 29 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Nonlocal Forecast - Conscious Agents: other group `other-1` (284 notes, 33% of the track's note energy)
- In synth terms: around E2, mixed or noisy partials, slow swell, falls 9 dB/s, centered.
- Hear it at: 3:01.8 (B1, 0.43 s, +53 dB alone), 0:20.1 (A2, 0.77 s, +52 dB alone), 0:20.6 (A1, 0.51 s, +51 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 82 (46 to 124) Hz; attack 192 (56 to 735) ms; decay -9 (-44 to -1) dB/s
  - brightness at the start 636 (369 to 1163) Hz; slope over the note 0.00 (-0.47 to 0.48) octaves
  - harmonic share 0.67 (0.21 to 0.92); partials off whole multiples 46 (17 to 124) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.0 (-8.2 to -2.2) dB; pan 0.01 (-0.04 to 0.06); left-right correlation 0.38 (0.06 to 0.68)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. Nonlocal Forecast - Conscious Agents: bass group `bass-1` (117 notes, 23% of the track's note energy)
- In synth terms: around E1, harmonic (string/reed/pad-like), soft attack, falls 8 dB/s, centered.
- Hear it at: 3:51.6 (G#1, 0.71 s, +11 dB alone), 3:51.4 (G#1, 0.52 s, +11 dB alone), 1:42.9 (A1, 4.22 s, +5 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 42 (36 to 52) Hz; attack 128 (34 to 478) ms; decay -8 (-21 to -0) dB/s
  - brightness at the start 118 (97 to 150) Hz; slope over the note 0.00 (-0.39 to 0.26) octaves
  - harmonic share 0.99 (0.83 to 1.00); partials off whole multiples 20 (5 to 75) cents
  - vibrato 0 (0 to 27) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.4 (-8.6 to -1.8) dB; pan -0.00 (-0.03 to 0.02); left-right correlation 0.97 (0.79 to 0.99)
- Group quality: weak (silhouette 0.22, 5 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Nonlocal Forecast - Conscious Agents sections:** 9 boundaries at 0:14.0, 0:27.0, 0:56.0, 1:48.0, 2:00.0, 2:23.0, 2:54.0, 3:21.0, 3:47.0; section lengths median 26 s (range 12 to 52). Reliable for sections of 10 s or more.
- **Nonlocal Forecast - Conscious Agents stem entries and exits:** drums plays 69% of the time (in: 0:28.0, 0:53.5, 3:21.0, 3:48.5; out: 0:47.5, 2:55.0, 3:46.0, 4:00.0); bass plays 82% of the time (in: 0:21.5, 1:57.5, 3:13.5; out: 0:09.0, 1:48.0, 3:02.0, 4:06.0); other plays 97% of the time (in: from the start; out: 4:11.0); vocals plays 39% of the time (in: 0:03.5, 0:17.5, 0:32.5, 0:40.5, 0:53.0; out: 0:14.5, 0:20.0, 0:36.0, 0:48.0, 0:58.5).
- **Nonlocal Forecast - Conscious Agents floor drops (kick and bass out 2 s or more while the rest plays):** 1.29 a minute: 0:12.8 for 12.0 s, 0:50.0 for 4.2 s, 1:56.0 for 2.2 s, 3:00.5 for 16.5 s, 4:03.0 for 2.5 s.
- **Nonlocal Forecast - Conscious Agents brightness sweeps (0.7 octave or more):** mix up 1.2 oct 0:00.0 to 0:05.5; mix up 2.2 oct 0:07.5 to 0:15.5; mix down 1.6 oct 0:23.0 to 0:31.5; mix up 1.1 oct 0:32.0 to 0:40.5; mix down 0.8 oct 0:41.0 to 0:48.5; mix down 0.8 oct 1:21.5 to 1:28.5; mix down 1.3 oct 1:33.5 to 1:38.5; mix up 2.3 oct 1:45.5 to 1:52.5 (22 more in techniques.json).
- **Nonlocal Forecast - Conscious Agents echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Nonlocal Forecast - Conscious Agents pumping locked to the kick:** under 1.5 dB; none found.
- **Nonlocal Forecast - Conscious Agents tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Nonlocal Forecast - Conscious Agents stereo movement:** vocals pan range 0.30.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Nonlocal Forecast - Conscious Agents meter:** about 80 BPM (could be 40 or 160; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.03); swung: off-beat at 0.71 of the beat (triplet feel); no cross-rhythm claim.
- **Nonlocal Forecast - Conscious Agents key and mode:** E ionian (major) (key signature margin 0.024); pitch-class weights C# 0.12, B 0.12, E 0.12, F# 0.12, D# 0.10.
- **Nonlocal Forecast - Conscious Agents chords:** 29 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.5 to 4.6 s); 40 distinct chords; most time on Bsus2 11%, Asus2 8%, F#sus2 8%, Emaj7 6%. The old counter in this same run said 13; Ears 1's 2-s counter said 10.  51% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Nonlocal Forecast - Conscious Agents bass:** root-note movement / mixed; 0.83 notes a second; most time on E 0.20, F# 0.18, B 0.16, A 0.10; steps 14%, thirds 5%, fourths and fifths 9%, octaves 4%, repeats 61%.
- **Nonlocal Forecast - Conscious Agents top line (from the 'other' stem; read by ear before trusting):** 644 notes, range 15 semitones (10th to 90th percentile); steps 30%, thirds 13%, fourths and fifths 23%, leaps 20%, repeats 14%; median interval 4 semitones; 47% of moves go up; phrases of about 11 notes, arch 41%, rising 15%, falling 15%, flat or wavy 30%. Reliable only when the line sits clearly above its accompaniment.
- **Nonlocal Forecast - Conscious Agents repetition:** 43 bars of 6.0 s; strongest repeat distances 1 bars (0.54), 11 bars (0.07), 21 bars (-0.19); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Nonlocal Forecast - Conscious Agents mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -16 (corr 0.96); low_120_500 -5 (corr 0.56); mid_500_2k -4 (corr 0.39); pres_2k_5k -5 (corr 0.53); air_gt5k -6 (corr 0.59); over time (2-s windows) 10th/50th/90th percentile -7/-5/-1 dB.
- **Nonlocal Forecast - Conscious Agents by part:** drums: 22% of the power, width -14 dB, pan -0.03, mono loss 0.2 dB, widest in low_120_500 (-12 dB); bass: 39% of the power, width -16 dB, pan +0.00, mono loss 0.1 dB, widest in low_120_500 (-12 dB); other: 39% of the power, width -4 dB, pan +0.01, mono loss 1.6 dB, widest in mid_500_2k (-3 dB); vocals: 0% of the power, width -6 dB, pan +0.01, mono loss 1.0 dB, widest in mid_500_2k (-5 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Nonlocal Forecast - Conscious Agents: 80 BPM, 12 settled chords a minute, 4% of energy above 2 kHz, width -8 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Nonlocal Forecast - Conscious Agents, drums group `drums-1` (361 notes): low thump, soft attack, falls 84 dB/s, centered; hear it at 1:51.9, 1:52.1. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - Conscious Agents, bass group `bass-2` (46 notes): around B1, harmonic (string/reed/pad-like), slow swell, falls 8 dB/s, centered; hear it at 3:49.7, 0:53.7. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - Conscious Agents, other group `other-2` (38 notes): around A#3, mixed or noisy partials, slow swell, falls 4 dB/s, centered; hear it at 4:07.3, 4:07.4. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - Conscious Agents, drums group `drums-2` (139 notes): mid snap, quick attack, falls 82 dB/s, centered; hear it at 1:50.9, 1:53.6. **[JUDGMENT]** why it waits.
