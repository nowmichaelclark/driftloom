## AC_hours_and_town (draft card from Ears 3 tools, 2026-11-07)

How it was made: 73 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: Title; K.K. Lullaby; K.K. Ragtime; Only Me; 3AM; 9AM; 3PM; 9PM. Typical track: Title. Least like the rest: Only Me, K.K. Lullaby, K.K. Ragtime.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Title**: share of power drums 51%, bass 0%, other 49%, vocals 0%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 112 BPM agrees with the drum-grid beat of 112.4 BPM.
- **K.K. Lullaby**: share of power drums 0%, bass 0%, other 58%, vocals 42%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
- **K.K. Ragtime**: share of power drums 0%, bass 0%, other 39%, vocals 61%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
- **Only Me**: share of power drums 0%, bass 1%, other 30%, vocals 70%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
- **3AM**: share of power drums 8%, bass 91%, other 1%, vocals 0%.
  - other stem holds 1.0% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 97 BPM agrees with the drum-grid beat of 97.6 BPM.
- **9AM**: share of power drums 99%, bass 0%, other 1%, vocals 0%.
  - bass stem is near empty (0.1%): bass notes, pumping and wobble are void.
  - other stem holds 0.8% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 105 BPM agrees with the drum-grid beat of 105.4 BPM.
- **3PM**: share of power drums 79%, bass 0%, other 21%, vocals 0%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 94 BPM agrees with the drum-grid beat of 93.9 BPM.
- **9PM**: share of power drums 60%, bass 34%, other 7%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 69 BPM agrees with the drum-grid beat of 68.9 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 69 to 112 BPM (octave-uncertain); keys D phrygian, D ionian, G# lydian, D# lydian, A# ionian, C ionian; mix width -34 to -17 dB; chord changes 34 to 67 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 9AM: drums group `drums-1` (239 notes, 59% of the track's note energy)
- In synth terms: low thump, quick attack, falls 81 dB/s, centered.
- Hear it at: 2:14.3 (A#1, 0.39 s, +52 dB alone), 1:12.7 (A#1, 0.37 s, +52 dB alone), 1:49.2 (A#1, 0.39 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 58 (57 to 60) Hz; attack 25 (17 to 57) ms; decay -81 (-147 to -70) dB/s
  - brightness at the start 79 (67 to 92) Hz; slope over the note -0.02 (-0.10 to 0.10) octaves
  - harmonic share 0.90 (0.18 to 0.99); partials off whole multiples 174 (73 to 405) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.0 (-0.1 to -0.0) dB; pan 0.00 (0.00 to 0.02); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S2. 9PM: drums group `drums-1` (270 notes, 49% of the track's note energy)
- In synth terms: low thump, quick attack, falls 21 dB/s, centered.
- Hear it at: 2:38.8 (G#1, 0.88 s, +58 dB alone), 1:15.0 (G#1, 0.66 s, +56 dB alone), 0:12.2 (G#1, 0.64 s, +56 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 53 (53 to 53) Hz; attack 9 (4 to 67) ms; decay -21 (-47 to -11) dB/s
  - brightness at the start 70 (66 to 85) Hz; slope over the note -0.10 (-0.33 to -0.02) octaves
  - harmonic share 1.00 (0.99 to 1.00); partials off whole multiples 102 (4 to 219) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.0 (-5.4 to -0.0) dB; pan 0.01 (0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S3. K.K. Lullaby: other group `other-1` (275 notes, 42% of the track's note energy)
- In synth terms: around F#2, harmonic (string/reed/pad-like), soft attack, falls 29 dB/s, centered.
- Hear it at: 0:04.8 (D2, 0.4 s, +61 dB alone), 0:06.0 (D2, 0.36 s, +61 dB alone), 0:01.6 (D2, 0.41 s, +60 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 93 (49 to 196) Hz; attack 46 (13 to 97) ms; decay -29 (-32 to -16) dB/s
  - brightness at the start 314 (188 to 479) Hz; slope over the note -0.19 (-0.41 to 0.27) octaves
  - harmonic share 0.94 (0.25 to 1.00); partials off whole multiples 23 (1 to 162) cents
  - vibrato 0 (0 to 1) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-10.4 to -0.0) dB; pan 0.05 (0.03 to 0.06); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. Only Me: vocals group `vocals-1` (158 notes, 41% of the track's note energy)
- In synth terms: around D3, harmonic (string/reed/pad-like), soft attack, falls 29 dB/s, centered.
- Hear it at: 2:18.4 (C#3, 0.29 s, +36 dB alone), 2:18.0 (E3, 0.35 s, +26 dB alone), 2:16.2 (B2, 0.23 s, +27 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 148 (111 to 219) Hz; attack 77 (51 to 113) ms; decay -29 (-194 to -4) dB/s
  - brightness at the start 2146 (1000 to 2770) Hz; slope over the note -0.01 (-0.33 to 0.10) octaves
  - harmonic share 1.00 (0.93 to 1.00); partials off whole multiples 5 (0 to 23) cents
  - vibrato 0 (0 to 3) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.7 (-3.1 to -0.2) dB; pan -0.04 (-0.05 to -0.03); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

#### S5. Title: other group `other-1` (153 notes, 40% of the track's note energy)
- In synth terms: around D2, mixed or noisy partials, soft attack, falls 22 dB/s, centered.
- Hear it at: 0:40.0 (F2, 0.34 s, +52 dB alone), 0:23.1 (D#2, 0.25 s, +50 dB alone), 0:18.9 (G2, 0.26 s, +45 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 75 (48 to 104) Hz; attack 54 (21 to 144) ms; decay -22 (-153 to -13) dB/s
  - brightness at the start 365 (238 to 481) Hz; slope over the note -0.09 (-0.38 to 0.27) octaves
  - harmonic share 0.82 (0.19 to 1.00); partials off whole multiples 39 (5 to 162) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.3 (-7.3 to -0.1) dB; pan -0.08 (-0.18 to 0.01); left-right correlation 0.99 (0.94 to 1.00)
- Group quality: weak (silhouette 0.23, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. K.K. Lullaby: vocals group `vocals-1` (113 notes, 33% of the track's note energy)
- In synth terms: around D#3, harmonic (string/reed/pad-like), soft attack, falls 9 dB/s, centered.
- Hear it at: 0:14.5 (B2, 0.92 s, +11 dB alone), 1:06.0 (B2, 0.89 s, +12 dB alone), 2:01.9 (C3, 0.89 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 156 (98 to 185) Hz; attack 77 (51 to 131) ms; decay -9 (-25 to -3) dB/s
  - brightness at the start 1847 (802 to 2794) Hz; slope over the note -0.07 (-0.93 to 0.13) octaves
  - harmonic share 1.00 (0.98 to 1.00); partials off whole multiples 1 (0 to 8) cents
  - vibrato 1 (0 to 12) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-4.7 to -0.4) dB; pan -0.03 (-0.04 to -0.03); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

#### S7. 3PM: drums group `drums-1` (73 notes, 31% of the track's note energy)
- In synth terms: low thump, quick attack, falls 254 dB/s, centered.
- Hear it at: 0:00.6 (C2, 0.27 s, +54 dB alone), 1:30.2 (C2, 0.7 s, +51 dB alone), 1:10.0 (C2, 0.38 s, +50 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 67 (66 to 67) Hz; attack 20 (19 to 20) ms; decay -254 (-256 to -251) dB/s
  - brightness at the start 68 (68 to 83) Hz; slope over the note -0.00 (-0.28 to 0.01) octaves
  - harmonic share 1.00 (1.00 to 1.00); partials off whole multiples 368 (0 to 445) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-0.5 to -0.0) dB; pan 0.01 (0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. K.K. Ragtime: other group `other-1` (224 notes, 30% of the track's note energy)
- In synth terms: around A2, harmonic (string/reed/pad-like), quick attack, falls 31 dB/s, centered.
- Hear it at: 0:05.8 (D3, 0.39 s, +52 dB alone), 0:29.1 (A2, 0.31 s, +48 dB alone), 1:28.6 (D3, 0.41 s, +49 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 110 (82 to 147) Hz; attack 15 (10 to 49) ms; decay -31 (-33 to -11) dB/s
  - brightness at the start 204 (154 to 271) Hz; slope over the note -0.06 (-0.39 to 1.05) octaves
  - harmonic share 1.00 (0.89 to 1.00); partials off whole multiples 2 (1 to 64) cents
  - vibrato 0 (0 to 32) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.7 (-6.7 to -0.0) dB; pan 0.05 (0.04 to 0.06); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Title sections:** 6 boundaries at 0:10.0, 0:21.0, 0:35.0, 0:47.0, 1:07.0, 1:22.0; section lengths median 12 s (range 7 to 20). Reliable for sections of 10 s or more.
- **Title stem entries and exits:** drums plays 90% of the time (in: 0:43.5; out: 0:39.0, 1:25.0); bass plays 0% of the time (in: from the start; out: never); other plays 87% of the time (in: 0:08.0, 0:53.5; out: 0:51.0, 1:27.5); vocals plays 0% of the time (in: from the start; out: never).
- **Title floor drops (kick and bass out 2 s or more while the rest plays):** 1.51 a minute: 0:38.0 for 4.8 s, 0:42.2 for 2.0 s.
- **Title brightness sweeps (0.7 octave or more):** mix down 3.7 oct 0:00.5 to 0:06.5; mix down 0.8 oct 0:18.0 to 0:23.0; mix up 1.3 oct 0:40.5 to 0:45.5; mix down 2.2 oct 0:45.5 to 0:53.5; mix down 1.1 oct 1:06.0 to 1:14.5; mix up 1.4 oct 1:23.0 to 1:28.0; other down 1.7 oct 0:47.5 to 0:53.0; other up 1.2 oct 0:53.0 to 0:58.5 (6 more in techniques.json).
- **Title echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Title pumping locked to the kick:** other dips 12.8 dB at the kick (peak 778 ms after, kick every 0.80 s); bass dips 22.2 dB at the kick (peak 713 ms after, kick every 0.80 s). The tool reads about 70% of the true depth, so this is a floor.
- **Title tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Title stereo movement:** drums pan range 0.29; other pan range 0.39.
- **K.K. Lullaby sections:** 8 boundaries at 0:02.0, 0:29.0, 0:53.0, 1:14.0, 1:27.0, 1:37.0, 1:55.0, 2:19.0; section lengths median 18 s (range 2 to 27). Reliable for sections of 10 s or more.
- **K.K. Lullaby stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 0% of the time (in: from the start; out: never); other plays 100% of the time (in: from the start; out: never); vocals plays 70% of the time (in: 0:05.5, 0:34.5, 1:52.5; out: 0:30.0, 1:22.0, 2:19.0).
- **K.K. Lullaby floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **K.K. Lullaby brightness sweeps (0.7 octave or more):** mix up 0.7 oct 0:05.0 to 0:11.0; mix up 1.9 oct 0:18.5 to 0:24.0; mix up 0.8 oct 1:09.5 to 1:16.0; other down 0.8 oct 0:06.5 to 0:15.5; other up 0.8 oct 0:15.5 to 0:20.5; other down 1.0 oct 0:32.0 to 0:39.0; other up 1.3 oct 0:39.0 to 0:44.0; other down 1.2 oct 0:44.5 to 0:51.5 (13 more in techniques.json).
- **K.K. Lullaby echo times:** other: 419 ms (+3.4 dB, 3 later repeats).
- **K.K. Lullaby pumping locked to the kick:** other dips 4.7 dB at the kick (peak 0 ms after, kick every 0.43 s); bass dips 3.4 dB at the kick (peak 364 ms after, kick every 0.43 s). The tool reads about 70% of the true depth, so this is a floor.
- **K.K. Lullaby tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **K.K. Lullaby stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **K.K. Ragtime sections:** 7 boundaries at 0:07.0, 0:28.0, 1:04.0, 1:22.0, 1:45.0, 2:01.0, 2:17.0; section lengths median 17 s (range 2 to 36). Reliable for sections of 10 s or more.
- **K.K. Ragtime stem entries and exits:** drums plays 4% of the time (in: from the start; out: 0:05.0); bass plays 2% of the time (in: 2:14.0; out: 2:17.0); other plays 100% of the time (in: from the start; out: never); vocals plays 97% of the time (in: 0:04.5; out: never).
- **K.K. Ragtime floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **K.K. Ragtime brightness sweeps (0.7 octave or more):** mix down 1.7 oct 0:23.0 to 0:28.0; mix up 2.6 oct 0:45.0 to 0:54.5; mix down 1.9 oct 1:19.0 to 1:26.5; mix up 1.6 oct 1:53.0 to 2:04.5; mix down 1.1 oct 2:04.5 to 2:09.5; other down 1.1 oct 1:11.0 to 1:18.0; other up 1.3 oct 1:18.5 to 1:24.5; other down 1.6 oct 1:40.5 to 1:49.5 (11 more in techniques.json).
- **K.K. Ragtime echo times:** other: 389 ms (+4.3 dB, 2 later repeats); drums: 718 ms (+12.7 dB, 1 later repeats).
- **K.K. Ragtime pumping locked to the kick:** other dips 11.5 dB at the kick (peak 309 ms after, kick every 0.39 s); bass dips 6.8 dB at the kick (peak 264 ms after, kick every 0.39 s). The tool reads about 70% of the true depth, so this is a floor.
- **K.K. Ragtime tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **K.K. Ragtime stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Only Me sections:** 8 boundaries at 0:06.0, 0:16.0, 0:39.0, 1:00.0, 1:19.0, 1:30.0, 1:46.0, 2:22.0; section lengths median 16 s (range 5 to 36). Reliable for sections of 10 s or more.
- **Only Me stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 3% of the time (in: 0:03.0; out: 0:08.0); other plays 100% of the time (in: from the start; out: never); vocals plays 82% of the time (in: 0:07.0, 0:44.5, 1:20.0, 1:48.0; out: 0:39.0, 1:16.5, 1:42.0, 2:22.0).
- **Only Me floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Only Me brightness sweeps (0.7 octave or more):** mix down 2.3 oct 0:00.0 to 0:06.0; mix down 1.7 oct 0:37.5 to 0:42.5; mix up 1.2 oct 0:42.5 to 0:48.5; mix up 0.8 oct 1:35.0 to 1:42.0; mix down 2.9 oct 1:42.0 to 1:47.5; mix up 1.2 oct 1:56.0 to 2:04.0; mix down 2.5 oct 2:19.5 to 2:25.0; other up 1.5 oct 0:00.0 to 0:09.0 (6 more in techniques.json).
- **Only Me echo times:** other: 634 ms (+3.1 dB, 2 later repeats).
- **Only Me pumping locked to the kick:** other dips 6.7 dB at the kick (peak 249 ms after, kick every 0.36 s); bass dips 4.9 dB at the kick (peak 229 ms after, kick every 0.36 s). The tool reads about 70% of the true depth, so this is a floor.
- **Only Me tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Only Me stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **3AM sections:** 5 boundaries at 0:02.0, 0:50.0, 1:29.0, 2:18.0, 2:58.0; section lengths median 40 s (range 2 to 49). Reliable for sections of 10 s or more.
- **3AM stem entries and exits:** drums plays 100% of the time (in: from the start; out: never); bass plays 77% of the time (in: 0:04.0, 0:14.0, 0:19.0, 0:24.0, 0:29.0; out: 0:11.5, 0:16.5, 0:21.5, 0:26.5, 0:31.5); other plays 82% of the time (in: 0:09.0, 1:38.0; out: 1:26.0, 2:55.0); vocals plays 0% of the time (in: from the start; out: never).
- **3AM floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **3AM brightness sweeps (0.7 octave or more):** mix down 2.0 oct 0:14.5 to 0:21.0; mix up 4.7 oct 0:27.0 to 0:38.0; mix down 4.4 oct 0:46.0 to 0:53.5; mix up 2.9 oct 1:25.0 to 1:30.0; mix up 5.9 oct 1:34.5 to 1:47.5; mix down 5.1 oct 1:56.0 to 2:07.0; mix up 3.4 oct 2:07.0 to 2:15.0; mix down 3.8 oct 2:15.0 to 2:21.5 (11 more in techniques.json).
- **3AM echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **3AM pumping locked to the kick:** other dips 15.3 dB at the kick (peak 978 ms after, kick every 1.03 s); bass dips 26.9 dB at the kick (peak 713 ms after, kick every 1.03 s). The tool reads about 70% of the true depth, so this is a floor.
- **3AM tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **3AM stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **9AM sections:** 8 boundaries at 0:11.0, 0:43.0, 1:02.0, 1:17.0, 1:34.0, 1:54.0, 2:13.0, 2:24.0; section lengths median 17 s (range 2 to 32). Reliable for sections of 10 s or more.
- **9AM stem entries and exits:** drums plays 100% of the time (in: from the start; out: never); bass plays 21% of the time (in: 0:11.5, 0:29.0, 0:46.5, 1:07.0, 1:22.0; out: 0:17.5, 0:35.0, 0:55.0, 1:09.5, 1:29.5); other plays 50% of the time (in: 0:08.5, 0:43.0, 1:17.0, 1:51.5; out: 0:27.0, 1:01.0, 1:35.5, 2:09.5); vocals plays 0% of the time (in: from the start; out: never).
- **9AM floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **9AM brightness sweeps (0.7 octave or more):** mix up 4.0 oct 0:00.0 to 0:18.0; mix down 3.2 oct 0:18.0 to 0:28.0; mix up 1.4 oct 0:28.0 to 0:35.5; mix down 1.3 oct 0:35.5 to 0:41.5; mix up 2.4 oct 0:41.5 to 0:53.0; mix down 0.9 oct 0:53.5 to 1:03.5; mix up 2.7 oct 1:19.5 to 1:26.5; mix down 3.1 oct 1:26.5 to 1:36.0 (24 more in techniques.json).
- **9AM echo times:** other: 459 ms (+11.8 dB, 1 later repeats).
- **9AM pumping locked to the kick:** other dips 6.0 dB at the kick (peak 254 ms after, kick every 0.29 s); bass dips 5.9 dB at the kick (peak 135 ms after, kick every 0.29 s). The tool reads about 70% of the true depth, so this is a floor.
- **9AM tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **9AM stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **3PM sections:** 5 boundaries at 0:03.0, 0:32.0, 0:45.0, 1:12.0, 1:26.0; section lengths median 14 s (range 3 to 29). Reliable for sections of 10 s or more.
- **3PM stem entries and exits:** drums plays 100% of the time (in: from the start; out: never); bass plays 0% of the time (in: from the start; out: never); other plays 97% of the time (in: from the start; out: 1:30.5); vocals plays 0% of the time (in: from the start; out: never).
- **3PM floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **3PM brightness sweeps (0.7 octave or more):** mix up 3.6 oct 0:04.0 to 0:15.0; mix down 3.3 oct 0:16.5 to 0:25.0; mix up 2.6 oct 0:25.0 to 0:36.5; mix down 3.3 oct 0:37.0 to 0:45.5; mix up 2.4 oct 0:45.5 to 0:57.0; mix down 5.1 oct 0:57.5 to 1:06.0; mix up 4.3 oct 1:06.0 to 1:16.5; mix down 4.2 oct 1:16.5 to 1:26.0 (15 more in techniques.json).
- **3PM echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **3PM pumping locked to the kick:** other dips 26.4 dB at the kick (peak 833 ms after, kick every 0.96 s); bass dips 28.1 dB at the kick (peak 853 ms after, kick every 0.96 s). The tool reads about 70% of the true depth, so this is a floor.
- **3PM tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **3PM stereo movement:** other pan range 0.56.
- **9PM sections:** 9 boundaries at 0:03.0, 0:42.0, 1:08.0, 1:22.0, 1:40.0, 1:50.0, 2:08.0, 2:18.0, 2:36.0; section lengths median 16 s (range 3 to 39). Reliable for sections of 10 s or more.
- **9PM stem entries and exits:** drums plays 100% of the time (in: from the start; out: never); bass plays 68% of the time (in: 0:13.0, 1:37.0; out: 1:09.0, 2:32.5); other plays 91% of the time (in: 1:16.0, 1:23.0, 1:30.0, 1:37.0, 2:40.0; out: 1:13.5, 1:20.5, 1:27.5, 1:34.5, 2:37.0); vocals plays 0% of the time (in: from the start; out: never).
- **9PM floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **9PM brightness sweeps (0.7 octave or more):** mix down 2.3 oct 1:46.5 to 1:52.0; other down 0.8 oct 0:10.5 to 0:18.5; other down 0.8 oct 0:24.0 to 0:39.0; other up 1.0 oct 0:39.0 to 0:44.5; other up 1.7 oct 1:03.0 to 1:09.0; other down 0.9 oct 1:09.0 to 1:15.0; other up 1.0 oct 1:43.0 to 1:50.5; other down 1.8 oct 1:51.0 to 1:57.5 (4 more in techniques.json).
- **9PM echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **9PM pumping locked to the kick:** other dips 10.8 dB at the kick (peak 803 ms after, kick every 1.09 s); bass dips 44.9 dB at the kick (peak 993 ms after, kick every 1.09 s). The tool reads about 70% of the true depth, so this is a floor.
- **9PM tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **9PM stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Title meter:** about 112 BPM (could be 56 or 224; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.80 of the beat; no cross-rhythm claim.
- **Title key and mode:** D phrygian (low confidence: the key signature margin is 0.018, so read this as a guess); pitch-class weights F 0.15, D 0.14, D# 0.12, G 0.10, A# 0.09.
- **Title chords:** 53 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.3 to 2.0 s); 29 distinct chords; most time on C#maj7 12%, C# 8%, D#maj7 7%, Fmaj7 7%. The old counter in this same run said 20; Ears 1's 2-s counter said 20.  48% of the changes land on a beat (chance would be 56%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Title top line (from the 'other' stem; read by ear before trusting):** 164 notes, range 14 semitones (10th to 90th percentile); steps 25%, thirds 23%, fourths and fifths 24%, leaps 23%, repeats 6%; median interval 4 semitones; 53% of moves go up; phrases of about 7 notes, arch 45%, rising 9%, falling 27%, flat or wavy 18%. Reliable only when the line sits clearly above its accompaniment.
- **Title repetition:** 83 bars of 1.1 s; strongest repeat distances 1 bars (0.34), 8 bars (0.26), 4 bars (0.21); 16% of bars near-duplicate an earlier bar.
- **K.K. Lullaby meter:** about 75 BPM (could be 37 or 149; the tool cannot tell the beat level), 6 beats a bar; straight eighths; no cross-rhythm claim.
- **K.K. Lullaby key and mode:** D ionian (major) (key signature margin 0.024); pitch-class weights D 0.12, G 0.11, A 0.11, E 0.10, F# 0.09.
- **K.K. Lullaby chords:** 67 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 0.7 s (10th to 90th percentile 0.4 to 1.7 s); 49 distinct chords; most time on A7 12%, D5 10%, D 6%, C#dim 5%. The old counter in this same run said 26; Ears 1's 2-s counter said 26.  62% of the changes land on a beat (chance would be 37%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **K.K. Lullaby top line (from the 'other' stem; read by ear before trusting):** 284 notes, range 31 semitones (10th to 90th percentile); steps 12%, thirds 19%, fourths and fifths 32%, leaps 31%, repeats 6%; median interval 5 semitones; 53% of moves go up; phrases of about 10 notes, arch 71%, rising 19%, falling 10%, flat or wavy 0%. Reliable only when the line sits clearly above its accompaniment.
- **K.K. Lullaby repetition:** 29 bars of 4.8 s; strongest repeat distances 11 bars (0.15), 3 bars (0.13), 14 bars (-0.01); 4% of bars near-duplicate an earlier bar.
- **K.K. Ragtime meter:** about 81 BPM (could be 41 or 162; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.22); straight eighths; no cross-rhythm claim.
- **K.K. Ragtime key and mode:** D ionian (major) (low confidence: the key signature margin is 0.001, so read this as a guess); pitch-class weights A 0.16, D 0.13, E 0.10, F# 0.09, G 0.07.
- **K.K. Ragtime chords:** 47 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 0.7 s (10th to 90th percentile 0.5 to 3.0 s); 30 distinct chords; most time on Dmaj7 28%, A7 8%, D 8%, Gsus2 6%. The old counter in this same run said 16; Ears 1's 2-s counter said 16.  66% of the changes land on a beat (chance would be 41%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **K.K. Ragtime top line (from the 'other' stem; read by ear before trusting):** 368 notes, range 9 semitones (10th to 90th percentile); steps 19%, thirds 7%, fourths and fifths 24%, leaps 16%, repeats 33%; median interval 2 semitones; 49% of moves go up; phrases of about 24 notes, arch 33%, rising 0%, falling 17%, flat or wavy 50%. Reliable only when the line sits clearly above its accompaniment.
- **K.K. Ragtime repetition:** 46 bars of 3.0 s; strongest repeat distances 18 bars (0.30), 2 bars (0.16), 8 bars (0.11); 47% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Only Me meter:** about 96 BPM (could be 48 or 192; the tool cannot tell the beat level), 3 beats a bar; straight eighths; no cross-rhythm claim.
- **Only Me key and mode:** D ionian (major) (key signature margin 0.026); pitch-class weights D 0.14, A 0.13, G 0.13, B 0.12, F# 0.10.
- **Only Me chords:** 51 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.4 to 2.2 s); 23 distinct chords; most time on A7 18%, Bmin7 12%, G5 9%, Gmaj7 9%. The old counter in this same run said 25; Ears 1's 2-s counter said 25.  59% of the changes land on a beat (chance would be 48%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Only Me top line (from the 'other' stem; read by ear before trusting):** 345 notes, range 9 semitones (10th to 90th percentile); steps 12%, thirds 47%, fourths and fifths 25%, leaps 9%, repeats 7%; median interval 4 semitones; 50% of moves go up; phrases of about 16 notes, arch 45%, rising 9%, falling 9%, flat or wavy 36%. Reliable only when the line sits clearly above its accompaniment.
- **Only Me repetition:** 78 bars of 1.9 s; strongest repeat distances 4 bars (0.39), 20 bars (0.26), 16 bars (0.21); 48% of bars near-duplicate an earlier bar.
- **3AM meter:** about 97 BPM (could be 49 or 195; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim.
- **3AM key and mode:** G# lydian (key signature margin 0.051); fits G# pentatonic; pitch-class weights D 0.22, D# 0.19, G# 0.14, C# 0.07, B 0.07.
- **3AM chords:** 50 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 0.7 s (10th to 90th percentile 0.6 to 3.0 s); 22 distinct chords; most time on Emaj7 21%, G#5 19%, G#dim 11%, D5 11%. The old counter in this same run said 12; Ears 1's 2-s counter said 12.  27% of the changes land on a beat (chance would be 49%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **3AM bass:** root-note movement / mixed; 0.93 notes a second; most time on G# 0.25, D 0.24, D# 0.24, B 0.14; steps 18%, thirds 22%, fourths and fifths 21%, octaves 0%, repeats 22%.
- **3AM top line (from the 'other' stem; read by ear before trusting):** 259 notes, range 16 semitones (10th to 90th percentile); steps 19%, thirds 43%, fourths and fifths 10%, leaps 15%, repeats 14%; median interval 3 semitones; 48% of moves go up; phrases of about 7 notes, arch 17%, rising 4%, falling 65%, flat or wavy 13%. Reliable only when the line sits clearly above its accompaniment.
- **3AM repetition:** 76 bars of 2.5 s; strongest repeat distances 2 bars (0.63), 4 bars (0.42), 32 bars (0.33); 65% of bars near-duplicate an earlier bar.
- **9AM meter:** about 105 BPM (could be 53 or 210; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **9AM key and mode:** D# lydian (key signature margin 0.033); pitch-class weights D 0.14, D# 0.13, E 0.10, F 0.10, A 0.09.
- **9AM chords:** 34 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.1 s (10th to 90th percentile 0.2 to 4.5 s); 20 distinct chords; most time on D#maj7 56%, F 8%, C 7%, G 6%. The old counter in this same run said 9; Ears 1's 2-s counter said 3.  60% of the changes land on a beat (chance would be 53%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **9AM bass:** pedal (one note held or repeated); 0.17 notes a second; most time on D# 0.78, A# 0.22; steps 0%, thirds 0%, fourths and fifths 33%, octaves 0%, repeats 67%.
- **9AM top line (from the 'other' stem; read by ear before trusting):** 191 notes, range 45 semitones (10th to 90th percentile); steps 47%, thirds 19%, fourths and fifths 6%, leaps 16%, repeats 12%; median interval 2 semitones; 50% of moves go up; phrases of about 4 notes, arch 11%, rising 11%, falling 67%, flat or wavy 11%. Reliable only when the line sits clearly above its accompaniment.
- **9AM repetition:** 127 bars of 1.1 s; strongest repeat distances 30 bars (0.90), 1 bars (0.30), 4 bars (0.18); 36% of bars near-duplicate an earlier bar.
- **3PM meter:** about 94 BPM (could be 47 or 187; the tool cannot tell the beat level), 4 beats a bar; no clear off-beat onsets; no cross-rhythm claim.
- **3PM key and mode:** A# ionian (major) (low confidence: the key signature margin is 0.001, so read this as a guess); pitch-class weights A# 0.14, C 0.12, D 0.11, F 0.11, G 0.09.
- **3PM chords:** 42 changes a minute (19 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.5 to 3.2 s); 14 distinct chords; most time on Fmin7 46%, Gmin7 18%, C7 10%, Cmin7 7%. The old counter in this same run said 13; Ears 1's 2-s counter said 6.  58% of the changes land on a beat (chance would be 47%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **3PM top line (from the 'other' stem; read by ear before trusting):** 163 notes, range 38 semitones (10th to 90th percentile); steps 20%, thirds 9%, fourths and fifths 16%, leaps 44%, repeats 10%; median interval 7 semitones; 59% of moves go up; phrases of about 8 notes, arch 61%, rising 28%, falling 0%, flat or wavy 11%. Reliable only when the line sits clearly above its accompaniment.
- **3PM repetition:** 36 bars of 2.6 s; strongest repeat distances 16 bars (0.95), 8 bars (0.92), 18 bars (0.45); 51% of bars near-duplicate an earlier bar.
- **9PM meter:** about 69 BPM (could be 34 or 138; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **9PM key and mode:** C ionian (major) (key signature margin 0.036); fits C major pentatonic; pitch-class weights F 0.20, C 0.20, E 0.14, G 0.09, C# 0.07.
- **9PM chords:** 37 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.4 to 3.1 s); 17 distinct chords; most time on Fsus2 21%, Fmaj7 21%, C5 12%, Cmaj7 9%. The old counter in this same run said 18; Ears 1's 2-s counter said 3.  33% of the changes land on a beat (chance would be 34%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **9PM bass:** root-note movement / mixed; 0.51 notes a second; most time on C 0.49, F 0.38, G 0.06, E 0.04; steps 7%, thirds 2%, fourths and fifths 10%, octaves 0%, repeats 65%.
- **9PM top line (from the 'other' stem; read by ear before trusting):** 315 notes, range 10 semitones (10th to 90th percentile); steps 18%, thirds 19%, fourths and fifths 16%, leaps 27%, repeats 19%; median interval 4 semitones; 61% of moves go up; phrases of about 13 notes, arch 38%, rising 0%, falling 38%, flat or wavy 25%. Reliable only when the line sits clearly above its accompaniment.
- **9PM repetition:** 23 bars of 7.0 s; strongest repeat distances 4 bars (0.50), 8 bars (0.36), 10 bars (0.13); 59% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Title mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.98); low_120_500 -18 (corr 0.97); mid_500_2k -16 (corr 0.95); pres_2k_5k -18 (corr 0.97); air_gt5k -13 (corr 0.95); over time (2-s windows) 10th/50th/90th percentile -21/-18/-13 dB.
- **Title by part:** drums: 50% of the power, width -26 dB, pan +0.01, mono loss 0.0 dB, widest in low_120_500 (-19 dB); bass: 0% of the power, width -11 dB, pan +0.00, mono loss 0.3 dB, widest in sub_lt120 (-7 dB); other: 50% of the power, width -16 dB, pan -0.13, mono loss 0.1 dB, widest in sub_lt120 (-12 dB); vocals: 0% of the power, width -18 dB, pan +0.00, mono loss 0.1 dB, widest in sub_lt120 (-16 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **K.K. Lullaby mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 1.00); low_120_500 -25 (corr 1.00); mid_500_2k -27 (corr 1.00); pres_2k_5k -26 (corr 1.00); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -27/-26/-25 dB.
- **K.K. Lullaby by part:** drums: 0% of the power, width -12 dB, pan +0.07, mono loss 0.2 dB, widest in low_120_500 (-11 dB); bass: 0% of the power, width -13 dB, pan -0.04, mono loss 0.2 dB, widest in pres_2k_5k (-10 dB); other: 58% of the power, width -26 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-25 dB); vocals: 42% of the power, width -27 dB, pan -0.07, mono loss 0.0 dB, widest in pres_2k_5k (-26 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **K.K. Ragtime mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 1.00); low_120_500 -25 (corr 1.00); mid_500_2k -26 (corr 1.00); pres_2k_5k -26 (corr 1.00); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -27/-26/-25 dB.
- **K.K. Ragtime by part:** drums: 0% of the power, width -25 dB, pan -0.10, mono loss 0.0 dB, widest in mid_500_2k (-25 dB); bass: 0% of the power, width -34 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-38 dB); other: 39% of the power, width -25 dB, pan +0.08, mono loss 0.0 dB, widest in sub_lt120 (-25 dB); vocals: 61% of the power, width -27 dB, pan -0.07, mono loss 0.0 dB, widest in pres_2k_5k (-26 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Only Me mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 1.00); low_120_500 -26 (corr 1.00); mid_500_2k -26 (corr 1.00); pres_2k_5k -26 (corr 1.00); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -27/-26/-25 dB.
- **Only Me by part:** drums: 0% of the power, width -13 dB, pan +0.08, mono loss 0.2 dB, widest in air_gt5k (-9 dB); bass: 1% of the power, width -24 dB, pan +0.11, mono loss 0.0 dB, widest in sub_lt120 (-24 dB); other: 30% of the power, width -26 dB, pan +0.03, mono loss 0.0 dB, widest in low_120_500 (-25 dB); vocals: 70% of the power, width -26 dB, pan -0.08, mono loss 0.0 dB, widest in pres_2k_5k (-26 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **3AM mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -40 (corr 1.00); low_120_500 -19 (corr 0.98); mid_500_2k -11 (corr 0.88); pres_2k_5k -14 (corr 0.93); air_gt5k -10 (corr 0.83); over time (2-s windows) 10th/50th/90th percentile -28/-18/-12 dB.
- **3AM by part:** drums: 8% of the power, width -25 dB, pan +0.01, mono loss 0.0 dB, widest in low_120_500 (-23 dB); bass: 91% of the power, width -45 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-45 dB); other: 1% of the power, width -10 dB, pan +0.30, mono loss 0.4 dB, widest in mid_500_2k (-9 dB); vocals: 0% of the power, width -25 dB, pan +0.00, mono loss 0.0 dB, widest in mid_500_2k (-26 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **9AM mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -33 (corr 1.00); low_120_500 -27 (corr 1.00); mid_500_2k -30 (corr 1.00); pres_2k_5k -24 (corr 0.99); air_gt5k -12 (corr 0.88); over time (2-s windows) 10th/50th/90th percentile -25/-24/-23 dB.
- **9AM by part:** drums: 99% of the power, width -29 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-27 dB); bass: 0% of the power, width -44 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-49 dB); other: 1% of the power, width -31 dB, pan +0.01, mono loss 0.0 dB, widest in pres_2k_5k (-31 dB); vocals: 0% of the power, width -15 dB, pan +0.02, mono loss 0.1 dB, widest in air_gt5k (-9 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **3PM mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -34 (corr 1.00); low_120_500 -16 (corr 0.96); mid_500_2k -11 (corr 0.84); pres_2k_5k -14 (corr 0.95); air_gt5k -13 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -19/-14/-11 dB.
- **3PM by part:** drums: 77% of the power, width -27 dB, pan +0.03, mono loss 0.0 dB, widest in low_120_500 (-38 dB); bass: 0% of the power, width -11 dB, pan -0.00, mono loss 0.3 dB, widest in air_gt5k (-8 dB); other: 23% of the power, width -11 dB, pan -0.03, mono loss 0.4 dB, widest in low_120_500 (-10 dB); vocals: 0% of the power, width -16 dB, pan +0.02, mono loss 0.1 dB, widest in air_gt5k (-13 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **9PM mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -39 (corr 1.00); low_120_500 -35 (corr 1.00); mid_500_2k -29 (corr 1.00); pres_2k_5k -32 (corr 1.00); air_gt5k -14 (corr 0.94); over time (2-s windows) 10th/50th/90th percentile -31/-27/-23 dB.
- **9PM by part:** drums: 60% of the power, width -32 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-39 dB); bass: 34% of the power, width -56 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-54 dB); other: 7% of the power, width -31 dB, pan -0.02, mono loss 0.0 dB, widest in low_120_500 (-32 dB); vocals: 0% of the power, width -27 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-33 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Title: 112 BPM, 10 settled chords a minute, 2% of energy above 2 kHz, width -18 dB; K.K. Lullaby: 75 BPM, 11 settled chords a minute, 14% of energy above 2 kHz, width -26 dB; K.K. Ragtime: 81 BPM, 9 settled chords a minute, 13% of energy above 2 kHz, width -26 dB; Only Me: 96 BPM, 11 settled chords a minute, 19% of energy above 2 kHz, width -26 dB; 3AM: 97 BPM, 9 settled chords a minute, 0% of energy above 2 kHz, width -29 dB; 9AM: 105 BPM, 15 settled chords a minute, 2% of energy above 2 kHz, width -29 dB; 3PM: 94 BPM, 19 settled chords a minute, 8% of energy above 2 kHz, width -17 dB; 9PM: 69 BPM, 17 settled chords a minute, 2% of energy above 2 kHz, width -34 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Title, drums group `drums-1` (117 notes): low thump, quick attack, falls 614 dB/s, centered; hear it at 0:53.0, 0:53.3. **[JUDGMENT]** why it waits.
- 3AM, bass group `bass-1` (40 notes): around D1, harmonic (string/reed/pad-like), slow swell, falls 7 dB/s, centered; hear it at 2:55.5, 2:50.6. **[JUDGMENT]** why it waits.
- 9PM, drums group `drums-2` (188 notes): high tick, click attack, falls 240 dB/s, centered; hear it at 2:32.6, 1:22.9. **[JUDGMENT]** why it waits.
- Only Me, other group `other-1` (171 notes): around A1, harmonic (string/reed/pad-like), soft attack, falls 29 dB/s, centered; hear it at 2:21.4, 0:42.2. **[JUDGMENT]** why it waits.
- 9AM, drums group `drums-2` (96 notes): low thump, soft attack, falls 145 dB/s, gets darker over the note, centered; hear it at 1:46.8, 0:01.7. **[JUDGMENT]** why it waits.
- 3AM, bass group `bass-2` (71 notes): around G#1, harmonic (string/reed/pad-like), slow swell, falls 17 dB/s, centered; hear it at 2:32.5, 1:21.1. **[JUDGMENT]** why it waits.
- 3AM, drums group `drums-1` (298 notes): high tick, quick attack, falls 284 dB/s, centered; hear it at 0:13.5, 0:43.1. **[JUDGMENT]** why it waits.
- K.K. Lullaby, other group `other-2` (56 notes): around C#3, harmonic (string/reed/pad-like), soft attack, falls 4 dB/s, centered; hear it at 1:39.8, 1:35.1. **[JUDGMENT]** why it waits.
- **Rainy Day** (1:48.5, 112 BPM by the mix-level count): stands out for pitch bends a minute 81.29 (high, album median 8.40); wobble (cents) 9.90 (high, album median 3.09). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Post Office - Rude Postmaster (Phyllis)** (2:30.2, 144 BPM by the mix-level count): stands out for brightness sweep (octaves) 3.25 (high, album median 0.88); pitch bends a minute 41.14 (high, album median 8.40). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **5AM** (3:15.2, 103 BPM by the mix-level count): stands out for brightness sweep (octaves) 2.62 (high, album median 0.88). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **I'm Debt Free!** (0:40.3, 129 BPM by the mix-level count): stands out for pitch bends a minute 44.65 (high, album median 8.40). Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **2PM** (2:19.3, 103 BPM by the mix-level count): stands out for pitch bends a minute 38.76 (high, album median 8.40). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Katrina's Tent** (0:45.8, 112 BPM by the mix-level count): stands out for width (side/mid dB) 0.10 (high, album median -19.50). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **6PM** (2:23.9, 103 BPM by the mix-level count): stands out for tail (dB a second) -65.10 (low, album median -16.00). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Police Station** (1:12.0, 56 BPM by the mix-level count): stands out for tail (dB a second) -63.30 (low, album median -16.00). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
