## Nonlocal Forecast - Bubble Universe! (draft card from Ears 3 tools, 2026-11-07)

How it was made: 10 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: 02 Planck Lengths; 08 Foam, Vacuum, Om; 10 Wave Nature. Typical track: 02 Planck Lengths. Least like the rest: 08 Foam, Vacuum, Om, 10 Wave Nature.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **02 Planck Lengths**: share of power drums 49%, bass 19%, other 31%, vocals 0%.
  - vocals stem holds 0.2%: bleed on an instrumental, not a voice.
  - meter tool 143 BPM agrees with the drum-grid beat of 143.5 BPM.
- **08 Foam, Vacuum, Om**: share of power drums 0%, bass 23%, other 76%, vocals 1%.
  - vocals stem holds 0.6%: bleed on an instrumental, not a voice.
- **10 Wave Nature**: share of power drums 12%, bass 2%, other 82%, vocals 4%.
  - bass stem is thin (2.5%): bass notes, pumping and wobble are guesses.
  - vocals stem holds 3.9%: bleed on an instrumental, not a voice.
  - meter tool 118 BPM does not match the drum-grid beat of 215.1 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 108 to 143 BPM (octave-uncertain); keys G phrygian, F lydian, C aeolian; mix width -10 to -1 dB; chord changes 6 to 23 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 10 Wave Nature: other group `other-1` (278 notes, 72% of the track's note energy)
- In synth terms: around D#2, mixed or noisy partials, slow swell, falls 4 dB/s, centered.
- Hear it at: 1:45.3 (D#2, 1.94 s, +52 dB alone), 3:17.0 (G#2, 1.43 s, +52 dB alone), 3:31.9 (G#3, 1.69 s, +55 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 78 (44 to 156) Hz; attack 303 (73 to 855) ms; decay -4 (-37 to 2) dB/s
  - brightness at the start 483 (320 to 645) Hz; slope over the note 0.04 (-0.26 to 0.52) octaves
  - harmonic share 0.68 (0.30 to 0.93); partials off whole multiples 46 (15 to 113) cents
  - vibrato 0 (0 to 21) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.4 (-5.1 to -2.6) dB; pan 0.00 (-0.10 to 0.08); left-right correlation -0.02 (-0.19 to 0.15)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. 02 Planck Lengths: other group `other-1` (417 notes, 39% of the track's note energy)
- In synth terms: around E2, mixed or noisy partials, soft attack, falls 25 dB/s, centered.
- Hear it at: 2:35.0 (F#1, 6.31 s, +49 dB alone), 2:13.2 (D#2, 0.1 s, +46 dB alone), 2:13.1 (D#2, 0.11 s, +42 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 84 (48 to 194) Hz; attack 81 (16 to 696) ms; decay -25 (-91 to -0) dB/s
  - brightness at the start 623 (403 to 1101) Hz; slope over the note 0.00 (-0.22 to 0.32) octaves
  - harmonic share 0.66 (0.24 to 0.93); partials off whole multiples 47 (16 to 126) cents
  - vibrato 0 (0 to 10) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.9 (-8.0 to -1.6) dB; pan -0.01 (-0.11 to 0.11); left-right correlation 0.49 (0.26 to 0.67)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. 08 Foam, Vacuum, Om: other group `other-1` (233 notes, 28% of the track's note energy)
- In synth terms: around C2, mixed or noisy partials, soft attack, falls 10 dB/s, centered.
- Hear it at: 2:41.2 (F2, 0.14 s, +52 dB alone), 2:36.2 (F2, 0.06 s, +52 dB alone), 1:22.8 (C2, 0.52 s, +49 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 67 (65 to 74) Hz; attack 93 (16 to 267) ms; decay -10 (-80 to 5) dB/s
  - brightness at the start 216 (160 to 292) Hz; slope over the note 0.00 (-0.07 to 0.15) octaves
  - harmonic share 0.84 (0.66 to 0.92); partials off whole multiples 53 (26 to 129) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.9 (-3.4 to -1.3) dB; pan -0.04 (-0.40 to 0.36); left-right correlation 0.37 (0.07 to 0.55)
- Group quality: weak (silhouette 0.21, 4 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. 08 Foam, Vacuum, Om: bass group `bass-1` (314 notes, 22% of the track's note energy)
- In synth terms: around D2, harmonic (string/reed/pad-like), slow swell, falls 15 dB/s, centered.
- Hear it at: 0:56.1 (F2, 0.76 s, +4 dB alone), 0:59.3 (F2, 1.17 s, +1 dB alone), 0:55.8 (F2, 0.52 s, +4 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 74 (55 to 84) Hz; attack 191 (10 to 496) ms; decay -15 (-79 to -2) dB/s
  - brightness at the start 82 (67 to 99) Hz; slope over the note 0.00 (-0.01 to 0.07) octaves
  - harmonic share 1.00 (0.95 to 1.00); partials off whole multiples 26 (8 to 109) cents
  - vibrato 0 (0 to 2) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -8.7 (-24.6 to -4.6) dB; pan -0.00 (-0.23 to 0.23); left-right correlation 0.96 (0.54 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S5. 02 Planck Lengths: bass group `bass-1` (217 notes, 19% of the track's note energy)
- In synth terms: around G1, harmonic (string/reed/pad-like), slow swell, falls 12 dB/s, centered.
- Hear it at: 1:52.8 (F1, 0.41 s, +6 dB alone), 1:56.1 (F1, 0.49 s, +5 dB alone), 1:54.4 (F1, 0.37 s, +5 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 48 (38 to 64) Hz; attack 167 (25 to 669) ms; decay -12 (-59 to 3) dB/s
  - brightness at the start 115 (95 to 150) Hz; slope over the note 0.00 (-0.24 to 0.20) octaves
  - harmonic share 0.97 (0.11 to 1.00); partials off whole multiples 22 (6 to 105) cents
  - vibrato 0 (0 to 16) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.0 (-12.8 to -2.5) dB; pan -0.00 (-0.00 to 0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. 10 Wave Nature: other group `other-2` (101 notes, 16% of the track's note energy)
- In synth terms: around F6, bell- or metal-like (partials off whole multiples), soft attack, falls 16 dB/s, centered.
- Hear it at: 3:58.5 (E6, 1.27 s, +47 dB alone), 3:58.2 (F#5, 0.25 s, +54 dB alone), 3:58.0 (D#5, 0.3 s, +48 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 1379 (592 to 1629) Hz; attack 123 (45 to 623) ms; decay -16 (-107 to -1) dB/s
  - brightness at the start 3784 (3209 to 5014) Hz; slope over the note 0.00 (-0.08 to 0.22) octaves
  - harmonic share 0.29 (0.08 to 0.67); partials off whole multiples 87 (37 to 178) cents
  - vibrato 0 (0 to 14) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.3 (-4.4 to -1.5) dB; pan -0.02 (-0.11 to 0.05); left-right correlation 0.25 (-0.11 to 0.43)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **02 Planck Lengths sections:** 10 boundaries at 0:04.0, 0:19.0, 0:39.0, 1:23.0, 1:34.0, 1:48.0, 2:14.0, 2:44.0, 3:33.0, 3:44.0; section lengths median 20 s (range 4 to 49). Reliable for sections of 10 s or more.
- **02 Planck Lengths stem entries and exits:** drums plays 66% of the time (in: 0:05.0, 0:46.5, 1:28.5, 2:14.5, 2:43.0; out: 0:39.5, 1:22.5, 1:48.0, 2:24.5, 3:44.5); bass plays 73% of the time (in: 0:06.0, 1:33.5, 2:43.0; out: 1:25.0, 2:13.5, 3:43.5); other plays 92% of the time (in: 0:02.5, 3:47.5, 3:55.5; out: 3:42.0, 3:51.5, 3:58.0); vocals plays 28% of the time (in: 0:03.0, 0:22.5, 0:42.5, 0:58.0, 1:18.5; out: 0:17.5, 0:31.0, 0:45.0, 1:02.5, 1:22.5).
- **02 Planck Lengths floor drops (kick and bass out 2 s or more while the rest plays):** 1.36 a minute: 1:23.8 for 3.0 s, 1:27.0 for 7.0 s, 1:48.8 for 4.0 s, 2:12.2 for 7.8 s, 2:23.2 for 20.2 s.
- **02 Planck Lengths brightness sweeps (0.7 octave or more):** mix down 4.2 oct 0:00.0 to 0:10.0; mix down 0.8 oct 0:25.0 to 0:30.5; mix up 0.8 oct 0:31.0 to 0:38.5; mix down 1.3 oct 0:38.5 to 0:53.5; mix up 0.8 oct 0:54.0 to 0:59.5; mix up 3.5 oct 1:24.5 to 1:30.5; mix down 3.0 oct 1:30.5 to 1:37.5; mix down 1.1 oct 1:39.0 to 1:44.0 (27 more in techniques.json).
- **02 Planck Lengths echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **02 Planck Lengths pumping locked to the kick:** under 1.5 dB; none found.
- **02 Planck Lengths tape wobble and speed:** other wobbles about 15 cents at 1.7 Hz; bass wobbles about 22 cents at 0.7 Hz.
- **02 Planck Lengths stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **02 Planck Lengths builds:** 2:30.0 to 2:52.0.
- **08 Foam, Vacuum, Om sections:** 11 boundaries at 0:38.0, 0:52.0, 1:03.0, 1:46.0, 1:59.0, 2:09.0, 2:27.0, 2:45.0, 3:05.0, 3:28.0, 3:54.0; section lengths median 19 s (range 10 to 65). Reliable for sections of 10 s or more.
- **08 Foam, Vacuum, Om stem entries and exits:** drums plays 16% of the time (in: 0:41.0, 0:48.5, 1:00.5, 1:23.5, 1:52.0; out: 0:45.5, 0:56.5, 1:08.5, 1:42.0, 1:54.5); bass plays 56% of the time (in: 0:50.5, 1:09.5, 1:38.5, 2:20.0, 2:43.5; out: 1:06.5, 1:17.5, 2:16.5, 2:27.5, 2:52.5); other plays 99% of the time (in: from the start; out: 4:55.0); vocals plays 30% of the time (in: 0:37.0, 1:01.5, 1:24.5, 1:40.0, 1:59.0; out: 0:44.5, 1:07.5, 1:31.5, 1:44.5, 2:04.5).
- **08 Foam, Vacuum, Om floor drops:** low end too sparse to say (on in under 75% of the track).
- **08 Foam, Vacuum, Om brightness sweeps (0.7 octave or more):** mix down 0.7 oct 0:19.0 to 0:25.5; mix up 1.5 oct 0:25.5 to 0:31.0; mix down 1.3 oct 0:31.0 to 0:36.0; mix down 1.0 oct 0:40.0 to 0:45.5; mix down 1.3 oct 0:51.5 to 0:58.0; mix up 1.3 oct 3:02.0 to 3:07.5; mix up 1.8 oct 3:25.0 to 3:33.0; mix down 0.7 oct 3:33.5 to 3:42.5 (19 more in techniques.json).
- **08 Foam, Vacuum, Om echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **08 Foam, Vacuum, Om pumping locked to the kick:** under 1.5 dB; none found.
- **08 Foam, Vacuum, Om tape wobble and speed:** other wobbles about 19 cents at 1.1 Hz; other speed moves up to 29 cents in 4 s; bass wobbles about 21 cents at 1.2 Hz.
- **08 Foam, Vacuum, Om stereo movement:** drums pan range 0.40; bass pan range 0.37; other pan range 0.47, cycling every 3 s; vocals pan range 0.43.
- **10 Wave Nature sections:** 12 boundaries at 0:25.0, 0:51.0, 1:02.0, 1:14.0, 1:38.0, 1:48.0, 2:06.0, 2:27.0, 2:49.0, 2:59.0, 3:10.0, 3:34.0; section lengths median 21 s (range 10 to 28). Reliable for sections of 10 s or more.
- **10 Wave Nature stem entries and exits:** drums plays 18% of the time (in: 0:03.5, 0:12.5, 0:40.0, 0:57.5, 1:23.0; out: 0:06.5, 0:18.5, 0:45.5, 1:05.0, 1:27.0); bass plays 4% of the time (in: 0:40.5, 0:57.5, 1:33.5, 2:22.5; out: 0:43.0, 1:00.0, 1:36.0, 2:25.0); other plays 85% of the time (in: 0:07.5, 0:23.5, 3:44.0; out: 0:11.5, 3:40.0, 3:48.0); vocals plays 43% of the time (in: 0:25.0, 1:03.5, 1:21.5, 1:27.0, 2:09.0; out: 0:31.5, 1:18.0, 1:24.5, 1:35.5, 3:15.0).
- **10 Wave Nature floor drops:** low end too sparse to say (on in under 75% of the track).
- **10 Wave Nature brightness sweeps (0.7 octave or more):** mix down 3.1 oct 0:17.5 to 0:27.5; mix down 0.9 oct 1:28.0 to 1:34.0; mix up 1.3 oct 1:34.5 to 1:40.0; mix up 0.9 oct 3:24.5 to 3:29.5; mix down 2.3 oct 3:29.5 to 3:35.5; mix up 4.2 oct 3:35.5 to 3:42.0; mix up 0.8 oct 3:45.5 to 3:51.0; other down 3.4 oct 0:20.0 to 0:27.5 (10 more in techniques.json).
- **10 Wave Nature echo times:** drums: 354 ms (+4.2 dB, 3 later repeats).
- **10 Wave Nature pumping locked to the kick:** bass dips 3.0 dB at the kick (peak 259 ms after, kick every 0.29 s). The tool reads about 70% of the true depth, so this is a floor.
- **10 Wave Nature tape wobble and speed:** other wobbles about 7 cents at 1.2 Hz.
- **10 Wave Nature stereo movement:** drums pan range 0.37; vocals pan range 0.35.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **02 Planck Lengths meter:** about 143 BPM (could be 72 or 286; the tool cannot tell the beat level), 8 beats a bar; swung: off-beat at 0.76 of the beat; no cross-rhythm claim.
- **02 Planck Lengths key and mode:** G phrygian (low confidence: the key signature margin is 0.016, so read this as a guess); pitch-class weights G 0.13, C 0.11, D# 0.11, F 0.09, D 0.09.
- **02 Planck Lengths chords:** 23 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.7 to 4.6 s); 44 distinct chords; most time on G5 10%, C5 9%, F#sus2 7%, F5 6%. The old counter in this same run said 12; Ears 1's 2-s counter said 11.  84% of the changes land on a beat (chance would be 72%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **02 Planck Lengths bass:** root-note movement / mixed; 0.98 notes a second; most time on G 0.24, C 0.16, A 0.12, F 0.10; steps 10%, thirds 6%, fourths and fifths 3%, octaves 3%, repeats 75%.
- **02 Planck Lengths top line (from the 'other' stem; read by ear before trusting):** 635 notes, range 11 semitones (10th to 90th percentile); steps 14%, thirds 20%, fourths and fifths 41%, leaps 12%, repeats 14%; median interval 5 semitones; 51% of moves go up; phrases of about 11 notes, arch 40%, rising 20%, falling 33%, flat or wavy 7%. Reliable only when the line sits clearly above its accompaniment.
- **02 Planck Lengths repetition:** 73 bars of 3.4 s; strongest repeat distances 1 bars (0.46), 7 bars (0.06), 14 bars (0.05); 0% of bars near-duplicate an earlier bar.
- **08 Foam, Vacuum, Om meter:** about 108 BPM (could be 54 or 216; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.17); swung: off-beat at 0.56 of the beat; no cross-rhythm claim; many unrelated periodicities found (4:3, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **08 Foam, Vacuum, Om key and mode:** F lydian (key signature margin 0.095); pitch-class weights C 0.21, D 0.17, E 0.12, B 0.12, F 0.12.
- **08 Foam, Vacuum, Om chords:** 6 changes a minute (5 a minute are chords that last 1.5 s or more); median chord 4.6 s (10th to 90th percentile 1.4 to 19.3 s); 16 distinct chords; most time on G 16%, Cmaj7 16%, C5 14%, D5 12%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  50% of the changes land on a beat (chance would be 54%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **08 Foam, Vacuum, Om bass:** ostinato (a 2-note figure repeats); 0.36 notes a second; most time on F 0.34, E 0.18, A 0.16, C 0.15; steps 4%, thirds 3%, fourths and fifths 2%, octaves 2%, repeats 89%.
- **08 Foam, Vacuum, Om top line (from the 'other' stem; read by ear before trusting):** 776 notes, range 12 semitones (10th to 90th percentile); steps 5%, thirds 34%, fourths and fifths 19%, leaps 15%, repeats 27%; median interval 4 semitones; 50% of moves go up; phrases of about 9 notes, arch 30%, rising 23%, falling 17%, flat or wavy 30%. Reliable only when the line sits clearly above its accompaniment.
- **08 Foam, Vacuum, Om repetition:** 59 bars of 5.0 s; strongest repeat distances 1 bars (0.74); 12% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **10 Wave Nature meter:** about 118 BPM (could be 59 or 237; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.07); swung: off-beat at 0.62 of the beat; no cross-rhythm claim.
- **10 Wave Nature key and mode:** C aeolian (minor) (low confidence: the key signature margin is 0.016, so read this as a guess); pitch-class weights C 0.14, G 0.11, D# 0.10, E 0.10, F 0.09.
- **10 Wave Nature chords:** 16 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 2.5 s (10th to 90th percentile 0.7 to 8.6 s); 36 distinct chords; most time on Cmaj7 14%, Fsus2 8%, G#maj7 7%, Bmaj7 7%. The old counter in this same run said 3; Ears 1's 2-s counter said 4.  52% of the changes land on a beat (chance would be 59%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **10 Wave Nature top line (from the 'other' stem; read by ear before trusting):** 622 notes, range 12 semitones (10th to 90th percentile); steps 6%, thirds 18%, fourths and fifths 35%, leaps 14%, repeats 27%; median interval 4 semitones; 50% of moves go up; phrases of about 22 notes, arch 82%, rising 9%, falling 0%, flat or wavy 9%. Reliable only when the line sits clearly above its accompaniment.
- **10 Wave Nature repetition:** 119 bars of 2.0 s; strongest repeat distances 1 bars (0.73), 24 bars (0.07); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **02 Planck Lengths mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -23 (corr 0.99); low_120_500 -7 (corr 0.69); mid_500_2k -5 (corr 0.50); pres_2k_5k -5 (corr 0.51); air_gt5k -7 (corr 0.64); over time (2-s windows) 10th/50th/90th percentile -8/-6/-3 dB.
- **02 Planck Lengths by part:** drums: 45% of the power, width -17 dB, pan -0.01, mono loss 0.1 dB, widest in low_120_500 (-14 dB); bass: 17% of the power, width -29 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-24 dB); other: 38% of the power, width -5 dB, pan -0.02, mono loss 1.2 dB, widest in mid_500_2k (-4 dB); vocals: 0% of the power, width -7 dB, pan -0.01, mono loss 0.8 dB, widest in mid_500_2k (-5 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **08 Foam, Vacuum, Om mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -7 (corr 0.64); low_120_500 -1 (corr 0.10); mid_500_2k -1 (corr 0.07); pres_2k_5k -2 (corr 0.23); air_gt5k -2 (corr 0.26); over time (2-s windows) 10th/50th/90th percentile -2/-1/0 dB.
- **08 Foam, Vacuum, Om by part:** drums: 0% of the power, width -1 dB, pan +0.01, mono loss 2.7 dB, widest in pres_2k_5k (0 dB); bass: 16% of the power, width -10 dB, pan +0.01, mono loss 0.4 dB, widest in sub_lt120 (-11 dB); other: 83% of the power, width -1 dB, pan -0.06, mono loss 2.4 dB, widest in low_120_500 (-1 dB); vocals: 1% of the power, width -0 dB, pan -0.10, mono loss 2.9 dB, widest in mid_500_2k (0 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **10 Wave Nature mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -11 (corr 0.86); low_120_500 0 (corr -0.03); mid_500_2k 0 (corr -0.01); pres_2k_5k -1 (corr 0.09); air_gt5k -1 (corr 0.14); over time (2-s windows) 10th/50th/90th percentile -2/0/1 dB.
- **10 Wave Nature by part:** drums: 6% of the power, width -16 dB, pan -0.00, mono loss 0.1 dB, widest in sub_lt120 (-16 dB); bass: 1% of the power, width -19 dB, pan -0.06, mono loss 0.1 dB, widest in sub_lt120 (-20 dB); other: 88% of the power, width 0 dB, pan -0.01, mono loss 3.1 dB, widest in low_120_500 (0 dB); vocals: 5% of the power, width 1 dB, pan -0.01, mono loss 3.5 dB, widest in mid_500_2k (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 02 Planck Lengths: 143 BPM, 15 settled chords a minute, 4% of energy above 2 kHz, width -10 dB; 08 Foam, Vacuum, Om: 108 BPM, 5 settled chords a minute, 2% of energy above 2 kHz, width -2 dB; 10 Wave Nature: 118 BPM, 12 settled chords a minute, 2% of energy above 2 kHz, width -1 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- 08 Foam, Vacuum, Om, bass group `bass-2` (159 notes): around F1, harmonic (string/reed/pad-like), slow swell, falls 15 dB/s, centered; hear it at 4:36.1, 4:32.8. **[JUDGMENT]** why it waits.
- 08 Foam, Vacuum, Om, other group `other-2` (155 notes): around D1, harmonic (string/reed/pad-like), soft attack, falls 12 dB/s, centered; hear it at 2:41.3, 2:34.2. **[JUDGMENT]** why it waits.
- 02 Planck Lengths, drums group `drums-1` (180 notes): low thump, soft attack, falls 169 dB/s, centered; hear it at 3:42.2, 3:41.6. **[JUDGMENT]** why it waits.
- 02 Planck Lengths, drums group `drums-2` (164 notes): mid snap, quick attack, falls 112 dB/s, gets brighter over the note, centered; hear it at 3:40.0, 2:20.4. **[JUDGMENT]** why it waits.
- 10 Wave Nature, drums group `drums-1` (128 notes): low thump, quick attack, falls 136 dB/s, centered; hear it at 2:23.5, 3:06.1. **[JUDGMENT]** why it waits.
- 02 Planck Lengths, bass group `bass-2` (96 notes): around D#2, bell- or metal-like (partials off whole multiples), slow swell, falls 21 dB/s, centered; hear it at 1:57.1, 1:55.1. **[JUDGMENT]** why it waits.
- 02 Planck Lengths, other group `other-2` (61 notes): around G4, mixed or noisy partials, quick attack, falls 69 dB/s, centered; hear it at 3:51.4, 3:49.1. **[JUDGMENT]** why it waits.
- 10 Wave Nature, vocals group `vocals-1` (429 notes): around D#4, mixed or noisy partials, soft attack, falls 26 dB/s, centered; hear it at 0:15.3, 2:54.4. **[JUDGMENT]** why it waits.
- **05 Triangular Format** (2:50.0, 118 BPM by the mix-level count): stands out for brightness sweep (octaves) 2.14 (high, album median 0.97); wobble (cents) 3.56 (low, album median 4.67). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **09 Conscious Agent Combos** (4:29.9, 112 BPM by the mix-level count): stands out for brightness sweep (octaves) 1.87 (high, album median 0.97). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **04 The Direct Path** (4:01.8, 112 BPM by the mix-level count): stands out for brightness sweep (octaves) 1.73 (high, album median 0.97). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
