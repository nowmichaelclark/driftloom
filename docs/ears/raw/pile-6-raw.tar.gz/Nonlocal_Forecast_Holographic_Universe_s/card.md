## Nonlocal Forecast - Holographic Universe(s_)! (draft card from Ears 3 tools, 2026-11-07)

How it was made: 12 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: Nonlocal Forecast - My Big T.O.E.; Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz); Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1); Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream. Typical track: Nonlocal Forecast - My Big T.O.E.. Least like the rest: Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz), Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1), Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Nonlocal Forecast - My Big T.O.E.**: share of power drums 62%, bass 11%, other 27%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 115 BPM is two thirds of the drum-grid beat of 172.4 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz)**: share of power drums 60%, bass 30%, other 10%, vocals 0%.
  - vocals stem holds 0.4%: bleed on an instrumental, not a voice.
  - meter tool 121 BPM agrees with the drum-grid beat of 120.2 BPM.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1)**: share of power drums 6%, bass 0%, other 88%, vocals 7%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - meter tool 127 BPM is two thirds of the drum-grid beat of 191.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream**: share of power drums 32%, bass 32%, other 35%, vocals 1%.
  - vocals stem holds 0.9%: bleed on an instrumental, not a voice.
  - meter tool 77 BPM does not match the drum-grid beat of 235.3 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 77 to 127 BPM (octave-uncertain); keys C# ionian, G mixolydian, F phrygian, D dorian; mix width -13 to -2 dB; chord changes 13 to 33 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1): other group `other-1` (419 notes, 84% of the track's note energy)
- In synth terms: around F2, bell- or metal-like (partials off whole multiples), soft attack, falls 22 dB/s, centered.
- Hear it at: 0:49.4 (C#2, 0.31 s, +51 dB alone), 0:51.1 (A1, 0.37 s, +52 dB alone), 0:51.4 (E3, 0.31 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 87 (34 to 185) Hz; attack 90 (21 to 268) ms; decay -22 (-61 to -1) dB/s
  - brightness at the start 376 (226 to 643) Hz; slope over the note 0.00 (-0.09 to 0.43) octaves
  - harmonic share 0.61 (0.16 to 0.93); partials off whole multiples 64 (20 to 140) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.0 (-5.5 to -1.5) dB; pan 0.01 (-0.18 to 0.20); left-right correlation 0.13 (-0.29 to 0.48)
- Group quality: weak (silhouette 0.18, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream: other group `other-1` (500 notes, 53% of the track's note energy)
- In synth terms: around G2, mixed or noisy partials, soft attack, falls 11 dB/s, centered.
- Hear it at: 0:33.3 (A#2, 0.53 s, +50 dB alone), 0:30.4 (C3, 2.32 s, +45 dB alone), 0:40.6 (G1, 0.3 s, +51 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 99 (44 to 196) Hz; attack 135 (36 to 481) ms; decay -11 (-33 to -1) dB/s
  - brightness at the start 722 (242 to 1299) Hz; slope over the note 0.05 (-0.26 to 0.77) octaves
  - harmonic share 0.70 (0.21 to 0.97); partials off whole multiples 53 (12 to 130) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.9 (-8.1 to -0.6) dB; pan -0.01 (-0.08 to 0.05); left-right correlation 0.72 (0.53 to 0.83)
- Group quality: weak (silhouette 0.18, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz): drums group `drums-1` (382 notes, 47% of the track's note energy)
- In synth terms: low thump, soft attack, falls 67 dB/s, centered.
- Hear it at: 0:31.8 (A#1, 0.2 s, +11 dB alone), 1:34.7 (A#1, 0.27 s, +9 dB alone), 0:59.0 (B1, 0.28 s, +9 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 58 (39 to 68) Hz; attack 123 (107 to 134) ms; decay -67 (-79 to -53) dB/s
  - brightness at the start 143 (71 to 365) Hz; slope over the note 0.03 (0.00 to 4.92) octaves
  - harmonic share 0.97 (0.71 to 1.00); partials off whole multiples 147 (59 to 236) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-2.1 to -0.7) dB; pan 0.00 (-0.01 to 0.01); left-right correlation 1.00 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S4. Nonlocal Forecast - My Big T.O.E.: drums group `drums-1` (264 notes, 29% of the track's note energy)
- In synth terms: low thump, soft attack, falls 180 dB/s, centered.
- Hear it at: 2:46.5 (G1, 0.19 s, +22 dB alone), 2:46.2 (F#1, 0.38 s, +19 dB alone), 2:46.1 (G#1, 0.24 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (47 to 57) Hz; attack 55 (38 to 55) ms; decay -180 (-212 to -141) dB/s
  - brightness at the start 120 (85 to 196) Hz; slope over the note 0.00 (-0.14 to 1.19) octaves
  - harmonic share 0.80 (0.27 to 1.00); partials off whole multiples 167 (56 to 354) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.1 (-2.0 to -0.4) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 0.99 (0.96 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream: bass group `bass-1` (263 notes, 22% of the track's note energy)
- In synth terms: around A1, harmonic (string/reed/pad-like), soft attack, falls 6 dB/s, centered.
- Hear it at: 0:12.0 (?, 2.07 s, +10 dB alone), 2:42.7 (E1, 0.26 s, +8 dB alone), 0:08.2 (D#2, 1.43 s, +4 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 55 (37 to 73) Hz; attack 104 (10 to 394) ms; decay -6 (-20 to 1) dB/s
  - brightness at the start 115 (83 to 143) Hz; slope over the note 0.00 (-0.11 to 0.23) octaves
  - harmonic share 0.99 (0.88 to 1.00); partials off whole multiples 9 (3 to 71) cents
  - vibrato 0 (0 to 8) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.3 (-13.4 to -2.7) dB; pan 0.01 (-0.05 to 0.08); left-right correlation 0.92 (0.83 to 0.98)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. Nonlocal Forecast - My Big T.O.E.: other group `other-1` (43 notes, 21% of the track's note energy)
- In synth terms: around G1, mixed or noisy partials, slow swell, falls 3 dB/s, vibrato about 8 cents at 5.1 Hz, centered.
- Hear it at: 1:53.0 (D#2, 0.69 s, +47 dB alone), 1:53.7 (D#2, 3.55 s, +36 dB alone), 1:52.9 (D#2, 0.47 s, +38 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (46 to 68) Hz; attack 324 (36 to 1290) ms; decay -3 (-8 to -1) dB/s
  - brightness at the start 439 (347 to 644) Hz; slope over the note 0.14 (-0.30 to 1.01) octaves
  - harmonic share 0.71 (0.30 to 0.96); partials off whole multiples 50 (9 to 81) cents
  - vibrato 8 (0 to 33) cents; detune beating 0.0 (0.0 to 0.3) Hz
  - level against the mix -5.4 (-7.7 to -1.5) dB; pan 0.05 (0.03 to 0.09); left-right correlation 0.69 (0.55 to 0.79)
- Group quality: weak (silhouette 0.18, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz): other group `other-1` (45 notes, 12% of the track's note energy)
- In synth terms: around G2, mixed or noisy partials, slow swell, falls 5 dB/s, gets brighter over the note, vibrato about 9 cents at 5.0 Hz, centered.
- Hear it at: 0:01.7 (G2, 1.55 s, +54 dB alone), 0:00.0 (G1, 1.99 s, +52 dB alone), 0:09.7 (A2, 2.26 s, +34 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 98 (45 to 131) Hz; attack 342 (82 to 2033) ms; decay -5 (-10 to -2) dB/s
  - brightness at the start 464 (385 to 643) Hz; slope over the note 0.80 (0.26 to 2.33) octaves
  - harmonic share 0.79 (0.49 to 0.96); partials off whole multiples 31 (13 to 92) cents
  - vibrato 9 (0 to 24) cents; detune beating 0.0 (0.0 to 0.5) Hz
  - level against the mix -12.0 (-15.2 to -1.9) dB; pan -0.01 (-0.05 to 0.05); left-right correlation 0.27 (0.21 to 0.36)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S8. Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1): vocals group `vocals-1` (341 notes, 12% of the track's note energy)
- In synth terms: around C4, mixed or noisy partials, soft attack, falls 29 dB/s, centered.
- Hear it at: 2:15.0 (E3, 4.38 s, +8 dB alone), 1:38.1 (A3, 0.24 s, +2 dB alone), 1:38.3 (A3, 0.3 s, +1 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 261 (88 to 519) Hz; attack 115 (38 to 331) ms; decay -29 (-122 to -2) dB/s
  - brightness at the start 725 (368 to 1484) Hz; slope over the note 0.00 (-0.12 to 0.35) octaves
  - harmonic share 0.69 (0.09 to 0.98); partials off whole multiples 34 (0 to 113) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -17.7 (-38.8 to -6.9) dB; pan -0.01 (-0.17 to 0.21); left-right correlation 0.66 (-0.25 to 0.92)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Nonlocal Forecast - My Big T.O.E. sections:** 8 boundaries at 0:31.0, 0:45.0, 1:02.0, 1:22.0, 1:47.0, 1:59.0, 2:09.0, 2:47.0; section lengths median 17 s (range 3 to 38). Reliable for sections of 10 s or more.
- **Nonlocal Forecast - My Big T.O.E. stem entries and exits:** drums plays 74% of the time (in: 0:30.0, 0:49.5, 1:56.5; out: 0:46.0, 1:47.0, 2:48.0); bass plays 95% of the time (in: 1:56.5; out: 1:52.5, 2:46.0); other plays 99% of the time (in: from the start; out: 2:47.5); vocals plays 6% of the time (in: 1:43.0, 2:10.0, 2:20.0; out: 1:46.0, 2:12.5, 2:25.0).
- **Nonlocal Forecast - My Big T.O.E. floor drops (kick and bass out 2 s or more while the rest plays):** 0.79 a minute: 0:10.0 for 2.5 s, 1:52.2 for 4.8 s.
- **Nonlocal Forecast - My Big T.O.E. brightness sweeps (0.7 octave or more):** mix up 0.9 oct 0:20.5 to 0:29.5; mix down 1.5 oct 0:29.5 to 0:38.0; mix down 1.4 oct 1:18.5 to 1:25.5; mix up 1.2 oct 1:25.5 to 1:31.0; mix up 1.7 oct 1:40.0 to 1:45.5; mix up 2.6 oct 1:50.0 to 1:55.0; mix down 3.3 oct 1:55.0 to 2:01.0; mix up 3.6 oct 2:43.5 to 2:49.0 (12 more in techniques.json).
- **Nonlocal Forecast - My Big T.O.E. echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Nonlocal Forecast - My Big T.O.E. pumping locked to the kick:** under 1.5 dB; none found.
- **Nonlocal Forecast - My Big T.O.E. tape wobble and speed:** bass wobbles about 16 cents at 3.3 Hz.
- **Nonlocal Forecast - My Big T.O.E. stereo movement:** bass pan range 0.36; vocals pan range 0.44.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) sections:** 7 boundaries at 0:32.0, 0:56.0, 1:27.0, 1:52.0, 2:03.0, 2:25.0, 2:40.0; section lengths median 23 s (range 7 to 32). Reliable for sections of 10 s or more.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) stem entries and exits:** drums plays 77% of the time (in: 0:31.0; out: 2:39.5); bass plays 77% of the time (in: 0:31.5; out: 2:39.5); other plays 100% of the time (in: from the start; out: never); vocals plays 34% of the time (in: 0:04.5, 0:21.5, 1:00.0, 1:32.0, 2:03.5; out: 0:18.0, 0:31.5, 1:03.5, 1:41.0, 2:10.5).
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) floor drops (kick and bass out 2 s or more while the rest plays):** 0.40 a minute: 0:08.2 for 23.5 s.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:00.0 to 0:06.5; mix up 1.0 oct 0:10.5 to 0:15.5; mix down 4.4 oct 0:23.5 to 0:37.5; mix up 4.1 oct 0:38.0 to 0:44.0; mix down 4.1 oct 0:44.0 to 1:02.0; mix up 3.4 oct 1:02.5 to 1:23.0; mix up 3.5 oct 1:33.5 to 1:44.0; mix down 4.0 oct 1:44.0 to 1:59.0 (16 more in techniques.json).
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) pumping locked to the kick:** other dips 1.8 dB at the kick (peak 344 ms after, kick every 0.49 s); bass dips 21.7 dB at the kick (peak 449 ms after, kick every 0.49 s). The tool reads about 70% of the true depth, so this is a floor.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) tape wobble and speed:** other wobbles about 23 cents at 0.3 Hz.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) builds:** 0:19.0 to 0:40.0.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) sections:** 5 boundaries at 0:06.0, 0:26.0, 0:53.0, 1:23.0, 2:15.0; section lengths median 24 s (range 6 to 52). Reliable for sections of 10 s or more.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) stem entries and exits:** drums plays 28% of the time (in: 0:53.5, 1:22.5, 1:50.5; out: 0:57.0, 1:45.0, 2:04.0); bass plays 0% of the time (in: from the start; out: never); other plays 93% of the time (in: 0:05.0; out: 2:16.0); vocals plays 75% of the time (in: 0:22.5, 0:55.5, 1:10.0; out: 0:48.5, 1:06.5, 2:19.5).
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) floor drops:** low end too sparse to say (on in under 75% of the track).
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) brightness sweeps (0.7 octave or more):** mix down 1.3 oct 0:22.0 to 0:30.0; mix up 2.1 oct 0:48.5 to 0:58.0; mix down 1.1 oct 0:58.0 to 1:03.5; mix up 0.8 oct 1:04.0 to 1:09.5; mix down 1.2 oct 1:14.5 to 1:20.5; mix up 1.1 oct 1:20.5 to 1:27.0; mix down 1.5 oct 1:27.5 to 1:42.0; mix up 0.8 oct 1:51.0 to 2:01.0 (20 more in techniques.json).
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) echo times:** drums: 474 ms (+10.1 dB, 3 later repeats).
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) pumping locked to the kick:** under 1.5 dB; none found.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) stereo movement:** drums pan range 0.31; other pan range 0.36; vocals pan range 0.55.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream sections:** 16 boundaries at 0:02.0, 0:18.0, 0:38.0, 0:49.0, 1:05.0, 1:39.0, 2:00.0, 2:17.0, 2:37.0, 3:06.0, 3:17.0, 3:28.0; section lengths median 17 s (range 2 to 42). Reliable for sections of 10 s or more.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream stem entries and exits:** drums plays 49% of the time (in: 0:02.5, 1:13.0, 2:15.0; out: 0:12.0, 1:16.5, 4:38.5); bass plays 80% of the time (in: 0:05.0, 0:41.0, 1:05.5, 2:03.5; out: 0:24.0, 0:49.0, 1:53.0, 5:01.0); other plays 91% of the time (in: 0:16.0; out: 5:04.5); vocals plays 33% of the time (in: 1:39.0, 1:54.0, 2:04.0, 3:12.5, 3:36.0; out: 1:46.5, 2:00.5, 2:22.5, 3:31.5, 3:56.0).
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream floor drops:** low end too sparse to say (on in under 75% of the track).
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream brightness sweeps (0.7 octave or more):** mix down 3.8 oct 0:04.5 to 0:12.5; mix up 3.8 oct 0:12.5 to 0:22.0; mix down 2.6 oct 0:22.0 to 0:31.0; mix up 2.3 oct 0:31.5 to 0:36.5; mix down 1.9 oct 0:42.0 to 0:47.0; mix up 0.7 oct 1:06.0 to 1:12.0; mix up 0.9 oct 1:33.0 to 1:39.0; mix down 1.1 oct 1:46.0 to 1:54.5 (37 more in techniques.json).
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream pumping locked to the kick:** under 1.5 dB; none found.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream tape wobble and speed:** bass wobbles about 9 cents at 2.8 Hz.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream stereo movement:** vocals pan range 0.30.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream builds:** 0:00.0 to 0:20.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Nonlocal Forecast - My Big T.O.E. meter:** about 115 BPM (could be 57 or 229; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.07); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim.
- **Nonlocal Forecast - My Big T.O.E. key and mode:** C# ionian (major) (key signature margin 0.022); pitch-class weights C# 0.17, D# 0.16, G# 0.11, F# 0.11, G 0.09.
- **Nonlocal Forecast - My Big T.O.E. chords:** 28 changes a minute (18 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.5 to 4.5 s); 19 distinct chords; most time on F#sus2 19%, C#5 15%, D# 14%, F#5 9%. The old counter in this same run said 18; Ears 1's 2-s counter said 7.  52% of the changes land on a beat (chance would be 57%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Nonlocal Forecast - My Big T.O.E. bass:** pedal (one note held or repeated); 0.48 notes a second; most time on C# 0.85, D# 0.07, F# 0.07, F 0.01; steps 14%, thirds 4%, fourths and fifths 4%, octaves 0%, repeats 79%.
- **Nonlocal Forecast - My Big T.O.E. top line (from the 'other' stem; read by ear before trusting):** 331 notes, range 11 semitones (10th to 90th percentile); steps 25%, thirds 17%, fourths and fifths 25%, leaps 19%, repeats 14%; median interval 4 semitones; 49% of moves go up; phrases of about 7 notes, arch 25%, rising 38%, falling 29%, flat or wavy 8%. Reliable only when the line sits clearly above its accompaniment.
- **Nonlocal Forecast - My Big T.O.E. repetition:** 36 bars of 4.7 s; strongest repeat distances 1 bars (0.32), 5 bars (0.09), 14 bars (0.08); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) meter:** about 121 BPM (could be 60 or 242; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.18); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) key and mode:** G mixolydian (low confidence: the key signature margin is 0.007, so read this as a guess); pitch-class weights G 0.12, D 0.11, C 0.10, F 0.10, E 0.09.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) chords:** 13 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 4.1 s (10th to 90th percentile 0.8 to 8.1 s); 12 distinct chords; most time on Gmaj7 26%, Csus2 20%, Fmaj7 20%, Amaj7 18%. The old counter in this same run said 6; Ears 1's 2-s counter said 1.  64% of the changes land on a beat (chance would be 60%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) bass:** root-note movement / mixed; 0.34 notes a second; most time on G 0.65, A 0.19, F 0.05, G# 0.04; steps 18%, thirds 2%, fourths and fifths 4%, octaves 20%, repeats 52%.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) top line (from the 'other' stem; read by ear before trusting):** 392 notes, range 21 semitones (10th to 90th percentile); steps 19%, thirds 4%, fourths and fifths 25%, leaps 27%, repeats 26%; median interval 5 semitones; 49% of moves go up; phrases of about 5 notes, arch 27%, rising 47%, falling 13%, flat or wavy 13%. Reliable only when the line sits clearly above its accompaniment.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) repetition:** 84 bars of 2.0 s; strongest repeat distances 1 bars (0.71), 8 bars (0.31), 16 bars (0.26); 10% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) meter:** about 127 BPM (could be 63 or 253; the tool cannot tell the beat level), bar length unclear (best guess 3, score 0.07); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) key and mode:** F phrygian (low confidence: the key signature margin is 0.002, so read this as a guess); pitch-class weights C 0.13, F 0.12, A 0.12, D# 0.11, E 0.11.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) chords:** 29 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.5 to 3.5 s); 25 distinct chords; most time on Adim 15%, C#maj7 12%, F5 11%, A5 8%. The old counter in this same run said 19; Ears 1's 2-s counter said 18.  47% of the changes land on a beat (chance would be 63%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) top line (from the 'other' stem; read by ear before trusting):** 323 notes, range 9 semitones (10th to 90th percentile); steps 11%, thirds 28%, fourths and fifths 40%, leaps 9%, repeats 13%; median interval 4 semitones; 50% of moves go up; phrases of about 27 notes, arch 38%, rising 0%, falling 25%, flat or wavy 38%. Reliable only when the line sits clearly above its accompaniment.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) repetition:** 99 bars of 1.4 s; strongest repeat distances 1 bars (0.61), 7 bars (0.32), 14 bars (0.16); 6% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream meter:** about 77 BPM (could be 39 or 155; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.21); swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream key and mode:** D dorian (low confidence: the key signature margin is 0.014, so read this as a guess); pitch-class weights A 0.12, G 0.11, D 0.10, G# 0.10, B 0.09.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream chords:** 33 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.6 to 3.2 s); 41 distinct chords; most time on Gsus2 14%, D5 10%, A#5 10%, C5 7%. The old counter in this same run said 17; Ears 1's 2-s counter said 16.  40% of the changes land on a beat (chance would be 39%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream bass:** root-note movement / mixed; 0.82 notes a second; most time on D 0.27, A 0.17, A# 0.15, B 0.11; steps 23%, thirds 4%, fourths and fifths 15%, octaves 3%, repeats 46%.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream top line (from the 'other' stem; read by ear before trusting):** 703 notes, range 21 semitones (10th to 90th percentile); steps 18%, thirds 11%, fourths and fifths 18%, leaps 39%, repeats 15%; median interval 5 semitones; 52% of moves go up; phrases of about 8 notes, arch 63%, rising 21%, falling 5%, flat or wavy 11%. Reliable only when the line sits clearly above its accompaniment.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream repetition:** 203 bars of 1.6 s; strongest repeat distances 1 bars (0.54), 11 bars (0.14), 14 bars (0.12); 7% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Nonlocal Forecast - My Big T.O.E. mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -13 (corr 0.91); low_120_500 -6 (corr 0.64); mid_500_2k -5 (corr 0.53); pres_2k_5k -4 (corr 0.46); air_gt5k -5 (corr 0.48); over time (2-s windows) 10th/50th/90th percentile -7/-6/-4 dB.
- **Nonlocal Forecast - My Big T.O.E. by part:** drums: 58% of the power, width -16 dB, pan +0.01, mono loss 0.1 dB, widest in low_120_500 (-8 dB); bass: 12% of the power, width -7 dB, pan +0.27, mono loss 0.8 dB, widest in sub_lt120 (-7 dB); other: 30% of the power, width -7 dB, pan +0.13, mono loss 0.8 dB, widest in mid_500_2k (-6 dB); vocals: 0% of the power, width -4 dB, pan -0.09, mono loss 1.4 dB, widest in low_120_500 (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -24 (corr 0.99); low_120_500 -7 (corr 0.69); mid_500_2k -5 (corr 0.51); pres_2k_5k -5 (corr 0.52); air_gt5k -4 (corr 0.40); over time (2-s windows) 10th/50th/90th percentile -7/-6/-4 dB.
- **Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz) by part:** drums: 57% of the power, width -23 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-38 dB); bass: 28% of the power, width -27 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-27 dB); other: 14% of the power, width -4 dB, pan +0.01, mono loss 1.4 dB, widest in low_120_500 (-3 dB); vocals: 0% of the power, width -10 dB, pan -0.00, mono loss 0.4 dB, widest in mid_500_2k (-6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -7 (corr 0.68); low_120_500 -2 (corr 0.18); mid_500_2k -2 (corr 0.18); pres_2k_5k -1 (corr 0.12); air_gt5k -1 (corr 0.07); over time (2-s windows) 10th/50th/90th percentile -4/-1/1 dB.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1) by part:** drums: 3% of the power, width -20 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-26 dB); bass: 0% of the power, width -9 dB, pan -0.00, mono loss 0.5 dB, widest in mid_500_2k (-9 dB); other: 91% of the power, width -1 dB, pan -0.06, mono loss 2.5 dB, widest in low_120_500 (-1 dB); vocals: 5% of the power, width -5 dB, pan -0.03, mono loss 1.3 dB, widest in mid_500_2k (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -15 (corr 0.93); low_120_500 -8 (corr 0.75); mid_500_2k -6 (corr 0.62); pres_2k_5k -6 (corr 0.63); air_gt5k -8 (corr 0.70); over time (2-s windows) 10th/50th/90th percentile -9/-7/-4 dB.
- **Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream by part:** drums: 30% of the power, width -17 dB, pan -0.01, mono loss 0.1 dB, widest in low_120_500 (-15 dB); bass: 31% of the power, width -13 dB, pan +0.00, mono loss 0.2 dB, widest in low_120_500 (-9 dB); other: 38% of the power, width -7 dB, pan -0.02, mono loss 0.7 dB, widest in mid_500_2k (-7 dB); vocals: 1% of the power, width -5 dB, pan -0.02, mono loss 1.1 dB, widest in low_120_500 (-5 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Nonlocal Forecast - My Big T.O.E.: 115 BPM, 18 settled chords a minute, 2% of energy above 2 kHz, width -10 dB; Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz): 121 BPM, 9 settled chords a minute, 5% of energy above 2 kHz, width -13 dB; Nonlocal Forecast - We're Smeared Across a 2D Surface (Part -1): 127 BPM, 17 settled chords a minute, 1% of energy above 2 kHz, width -2 dB; Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream: 77 BPM, 14 settled chords a minute, 4% of energy above 2 kHz, width -10 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Nonlocal Forecast - My Big T.O.E., bass group `bass-1` (170 notes): around C#1, harmonic (string/reed/pad-like), soft attack, falls 4 dB/s, centered; hear it at 0:46.0, 0:05.5. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - My Big T.O.E., other group `other-2` (63 notes): around G1, bell- or metal-like (partials off whole multiples), soft attack, falls 4 dB/s, centered; hear it at 0:10.0, 0:08.3. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream, drums group `drums-1` (188 notes): low thump, soft attack, falls 188 dB/s, gets brighter over the note, centered; hear it at 2:56.6, 4:34.5. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz), bass group `bass-1` (118 notes): around B1, bell- or metal-like (partials off whole multiples), quick attack, falls 219 dB/s, centered; hear it at 2:38.5, 0:57.4. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - My Big T.O.E., drums group `drums-2` (48 notes): mid snap, soft attack, falls 186 dB/s, gets brighter over the note, centered; hear it at 2:44.5, 2:07.6. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz), other group `other-2` (36 notes): around C#3, mixed or noisy partials, slow swell, falls 3 dB/s, centered; hear it at 2:45.0, 2:44.9. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - My Incomplete T.O.E. (feat. Fire-Toolz), bass group `bass-2` (125 notes): around G2, bell- or metal-like (partials off whole multiples), quick attack, falls 142 dB/s, centered; hear it at 1:25.2, 1:27.1. **[JUDGMENT]** why it waits.
- Nonlocal Forecast - The Bubbling Up of Duality On an Autumn Night By a Forest Stream, bass group `bass-2` (73 notes): around A2, harmonic (string/reed/pad-like), soft attack, falls 30 dB/s, centered; hear it at 0:45.3, 0:16.5. **[JUDGMENT]** why it waits.
- **Nonlocal Forecast - Extended to Disparate Fields** (3:46.6, 96 BPM by the mix-level count): stands out for pitch bends a minute 18.54 (high, album median 3.28); wobble (cents) 5.84 (high, album median 3.77). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Nonlocal Forecast - First Concrete Realization** (2:18.6, 136 BPM by the mix-level count): stands out for brightness sweep (octaves) 2.42 (high, album median 1.29). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Nonlocal Forecast - The Missing Link Is Extremely Nonlocal, Extremely Scrambled** (1:06.9, 136 BPM by the mix-level count): stands out for repetition 0.22 (low, album median 0.47). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Nonlocal Forecast - We're Smeared Across a 2D Surface (Part 1)** (1:26.7, 136 BPM by the mix-level count): stands out for width (side/mid dB) -13.80 (low, album median -9.85). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Nonlocal Forecast - Space-Time = Infinity-Eternity Objectified** (6:08.3, 108 BPM by the mix-level count): stands out for repetition 0.68 (high, album median 0.47). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
