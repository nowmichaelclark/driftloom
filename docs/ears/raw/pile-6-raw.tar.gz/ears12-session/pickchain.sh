#!/bin/bash
P6="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6"
cd ~/ears12
for d in "$HOME/ears12/src/AC_hours_and_town" "$P6/Nonlocal Forecast - Bubble Universe!" "$P6/Nonlocal Forecast - Holographic Universe(s_)!" "$P6/Nonlocal Forecast - Conscious Agents" "$P6/Fire‐Toolz & Nonlocal Forecast - Triangular Reformat" "$P6/Jaga Jazzist (2020) - Pyramid"; do
  s=$(date +%s)
  $HOME/ears12/venv/bin/python -P /home/kruu-mikey/driftloom/tools/ears/album.py "$d" ~/ears12/work --stages pick --workers 2
  echo "PICK_DONE $d $(( $(date +%s) - s )) s"
done
echo PICKCHAIN_DONE
