# Ears 12: mix-level pass over the 24 base hours of Animal Crossing: hpss split (rough stems) + theory.py,
# plus level at the start and end of each file (does the hour fade or cut at its loop point?)
import sys, os, json, subprocess, time, numpy as np
sys.path.insert(0, "/home/kruu-mikey/driftloom/tools/ears")
import split, theory
D = "/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/(2001) Animal Crossing Original Soundtrack/"
W = os.path.expanduser("~/ears12/work/AC_hours"); os.makedirs(W, exist_ok=True)
names = sorted(os.listdir(D))
def find(n): return [x for x in names if x.startswith("%d " % n)][0]
only = [int(x) for x in sys.argv[1:]] or list(range(24))
for h in only:
    f = D + find(57 + h); out = "%s/h%02d" % (W, h)
    if os.path.exists(out + "/theory.json"): continue
    os.makedirs(out, exist_ok=True); t0 = time.time()
    info = split.split(f, out + "/stems", mode="hpss")
    theory.run(out + "/stems", f, out + "/theory.json")
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", f, "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], capture_output=True).stdout
    y = np.frombuffer(raw, np.float32); sr = 16000
    def db(x): return 20 * np.log10(np.sqrt((x ** 2).mean()) + 1e-9)
    win = lambda a, b: db(y[int(a * sr):int(b * sr)])
    n = len(y) / sr
    edge = {"seconds": round(float(n), 1), "head_0_1s": round(win(0, 1), 1), "head_1_3s": round(win(1, 3), 1), "median_10s": round(float(np.median([win(i, i + 10) for i in range(0, int(n) - 10, 5)])), 1),
            "tail_m3_m1s": round(win(n - 3, n - 1), 1), "tail_last_1s": round(win(n - 1, n), 1)}
    json.dump(edge, open(out + "/edges.json", "w"), default=float)
    print("hour", h, "done in %.0f s" % (time.time() - t0), flush=True)
