import json,re,sys,numpy as np
def rows(path):
    d=json.load(open(path)); return {r['track']:r for r in d['rows'] if 'error' not in r and 'skip' not in r}
def hr(name):
    m=re.match(r'(\d+) (\d+)(AM|PM)',name)
    if not m: return None
    return int(m.group(2))%12+(12 if m.group(3)=='PM' else 0)
b=rows('work/AC_hours_and_town/pick.json'); s=rows('work/AC_seasons/pick.json')
cols=['seconds','lufs','tempo','pulse','centroid_hz','onsets_per_s','chord_changes_per_min','key_major_r','key_minor_r','width_db','air_gt5k','sub_lt120','pres_2k_5k','tuning_cents','repeat','tail_db_per_s']
def table(R,label):
    print(label); print('h  '+' '.join('%8s'%c[:8] for c in cols))
    out={}
    for t,r in sorted(R.items(), key=lambda kv:(hr(kv[0]) if hr(kv[0]) is not None else 99)):
        h=hr(t)
        if h is None: continue
        out[h]=r
        print('%2d '%h+' '.join('%8.2f'%(r.get(c) if r.get(c) is not None else float('nan')) for c in cols))
    return out
B=table(b,'BASE')
W={hr(t):r for t,r in s.items() if 'Winter' in t}; C={hr(t):r for t,r in s.items() if 'Cheery' in t or 'Cherry' in t}
print('median base/winter/cherry'); 
for c in cols:
    print('%-22s %8.3f %8.3f %8.3f'%(c,*[np.median([r[c] for r in D.values() if r.get(c) is not None]) for D in (B,W,C)]))
