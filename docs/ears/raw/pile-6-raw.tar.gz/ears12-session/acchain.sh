#!/bin/bash
cd ~/ears12
s=$(date +%s)
./chain.sh "$HOME/ears12/src/AC_hours_and_town"
echo "AC_DEEP_DONE $(( $(date +%s) - s )) s"
s2=$(date +%s)
venv/bin/python -P helpers/hours_pass.py
echo "AC_HOURS_DONE $(( $(date +%s) - s2 )) s"
