#!/bin/bash
# usage: chain.sh "album dir" ...   (one album at a time, one stage per process, resumes from cache)
for d in "$@"; do
  s=$(date +%s)
  for st in split events techniques theory space check card; do
    $HOME/ears12/venv/bin/python -P /home/kruu-mikey/driftloom/tools/ears/album.py "$d" ~/ears12/work --stages $st --workers 2
  done
  echo "ALBUM_DONE $d $(( $(date +%s) - s )) s"
done
echo CHAIN_DONE
