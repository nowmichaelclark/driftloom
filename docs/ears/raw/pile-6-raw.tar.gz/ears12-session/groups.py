import json,sys
w=sys.argv[1]
for tr in sys.argv[2:]:
    d=json.load(open(f'{w}/{tr}/events.json'))
    print('==',tr)
    for st,v in d['stems'].items():
        for g in v.get('groups') or []:
            f=g['fingerprint']; m=lambda k:(f[k]['med'] if f[k]['med'] is not None else float('nan'))
            print('  %-6s n%-4d wt%5.1f f0 %5.0f Hz att %4.0f ms dec %5.0f dB/s bright %5.0f harm %.2f inh %3.0f vs-mix %5.1f corr %.2f'%(g['stem'],g['n'],g['weight'],m('f0_hz'),m('attack_ms'),m('decay_db_s'),m('bright_start_hz'),m('harm_share'),m('inharm_cents'),m('vs_mix_db'),m('lr_corr')))
