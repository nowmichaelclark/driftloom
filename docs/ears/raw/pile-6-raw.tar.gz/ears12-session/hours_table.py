import json, os, re, numpy as np
W=os.path.expanduser("~/ears12/work")
def rows(path):
    d=json.load(open(path)); return {r['track']:r for r in d['rows'] if 'error' not in r and 'skip' not in r}
def hr(name):
    m=re.match(r'(\d+) (\d+)(AM|PM)',name)
    return None if not m else int(m.group(2))%12+(12 if m.group(3)=='PM' else 0)
B={hr(t):r for t,r in rows(W+"/AC_hours_and_town/pick.json").items() if hr(t) is not None}
out=[]
print("hr  BPM  bar  mode              conf  chg/min  settled%  eighth  trip  top chords                      cen  on/s  LUFS  wid  >2k%  head tail")
for h in range(24):
    d=W+"/AC_hours/h%02d"%h
    th=json.load(open(d+"/theory.json")); ed=json.load(open(d+"/edges.json"))
    N=lambda d:{a:(b if b is not None else float("nan")) for a,b in d.items()}
    m=N(th["meter"]); k=N(th["key"]); c=th["chords"]
    segs=c["segments"]; tot=sum(s["t1"]-s["t0"] for s in segs); dur={}
    for s in segs: dur[s["chord"]]=dur.get(s["chord"],0)+s["t1"]-s["t0"]
    top=", ".join("%s %d%%"%(n,100*v/tot) for n,v in sorted(dur.items(),key=lambda x:-x[1])[:3])
    r={k:(v if v is not None else float("nan")) for k,v in B[h].items()}
    ch=len(segs)/ (th["seconds"]/60)
    settled=sum(1 for s in segs if s["t1"]-s["t0"]>=1.5)/(th["seconds"]/60)
    gt2=100*(r.get("pres_2k_5k",0)+r.get("air_gt5k",0))
    print("%2d %5.1f %3d  %-3s %-11s %5.3f  %5.1f  %5.1f  %5.3f  %4.2f  %-32s %4.0f %4.2f %5.1f %5.1f %4.1f %5.1f %5.1f"%(h,m["bpm"],m.get("beats_per_bar") or 0,str(k["tonic"]),str(k["mode"]).split()[0],k["tonic_margin"],ch,settled,m.get("eighth_off_phase",0),m.get("triplet_share",0),top,r["centroid_hz"],r["onsets_per_s"],r["lufs"],r["width_db"],gt2,ed["head_0_1s"]-ed["median_10s"],ed["tail_last_1s"]-ed["median_10s"]))
