import subprocess, numpy as np, os, librosa
D="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/(2001) Animal Crossing Original Soundtrack/"
names=sorted(os.listdir(D))
def find(n): return [x for x in names if x.startswith("%d "%n)][0]
def chroma(f):
    raw=subprocess.run(["ffmpeg","-v","error","-i",f,"-ac","1","-ar","11025","-f","f32le","-"],capture_output=True).stdout
    y=np.frombuffer(raw,np.float32)
    return librosa.feature.chroma_stft(y=y,sr=11025,hop_length=2756,n_fft=4096)  # 0.25 s frames
res=[]
for h in range(24):
    b,w,c=chroma(D+find(57+h)),chroma(D+find(194+h)),chroma(D+find(218+h))
    n=min(b.shape[1],w.shape[1],c.shape[1])
    def sim(x,y):
        x=x[:,:n]; y=y[:,:n]
        # mean chroma profile similarity (key) and frame-by-frame cosine (melody/chords)
        gp=np.dot(x.mean(1),y.mean(1))/np.linalg.norm(x.mean(1))/np.linalg.norm(y.mean(1))
        fr=np.mean(np.sum(x*y,0)/(np.linalg.norm(x,axis=0)*np.linalg.norm(y,axis=0)+1e-9))
        return gp,fr
    s1,s2,s3=sim(b,w),sim(b,c),sim(w,c)
    print("%2d base-winter profile %.2f frames %.2f | base-cherry %.2f %.2f | winter-cherry %.2f %.2f"%(h,*s1,*s2,*s3),flush=True)
