import subprocess, numpy as np, glob, re, os, sys
D="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/(2001) Animal Crossing Original Soundtrack/"
def load(f):
    raw=subprocess.run(["ffmpeg","-v","error","-i",f,"-ac","1","-ar","16000","-f","f32le","-"],capture_output=True).stdout
    return np.frombuffer(raw,np.float32)
names=sorted(os.listdir(D))
def find(n): return [x for x in names if x.startswith("%d "%n)][0]
print("hour  seconds(base/winter/cherry)  corr(base,winter) corr(base,cherry) rms dB diff(w,c)  centroid base/w/c Hz")
def cen(y):
    S=np.abs(np.fft.rfft(y[:16000*60]))**2; f=np.fft.rfftfreq(min(len(y),16000*60),1/16000); return (S*f).sum()/S.sum()
for h in range(24):
    b,w,c=load(D+find(57+h)),load(D+find(194+h)),load(D+find(218+h))
    n=min(len(b),len(w),len(c),16000*60)
    def corr(x,y): return float(np.corrcoef(x[:n],y[:n])[0,1])
    rms=lambda x:20*np.log10(np.sqrt((x[:n]**2).mean())+1e-9)
    print("%2d  %.0f/%.0f/%.0f  %.3f %.3f  %+.1f %+.1f   %.0f/%.0f/%.0f"%(h,len(b)/16000,len(w)/16000,len(c)/16000,corr(b,w),corr(b,c),rms(w)-rms(b),rms(c)-rms(b),cen(b),cen(w),cen(c)))
