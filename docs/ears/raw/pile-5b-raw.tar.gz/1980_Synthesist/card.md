## 1980 - Synthesist (draft card from Ears 3 tools, 2026-11-07)

How it was made: EP or short record (8 usable tracks): every track. Deep pass on: 01. So Weit,So Gut; 02. B.Aldrian; 03. Emphasis; 04. Synthesist; 05. 1847 - Earth; 06. Trauma; 07. Transcendental Overdrive; 08. Tai Ki. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **01. So Weit,So Gut**: share of power drums 12%, bass 20%, other 69%, vocals 0%.
  - vocals stem holds 0.2%: bleed on an instrumental, not a voice.
  - meter tool 91 BPM is half of the drum-grid beat of 178.0 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **02. B.Aldrian**: share of power drums 0%, bass 1%, other 98%, vocals 1%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.7%: bleed on an instrumental, not a voice.
- **03. Emphasis**: share of power drums 21%, bass 29%, other 48%, vocals 2%.
  - vocals stem holds 2.0%: bleed on an instrumental, not a voice.
  - meter tool 83 BPM is half of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **04. Synthesist**: share of power drums 10%, bass 0%, other 90%, vocals 0%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.1%: bleed on an instrumental, not a voice.
  - meter tool 105 BPM agrees with the drum-grid beat of 105.4 BPM.
- **05. 1847 - Earth**: share of power drums 33%, bass 9%, other 47%, vocals 11%.
  - meter tool 91 BPM does not match the drum-grid beat of 224.7 BPM by a simple ratio: listen.
- **06. Trauma**: share of power drums 0%, bass 1%, other 99%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.4%: bleed on an instrumental, not a voice.
- **07. Transcendental Overdrive**: share of power drums 16%, bass 50%, other 33%, vocals 1%.
  - vocals stem holds 1.2%: bleed on an instrumental, not a voice.
  - meter tool 84 BPM is half of the drum-grid beat of 166.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **08. Tai Ki**: share of power drums 0%, bass 0%, other 100%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 83 to 154 BPM (octave-uncertain); keys C# ionian, C# lydian, B ionian, F dorian, E mixolydian, G mixolydian, A# phrygian; mix width -10 to 20 dB; chord changes 3 to 83 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 06. Trauma: other group `other-1` (416 notes, 85% of the track's note energy)
- In synth terms: around D1, mixed or noisy partials, slow swell, falls 4 dB/s, centered.
- Hear it at: 2:21.0 (D1, 2.62 s, +53 dB alone), 2:14.0 (D1, 1.78 s, +53 dB alone), 4:51.6 (D1, 2.41 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 37 (36 to 73) Hz; attack 218 (32 to 922) ms; decay -4 (-45 to 1) dB/s
  - brightness at the start 378 (242 to 592) Hz; slope over the note 0.10 (-0.06 to 0.76) octaves
  - harmonic share 0.77 (0.31 to 0.92); partials off whole multiples 42 (19 to 88) cents
  - vibrato 0 (0 to 14) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.2 (-1.7 to -0.7) dB; pan -0.12 (-0.18 to 0.01); left-right correlation 0.54 (0.38 to 0.73)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. 02. B.Aldrian: other group `other-1` (330 notes, 59% of the track's note energy)
- In synth terms: around C#1, harmonic (string/reed/pad-like), soft attack, falls 12 dB/s, centered.
- Hear it at: 2:26.8 (C#1, 0.31 s, +54 dB alone), 2:59.0 (C#1, 0.15 s, +53 dB alone), 1:30.4 (C#1, 0.4 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 34 (34 to 46) Hz; attack 79 (17 to 296) ms; decay -12 (-71 to 4) dB/s
  - brightness at the start 525 (376 to 848) Hz; slope over the note 0.00 (-0.01 to 0.16) octaves
  - harmonic share 0.99 (0.88 to 1.00); partials off whole multiples 8 (3 to 17) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.8 (-1.3 to -0.4) dB; pan -0.04 (-0.11 to 0.04); left-right correlation 0.71 (0.56 to 0.82)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. 08. Tai Ki: other group `other-1` (235 notes, 56% of the track's note energy)
- In synth terms: around F4, mixed or noisy partials, soft attack, falls 23 dB/s, centered.
- Hear it at: 1:23.3 (E4, 0.26 s, +38 dB alone), 1:48.6 (A#4, 0.4 s, +39 dB alone), 2:15.6 (A#3, 0.37 s, +38 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 347 (191 to 945) Hz; attack 102 (34 to 249) ms; decay -23 (-105 to -1) dB/s
  - brightness at the start 1409 (1200 to 1683) Hz; slope over the note 0.00 (-0.07 to 0.15) octaves
  - harmonic share 0.34 (0.09 to 0.91); partials off whole multiples 54 (23 to 155) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -18.0 (-20.4 to -15.9) dB; pan 0.02 (0.01 to 0.04); left-right correlation -0.97 (-0.98 to -0.95)
- Group quality: weak (silhouette 0.21, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. 03. Emphasis: other group `other-1` (470 notes, 53% of the track's note energy)
- In synth terms: around F#3, mixed or noisy partials, slow swell, falls 12 dB/s, centered.
- Hear it at: 4:44.1 (A2, 0.25 s, +18 dB alone), 4:44.3 (E3, 0.31 s, +8 dB alone), 4:41.5 (B2, 0.32 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 186 (93 to 368) Hz; attack 160 (41 to 490) ms; decay -12 (-63 to 1) dB/s
  - brightness at the start 1172 (674 to 1579) Hz; slope over the note 0.00 (-0.24 to 0.35) octaves
  - harmonic share 0.65 (0.23 to 0.93); partials off whole multiples 52 (18 to 128) cents
  - vibrato 0 (0 to 4) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.9 (-5.5 to -2.9) dB; pan -0.05 (-0.14 to 0.08); left-right correlation 0.42 (0.32 to 0.56)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. 04. Synthesist: other group `other-1` (315 notes, 47% of the track's note energy)
- In synth terms: around C3, mixed or noisy partials, soft attack, falls 44 dB/s, centered.
- Hear it at: 0:34.7 (G#2, 0.12 s, +53 dB alone), 0:22.9 (C3, 0.15 s, +51 dB alone), 0:10.9 (C#3, 0.11 s, +50 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 133 (103 to 171) Hz; attack 61 (22 to 201) ms; decay -44 (-73 to -13) dB/s
  - brightness at the start 431 (291 to 637) Hz; slope over the note 0.15 (0.00 to 0.48) octaves
  - harmonic share 0.68 (0.29 to 0.94); partials off whole multiples 59 (21 to 156) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.1 (-1.8 to -0.6) dB; pan 0.01 (-0.07 to 0.09); left-right correlation 0.68 (0.45 to 0.77)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. 08. Tai Ki: other group `other-2` (264 notes, 44% of the track's note energy)
- In synth terms: around D#2, mixed or noisy partials, soft attack, falls 24 dB/s, centered.
- Hear it at: 1:23.7 (G2, 0.24 s, +40 dB alone), 1:43.1 (F#2, 0.52 s, +39 dB alone), 1:39.3 (F#2, 0.52 s, +38 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 79 (59 to 135) Hz; attack 102 (30 to 247) ms; decay -24 (-88 to -3) dB/s
  - brightness at the start 1367 (1117 to 1681) Hz; slope over the note 0.00 (-0.16 to 0.13) octaves
  - harmonic share 0.80 (0.40 to 0.97); partials off whole multiples 25 (13 to 43) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -19.8 (-23.2 to -17.2) dB; pan 0.02 (0.01 to 0.04); left-right correlation -0.98 (-0.99 to -0.96)
- Group quality: weak (silhouette 0.21, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. 01. So Weit,So Gut: other group `other-1` (121 notes, 40% of the track's note energy)
- In synth terms: around B2, mixed or noisy partials, slow swell, falls 2 dB/s, centered.
- Hear it at: 4:25.1 (G#3, 0.17 s, +29 dB alone), 2:60.0 (G#2, 0.35 s, +23 dB alone), 2:58.3 (F#3, 0.16 s, +24 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 121 (90 to 241) Hz; attack 244 (48 to 1923) ms; decay -2 (-31 to 1) dB/s
  - brightness at the start 1163 (687 to 1540) Hz; slope over the note 0.08 (-0.26 to 0.54) octaves
  - harmonic share 0.75 (0.49 to 0.92); partials off whole multiples 37 (17 to 69) cents
  - vibrato 0 (0 to 25) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-4.9 to -1.9) dB; pan 0.05 (0.01 to 0.15); left-right correlation 0.24 (-0.02 to 0.39)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S8. 02. B.Aldrian: other group `other-2` (168 notes, 37% of the track's note energy)
- In synth terms: around C#3, mixed or noisy partials, soft attack, falls 20 dB/s, centered.
- Hear it at: 2:22.9 (C#3, 1.07 s, +51 dB alone), 2:27.0 (C#3, 0.2 s, +53 dB alone), 2:23.8 (D#3, 0.3 s, +53 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 137 (69 to 139) Hz; attack 97 (21 to 339) ms; decay -20 (-151 to 3) dB/s
  - brightness at the start 460 (352 to 647) Hz; slope over the note 0.00 (0.00 to 0.27) octaves
  - harmonic share 0.83 (0.23 to 0.96); partials off whole multiples 34 (12 to 93) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.7 (-1.0 to -0.5) dB; pan -0.03 (-0.11 to 0.06); left-right correlation 0.72 (0.62 to 0.81)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **01. So Weit,So Gut sections:** 14 boundaries at 0:02.0, 0:16.0, 0:59.0, 1:15.0, 1:47.0, 2:00.0, 2:31.0, 2:53.0, 3:12.0, 3:45.0, 4:07.0, 4:27.0; section lengths median 20 s (range 2 to 43). Reliable for sections of 10 s or more.
- **01. So Weit,So Gut stem entries and exits:** drums plays 98% of the time (in: from the start; out: 5:14.5); bass plays 69% of the time (in: 1:39.0, 3:01.0, 4:28.5; out: 0:55.0, 2:34.5, 4:07.0, 5:14.5); other plays 98% of the time (in: from the start; out: 5:14.0); vocals plays 19% of the time (in: 1:04.5, 2:14.0, 3:13.5, 3:30.0, 3:42.5; out: 1:12.0, 2:28.0, 3:20.5, 3:38.0, 3:45.0).
- **01. So Weit,So Gut floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **01. So Weit,So Gut brightness sweeps (0.7 octave or more):** mix down 0.8 oct 0:35.5 to 0:43.0; mix up 0.9 oct 0:51.0 to 0:57.0; mix down 0.7 oct 0:57.5 to 1:10.5; mix up 1.1 oct 1:11.0 to 1:19.5; mix up 0.8 oct 1:54.5 to 2:03.0; mix up 1.1 oct 2:16.0 to 2:24.0; mix up 0.9 oct 2:44.0 to 2:52.0; mix down 1.0 oct 3:40.5 to 3:48.5 (10 more in techniques.json).
- **01. So Weit,So Gut echo times:** drums: 329 ms (+22.8 dB, 3 later repeats).
- **01. So Weit,So Gut pumping locked to the kick:** other dips 1.7 dB at the kick (peak 10 ms after, kick every 0.33 s); bass dips 5.9 dB at the kick (peak 165 ms after, kick every 0.33 s). The tool reads about 70% of the true depth, so this is a floor.
- **01. So Weit,So Gut tape wobble and speed:** other wobbles about 11 cents at 3.2 Hz.
- **01. So Weit,So Gut stereo movement:** other pan range 0.36; vocals pan range 0.56.
- **02. B.Aldrian sections:** 11 boundaries at 0:02.0, 0:36.0, 1:03.0, 1:21.0, 1:44.0, 2:23.0, 2:39.0, 2:49.0, 3:30.0, 4:07.0, 4:37.0; section lengths median 25 s (range 2 to 41). Reliable for sections of 10 s or more.
- **02. B.Aldrian stem entries and exits:** drums plays 2% of the time (in: 0:25.5; out: 0:30.0); bass plays 49% of the time (in: 0:03.5, 0:11.0, 1:33.0, 2:02.5, 2:44.5; out: 0:07.5, 0:25.5, 1:58.5, 2:22.5, 2:48.5); other plays 96% of the time (in: 0:04.0; out: 4:42.5); vocals plays 10% of the time (in: 3:31.0, 3:42.0; out: 3:37.5, 4:05.0).
- **02. B.Aldrian floor drops:** low end too sparse to say (on in under 75% of the track).
- **02. B.Aldrian brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:00.5 to 0:10.0; mix up 0.7 oct 0:28.0 to 0:34.0; mix down 0.7 oct 0:34.5 to 0:45.5; mix up 0.8 oct 0:45.5 to 0:53.0; mix up 1.3 oct 0:54.0 to 1:00.5; mix down 0.8 oct 1:01.0 to 1:09.5; mix up 0.8 oct 1:10.0 to 1:16.0; mix down 1.1 oct 1:23.0 to 1:29.5 (35 more in techniques.json).
- **02. B.Aldrian echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **02. B.Aldrian pumping locked to the kick:** other dips 1.8 dB at the kick (peak 564 ms after, kick every 0.59 s); bass dips 3.8 dB at the kick (peak 534 ms after, kick every 0.59 s). The tool reads about 70% of the true depth, so this is a floor.
- **02. B.Aldrian tape wobble and speed:** other wobbles about 9 cents at 3.2 Hz; other speed moves up to 22 cents in 4 s; bass wobbles about 12 cents at 0.7 Hz; bass speed moves up to 9 cents in 4 s.
- **02. B.Aldrian stereo movement:** other pan range 0.26; vocals pan range 0.46.
- **03. Emphasis sections:** 15 boundaries at 0:02.0, 1:05.0, 1:15.0, 1:38.0, 1:50.0, 2:03.0, 2:15.0, 2:28.0, 2:41.0, 3:06.0, 3:31.0, 3:45.0; section lengths median 14 s (range 2 to 63). Reliable for sections of 10 s or more.
- **03. Emphasis stem entries and exits:** drums plays 98% of the time (in: from the start; out: 4:50.5); bass plays 95% of the time (in: 0:23.0, 4:47.5; out: 0:19.5, 4:43.0, 4:50.5); other plays 98% of the time (in: from the start; out: 4:51.5); vocals plays 32% of the time (in: 1:20.5, 1:50.0, 2:14.0, 2:43.5, 3:09.0; out: 1:23.5, 2:05.0, 2:22.5, 2:52.0, 3:13.0).
- **03. Emphasis floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **03. Emphasis brightness sweeps (0.7 octave or more):** mix up 0.9 oct 0:39.5 to 0:48.0; mix up 0.8 oct 0:51.0 to 0:59.5; mix down 0.9 oct 1:23.5 to 1:28.5; mix up 0.9 oct 1:56.0 to 2:07.5; mix up 0.8 oct 4:01.5 to 4:10.0; mix up 0.8 oct 4:34.0 to 4:39.0; mix down 1.0 oct 4:39.0 to 4:46.5; other up 0.8 oct 0:07.5 to 0:16.0 (11 more in techniques.json).
- **03. Emphasis echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **03. Emphasis pumping locked to the kick:** under 1.5 dB; none found.
- **03. Emphasis tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **03. Emphasis stereo movement:** vocals pan range 0.54.
- **04. Synthesist sections:** 22 boundaries at 1:04.0, 1:14.0, 1:42.0, 1:59.0, 2:09.0, 2:21.0, 2:35.0, 2:45.0, 2:58.0, 3:14.0, 3:29.0, 3:41.0; section lengths median 15 s (range 10 to 64). Reliable for sections of 10 s or more.
- **04. Synthesist stem entries and exits:** drums plays 91% of the time (in: 0:35.0; out: 7:27.5); bass plays 0% of the time (in: from the start; out: never); other plays 99% of the time (in: from the start; out: 7:27.5); vocals plays 4% of the time (in: 6:20.0, 6:56.0, 7:12.5; out: 6:33.0, 6:59.0, 7:16.5).
- **04. Synthesist floor drops (kick and bass out 2 s or more while the rest plays):** 0.15 a minute: 0:22.5 for 13.0 s.
- **04. Synthesist brightness sweeps (0.7 octave or more):** mix down 0.9 oct 2:36.5 to 2:45.0; mix up 0.7 oct 2:55.0 to 3:04.0; mix up 0.8 oct 4:31.5 to 4:36.5; mix down 0.8 oct 4:52.5 to 5:00.0; mix up 1.0 oct 5:05.0 to 5:19.0; mix down 0.9 oct 5:53.5 to 6:06.0; mix down 1.0 oct 6:30.0 to 6:36.0; mix down 0.7 oct 6:54.0 to 6:59.5 (31 more in techniques.json).
- **04. Synthesist echo times:** drums: 569 ms (+21.1 dB, 1 later repeats).
- **04. Synthesist pumping locked to the kick:** other dips 4.0 dB at the kick (peak 554 ms after, kick every 0.57 s); bass dips 11.5 dB at the kick (peak 509 ms after, kick every 0.57 s). The tool reads about 70% of the true depth, so this is a floor.
- **04. Synthesist tape wobble and speed:** other wobbles about 17 cents at 1.2 Hz.
- **04. Synthesist stereo movement:** vocals pan range 0.41.
- **05. 1847 - Earth sections:** 18 boundaries at 0:02.0, 0:26.0, 1:02.0, 1:18.0, 1:29.0, 1:41.0, 2:01.0, 2:30.0, 2:58.0, 3:14.0, 3:29.0, 3:42.0; section lengths median 16 s (range 2 to 71). Reliable for sections of 10 s or more.
- **05. 1847 - Earth stem entries and exits:** drums plays 88% of the time (in: 0:25.0, 6:23.0, 6:28.0; out: 6:15.5, 6:25.5, 6:30.5); bass plays 54% of the time (in: 0:25.0, 1:03.0, 1:15.5, 1:57.0, 2:32.0; out: 0:43.0, 1:06.0, 1:35.0, 2:04.5, 2:39.5); other plays 96% of the time (in: from the start; out: 6:28.5); vocals plays 97% of the time (in: from the start; out: 6:31.5).
- **05. 1847 - Earth floor drops (kick and bass out 2 s or more while the rest plays):** 0.50 a minute: 0:20.0 for 6.0 s, 6:08.8 for 5.0 s, 6:14.0 for 9.0 s.
- **05. 1847 - Earth brightness sweeps (0.7 octave or more):** mix down 1.2 oct 0:22.5 to 0:28.5; mix up 0.9 oct 0:57.5 to 1:02.5; mix down 0.7 oct 1:19.5 to 1:24.5; mix up 0.8 oct 1:37.0 to 1:43.0; mix up 0.9 oct 4:55.5 to 5:03.5; mix down 0.8 oct 5:36.0 to 5:41.0; mix up 1.1 oct 5:49.0 to 5:56.0; mix up 1.5 oct 6:04.0 to 6:12.5 (33 more in techniques.json).
- **05. 1847 - Earth echo times:** drums: 654 ms (+9.5 dB, 2 later repeats).
- **05. 1847 - Earth pumping locked to the kick:** other dips 2.3 dB at the kick (peak 95 ms after, kick every 0.27 s); bass dips 2.0 dB at the kick (peak 105 ms after, kick every 0.27 s). The tool reads about 70% of the true depth, so this is a floor.
- **05. 1847 - Earth tape wobble and speed:** other wobbles about 27 cents at 0.3 Hz.
- **05. 1847 - Earth stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **06. Trauma sections:** 21 boundaries at 0:22.0, 0:56.0, 1:12.0, 1:23.0, 1:37.0, 1:52.0, 2:18.0, 2:36.0, 2:56.0, 3:12.0, 3:31.0, 3:46.0; section lengths median 16 s (range 11 to 34). Reliable for sections of 10 s or more.
- **06. Trauma stem entries and exits:** drums plays 3% of the time (in: 4:07.0, 5:26.5, 5:33.0; out: 4:12.0, 5:30.5, 5:35.5); bass plays 15% of the time (in: 0:41.5, 4:14.0, 4:35.0, 5:09.5, 5:26.5; out: 0:48.0, 4:31.0, 4:37.5, 5:22.5, 5:37.5); other plays 97% of the time (in: 0:03.0; out: 6:25.5); vocals plays 11% of the time (in: 0:54.5, 3:31.5, 5:21.5; out: 0:58.0, 4:01.5, 5:29.5).
- **06. Trauma floor drops:** low end too sparse to say (on in under 75% of the track).
- **06. Trauma brightness sweeps (0.7 octave or more):** mix up 1.7 oct 0:00.0 to 0:05.0; mix up 0.7 oct 0:52.5 to 1:00.5; mix down 1.3 oct 1:47.5 to 1:53.5; mix up 0.9 oct 2:09.5 to 2:18.5; mix down 1.2 oct 2:19.5 to 2:24.5; mix down 1.1 oct 5:43.5 to 5:48.5; other up 1.7 oct 0:00.0 to 0:05.0; other up 0.8 oct 0:52.5 to 1:00.0 (13 more in techniques.json).
- **06. Trauma echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **06. Trauma pumping locked to the kick:** under 1.5 dB; none found.
- **06. Trauma tape wobble and speed:** other wobbles about 18 cents at 2.6 Hz; bass wobbles about 21 cents at 2.6 Hz.
- **06. Trauma stereo movement:** other pan range 0.23, cycling every 4 s; vocals pan range 0.33.
- **06. Trauma builds:** 0:00.0 to 0:24.0.
- **07. Transcendental Overdrive sections:** 14 boundaries at 0:02.0, 0:25.0, 1:06.0, 1:30.0, 1:56.0, 2:14.0, 2:33.0, 2:49.0, 3:10.0, 3:30.0, 3:41.0, 4:03.0; section lengths median 20 s (range 2 to 41). Reliable for sections of 10 s or more.
- **07. Transcendental Overdrive stem entries and exits:** drums plays 98% of the time (in: from the start; out: 4:46.0); bass plays 87% of the time (in: 0:18.5, 0:25.5, 0:41.0, 1:21.5, 3:36.0; out: 0:12.5, 0:21.0, 0:35.5, 1:18.0, 3:27.0); other plays 98% of the time (in: from the start; out: 4:48.0); vocals plays 26% of the time (in: 2:13.5, 2:19.5, 2:40.0, 3:48.0, 4:28.5; out: 2:16.5, 2:34.5, 2:54.5, 4:14.0, 4:46.5).
- **07. Transcendental Overdrive floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **07. Transcendental Overdrive brightness sweeps (0.7 octave or more):** mix up 1.5 oct 0:00.0 to 0:05.5; mix up 2.4 oct 0:19.0 to 0:27.5; mix down 1.3 oct 1:20.5 to 1:32.0; mix up 0.9 oct 2:15.0 to 2:23.0; mix down 0.7 oct 2:29.5 to 2:34.5; mix up 0.8 oct 2:53.5 to 2:59.0; mix up 0.8 oct 3:21.0 to 3:26.0; mix up 1.0 oct 4:10.5 to 4:19.5 (26 more in techniques.json).
- **07. Transcendental Overdrive echo times:** drums: 264 ms (+22.8 dB, 3 later repeats).
- **07. Transcendental Overdrive pumping locked to the kick:** bass dips 1.5 dB at the kick (peak 334 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **07. Transcendental Overdrive tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **07. Transcendental Overdrive stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **08. Tai Ki sections:** 11 boundaries at 0:19.0, 0:31.0, 0:52.0, 1:08.0, 1:23.0, 1:39.0, 1:51.0, 2:08.0, 2:24.0, 2:35.0, 2:45.0; section lengths median 16 s (range 10 to 51). Reliable for sections of 10 s or more.
- **08. Tai Ki stem entries and exits:** drums plays 10% of the time (in: 1:00.5, 1:09.0, 1:24.0, 1:52.0, 2:36.0; out: 1:03.5, 1:15.0, 1:27.0, 1:55.5, 2:38.5); bass plays 25% of the time (in: 0:30.0, 1:16.5, 1:34.0, 2:20.5; out: 0:59.5, 1:23.0, 1:45.5, 2:27.5); other plays 97% of the time (in: 0:04.0; out: 3:34.0); vocals plays 10% of the time (in: 0:23.5, 0:48.5, 1:00.5, 1:09.0, 1:24.0; out: 0:26.0, 0:51.0, 1:03.0, 1:12.0, 1:27.0).
- **08. Tai Ki floor drops (kick and bass out 2 s or more while the rest plays):** 0.31 a minute: 3:18.0 for 2.5 s.
- **08. Tai Ki brightness sweeps (0.7 octave or more):** mix down 0.9 oct 2:26.0 to 2:40.0; other down 0.9 oct 2:26.0 to 2:40.0; bass down 1.3 oct 0:00.0 to 0:11.5; bass up 0.7 oct 3:22.5 to 3:31.0.
- **08. Tai Ki echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **08. Tai Ki pumping locked to the kick:** under 1.5 dB; none found.
- **08. Tai Ki tape wobble and speed:** other wobbles about 15 cents at 0.8 Hz.
- **08. Tai Ki stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **01. So Weit,So Gut meter:** about 91 BPM (could be 45 or 181; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim.
- **01. So Weit,So Gut key and mode:** C# ionian (major) (low confidence: the key signature margin is 0.000, so read this as a guess); pitch-class weights C 0.11, B 0.11, C# 0.10, F# 0.10, G# 0.09.
- **01. So Weit,So Gut chords:** 23 changes a minute (5 a minute are chords that last 1.5 s or more); median chord 0.7 s (10th to 90th percentile 0.6 to 6.1 s); 15 distinct chords; most time on F#7 37%, C#7 23%, C#maj7 9%, Cdim 6%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  11% of the changes land on a beat (chance would be 45%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **01. So Weit,So Gut bass:** root-note movement / mixed; 0.53 notes a second; most time on C# 0.61, G# 0.19, B 0.06, F# 0.06; steps 5%, thirds 18%, fourths and fifths 4%, octaves 4%, repeats 66%.
- **01. So Weit,So Gut top line (from the 'other' stem; read by ear before trusting):** 817 notes, range 20 semitones (10th to 90th percentile); steps 18%, thirds 28%, fourths and fifths 13%, leaps 19%, repeats 22%; median interval 3 semitones; 52% of moves go up; phrases of about 8 notes, arch 37%, rising 30%, falling 16%, flat or wavy 17%. Reliable only when the line sits clearly above its accompaniment.
- **01. So Weit,So Gut repetition:** 242 bars of 1.3 s; strongest repeat distances 1 bars (0.66), 8 bars (0.33), 12 bars (0.21); 0% of bars near-duplicate an earlier bar.
- **02. B.Aldrian meter:** about 104 BPM (could be 52 or 207; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.05); swung: off-beat at 0.55 of the beat; no cross-rhythm claim; many unrelated periodicities found (4:3, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **02. B.Aldrian key and mode:** C# lydian (low confidence: the key signature margin is 0.009, so read this as a guess); fits C# pentatonic; pitch-class weights C# 0.39, G# 0.18, D# 0.07, A# 0.07, C 0.07.
- **02. B.Aldrian chords:** 7 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 5.6 s (10th to 90th percentile 2.5 to 18.1 s); 10 distinct chords; most time on C#5 62%, C#maj7 15%, C#sus2 8%, A#min 4%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  44% of the changes land on a beat (chance would be 52%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **02. B.Aldrian bass:** pedal (one note held or repeated); 0.30 notes a second; most time on C# 1.00; steps 0%, thirds 0%, fourths and fifths 0%, octaves 13%, repeats 85%.
- **02. B.Aldrian top line (from the 'other' stem; read by ear before trusting):** 384 notes, range 7 semitones (10th to 90th percentile); steps 16%, thirds 11%, fourths and fifths 32%, leaps 2%, repeats 39%; median interval 2 semitones; 50% of moves go up; phrases of about 6 notes, arch 12%, rising 18%, falling 24%, flat or wavy 47%. Reliable only when the line sits clearly above its accompaniment.
- **02. B.Aldrian repetition:** 125 bars of 2.3 s; strongest repeat distances 1 bars (0.66), 21 bars (0.04), 28 bars (0.03); 5% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **03. Emphasis meter:** about 83 BPM (could be 42 or 166; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.15); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **03. Emphasis key and mode:** B ionian (major) (low confidence: the key signature margin is 0.009, so read this as a guess); pitch-class weights F# 0.14, C# 0.13, E 0.11, B 0.10, D# 0.10.
- **03. Emphasis chords:** 83 changes a minute (7 a minute are chords that last 1.5 s or more); median chord 0.5 s (10th to 90th percentile 0.3 to 1.1 s); 14 distinct chords; most time on Bmaj7 29%, D#min7 19%, Asus2 12%, Esus2 10%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  44% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **03. Emphasis bass:** pedal (one note held or repeated); 0.03 notes a second; most time on A 0.85, B 0.14; steps 33%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 67%.
- **03. Emphasis top line (from the 'other' stem; read by ear before trusting):** 579 notes, range 21 semitones (10th to 90th percentile); steps 19%, thirds 15%, fourths and fifths 14%, leaps 31%, repeats 21%; median interval 3 semitones; 50% of moves go up; phrases of about 6 notes, arch 21%, rising 7%, falling 14%, flat or wavy 57%. Reliable only when the line sits clearly above its accompaniment.
- **03. Emphasis repetition:** 102 bars of 2.9 s; strongest repeat distances 1 bars (0.57), 10 bars (0.31), 6 bars (0.29); 2% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **04. Synthesist meter:** about 105 BPM (could be 53 or 211; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.04); straight eighths; no cross-rhythm claim.
- **04. Synthesist key and mode:** C# ionian (major) (low confidence: the key signature margin is 0.000, so read this as a guess); pitch-class weights C# 0.19, F 0.13, G# 0.13, C 0.10, A# 0.09.
- **04. Synthesist chords:** 6 changes a minute (4 a minute are chords that last 1.5 s or more); median chord 5.0 s (10th to 90th percentile 0.5 to 27.8 s); 8 distinct chords; most time on C#maj7 76%, A#min7 18%, C#sus2 2%, Fmin7 2%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  50% of the changes land on a beat (chance would be 53%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **04. Synthesist top line (from the 'other' stem; read by ear before trusting):** 1394 notes, range 5 semitones (10th to 90th percentile); steps 23%, thirds 24%, fourths and fifths 30%, leaps 3%, repeats 20%; median interval 3 semitones; 53% of moves go up; phrases of about 9 notes, arch 24%, rising 39%, falling 11%, flat or wavy 26%. Reliable only when the line sits clearly above its accompaniment.
- **04. Synthesist repetition:** 398 bars of 1.1 s; strongest repeat distances 1 bars (0.68), 32 bars (0.07); 1% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **05. 1847 - Earth meter:** about 91 BPM (could be 45 or 182; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.15); swung: off-beat at 0.60 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **05. 1847 - Earth key and mode:** F dorian (low confidence: the key signature margin is 0.002, so read this as a guess); pitch-class weights D 0.10, F 0.10, F# 0.09, C 0.09, C# 0.09.
- **05. 1847 - Earth chords:** 12 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 3.0 s (10th to 90th percentile 1.3 to 10.7 s); 18 distinct chords; most time on F#maj7 31%, D#min7 16%, Dmin7 9%, Dmaj7 9%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  49% of the changes land on a beat (chance would be 45%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **05. 1847 - Earth bass:** root-note movement / mixed; 0.12 notes a second; most time on F# 0.53, F 0.15, C# 0.07, D 0.06; steps 24%, thirds 9%, fourths and fifths 9%, octaves 0%, repeats 52%.
- **05. 1847 - Earth top line (from the 'other' stem; read by ear before trusting):** 1273 notes, range 9 semitones (10th to 90th percentile); steps 33%, thirds 16%, fourths and fifths 37%, leaps 7%, repeats 7%; median interval 3 semitones; 49% of moves go up; phrases of about 20 notes, arch 25%, rising 12%, falling 38%, flat or wavy 25%. Reliable only when the line sits clearly above its accompaniment.
- **05. 1847 - Earth repetition:** 76 bars of 5.3 s; strongest repeat distances 1 bars (0.80); 3% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **06. Trauma meter:** about 154 BPM (could be 77 or 307; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.11); swung: off-beat at 0.57 of the beat; no cross-rhythm claim.
- **06. Trauma key and mode:** E mixolydian (low confidence: the key signature margin is 0.002, so read this as a guess); fits E pentatonic; pitch-class weights D 0.23, A 0.21, E 0.16, B 0.06, C# 0.05.
- **06. Trauma chords:** 3 changes a minute (2 a minute are chords that last 1.5 s or more); median chord 4.0 s (10th to 90th percentile 0.7 to 60.1 s); 8 distinct chords; most time on Dsus2 94%, Dmaj7 3%, D7 1%, Dmin7 0%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  78% of the changes land on a beat (chance would be 77%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **06. Trauma bass:** root-note movement / mixed; 0.04 notes a second; most time on E 0.33, G# 0.31, F# 0.17, D 0.09; steps 31%, thirds 12%, fourths and fifths 6%, octaves 12%, repeats 6%.
- **06. Trauma top line (from the 'other' stem; read by ear before trusting):** 441 notes, range 6 semitones (10th to 90th percentile); steps 16%, thirds 3%, fourths and fifths 20%, leaps 8%, repeats 54%; median interval 0 semitones; 49% of moves go up; phrases of about 8 notes, arch 24%, rising 21%, falling 6%, flat or wavy 48%. Reliable only when the line sits clearly above its accompaniment.
- **06. Trauma repetition:** 111 bars of 3.5 s; strongest repeat distances 1 bars (0.67), 24 bars (-0.03), 29 bars (-0.03); 2% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **07. Transcendental Overdrive meter:** about 84 BPM (could be 42 or 168; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.62 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 5:3, 7:4), which means irregular timing, not a cross-rhythm claim.
- **07. Transcendental Overdrive key and mode:** G mixolydian (low confidence: the key signature margin is 0.009, so read this as a guess); pitch-class weights C 0.17, G 0.17, F 0.12, D 0.09, A 0.07.
- **07. Transcendental Overdrive chords:** 41 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.3 to 2.5 s); 15 distinct chords; most time on C5 28%, Fsus2 17%, F5 16%, G5 16%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  54% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **07. Transcendental Overdrive bass:** root-note movement / mixed; 1.25 notes a second; most time on G 0.34, F 0.20, C 0.14, F# 0.09; steps 13%, thirds 4%, fourths and fifths 33%, octaves 9%, repeats 17%.
- **07. Transcendental Overdrive top line (from the 'other' stem; read by ear before trusting):** 812 notes, range 17 semitones (10th to 90th percentile); steps 16%, thirds 17%, fourths and fifths 32%, leaps 24%, repeats 12%; median interval 5 semitones; 53% of moves go up; phrases of about 7 notes, arch 64%, rising 18%, falling 14%, flat or wavy 5%. Reliable only when the line sits clearly above its accompaniment.
- **07. Transcendental Overdrive repetition:** 205 bars of 1.4 s; strongest repeat distances 2 bars (0.61), 4 bars (0.58), 6 bars (0.41); 2% of bars near-duplicate an earlier bar.
- **08. Tai Ki meter:** about 110 BPM (could be 55 or 219; the tool cannot tell the beat level), bar length unclear (best guess 7, score 0.05); straight eighths; no cross-rhythm claim.
- **08. Tai Ki key and mode:** A# phrygian (low confidence: the key signature margin is 0.005, so read this as a guess); pitch-class weights F 0.13, A# 0.11, D# 0.09, F# 0.09, D 0.08.
- **08. Tai Ki chords:** 18 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 2.4 s (10th to 90th percentile 1.0 to 5.5 s); 29 distinct chords; most time on A#maj7 24%, D#sus2 9%, A#5 8%, A#7 7%. The old counter in this same run said 6; Ears 1's 2-s counter said 6.  59% of the changes land on a beat (chance would be 55%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **08. Tai Ki top line (from the 'other' stem; read by ear before trusting):** 427 notes, range 18 semitones (10th to 90th percentile); steps 11%, thirds 3%, fourths and fifths 16%, leaps 31%, repeats 40%; median interval 2 semitones; 51% of moves go up; phrases of about 16 notes, arch 38%, rising 25%, falling 19%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **08. Tai Ki repetition:** 56 bars of 3.8 s; strongest repeat distances 1 bars (0.51), 7 bars (0.11), 11 bars (0.03); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **01. So Weit,So Gut mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -15 (corr 0.96); low_120_500 -4 (corr 0.50); mid_500_2k -1 (corr 0.09); pres_2k_5k -1 (corr 0.15); air_gt5k 0 (corr -0.05); over time (2-s windows) 10th/50th/90th percentile -4/-2/-1 dB.
- **01. So Weit,So Gut by part:** drums: 8% of the power, width -12 dB, pan -0.06, mono loss 0.3 dB, widest in low_120_500 (-15 dB); bass: 14% of the power, width -15 dB, pan +0.30, mono loss 0.1 dB, widest in sub_lt120 (-15 dB); other: 78% of the power, width -2 dB, pan +0.21, mono loss 2.3 dB, widest in mid_500_2k (-1 dB); vocals: 0% of the power, width -2 dB, pan -0.01, mono loss 2.0 dB, widest in mid_500_2k (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **02. B.Aldrian mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -13 (corr 0.95); low_120_500 -9 (corr 0.76); mid_500_2k -4 (corr 0.44); pres_2k_5k -4 (corr 0.42); air_gt5k -1 (corr 0.07); over time (2-s windows) 10th/50th/90th percentile -9/-7/-5 dB.
- **02. B.Aldrian by part:** drums: 0% of the power, width -3 dB, pan +0.06, mono loss 1.6 dB, widest in air_gt5k (-0 dB); bass: 1% of the power, width -34 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-33 dB); other: 98% of the power, width -7 dB, pan -0.05, mono loss 0.8 dB, widest in mid_500_2k (-4 dB); vocals: 1% of the power, width -6 dB, pan -0.25, mono loss 1.0 dB, widest in low_120_500 (-5 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **03. Emphasis mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -15 (corr 0.94); low_120_500 -9 (corr 0.78); mid_500_2k -4 (corr 0.41); pres_2k_5k -3 (corr 0.33); air_gt5k 2 (corr -0.17); over time (2-s windows) 10th/50th/90th percentile -14/-6/-4 dB.
- **03. Emphasis by part:** drums: 19% of the power, width -11 dB, pan -0.17, mono loss 0.3 dB, widest in low_120_500 (-12 dB); bass: 24% of the power, width -20 dB, pan +0.16, mono loss 0.0 dB, widest in sub_lt120 (-19 dB); other: 55% of the power, width -4 dB, pan -0.06, mono loss 1.5 dB, widest in pres_2k_5k (-3 dB); vocals: 2% of the power, width -5 dB, pan -0.26, mono loss 1.3 dB, widest in mid_500_2k (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **04. Synthesist mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -16 (corr 0.96); low_120_500 -6 (corr 0.60); mid_500_2k -5 (corr 0.50); pres_2k_5k -3 (corr 0.30); air_gt5k 2 (corr -0.21); over time (2-s windows) 10th/50th/90th percentile -7/-6/-4 dB.
- **04. Synthesist by part:** drums: 8% of the power, width -12 dB, pan -0.13, mono loss 0.3 dB, widest in low_120_500 (-15 dB); bass: 0% of the power, width -12 dB, pan -0.00, mono loss 0.3 dB, widest in low_120_500 (-15 dB); other: 92% of the power, width -6 dB, pan +0.02, mono loss 1.1 dB, widest in mid_500_2k (-5 dB); vocals: 0% of the power, width -3 dB, pan -0.40, mono loss 1.7 dB, widest in low_120_500 (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **05. 1847 - Earth mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -7 (corr 0.65); low_120_500 -3 (corr 0.32); mid_500_2k -2 (corr 0.25); pres_2k_5k -2 (corr 0.20); air_gt5k -4 (corr 0.48); over time (2-s windows) 10th/50th/90th percentile -3/-2/-1 dB.
- **05. 1847 - Earth by part:** drums: 28% of the power, width -7 dB, pan +0.14, mono loss 0.8 dB, widest in low_120_500 (-6 dB); bass: 8% of the power, width -5 dB, pan +0.10, mono loss 1.1 dB, widest in sub_lt120 (-6 dB); other: 49% of the power, width -3 dB, pan +0.16, mono loss 1.7 dB, widest in low_120_500 (-2 dB); vocals: 15% of the power, width -1 dB, pan +0.13, mono loss 2.7 dB, widest in pres_2k_5k (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **06. Trauma mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -4 (corr 0.41); low_120_500 -7 (corr 0.67); mid_500_2k -2 (corr 0.26); pres_2k_5k -2 (corr 0.19); air_gt5k 0 (corr -0.03); over time (2-s windows) 10th/50th/90th percentile -7/-5/-3 dB.
- **06. Trauma by part:** drums: 0% of the power, width -14 dB, pan -0.12, mono loss 0.2 dB, widest in low_120_500 (-13 dB); bass: 0% of the power, width -33 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-33 dB); other: 99% of the power, width -5 dB, pan -0.17, mono loss 1.2 dB, widest in mid_500_2k (-2 dB); vocals: 0% of the power, width -8 dB, pan -0.22, mono loss 0.6 dB, widest in pres_2k_5k (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **07. Transcendental Overdrive mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.99); low_120_500 -16 (corr 0.95); mid_500_2k -5 (corr 0.54); pres_2k_5k -2 (corr 0.22); air_gt5k -0 (corr 0.01); over time (2-s windows) 10th/50th/90th percentile -12/-10/-6 dB.
- **07. Transcendental Overdrive by part:** drums: 14% of the power, width -18 dB, pan +0.10, mono loss 0.1 dB, widest in sub_lt120 (-20 dB); bass: 46% of the power, width -22 dB, pan +0.09, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); other: 39% of the power, width -6 dB, pan +0.08, mono loss 1.1 dB, widest in pres_2k_5k (-2 dB); vocals: 1% of the power, width -11 dB, pan +0.04, mono loss 0.4 dB, widest in pres_2k_5k (-9 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **08. Tai Ki mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub 32 (corr -1.00); low_120_500 27 (corr -1.00); mid_500_2k 11 (corr -0.87); pres_2k_5k 11 (corr -0.86); air_gt5k 7 (corr -0.65); over time (2-s windows) 10th/50th/90th percentile 15/17/19 dB.
- **08. Tai Ki by part:** drums: 0% of the power, width 3 dB, pan +0.05, mono loss 4.9 dB, widest in sub_lt120 (3 dB); bass: 0% of the power, width 7 dB, pan +0.04, mono loss 8.1 dB, widest in sub_lt120 (13 dB); other: 100% of the power, width 20 dB, pan +0.04, mono loss 20.1 dB, widest in sub_lt120 (32 dB); vocals: 0% of the power, width -13 dB, pan +0.11, mono loss 0.2 dB, widest in sub_lt120 (-13 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 01. So Weit,So Gut: 91 BPM, 5 settled chords a minute, 13% of energy above 2 kHz, width -3 dB; 02. B.Aldrian: 104 BPM, 6 settled chords a minute, 6% of energy above 2 kHz, width -7 dB; 03. Emphasis: 83 BPM, 7 settled chords a minute, 9% of energy above 2 kHz, width -7 dB; 04. Synthesist: 105 BPM, 4 settled chords a minute, 5% of energy above 2 kHz, width -6 dB; 05. 1847 - Earth: 91 BPM, 10 settled chords a minute, 3% of energy above 2 kHz, width -4 dB; 06. Trauma: 154 BPM, 2 settled chords a minute, 3% of energy above 2 kHz, width -5 dB; 07. Transcendental Overdrive: 84 BPM, 13 settled chords a minute, 7% of energy above 2 kHz, width -10 dB; 08. Tai Ki: 110 BPM, 14 settled chords a minute, 2% of energy above 2 kHz, width 20 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: 08. Tai Ki: mono loss 20.1 dB (opposite-polarity parts).

### For later
- 04. Synthesist, other group `other-2` (185 notes): around G#1, mixed or noisy partials, soft attack, falls 39 dB/s, centered; hear it at 0:16.5, 5:31.4. **[JUDGMENT]** why it waits.
- 07. Transcendental Overdrive, bass group `bass-1` (247 notes): around F2, harmonic (string/reed/pad-like), soft attack, falls 18 dB/s, centered; hear it at 1:36.5, 4:10.6. **[JUDGMENT]** why it waits.
- 01. So Weit,So Gut, other group `other-2` (309 notes): around B2, mixed or noisy partials, soft attack, falls 33 dB/s, leans right (+0.21); hear it at 1:16.0, 1:24.0. **[JUDGMENT]** why it waits.
- 05. 1847 - Earth, other group `other-1` (296 notes): around F1, mixed or noisy partials, soft attack, falls 59 dB/s, centered; hear it at 3:10.5, 3:12.9. **[JUDGMENT]** why it waits.
- 07. Transcendental Overdrive, other group `other-1` (256 notes): around G2, mixed or noisy partials, soft attack, falls 12 dB/s, centered; hear it at 0:39.0, 2:54.8. **[JUDGMENT]** why it waits.
- 05. 1847 - Earth, vocals group `vocals-1` (390 notes): around F3, bell- or metal-like (partials off whole multiples), slow swell, falls 19 dB/s, centered; hear it at 6:18.4, 6:08.5. **[JUDGMENT]** why it waits.
- 07. Transcendental Overdrive, other group `other-2` (210 notes): around A#3, harmonic (string/reed/pad-like), soft attack, falls 15 dB/s, centered; hear it at 0:43.6, 3:34.2. **[JUDGMENT]** why it waits.
- 06. Trauma, other group `other-2` (82 notes): around A2, bell- or metal-like (partials off whole multiples), slow swell, falls 5 dB/s, centered; hear it at 2:40.1, 4:53.4. **[JUDGMENT]** why it waits.
