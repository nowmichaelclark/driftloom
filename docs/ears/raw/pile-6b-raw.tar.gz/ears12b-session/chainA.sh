#!/bin/bash
cd ~/ears12b
PY=~/ears12b/venv/bin/python
A="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/Fire‐Toolz & Nonlocal Forecast - Triangular Reformat"
for st in split events,techniques space,check; do
  $PY -P /home/kruu-mikey/driftloom/tools/ears/album.py "$A" work --stages $st --workers 1
done
touch work/chainA.done
