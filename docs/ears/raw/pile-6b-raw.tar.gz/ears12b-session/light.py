import sys, os, json, time
sys.path.insert(0, '/home/kruu-mikey/driftloom/tools/ears')
import split, theory
from album import slug
w = sys.argv[1]
rep = json.load(open(os.path.join(w, 'pick.json')))
for t in rep['picks']:
    out = os.path.join(w, slug(t) + '_theory.json')
    if os.path.exists(out): continue
    sd = os.path.join(w, 'stems_hpss', slug(t))
    t0 = time.time()
    split.split(rep['paths'][t], sd, mode='hpss')
    theory.run(sd, rep['paths'][t], out)
    print(t, round(time.time() - t0), 's', flush=True)
