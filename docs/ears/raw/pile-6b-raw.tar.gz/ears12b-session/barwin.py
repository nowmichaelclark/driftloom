# Ears 12b: how the repeat length moves through a track: per 30-s window, the drum-onset autocorrelation at 2..9 beats of the grid
import sys, numpy as np, librosa
work, track, bpm = sys.argv[1], sys.argv[2], float(sys.argv[3]); unit_beats = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
y, sr = librosa.load(f"{work}/stems/{track}/drums.wav", sr=22050, mono=True)
hop = 256; env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop); dt = hop/sr; p = 60/bpm*unit_beats
W = int(30/dt); out=[]
for s in range(0, len(env)-W, W):
    e = env[s:s+W]-env[s:s+W].mean(); ac = np.correlate(e,e,"full")[W-1:]; ac/=ac[0]+1e-9
    sc = {}
    for n in range(2,13):
        i = int(round(n*p/dt)); sc[n] = float(ac[max(i-2,0):i+3].max())
    best = sorted(sc, key=sc.get, reverse=True)[:3]
    out.append((int(s*dt), best, [round(sc[b],2) for b in best]))
print(track, "grid beat %.3f s" % p)
for t,b,v in out: print("  %3d:%02d  best repeats (grid beats) %s  %s" % (t//60, t%60, b, v))
