#!/bin/bash
cd ~/ears12b
while [ ! -f work/chainG.done ]; do sleep 10; done
PY=~/ears12b/venv/bin/python
T=/home/kruu-mikey/driftloom/tools/ears
A="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/Fire‐Toolz & Nonlocal Forecast - Triangular Reformat"
date +%s > chainH.start
cd work/Fire_Toolz_Nonlocal_Forecast_Triangular_Reformat
for d in 03_Classical* 26_She* 31_One* 32_Dam*; do mkdir -p ../../old_theory/$d; cp $d/theory.json ../../old_theory/$d/; rm $d/theory.json; done
cd ../..
$PY -P $T/album.py "$A" work --stages theory,card --workers 1
touch work/chainH.done
