import sys, os, json, re
sys.path.insert(0, '/home/kruu-mikey/driftloom/tools/ears')
import pick
src_pick, album_dir, work = sys.argv[1:4]
rep = json.load(open(src_pick))
os.makedirs(work, exist_ok=True)
tracks = pick.group_tracks(album_dir, os.path.join(work, 'joined'))
rep['paths'] = {k: tracks[k] for k in rep['paths']}
for r in rep['rows']:
    r['file'] = tracks.get(r['track'], r['file'])
json.dump(rep, open(os.path.join(work, 'pick.json'), 'w'), indent=1)
print(len(tracks), 'tracks', rep['picks'])
