#!/bin/bash
cd ~/ears12b
while [ ! -f work/chainB.done ]; do sleep 10; done
PY=~/ears12b/venv/bin/python
T=/home/kruu-mikey/driftloom/tools/ears
A="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/Fire‐Toolz & Nonlocal Forecast - Triangular Reformat"
date +%s > chainC.start
for st in split events,techniques theory,space,check; do
  $PY -P $T/album.py "$A" work --stages $st --workers 1 --only "16 - Screamography"
done
touch work/chainC.done
