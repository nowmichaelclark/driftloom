#!/bin/bash
cd ~/ears12b
while [ ! -f work/chainF.done ]; do sleep 10; done
PY=~/ears12b/venv/bin/python
T=/home/kruu-mikey/driftloom/tools/ears
date +%s > chainG.start
mkdir -p AC_KK_rhythms
for st in split events,techniques theory,space,check; do
  $PY -P $T/album.py AC_KK_rhythms work --stages $st --workers 1
done
touch work/chainG.done
