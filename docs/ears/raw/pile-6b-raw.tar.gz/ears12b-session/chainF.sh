#!/bin/bash
cd ~/ears12b
while [ ! -f work/chainE.done ]; do sleep 10; done
PY=~/ears12b/venv/bin/python
T=/home/kruu-mikey/driftloom/tools/ears
B="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/Jaga Jazzist (2020) - Pyramid"
date +%s > chainF.start
for i in 1 2 3; do
  for st in theory space check; do
    $PY -P $T/album.py "$B" work --stages $st --workers 1
  done
done
$PY -P $T/album.py "$B" work --stages card --workers 1
touch work/chainF.done
