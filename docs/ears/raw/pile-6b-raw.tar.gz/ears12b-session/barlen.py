# Ears 12b: bar length by hand. Drum-onset autocorrelation: where the pattern repeats, in beats and eighths of a given grid.
import sys, numpy as np, librosa, soundfile as sf
work, track, bpm = sys.argv[1], sys.argv[2], float(sys.argv[3])
y, sr = librosa.load(f"{work}/stems/{track}/drums.wav", sr=22050, mono=True)
hop = 256
env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop)
env = env - env.mean()
ac = np.correlate(env, env, "full")[len(env)-1:]; ac /= ac[0]
dt = hop / sr; p = 60 / bpm
lags = np.arange(len(ac)) * dt
sel = (lags > 0.6) & (lags < 24)
from scipy.signal import find_peaks
pk, pr = find_peaks(ac[sel], prominence=0.02)
L = lags[sel][pk]; V = ac[sel][pk]
order = np.argsort(-V)[:12]
print(track, "grid %.1f BPM, beat %.3f s" % (bpm, p))
for i in sorted(order, key=lambda i: L[i]):
    print("   lag %6.2f s = %5.2f beats = %5.2f eighths   ac %.2f" % (L[i], L[i]/p, 2*L[i]/p, V[i]))
