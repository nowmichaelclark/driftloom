#!/bin/bash
cd ~/ears12b
PY=~/ears12b/venv/bin/python
T=/home/kruu-mikey/driftloom/tools/ears
A="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/Fire‐Toolz & Nonlocal Forecast - Triangular Reformat"
B="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/Jaga Jazzist (2020) - Pyramid"
$PY -P $T/album.py "$A" work --stages theory,card --workers 1
touch work/chainA2.done
for st in split events,techniques theory,space,check card; do
  $PY -P $T/album.py "$B" work --stages $st --workers 1
done
touch work/chainB.done
