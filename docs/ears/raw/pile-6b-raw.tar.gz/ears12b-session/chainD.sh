#!/bin/bash
cd ~/ears12b
while [ ! -f work/chainC.done ]; do sleep 10; done
PY=~/ears12b/venv/bin/python
T=/home/kruu-mikey/driftloom/tools/ears
B="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 6/Jaga Jazzist (2020) - Pyramid"
date +%s > chainD.start
$PY -P $T/album.py "$B" work --stages theory,space,check --workers 1
$PY -P $T/album.py "$B" work --stages card --workers 1
touch work/chainD1.done
S=/tmp/claude-1000/-home-kruu-mikey-driftloom/505ca1c6-e7a6-44e8-8e81-7cb0401e3122/scratchpad
for a in light/Nonlocal_Forecast_Bubble_Universe light/Nonlocal_Forecast_Holographic_Universe_s light/Nonlocal_Forecast_Conscious_Agents light/1980_Synthesist; do
  /usr/bin/time -f "$a %e s" $PY -P $S/light.py $a
done
touch work/chainD2.done
mkdir -p lf
for f in work/Jaga*/joined/*.wav work/Fire*/joined/03_Classical*.wav; do
  b=$(basename "$f" .wav)
  $PY -P $T/longform.py "$f" lf/$b.json > lf/$b.txt 2>&1
done
touch work/chainD.done
