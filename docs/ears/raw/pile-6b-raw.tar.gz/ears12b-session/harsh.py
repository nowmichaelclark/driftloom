# Ears 12b: where a mix goes bright and noise-like (a flag for listening, not a detector; uncalibrated)
# 1-s windows at 22.05 kHz mono: share of the energy at 1-6 kHz, spectral flatness in 1-6 kHz, window loudness
# against the track's median. A "harsh window": 1-6 kHz share >= 0.30 and flatness >= 0.15 (noise-like, not tonal).
import sys, json, subprocess, numpy as np
from scipy.signal import stft
def load(p):
    raw = subprocess.run(["ffmpeg","-v","error","-i",p,"-ac","1","-ar","22050","-f","f32le","-"],capture_output=True).stdout
    return np.frombuffer(raw,np.float32).astype(np.float64)
def scan(p):
    y = load(p); sr = 22050
    f,t,Z = stft(y, sr, nperseg=2048, noverlap=1024); P = np.abs(Z)**2
    band = (f>=1000)&(f<=6000)
    tot = P.sum(0)+1e-12; share = P[band].sum(0)/tot
    Pb = P[band]+1e-12; flat = np.exp(np.log(Pb).mean(0))/Pb.mean(0)
    # to 1-s windows
    n = int(sr/1024); k = len(t)//n
    sh = share[:k*n].reshape(k,n).mean(1); fl = flat[:k*n].reshape(k,n).mean(1); lv = 10*np.log10(tot[:k*n].reshape(k,n).mean(1))
    harsh = (sh>=0.30)&(fl>=0.15)
    med = np.median(lv)
    out = {"seconds":k,"harsh_share":float(harsh.mean()),"harsh_s":int(harsh.sum()),
           "level_vs_median_db": float(np.median(lv[harsh]-med)) if harsh.any() else None,
           "median_share_1_6k": float(np.median(sh)), "median_flat": float(np.median(fl))}
    # runs of 3+ s
    runs=[];i=0
    while i<k:
        if harsh[i]:
            j=i
            while j<k and harsh[j]: j+=1
            if j-i>=3: runs.append((i,j-i))
            i=j
        else: i+=1
    out["runs_3s"]=[f"{a//60}:{a%60:02d} for {d} s" for a,d in runs[:8]]; out["n_runs_3s"]=len(runs)
    return out
if __name__=="__main__":
    d=json.load(open(sys.argv[1]+"/pick.json")); res={}
    for tr,p in sorted(d["paths"].items()):
        res[tr]=scan(p); r=res[tr]
        print("%-50s harsh %4.1f%% (%3d s), %d runs>=3s, level %s dB, 1-6k share %.2f flat %.2f"%(tr[:50],100*r["harsh_share"],r["harsh_s"],r["n_runs_3s"],None if r["level_vs_median_db"] is None else round(r["level_vs_median_db"],1),r["median_share_1_6k"],r["median_flat"]),flush=True)
    json.dump(res,open(sys.argv[2],"w"),indent=1)
