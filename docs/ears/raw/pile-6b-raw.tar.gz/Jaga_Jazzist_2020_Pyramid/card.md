## Jaga Jazzist (2020) - Pyramid (draft card from Ears 3 tools, 2026-11-08)

How it was made: EP or short record (4 usable tracks): every track. Deep pass on: - Tomita; - Spiral Era; - The Shrine; - Apex. Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- Tomita**: share of power drums 21%, bass 37%, other 33%, vocals 9%.
  - meter tool 137 BPM agrees with the drum-grid beat of 136.1 BPM.
- **- Spiral Era**: share of power drums 20%, bass 55%, other 20%, vocals 5%.
  - vocals stem holds 5.3%: bleed on an instrumental, not a voice.
  - meter tool 60 BPM does not match the drum-grid beat of 161.3 BPM by a simple ratio: listen.
- **- The Shrine**: share of power drums 35%, bass 39%, other 22%, vocals 4%.
  - vocals stem holds 3.9%: bleed on an instrumental, not a voice.
  - meter tool 120 BPM agrees with the drum-grid beat of 120.2 BPM.
- **- Apex**: share of power drums 24%, bass 60%, other 15%, vocals 0%.
  - vocals stem holds 0.2%: bleed on an instrumental, not a voice.
  - meter tool 62 BPM agrees with the drum-grid beat of 61.5 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 60 to 137 BPM (octave-uncertain); keys G locrian, G lydian, A# aeolian, F phrygian; mix width -12 to -9 dB; chord changes 10 to 36 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Tomita: other group `other-1` (331 notes, 47% of the track's note energy)
- In synth terms: around F#2, mixed or noisy partials, slow swell, falls 4 dB/s, centered.
- Hear it at: 2:46.9 (F#2, 0.8 s, +53 dB alone), 7:46.1 (C2, 0.25 s, +56 dB alone), 0:54.5 (C#2, 0.53 s, +54 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 92 (52 to 132) Hz; attack 325 (60 to 1242) ms; decay -4 (-18 to 1) dB/s
  - brightness at the start 542 (364 to 878) Hz; slope over the note -0.02 (-0.65 to 0.37) octaves
  - harmonic share 0.66 (0.19 to 0.93); partials off whole multiples 51 (19 to 122) cents
  - vibrato 2 (0 to 12) cents; detune beating 0.0 (0.0 to 0.3) Hz
  - level against the mix -5.0 (-7.9 to -0.6) dB; pan 0.04 (-0.06 to 0.13); left-right correlation 0.75 (0.46 to 0.88)
- Group quality: weak (silhouette 0.22, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. - Spiral Era: other group `other-1` (499 notes, 25% of the track's note energy)
- In synth terms: around E2, mixed or noisy partials, slow swell, falls 10 dB/s, centered.
- Hear it at: 4:22.0 (B2, 0.2 s, +29 dB alone), 1:29.8 (A2, 0.1 s, +24 dB alone), 4:37.0 (A2, 0.18 s, +14 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 83 (52 to 200) Hz; attack 167 (38 to 598) ms; decay -10 (-47 to -0) dB/s
  - brightness at the start 577 (352 to 914) Hz; slope over the note 0.00 (-0.19 to 0.42) octaves
  - harmonic share 0.70 (0.22 to 0.93); partials off whole multiples 50 (17 to 122) cents
  - vibrato 0 (0 to 12) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.4 (-8.6 to -3.8) dB; pan 0.01 (-0.08 to 0.12); left-right correlation 0.43 (0.14 to 0.62)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. - The Shrine: other group `other-1` (350 notes, 25% of the track's note energy)
- In synth terms: around F#2, mixed or noisy partials, slow swell, falls 9 dB/s, centered.
- Hear it at: 2:11.8 (G#2, 0.49 s, +43 dB alone), 2:10.9 (G#2, 0.41 s, +42 dB alone), 2:11.3 (C3, 0.48 s, +40 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 90 (46 to 120) Hz; attack 228 (56 to 742) ms; decay -9 (-39 to 0) dB/s
  - brightness at the start 486 (348 to 814) Hz; slope over the note 0.00 (-0.41 to 0.45) octaves
  - harmonic share 0.68 (0.18 to 0.96); partials off whole multiples 46 (13 to 98) cents
  - vibrato 0 (0 to 16) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.7 (-7.9 to -1.8) dB; pan -0.02 (-0.16 to 0.11); left-right correlation 0.74 (0.59 to 0.87)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. - Tomita: bass group `bass-1` (417 notes, 24% of the track's note energy)
- In synth terms: around E2, harmonic (string/reed/pad-like), soft attack, falls 5 dB/s, centered.
- Hear it at: 5:29.1 (G2, 0.41 s, +10 dB alone), 5:06.6 (C#2, 1.2 s, +6 dB alone), 5:14.1 (C#2, 0.79 s, +9 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 83 (69 to 103) Hz; attack 84 (22 to 457) ms; decay -5 (-25 to 3) dB/s
  - brightness at the start 93 (78 to 107) Hz; slope over the note -0.00 (-0.16 to 0.24) octaves
  - harmonic share 0.99 (0.43 to 1.00); partials off whole multiples 27 (2 to 295) cents
  - vibrato 0 (0 to 20) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-4.3 to -1.1) dB; pan 0.04 (0.01 to 0.05); left-right correlation 0.99 (0.99 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S5. - Spiral Era: bass group `bass-1` (198 notes, 24% of the track's note energy)
- In synth terms: around E2, harmonic (string/reed/pad-like), soft attack, falls 33 dB/s, centered.
- Hear it at: 7:26.8 (E2, 0.37 s, +23 dB alone), 1:05.9 (D2, 0.32 s, +22 dB alone), 7:57.6 (E2, 0.59 s, +12 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 81 (61 to 98) Hz; attack 65 (23 to 275) ms; decay -33 (-85 to -3) dB/s
  - brightness at the start 85 (74 to 102) Hz; slope over the note 0.00 (-0.10 to 0.22) octaves
  - harmonic share 1.00 (0.95 to 1.00); partials off whole multiples 19 (3 to 128) cents
  - vibrato 0 (0 to 4) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.0 (-3.2 to -0.9) dB; pan 0.02 (-0.01 to 0.04); left-right correlation 0.99 (0.98 to 0.99)
- Group quality: weak (silhouette 0.25, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. - The Shrine: bass group `bass-1` (254 notes, 18% of the track's note energy)
- In synth terms: around A#1, bell- or metal-like (partials off whole multiples), soft attack, falls 21 dB/s, centered.
- Hear it at: 3:56.5 (B1, 0.25 s, +16 dB alone), 3:24.5 (A1, 0.27 s, +15 dB alone), 5:39.3 (C2, 0.51 s, +12 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 57 (39 to 76) Hz; attack 102 (23 to 316) ms; decay -21 (-69 to -1) dB/s
  - brightness at the start 100 (86 to 118) Hz; slope over the note 0.00 (-0.23 to 0.22) octaves
  - harmonic share 0.56 (0.05 to 1.00); partials off whole multiples 86 (11 to 278) cents
  - vibrato 0 (0 to 9) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-3.8 to -1.2) dB; pan 0.06 (0.04 to 0.10); left-right correlation 0.99 (0.97 to 0.99)
- Group quality: weak (silhouette 0.18, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S7. - Apex: drums group `drums-1` (317 notes, 15% of the track's note energy)
- In synth terms: low thump, soft attack, falls 459 dB/s, gets brighter over the note, centered.
- Hear it at: 1:27.2 (E1, 0.23 s, +23 dB alone), 1:33.1 (C2, 0.12 s, +24 dB alone), 1:31.0 (E1, 0.35 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (34 to 68) Hz; attack 57 (18 to 60) ms; decay -459 (-916 to -228) dB/s
  - brightness at the start 87 (71 to 175) Hz; slope over the note 0.53 (-0.02 to 4.67) octaves
  - harmonic share 0.49 (0.09 to 0.93); partials off whole multiples 154 (77 to 346) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-4.9 to -0.7) dB; pan 0.04 (0.03 to 0.06); left-right correlation 0.98 (0.98 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. - Apex: bass group `bass-1` (93 notes, 13% of the track's note energy)
- In synth terms: around B1, harmonic (string/reed/pad-like), slow swell, falls 13 dB/s, centered.
- Hear it at: 3:27.6 (A#1, 0.55 s, +11 dB alone), 5:59.9 (B1, 1.39 s, +8 dB alone), 3:28.0 (A#1, 0.95 s, +7 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 62 (61 to 62) Hz; attack 263 (105 to 540) ms; decay -13 (-31 to -0) dB/s
  - brightness at the start 76 (69 to 84) Hz; slope over the note 0.04 (-0.08 to 0.45) octaves
  - harmonic share 0.99 (0.94 to 1.00); partials off whole multiples 22 (8 to 50) cents
  - vibrato 0 (0 to 28) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.2 (-3.6 to -1.3) dB; pan 0.01 (-0.00 to 0.02); left-right correlation 0.99 (0.98 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- Tomita sections:** 41 boundaries at 0:07.0, 0:22.0, 0:35.0, 0:49.0, 0:59.0, 1:18.0, 1:33.0, 1:46.0, 1:58.0, 2:14.0, 2:35.0, 2:55.0; section lengths median 15 s (range 7 to 56). Reliable for sections of 10 s or more.
- **- Tomita stem entries and exits:** drums plays 63% of the time (in: 2:54.5, 8:21.5, 12:28.5; out: 7:09.5, 12:24.0, 12:51.0); bass plays 67% of the time (in: 0:19.5, 3:52.0, 7:56.0, 9:33.5; out: 0:25.5, 7:41.0, 9:22.5, 13:25.0); other plays 99% of the time (in: 0:02.0; out: 13:40.5); vocals plays 37% of the time (in: 1:04.0, 1:26.0, 1:41.0, 1:51.0, 2:02.5; out: 0:14.0, 1:23.5, 1:34.0, 1:45.0, 1:54.0).
- **- Tomita floor drops (kick and bass out 2 s or more while the rest plays):** 0.73 a minute: 0:41.2 for 134.0 s, 7:16.0 for 3.5 s, 7:30.0 for 3.0 s, 7:38.8 for 2.8 s, 7:42.2 for 14.2 s, 12:48.0 for 2.0 s, 12:55.2 for 2.0 s, 12:58.8 for 2.0 s.
- **- Tomita brightness sweeps (0.7 octave or more):** mix down 2.9 oct 0:00.0 to 0:05.0; mix up 1.5 oct 0:08.0 to 0:14.5; mix up 1.1 oct 0:37.5 to 0:43.5; mix down 1.8 oct 1:38.5 to 1:43.5; mix up 1.5 oct 1:43.5 to 1:48.5; mix down 1.6 oct 1:48.5 to 1:54.0; mix down 1.3 oct 1:58.5 to 2:04.0; mix up 1.3 oct 2:04.5 to 2:13.5 (55 more in techniques.json).
- **- Tomita echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Tomita pumping locked to the kick:** under 1.5 dB; none found.
- **- Tomita tape wobble and speed:** other wobbles about 7 cents at 2.1 Hz; bass wobbles about 16 cents at 0.8 Hz.
- **- Tomita stereo movement:** drums pan range 0.44; other pan range 0.26; vocals pan range 0.27.
- **- Spiral Era sections:** 24 boundaries at 0:17.0, 0:32.0, 0:53.0, 1:25.0, 1:56.0, 2:13.0, 2:30.0, 3:01.0, 3:17.0, 3:41.0, 3:56.0, 4:13.0; section lengths median 17 s (range 4 to 39). Reliable for sections of 10 s or more.
- **- Spiral Era stem entries and exits:** drums plays 99% of the time (in: from the start; out: 8:05.0); bass plays 96% of the time (in: 0:15.5; out: 8:05.0); other plays 95% of the time (in: 0:15.5; out: 7:58.0); vocals plays 56% of the time (in: 0:51.5, 3:01.0, 4:24.5, 4:37.0, 4:46.5; out: 1:57.5, 4:18.5, 4:27.0, 4:40.0, 5:18.0).
- **- Spiral Era floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Spiral Era brightness sweeps (0.7 octave or more):** mix down 2.8 oct 0:51.5 to 0:58.0; mix up 2.2 oct 1:06.5 to 1:11.5; mix up 1.0 oct 1:16.5 to 1:23.0; mix down 2.0 oct 1:25.0 to 1:30.5; mix up 1.6 oct 1:38.0 to 1:45.5; mix down 2.0 oct 2:09.0 to 2:14.0; mix down 1.3 oct 3:08.5 to 3:14.0; mix up 1.3 oct 3:31.5 to 3:39.0 (42 more in techniques.json).
- **- Spiral Era echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Spiral Era pumping locked to the kick:** under 1.5 dB; none found.
- **- Spiral Era tape wobble and speed:** other wobbles about 16 cents at 1.1 Hz.
- **- Spiral Era stereo movement:** vocals pan range 0.31.
- **- The Shrine sections:** 21 boundaries at 0:02.0, 1:04.0, 1:19.0, 1:37.0, 1:56.0, 2:09.0, 2:41.0, 3:08.0, 3:21.0, 4:49.0, 5:13.0, 6:04.0; section lengths median 19 s (range 2 to 88). Reliable for sections of 10 s or more.
- **- The Shrine stem entries and exits:** drums plays 84% of the time (in: 1:03.0, 2:31.0; out: 2:11.0, 9:01.0); bass plays 82% of the time (in: 1:03.5, 1:32.5, 1:59.0, 2:05.5, 2:18.5; out: 1:30.0, 1:54.0, 2:03.0, 2:10.0, 7:42.0); other plays 99% of the time (in: from the start; out: 9:01.5); vocals plays 36% of the time (in: 0:05.0, 1:17.0, 3:05.0, 3:17.0, 5:09.5; out: 0:57.5, 1:40.5, 3:10.5, 3:24.5, 5:15.0).
- **- The Shrine floor drops (kick and bass out 2 s or more while the rest plays):** 0.24 a minute: 0:27.2 for 36.5 s, 2:09.2 for 11.8 s.
- **- The Shrine brightness sweeps (0.7 octave or more):** mix up 0.8 oct 0:27.5 to 0:32.5; mix up 0.8 oct 1:15.5 to 1:21.0; mix down 2.0 oct 2:03.0 to 2:09.0; mix up 1.7 oct 2:09.5 to 2:20.0; mix down 1.2 oct 2:36.0 to 2:44.5; mix up 1.2 oct 2:45.0 to 2:51.0; mix up 0.7 oct 2:54.0 to 2:59.0; mix down 1.8 oct 3:18.0 to 3:26.0 (59 more in techniques.json).
- **- The Shrine echo times:** drums: 678 ms (+7.8 dB, 2 later repeats).
- **- The Shrine pumping locked to the kick:** other dips 2.1 dB at the kick (peak 130 ms after, kick every 0.36 s); bass dips 2.6 dB at the kick (peak 135 ms after, kick every 0.36 s). The tool reads about 70% of the true depth, so this is a floor.
- **- The Shrine tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- The Shrine stereo movement:** other pan range 0.35; vocals pan range 0.64.
- **- The Shrine builds:** 2:17.0 to 2:49.0.
- **- Apex sections:** 19 boundaries at 0:02.0, 0:55.0, 1:20.0, 1:34.0, 1:47.0, 2:15.0, 2:29.0, 3:16.0, 3:32.0, 3:55.0, 4:41.0, 5:07.0; section lengths median 21 s (range 2 to 53). Reliable for sections of 10 s or more.
- **- Apex stem entries and exits:** drums plays 96% of the time (in: from the start; out: 7:49.5); bass plays 87% of the time (in: 4:40.0; out: 3:55.5, 7:49.5); other plays 98% of the time (in: from the start; out: 7:58.5); vocals plays 8% of the time (in: 1:29.5, 2:26.5, 3:49.5, 4:01.5, 6:04.0; out: 1:33.0, 2:32.5, 3:54.0, 4:04.0, 6:16.5).
- **- Apex floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Apex brightness sweeps (0.7 octave or more):** mix down 1.7 oct 0:00.0 to 0:05.0; mix down 1.6 oct 0:30.0 to 0:38.5; mix up 1.1 oct 0:38.5 to 0:45.0; mix up 1.4 oct 0:59.5 to 1:04.5; mix up 1.5 oct 1:09.5 to 1:14.5; mix down 2.1 oct 1:22.0 to 1:29.5; mix up 1.6 oct 1:31.5 to 1:37.0; mix down 2.2 oct 1:37.0 to 1:43.5 (60 more in techniques.json).
- **- Apex echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Apex pumping locked to the kick:** other dips 1.6 dB at the kick (peak 15 ms after, kick every 0.48 s); bass dips 3.6 dB at the kick (peak 200 ms after, kick every 0.48 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Apex tape wobble and speed:** other wobbles about 6 cents at 0.8 Hz; bass wobbles about 15 cents at 2.3 Hz.
- **- Apex stereo movement:** vocals pan range 0.46.
- **- Apex builds:** 0:00.0 to 0:36.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Tomita meter:** about 137 BPM (could be 68 or 274; the tool cannot tell the beat level), bar length unclear (best guess 3, score 0.12); swung: off-beat at 0.75 of the beat; no cross-rhythm claim.
- **- Tomita key and mode:** G locrian (low confidence: the key signature margin is 0.008, so read this as a guess); pitch-class weights C 0.10, C# 0.10, D# 0.09, A 0.09, D 0.09.
- **- Tomita chords:** 30 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.5 to 4.2 s); 74 distinct chords; most time on C#maj7 9%, Amin7 7%, D#maj7 6%, Amaj7 6%. The old counter in this same run said 12; Ears 1's 2-s counter said 10.  75% of the changes land on a beat (chance would be 68%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Tomita bass:** root-note movement / mixed; 0.93 notes a second; most time on G 0.20, A 0.19, C# 0.13, F 0.10; steps 19%, thirds 9%, fourths and fifths 23%, octaves 4%, repeats 41%.
- **- Tomita top line (from the 'other' stem; read by ear before trusting):** 1458 notes, range 14 semitones (10th to 90th percentile); steps 22%, thirds 15%, fourths and fifths 22%, leaps 18%, repeats 22%; median interval 3 semitones; 50% of moves go up; phrases of about 10 notes, arch 40%, rising 20%, falling 25%, flat or wavy 16%. Reliable only when the line sits clearly above its accompaniment.
- **- Tomita repetition:** 628 bars of 1.3 s; strongest repeat distances 1 bars (0.66), 5 bars (0.42), 11 bars (0.39); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Spiral Era meter:** about 60 BPM (could be 30 or 120; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.62 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Spiral Era key and mode:** G lydian (low confidence: the key signature margin is 0.000, so read this as a guess); pitch-class weights G 0.13, E 0.11, G# 0.10, B 0.09, F# 0.08.
- **- Spiral Era chords:** 25 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 1.6 s (10th to 90th percentile 0.7 to 5.9 s); 39 distinct chords; most time on G#maj7 21%, Gmaj7 11%, E5 7%, A7 6%. The old counter in this same run said 11; Ears 1's 2-s counter said 9.  66% of the changes land on a beat (chance would be 30%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Spiral Era bass:** root-note movement / mixed; 1.43 notes a second; most time on G# 0.26, G 0.17, B 0.15, A 0.14; steps 10%, thirds 2%, fourths and fifths 18%, octaves 4%, repeats 59%.
- **- Spiral Era top line (from the 'other' stem; read by ear before trusting):** 1074 notes, range 11 semitones (10th to 90th percentile); steps 17%, thirds 18%, fourths and fifths 28%, leaps 20%, repeats 17%; median interval 4 semitones; 49% of moves go up; phrases of about 12 notes, arch 50%, rising 17%, falling 19%, flat or wavy 14%. Reliable only when the line sits clearly above its accompaniment.
- **- Spiral Era repetition:** 244 bars of 2.0 s; strongest repeat distances 1 bars (0.49), 4 bars (0.37), 16 bars (0.32); 10% of bars near-duplicate an earlier bar.
- **- The Shrine meter:** about 120 BPM (could be 60 or 240; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.68 of the beat (triplet feel); no cross-rhythm claim.
- **- The Shrine key and mode:** A# aeolian (minor) (key signature margin 0.021); pitch-class weights F 0.14, G# 0.10, F# 0.10, A# 0.10, C# 0.09.
- **- The Shrine chords:** 36 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.2 s (10th to 90th percentile 0.5 to 3.0 s); 41 distinct chords; most time on A#7 17%, G#maj7 9%, F#maj7 6%, C#maj7 6%. The old counter in this same run said 9; Ears 1's 2-s counter said 6.  81% of the changes land on a beat (chance would be 60%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- The Shrine bass:** root-note movement / mixed; 1.15 notes a second; most time on A# 0.23, G# 0.21, F 0.17, C 0.09; steps 16%, thirds 17%, fourths and fifths 37%, octaves 10%, repeats 12%.
- **- The Shrine top line (from the 'other' stem; read by ear before trusting):** 1094 notes, range 17 semitones (10th to 90th percentile); steps 16%, thirds 16%, fourths and fifths 22%, leaps 33%, repeats 14%; median interval 5 semitones; 51% of moves go up; phrases of about 6 notes, arch 44%, rising 25%, falling 16%, flat or wavy 16%. Reliable only when the line sits clearly above its accompaniment.
- **- The Shrine repetition:** 273 bars of 2.0 s; strongest repeat distances 1 bars (0.59), 16 bars (0.26), 12 bars (0.24); 8% of bars near-duplicate an earlier bar.
- **- Apex meter:** about 62 BPM (could be 31 or 123; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.22); swung: off-beat at 0.61 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Apex key and mode:** F phrygian (low confidence: the key signature margin is 0.007, so read this as a guess); pitch-class weights F 0.19, F# 0.10, C 0.10, B 0.10, E 0.09.
- **- Apex chords:** 10 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 3.8 s (10th to 90th percentile 0.8 to 9.2 s); 25 distinct chords; most time on F5 27%, A#sus2 22%, Bsus2 16%, Fmaj7 13%. The old counter in this same run said 3; Ears 1's 2-s counter said 3.  22% of the changes land on a beat (chance would be 31%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Apex bass:** ostinato (a 2-note figure repeats); 1.28 notes a second; most time on B 0.43, F 0.39, A# 0.12, G# 0.05; steps 3%, thirds 0%, fourths and fifths 4%, octaves 3%, repeats 89%.
- **- Apex top line (from the 'other' stem; read by ear before trusting):** 1337 notes, range 13 semitones (10th to 90th percentile); steps 20%, thirds 7%, fourths and fifths 32%, leaps 25%, repeats 16%; median interval 5 semitones; 49% of moves go up; phrases of about 10 notes, arch 30%, rising 22%, falling 16%, flat or wavy 32%. Reliable only when the line sits clearly above its accompaniment.
- **- Apex repetition:** 125 bars of 3.9 s; strongest repeat distances 1 bars (0.70), 20 bars (-0.04); 9% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Tomita mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -14 (corr 0.93); low_120_500 -8 (corr 0.72); mid_500_2k -6 (corr 0.58); pres_2k_5k -8 (corr 0.70); air_gt5k -12 (corr 0.89); over time (2-s windows) 10th/50th/90th percentile -13/-9/-4 dB.
- **- Tomita by part:** drums: 19% of the power, width -15 dB, pan +0.12, mono loss 0.1 dB, widest in sub_lt120 (-14 dB); bass: 34% of the power, width -20 dB, pan +0.05, mono loss 0.0 dB, widest in sub_lt120 (-20 dB); other: 35% of the power, width -7 dB, pan +0.07, mono loss 0.8 dB, widest in low_120_500 (-7 dB); vocals: 11% of the power, width -4 dB, pan +0.10, mono loss 1.6 dB, widest in mid_500_2k (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Spiral Era mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.97); low_120_500 -5 (corr 0.52); mid_500_2k -5 (corr 0.53); pres_2k_5k -4 (corr 0.45); air_gt5k -8 (corr 0.76); over time (2-s windows) 10th/50th/90th percentile -14/-5/-3 dB.
- **- Spiral Era by part:** drums: 18% of the power, width -17 dB, pan +0.13, mono loss 0.1 dB, widest in sub_lt120 (-16 dB); bass: 50% of the power, width -20 dB, pan +0.04, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); other: 26% of the power, width -3 dB, pan +0.03, mono loss 1.7 dB, widest in low_120_500 (-3 dB); vocals: 6% of the power, width -5 dB, pan +0.00, mono loss 1.1 dB, widest in low_120_500 (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- The Shrine mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -17 (corr 0.96); low_120_500 -10 (corr 0.81); mid_500_2k -6 (corr 0.59); pres_2k_5k -5 (corr 0.54); air_gt5k -7 (corr 0.65); over time (2-s windows) 10th/50th/90th percentile -12/-8/-6 dB.
- **- The Shrine by part:** drums: 33% of the power, width -15 dB, pan +0.11, mono loss 0.1 dB, widest in low_120_500 (-13 dB); bass: 37% of the power, width -19 dB, pan +0.12, mono loss 0.1 dB, widest in sub_lt120 (-19 dB); other: 25% of the power, width -7 dB, pan -0.08, mono loss 0.9 dB, widest in mid_500_2k (-6 dB); vocals: 5% of the power, width -5 dB, pan -0.20, mono loss 1.1 dB, widest in mid_500_2k (-5 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Apex mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.97); low_120_500 -8 (corr 0.75); mid_500_2k -5 (corr 0.55); pres_2k_5k -5 (corr 0.55); air_gt5k -9 (corr 0.78); over time (2-s windows) 10th/50th/90th percentile -13/-8/-4 dB.
- **- Apex by part:** drums: 23% of the power, width -18 dB, pan +0.08, mono loss 0.1 dB, widest in low_120_500 (-19 dB); bass: 58% of the power, width -16 dB, pan +0.04, mono loss 0.1 dB, widest in sub_lt120 (-18 dB); other: 18% of the power, width -6 dB, pan +0.07, mono loss 1.1 dB, widest in pres_2k_5k (-5 dB); vocals: 0% of the power, width -4 dB, pan +0.11, mono loss 1.4 dB, widest in mid_500_2k (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Tomita: 137 BPM, 12 settled chords a minute, 2% of energy above 2 kHz, width -9 dB; - Spiral Era: 60 BPM, 13 settled chords a minute, 2% of energy above 2 kHz, width -9 dB; - The Shrine: 120 BPM, 14 settled chords a minute, 2% of energy above 2 kHz, width -11 dB; - Apex: 62 BPM, 6 settled chords a minute, 3% of energy above 2 kHz, width -12 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- - Spiral Era, bass group `bass-2` (256 notes): around G#1, harmonic (string/reed/pad-like), soft attack, falls 26 dB/s, centered; hear it at 7:39.4, 7:50.8. **[JUDGMENT]** why it waits.
- - The Shrine, bass group `bass-2` (246 notes): around F2, harmonic (string/reed/pad-like), soft attack, falls 28 dB/s, centered; hear it at 3:54.1, 5:42.1. **[JUDGMENT]** why it waits.
- - The Shrine, vocals group `vocals-1` (172 notes): around G#4, mixed or noisy partials, slow swell, falls 15 dB/s, centered; hear it at 0:15.3, 0:30.7. **[JUDGMENT]** why it waits.
- - Apex, bass group `bass-2` (141 notes): around F1, harmonic (string/reed/pad-like), soft attack, falls 23 dB/s, centered; hear it at 3:40.0, 3:39.1. **[JUDGMENT]** why it waits.
- - Apex, other group `other-1` (154 notes): around F3, mixed or noisy partials, slow swell, falls 5 dB/s, centered; hear it at 5:58.0, 5:57.7. **[JUDGMENT]** why it waits.
- - Apex, other group `other-2` (346 notes): around F2, mixed or noisy partials, soft attack, falls 27 dB/s, centered; hear it at 0:27.2, 1:17.6. **[JUDGMENT]** why it waits.
- - Spiral Era, vocals group `vocals-1` (371 notes): around C#4, harmonic (string/reed/pad-like), slow swell, falls 19 dB/s, centered; hear it at 0:55.2, 1:12.8. **[JUDGMENT]** why it waits.
- - The Shrine, drums group `drums-1` (180 notes): low thump, soft attack, falls 124 dB/s, gets brighter over the note, centered; hear it at 1:56.1, 8:31.8. **[JUDGMENT]** why it waits.
