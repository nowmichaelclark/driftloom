## Fire‐Toolz & Nonlocal Forecast - Triangular Reformat (draft card from Ears 3 tools, 2026-11-08)

How it was made: 32 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: - She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix); - Dam Ambience; - Classical Information (Machinegirl - Full Moon Future Mix); - One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit); - Screamography (Wonkavision Particles Re-imagination Edit); - Experience ☆ Slips ☆ Away (Toiret Status Remix). Typical track: - She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix). Least like the rest: - Dam Ambience, - Classical Information (Machinegirl - Full Moon Future Mix), - One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit).
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix)**: share of power drums 12%, bass 61%, other 24%, vocals 3%.
  - vocals stem holds 2.9%: bleed on an instrumental, not a voice.
  - meter tool 89 BPM is two thirds of the drum-grid beat of 132.5 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Dam Ambience**: share of power drums 29%, bass 0%, other 39%, vocals 31%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - meter tool 123 BPM is three quarters of the drum-grid beat of 156.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Classical Information (Machinegirl - Full Moon Future Mix)**: share of power drums 59%, bass 7%, other 31%, vocals 2%.
  - vocals stem holds 2.3%: bleed on an instrumental, not a voice.
  - meter tool 79 BPM is three quarters of the drum-grid beat of 105.4 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit)**: share of power drums 57%, bass 30%, other 12%, vocals 1%.
  - vocals stem holds 1.4%: bleed on an instrumental, not a voice.
  - meter tool 85 BPM agrees with the drum-grid beat of 84.7 BPM.
- **- Screamography (Wonkavision Particles Re-imagination Edit)**: share of power drums 12%, bass 62%, other 23%, vocals 3%.
  - vocals stem holds 2.7%: bleed on an instrumental, not a voice.
  - meter tool 127 BPM is two thirds of the drum-grid beat of 184.6 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix)**: share of power drums 16%, bass 51%, other 13%, vocals 21%.
  - meter tool 117 BPM agrees with the drum-grid beat of 117.4 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 79 to 127 BPM (octave-uncertain); keys D# mixolydian, F lydian, G# ionian, F phrygian, G locrian; mix width -11 to -2 dB; chord changes 6 to 58 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix): bass group `bass-1` (213 notes, 52% of the track's note energy)
- In synth terms: around C#1, harmonic (string/reed/pad-like), soft attack, falls 15 dB/s, centered.
- Hear it at: 2:07.4 (D#1, 1.52 s, +13 dB alone), 2:04.0 (D#1, 1.39 s, +8 dB alone), 2:06.0 (D1, 0.44 s, +9 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 34 (33 to 42) Hz; attack 58 (33 to 103) ms; decay -15 (-220 to -2) dB/s
  - brightness at the start 87 (76 to 106) Hz; slope over the note 0.01 (-0.23 to 0.77) octaves
  - harmonic share 0.99 (0.36 to 1.00); partials off whole multiples 53 (9 to 162) cents
  - vibrato 0 (0 to 17) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-6.2 to -1.4) dB; pan 0.00 (-0.00 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S2. - Dam Ambience: vocals group `vocals-1` (500 notes, 33% of the track's note energy)
- In synth terms: around A3, mixed or noisy partials, slow swell, falls 19 dB/s, centered.
- Hear it at: 7:08.9 (G3, 2.11 s, +8 dB alone), 2:19.9 (C3, 0.84 s, +10 dB alone), 7:15.0 (F#3, 1.25 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 224 (70 to 500) Hz; attack 219 (52 to 794) ms; decay -19 (-120 to -1) dB/s
  - brightness at the start 936 (439 to 4593) Hz; slope over the note 0.00 (-0.72 to 0.92) octaves
  - harmonic share 0.38 (0.08 to 0.91); partials off whole multiples 56 (13 to 122) cents
  - vibrato 0 (0 to 32) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -9.1 (-15.6 to -3.4) dB; pan 0.09 (-0.19 to 0.30); left-right correlation -0.01 (-0.24 to 0.62)
- Group quality: weak (silhouette 0.18, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

#### S3. - Screamography (Wonkavision Particles Re-imagination Edit): bass group `bass-1` (214 notes, 33% of the track's note energy)
- In synth terms: around G1, bell- or metal-like (partials off whole multiples), soft attack, falls 27 dB/s, centered.
- Hear it at: 2:40.1 (B1, 0.21 s, +13 dB alone), 1:00.1 (G1, 4.25 s, +5 dB alone), 2:44.9 (?, 1.28 s, +7 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 49 (32 to 67) Hz; attack 89 (15 to 361) ms; decay -27 (-228 to 2) dB/s
  - brightness at the start 99 (84 to 138) Hz; slope over the note 0.00 (-0.27 to 0.27) octaves
  - harmonic share 0.32 (0.05 to 0.96); partials off whole multiples 155 (33 to 302) cents
  - vibrato 0 (0 to 23) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-11.3 to -0.9) dB; pan -0.01 (-0.05 to 0.02); left-right correlation 0.98 (0.92 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S4. - One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit): drums group `drums-1` (205 notes, 33% of the track's note energy)
- In synth terms: low thump, soft attack, falls 87 dB/s, centered.
- Hear it at: 0:37.8 (B1, 0.21 s, +21 dB alone), 1:34.0 (B1, 0.21 s, +20 dB alone), 1:26.5 (G#1, 0.25 s, +19 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 60 (58 to 63) Hz; attack 115 (97 to 135) ms; decay -87 (-135 to -47) dB/s
  - brightness at the start 94 (67 to 174) Hz; slope over the note 0.00 (-0.02 to 6.30) octaves
  - harmonic share 0.92 (0.39 to 1.00); partials off whole multiples 75 (4 to 165) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-1.5 to -0.1) dB; pan 0.00 (-0.00 to 0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. - Dam Ambience: other group `other-1` (234 notes, 32% of the track's note energy)
- In synth terms: around C#4, mixed or noisy partials, slow swell, falls 5 dB/s, centered.
- Hear it at: 3:58.6 (A#3, 2.08 s, +5 dB alone), 3:54.1 (C#4, 2.65 s, +3 dB alone), 4:59.5 (F3, 0.41 s, +10 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 283 (129 to 1090) Hz; attack 292 (85 to 1100) ms; decay -5 (-100 to 2) dB/s
  - brightness at the start 1255 (836 to 1775) Hz; slope over the note 0.00 (-0.20 to 0.19) octaves
  - harmonic share 0.36 (0.07 to 0.91); partials off whole multiples 53 (15 to 126) cents
  - vibrato 0 (0 to 18) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.4 (-8.0 to -2.6) dB; pan 0.03 (-0.15 to 0.17); left-right correlation 0.46 (0.22 to 0.65)
- Group quality: weak (silhouette 0.24, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. - Experience ☆ Slips ☆ Away (Toiret Status Remix): vocals group `vocals-1` (359 notes, 31% of the track's note energy)
- In synth terms: around F#3, bell- or metal-like (partials off whole multiples), soft attack, falls 47 dB/s, centered.
- Hear it at: 1:48.9 (D#4, 0.15 s, +43 dB alone), 1:51.8 (B3, 0.19 s, +34 dB alone), 1:44.0 (C#3, 0.32 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 190 (87 to 466) Hz; attack 99 (46 to 377) ms; decay -47 (-212 to -7) dB/s
  - brightness at the start 1133 (687 to 2054) Hz; slope over the note 0.00 (-0.45 to 0.76) octaves
  - harmonic share 0.33 (0.07 to 0.79); partials off whole multiples 74 (17 to 136) cents
  - vibrato 0 (0 to 26) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.5 (-13.8 to -1.7) dB; pan -0.01 (-0.32 to 0.31); left-right correlation 0.74 (-0.12 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

#### S7. - Experience ☆ Slips ☆ Away (Toiret Status Remix): other group `other-1` (437 notes, 30% of the track's note energy)
- In synth terms: around C#3, mixed or noisy partials, soft attack, falls 66 dB/s, centered.
- Hear it at: 0:00.6 (F3, 1.49 s, +53 dB alone), 0:00.5 (F3, 0.55 s, +53 dB alone), 0:00.0 (G#1, 0.54 s, +55 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 139 (58 to 311) Hz; attack 83 (35 to 345) ms; decay -66 (-169 to -6) dB/s
  - brightness at the start 762 (482 to 1045) Hz; slope over the note 0.00 (-0.46 to 0.39) octaves
  - harmonic share 0.75 (0.27 to 0.96); partials off whole multiples 36 (12 to 108) cents
  - vibrato 0 (0 to 2) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.9 (-17.3 to -1.4) dB; pan -0.01 (-0.21 to 0.23); left-right correlation 0.51 (-0.23 to 0.95)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S8. - Classical Information (Machinegirl - Full Moon Future Mix): drums group `drums-1` (381 notes, 28% of the track's note energy)
- In synth terms: low thump, quick attack, falls 74 dB/s, centered.
- Hear it at: 2:39.8 (A1, 0.17 s, +25 dB alone), 2:44.9 (A1, 0.19 s, +24 dB alone), 2:44.7 (A#1, 0.12 s, +22 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (40 to 70) Hz; attack 35 (28 to 89) ms; decay -74 (-110 to -43) dB/s
  - brightness at the start 118 (70 to 356) Hz; slope over the note 0.13 (0.00 to 2.53) octaves
  - harmonic share 0.94 (0.17 to 0.98); partials off whole multiples 150 (87 to 303) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.8 (-2.3 to -0.2) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) sections:** 6 boundaries at 0:29.0, 0:40.0, 1:01.0, 1:20.0, 1:50.0, 2:06.0; section lengths median 19 s (range 3 to 30). Reliable for sections of 10 s or more.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) stem entries and exits:** drums plays 96% of the time (in: 1:07.5; out: 1:02.5); bass plays 95% of the time (in: 1:07.5; out: 1:02.0); other plays 100% of the time (in: from the start; out: never); vocals plays 39% of the time (in: 0:38.5, 1:19.0, 1:56.5; out: 1:00.5, 1:44.0, 1:59.5).
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) floor drops (kick and bass out 2 s or more while the rest plays):** 0.52 a minute: 1:01.0 for 7.0 s.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) brightness sweeps (0.7 octave or more):** mix up 2.4 oct 0:00.0 to 0:22.5; mix up 0.8 oct 0:47.5 to 0:53.0; mix down 1.5 oct 1:41.5 to 1:46.5; mix up 1.6 oct 1:46.5 to 1:52.5; mix down 4.1 oct 1:52.5 to 2:08.0; other up 0.7 oct 0:01.0 to 0:12.0; other up 0.9 oct 0:12.5 to 0:20.0; other down 1.2 oct 1:28.0 to 1:38.0 (6 more in techniques.json).
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) pumping locked to the kick:** bass dips 6.3 dB at the kick (peak 0 ms after, kick every 0.42 s). The tool reads about 70% of the true depth, so this is a floor.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- Dam Ambience sections:** 17 boundaries at 0:02.0, 0:14.0, 0:51.0, 2:09.0, 2:29.0, 2:44.0, 3:31.0, 3:43.0, 4:08.0, 4:22.0, 4:38.0, 5:28.0; section lengths median 20 s (range 2 to 78). Reliable for sections of 10 s or more.
- **- Dam Ambience stem entries and exits:** drums plays 94% of the time (in: from the start; out: 7:26.0); bass plays 0% of the time (in: from the start; out: never); other plays 99% of the time (in: from the start; out: 7:52.5); vocals plays 92% of the time (in: 4:28.5; out: 4:21.0, 7:26.5).
- **- Dam Ambience floor drops (kick and bass out 2 s or more while the rest plays):** 0.98 a minute: 3:19.8 for 2.5 s, 3:27.5 for 2.2 s, 3:31.8 for 2.2 s, 3:43.2 for 2.5 s, 5:05.2 for 2.0 s, 5:17.8 for 2.0 s, 7:25.0 for 6.2 s.
- **- Dam Ambience brightness sweeps (0.7 octave or more):** mix up 2.4 oct 0:00.0 to 0:05.5; mix down 1.9 oct 0:07.5 to 0:17.0; mix down 0.8 oct 0:35.0 to 0:42.5; mix down 1.6 oct 0:47.0 to 0:54.0; mix up 1.5 oct 1:12.0 to 1:19.5; mix down 0.9 oct 1:19.5 to 1:24.5; mix down 1.1 oct 1:38.5 to 1:44.5; mix up 1.5 oct 1:57.5 to 2:05.0 (56 more in techniques.json).
- **- Dam Ambience echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Dam Ambience pumping locked to the kick:** bass dips 4.6 dB at the kick (peak 155 ms after, kick every 0.36 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Dam Ambience tape wobble and speed:** other wobbles about 17 cents at 0.4 Hz; other speed moves up to 6 cents in 4 s.
- **- Dam Ambience stereo movement:** drums pan range 0.89; other pan range 0.50, cycling every 10 s; vocals pan range 0.56.
- **- Classical Information (Machinegirl - Full Moon Future Mix) sections:** 18 boundaries at 0:03.0, 0:40.0, 0:56.0, 1:20.0, 2:02.0, 2:13.0, 2:26.0, 2:48.0, 2:59.0, 4:17.0, 5:03.0, 5:39.0; section lengths median 24 s (range 3 to 78). Reliable for sections of 10 s or more.
- **- Classical Information (Machinegirl - Full Moon Future Mix) stem entries and exits:** drums plays 79% of the time (in: 0:54.0, 5:25.5, 8:11.5; out: 4:53.5, 8:02.0, 8:26.0); bass plays 37% of the time (in: 0:38.5, 2:25.5, 2:35.0, 5:49.5, 5:55.5; out: 0:41.0, 2:28.0, 4:10.5, 5:52.5, 5:58.5); other plays 96% of the time (in: 8:17.0; out: 8:14.5, 8:24.0); vocals plays 47% of the time (in: 0:05.5, 0:53.0, 1:17.5, 1:26.5, 2:24.0; out: 0:41.0, 0:56.0, 1:22.5, 2:10.5, 2:26.5).
- **- Classical Information (Machinegirl - Full Moon Future Mix) floor drops (kick and bass out 2 s or more while the rest plays):** 2.44 a minute: 0:25.8 for 13.5 s, 0:39.8 for 3.5 s, 0:43.8 for 17.8 s, 1:55.2 for 4.8 s, 2:22.2 for 2.5 s, 4:32.5 for 2.2 s, 4:35.5 for 5.2 s, 4:43.5 for 43.0 s.
- **- Classical Information (Machinegirl - Full Moon Future Mix) brightness sweeps (0.7 octave or more):** mix down 1.1 oct 0:36.5 to 0:43.5; mix up 2.5 oct 0:50.0 to 1:09.5; mix down 1.1 oct 1:50.0 to 1:56.5; mix down 1.2 oct 2:00.5 to 2:09.0; mix up 1.0 oct 2:09.0 to 2:17.0; mix down 1.5 oct 3:20.0 to 3:25.5; mix down 1.1 oct 3:40.0 to 3:46.0; mix down 2.0 oct 4:00.0 to 4:05.5 (38 more in techniques.json).
- **- Classical Information (Machinegirl - Full Moon Future Mix) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Classical Information (Machinegirl - Full Moon Future Mix) pumping locked to the kick:** other dips 2.0 dB at the kick (peak 25 ms after, kick every 0.37 s); bass dips 1.7 dB at the kick (peak 155 ms after, kick every 0.37 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Classical Information (Machinegirl - Full Moon Future Mix) tape wobble and speed:** bass wobbles about 5 cents at 4.3 Hz.
- **- Classical Information (Machinegirl - Full Moon Future Mix) stereo movement:** other pan range 0.60, cycling every 3 s; vocals pan range 0.30.
- **- Classical Information (Machinegirl - Full Moon Future Mix) builds:** 5:04.0 to 5:27.0; 5:32.0 to 5:54.0.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) sections:** 8 boundaries at 0:09.0, 0:46.0, 1:31.0, 1:45.0, 2:01.0, 2:11.0, 2:33.0, 3:06.0; section lengths median 16 s (range 2 to 45). Reliable for sections of 10 s or more.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) stem entries and exits:** drums plays 52% of the time (in: 0:07.0; out: 1:45.0); bass plays 76% of the time (in: 0:07.5, 1:59.5, 2:32.0; out: 1:45.5, 2:11.0, 3:06.0); other plays 96% of the time (in: 0:07.0; out: never); vocals plays 60% of the time (in: 1:43.5, 2:55.0; out: 1:39.5, 1:53.5, 2:59.0).
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) floor drops (kick and bass out 2 s or more while the rest plays):** 0.71 a minute: 1:47.0 for 13.0 s, 2:10.2 for 22.5 s.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) brightness sweeps (0.7 octave or more):** mix down 3.2 oct 0:04.0 to 0:11.0; mix up 1.1 oct 1:42.5 to 1:47.5; mix down 2.0 oct 1:56.0 to 2:03.5; mix up 2.2 oct 2:03.5 to 2:13.5; mix down 1.0 oct 2:20.0 to 2:25.0; mix down 1.5 oct 2:29.5 to 2:35.0; mix up 1.7 oct 2:50.0 to 2:56.5; mix up 1.1 oct 3:02.5 to 3:07.5 (13 more in techniques.json).
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) pumping locked to the kick:** other dips 3.5 dB at the kick (peak 20 ms after, kick every 0.43 s); bass dips 5.4 dB at the kick (peak 414 ms after, kick every 0.43 s). The tool reads about 70% of the true depth, so this is a floor.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) stereo movement:** other pan range 0.72; vocals pan range 0.28.
- **- Screamography (Wonkavision Particles Re-imagination Edit) sections:** 10 boundaries at 0:10.0, 0:42.0, 0:59.0, 1:15.0, 1:26.0, 1:37.0, 1:53.0, 2:39.0, 2:53.0, 3:08.0; section lengths median 16 s (range 10 to 46). Reliable for sections of 10 s or more.
- **- Screamography (Wonkavision Particles Re-imagination Edit) stem entries and exits:** drums plays 92% of the time (in: 0:09.0, 0:20.0, 0:28.0; out: 0:16.5, 0:25.0); bass plays 90% of the time (in: 0:07.5, 0:20.5, 0:26.0, 0:58.5; out: 0:03.0, 0:15.5, 0:23.0, 0:55.5, 3:19.5); other plays 98% of the time (in: 3:17.0; out: 3:14.5); vocals plays 60% of the time (in: 0:34.5, 0:47.0, 1:52.5, 2:20.5, 2:52.5; out: 0:44.5, 1:46.5, 2:12.0, 2:44.0, 3:02.5).
- **- Screamography (Wonkavision Particles Re-imagination Edit) floor drops (kick and bass out 2 s or more while the rest plays):** 1.32 a minute: 0:15.2 for 6.2 s, 0:23.8 for 3.0 s, 0:37.8 for 2.5 s, 0:56.2 for 2.2 s.
- **- Screamography (Wonkavision Particles Re-imagination Edit) brightness sweeps (0.7 octave or more):** mix up 5.5 oct 0:00.0 to 0:08.5; mix down 2.0 oct 0:08.5 to 0:13.5; mix up 0.7 oct 0:14.0 to 0:19.0; mix up 1.5 oct 0:42.0 to 0:47.5; mix down 1.8 oct 0:50.0 to 0:55.0; mix down 1.5 oct 1:20.5 to 1:25.5; mix up 2.4 oct 1:25.5 to 1:31.5; mix down 2.4 oct 1:32.0 to 1:45.5 (31 more in techniques.json).
- **- Screamography (Wonkavision Particles Re-imagination Edit) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Screamography (Wonkavision Particles Re-imagination Edit) pumping locked to the kick:** under 1.5 dB; none found.
- **- Screamography (Wonkavision Particles Re-imagination Edit) tape wobble and speed:** other speed moves up to 7 cents in 4 s; bass wobbles about 14 cents at 1.0 Hz.
- **- Screamography (Wonkavision Particles Re-imagination Edit) stereo movement:** drums pan range 0.41; other pan range 0.36; vocals pan range 0.40.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) sections:** 10 boundaries at 0:02.0, 0:20.0, 0:53.0, 1:15.0, 1:26.0, 1:39.0, 1:58.0, 2:45.0, 3:05.0, 3:27.0; section lengths median 19 s (range 2 to 47). Reliable for sections of 10 s or more.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) stem entries and exits:** drums plays 81% of the time (in: 0:06.5, 0:32.0, 1:24.0, 1:57.5; out: 0:23.5, 1:16.0, 1:44.0, 3:26.0); bass plays 36% of the time (in: 1:29.5, 1:59.5, 3:05.0; out: 1:38.0, 2:44.0, 3:27.0); other plays 90% of the time (in: from the start; out: 3:08.0); vocals plays 88% of the time (in: 0:02.0, 0:42.5; out: 0:20.0).
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) floor drops:** low end too sparse to say (on in under 75% of the track).
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) brightness sweeps (0.7 octave or more):** mix up 2.5 oct 0:05.5 to 0:14.0; mix down 1.9 oct 0:14.5 to 0:23.5; mix up 1.1 oct 1:15.0 to 1:21.0; mix down 1.2 oct 1:35.5 to 1:40.5; mix down 1.4 oct 1:55.5 to 2:02.0; mix up 2.4 oct 2:31.5 to 2:39.0; mix up 2.2 oct 2:40.5 to 2:48.0; mix down 2.3 oct 3:02.5 to 3:08.0 (15 more in techniques.json).
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) pumping locked to the kick:** bass dips 5.3 dB at the kick (peak 474 ms after, kick every 0.49 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) tape wobble and speed:** other wobbles about 12 cents at 5.8 Hz; other speed moves up to 25 cents in 4 s; bass wobbles about 10 cents at 5.2 Hz.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) stereo movement:** drums pan range 0.30; other pan range 0.36; vocals pan range 0.50.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) builds:** 0:14.0 to 0:35.0; 2:55.0 to 3:15.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) meter:** about 89 BPM (could be 45 or 179; the tool cannot tell the beat level), 3 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) key and mode:** D# mixolydian (low confidence: the key signature margin is 0.005, so read this as a guess); pitch-class weights A# 0.12, C 0.12, F 0.10, C# 0.10, D# 0.09.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) chords:** 13 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 2.3 s (10th to 90th percentile 1.8 to 5.7 s); 5 distinct chords; most time on C#maj7 38%, A#maj7 25%, Fmaj7 18%, D#maj7 18%. The old counter in this same run said 7; Ears 1's 2-s counter said 4.  55% of the changes land on a beat (chance would be 45%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) bass:** root-note movement / mixed; 0.94 notes a second; most time on D# 0.54, C# 0.34, F 0.08, E 0.01; steps 17%, thirds 2%, fourths and fifths 0%, octaves 19%, repeats 49%.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) top line (from the 'other' stem; read by ear before trusting):** 332 notes, range 24 semitones (10th to 90th percentile); steps 14%, thirds 9%, fourths and fifths 8%, leaps 37%, repeats 31%; median interval 4 semitones; 48% of moves go up; phrases of about 8 notes, arch 26%, rising 9%, falling 57%, flat or wavy 9%. Reliable only when the line sits clearly above its accompaniment.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) repetition:** 63 bars of 2.0 s; strongest repeat distances 1 bars (0.45), 7 bars (0.20), 18 bars (0.07); 6% of bars near-duplicate an earlier bar.
- **- Dam Ambience meter:** about 123 BPM (could be 61 or 246; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.04); swung: off-beat at 0.77 of the beat; no cross-rhythm claim; many unrelated periodicities found (5:2), which means irregular timing, not a cross-rhythm claim.
- **- Dam Ambience key and mode:** F lydian (key signature margin 0.039); pitch-class weights C 0.12, F 0.12, B 0.10, A 0.09, G 0.09.
- **- Dam Ambience chords:** 6 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 6.7 s (10th to 90th percentile 2.1 to 21.6 s); 25 distinct chords; most time on F5 20%, Dmaj7 18%, Cmaj7 13%, Dmin7 6%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  71% of the changes land on a beat (chance would be 61%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Dam Ambience top line (from the 'other' stem; read by ear before trusting):** 1094 notes, range 31 semitones (10th to 90th percentile); steps 18%, thirds 5%, fourths and fifths 12%, leaps 32%, repeats 33%; median interval 2 semitones; 50% of moves go up; phrases of about 13 notes, arch 19%, rising 30%, falling 24%, flat or wavy 27%. Reliable only when the line sits clearly above its accompaniment.
- **- Dam Ambience repetition:** 486 bars of 1.0 s; strongest repeat distances 1 bars (0.87); 9% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Classical Information (Machinegirl - Full Moon Future Mix) meter:** about 79 BPM (could be 40 or 159; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.77 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- Classical Information (Machinegirl - Full Moon Future Mix) key and mode:** G# ionian (major) (key signature margin 0.023); pitch-class weights F 0.13, A# 0.11, G 0.11, D# 0.10, C 0.10.
- **- Classical Information (Machinegirl - Full Moon Future Mix) chords:** 52 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 0.8 s (10th to 90th percentile 0.6 to 1.7 s); 33 distinct chords; most time on G#maj7 30%, F#maj7 13%, Cmin7 12%, A#sus2 12%. The old counter in this same run said 9; Ears 1's 2-s counter said 5.  17% of the changes land on a beat (chance would be 40%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Classical Information (Machinegirl - Full Moon Future Mix) bass:** root-note movement / mixed; 0.36 notes a second; most time on G# 0.63, A# 0.20, B 0.07, G 0.04; steps 26%, thirds 2%, fourths and fifths 3%, octaves 7%, repeats 54%.
- **- Classical Information (Machinegirl - Full Moon Future Mix) top line (from the 'other' stem; read by ear before trusting):** 1463 notes, range 19 semitones (10th to 90th percentile); steps 12%, thirds 16%, fourths and fifths 35%, leaps 30%, repeats 8%; median interval 5 semitones; 50% of moves go up; phrases of about 9 notes, arch 53%, rising 10%, falling 17%, flat or wavy 20%. Reliable only when the line sits clearly above its accompaniment.
- **- Classical Information (Machinegirl - Full Moon Future Mix) repetition:** 171 bars of 3.0 s; strongest repeat distances 2 bars (0.70), 4 bars (0.55), 8 bars (0.33); 16% of bars near-duplicate an earlier bar.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) meter:** about 85 BPM (could be 43 or 171; the tool cannot tell the beat level), bar length unclear (best guess 6, score 0.13); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) key and mode:** F phrygian (key signature margin 0.020); pitch-class weights F 0.13, F# 0.12, D 0.11, C# 0.11, C 0.08.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) chords:** 58 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 0.8 s (10th to 90th percentile 0.5 to 1.9 s); 43 distinct chords; most time on F#maj7 13%, F#5 8%, F5 7%, Fmin7 7%. The old counter in this same run said 22; Ears 1's 2-s counter said 14.  48% of the changes land on a beat (chance would be 43%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) bass:** root-note movement / mixed; 0.89 notes a second; most time on F 0.36, F# 0.13, D 0.12, B 0.09; steps 34%, thirds 6%, fourths and fifths 30%, octaves 5%, repeats 20%.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) top line (from the 'other' stem; read by ear before trusting):** 450 notes, range 11 semitones (10th to 90th percentile); steps 14%, thirds 27%, fourths and fifths 28%, leaps 16%, repeats 14%; median interval 4 semitones; 53% of moves go up; phrases of about 6 notes, arch 29%, rising 39%, falling 26%, flat or wavy 6%. Reliable only when the line sits clearly above its accompaniment.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) repetition:** 44 bars of 4.2 s; strongest repeat distances 2 bars (0.50), 9 bars (0.20); 2% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Screamography (Wonkavision Particles Re-imagination Edit) meter:** about 127 BPM (could be 63 or 254; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.10); swung: off-beat at 0.65 of the beat (triplet feel); no cross-rhythm claim.
- **- Screamography (Wonkavision Particles Re-imagination Edit) key and mode:** G locrian (low confidence: the key signature margin is 0.004, so read this as a guess); pitch-class weights G 0.14, C 0.10, F 0.10, C# 0.09, D 0.09.
- **- Screamography (Wonkavision Particles Re-imagination Edit) chords:** 32 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.7 to 3.7 s); 46 distinct chords; most time on Fsus2 11%, G#maj7 8%, C#dim 7%, Fmaj7 7%. The old counter in this same run said 9; Ears 1's 2-s counter said 7.  64% of the changes land on a beat (chance would be 63%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Screamography (Wonkavision Particles Re-imagination Edit) bass:** root-note movement / mixed; 0.49 notes a second; most time on G 0.31, C 0.16, F 0.14, C# 0.10; steps 21%, thirds 4%, fourths and fifths 8%, octaves 17%, repeats 35%.
- **- Screamography (Wonkavision Particles Re-imagination Edit) top line (from the 'other' stem; read by ear before trusting):** 353 notes, range 28 semitones (10th to 90th percentile); steps 15%, thirds 14%, fourths and fifths 13%, leaps 41%, repeats 16%; median interval 5 semitones; 50% of moves go up; phrases of about 8 notes, arch 37%, rising 26%, falling 26%, flat or wavy 11%. Reliable only when the line sits clearly above its accompaniment.
- **- Screamography (Wonkavision Particles Re-imagination Edit) repetition:** 215 bars of 0.9 s; strongest repeat distances 1 bars (0.59), 11 bars (0.31), 23 bars (0.19); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) meter:** about 117 BPM (could be 59 or 235; the tool cannot tell the beat level), bar length unclear (best guess 12, score 0.15); swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) key and mode:** D# mixolydian (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights D# 0.17, F 0.11, C# 0.09, A# 0.09, E 0.09.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) chords:** 29 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.7 to 3.4 s); 24 distinct chords; most time on D#min7 16%, G#sus2 12%, D#maj7 12%, C#sus2 12%. The old counter in this same run said 8; Ears 1's 2-s counter said 6.  63% of the changes land on a beat (chance would be 59%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) bass:** root-note movement / mixed; 0.49 notes a second; most time on D# 0.33, C 0.25, F 0.24, A# 0.16; steps 13%, thirds 2%, fourths and fifths 12%, octaves 20%, repeats 44%.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) top line (from the 'other' stem; read by ear before trusting):** 451 notes, range 12 semitones (10th to 90th percentile); steps 34%, thirds 7%, fourths and fifths 18%, leaps 22%, repeats 20%; median interval 2 semitones; 50% of moves go up; phrases of about 11 notes, arch 53%, rising 29%, falling 12%, flat or wavy 6%. Reliable only when the line sits clearly above its accompaniment.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) repetition:** 34 bars of 6.1 s; strongest repeat distances 1 bars (0.69), 10 bars (0.08); 12% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -31 (corr 1.00); low_120_500 -4 (corr 0.47); mid_500_2k -2 (corr 0.27); pres_2k_5k -4 (corr 0.39); air_gt5k -3 (corr 0.32); over time (2-s windows) 10th/50th/90th percentile -5/-3/-2 dB.
- **- She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix) by part:** drums: 11% of the power, width -14 dB, pan +0.02, mono loss 0.2 dB, widest in sub_lt120 (-29 dB); bass: 53% of the power, width -38 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-44 dB); other: 32% of the power, width -3 dB, pan +0.11, mono loss 1.8 dB, widest in mid_500_2k (-2 dB); vocals: 4% of the power, width -2 dB, pan +0.19, mono loss 2.0 dB, widest in mid_500_2k (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Dam Ambience mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -3 (corr 0.37); low_120_500 -3 (corr 0.29); mid_500_2k -3 (corr 0.34); pres_2k_5k -1 (corr 0.15); air_gt5k 1 (corr -0.13); over time (2-s windows) 10th/50th/90th percentile -4/-2/-1 dB.
- **- Dam Ambience by part:** drums: 31% of the power, width -1 dB, pan +0.01, mono loss 2.4 dB, widest in air_gt5k (1 dB); bass: 0% of the power, width -6 dB, pan +0.02, mono loss 1.0 dB, widest in pres_2k_5k (-4 dB); other: 36% of the power, width -4 dB, pan +0.06, mono loss 1.5 dB, widest in low_120_500 (-3 dB); vocals: 33% of the power, width -2 dB, pan +0.09, mono loss 2.2 dB, widest in air_gt5k (3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Classical Information (Machinegirl - Full Moon Future Mix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -19 (corr 0.97); low_120_500 -6 (corr 0.57); mid_500_2k -4 (corr 0.44); pres_2k_5k -5 (corr 0.53); air_gt5k -12 (corr 0.88); over time (2-s windows) 10th/50th/90th percentile -10/-4/-2 dB.
- **- Classical Information (Machinegirl - Full Moon Future Mix) by part:** drums: 52% of the power, width -20 dB, pan +0.01, mono loss 0.0 dB, widest in low_120_500 (-16 dB); bass: 6% of the power, width -19 dB, pan +0.03, mono loss 0.1 dB, widest in sub_lt120 (-20 dB); other: 39% of the power, width -4 dB, pan -0.11, mono loss 1.6 dB, widest in low_120_500 (-3 dB); vocals: 3% of the power, width -6 dB, pan +0.01, mono loss 1.0 dB, widest in mid_500_2k (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -33 (corr 1.00); low_120_500 -7 (corr 0.69); mid_500_2k -3 (corr 0.35); pres_2k_5k -5 (corr 0.52); air_gt5k -11 (corr 0.87); over time (2-s windows) 10th/50th/90th percentile -8/-6/-0 dB.
- **- One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit) by part:** drums: 53% of the power, width -27 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-43 dB); bass: 28% of the power, width -22 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-17 dB); other: 17% of the power, width -3 dB, pan -0.24, mono loss 1.9 dB, widest in mid_500_2k (-2 dB); vocals: 2% of the power, width -6 dB, pan +0.02, mono loss 0.9 dB, widest in mid_500_2k (-6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Screamography (Wonkavision Particles Re-imagination Edit) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -15 (corr 0.94); low_120_500 -4 (corr 0.45); mid_500_2k -4 (corr 0.45); pres_2k_5k -4 (corr 0.38); air_gt5k -4 (corr 0.39); over time (2-s windows) 10th/50th/90th percentile -8/-4/-1 dB.
- **- Screamography (Wonkavision Particles Re-imagination Edit) by part:** drums: 13% of the power, width -6 dB, pan -0.01, mono loss 0.9 dB, widest in mid_500_2k (1 dB); bass: 56% of the power, width -17 dB, pan -0.04, mono loss 0.1 dB, widest in sub_lt120 (-19 dB); other: 27% of the power, width -5 dB, pan +0.01, mono loss 1.3 dB, widest in low_120_500 (-4 dB); vocals: 3% of the power, width -6 dB, pan +0.08, mono loss 0.9 dB, widest in mid_500_2k (-6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -28 (corr 1.00); low_120_500 -6 (corr 0.59); mid_500_2k -4 (corr 0.45); pres_2k_5k -3 (corr 0.33); air_gt5k -3 (corr 0.32); over time (2-s windows) 10th/50th/90th percentile -10/-5/-1 dB.
- **- Experience ☆ Slips ☆ Away (Toiret Status Remix) by part:** drums: 15% of the power, width -14 dB, pan -0.01, mono loss 0.2 dB, widest in mid_500_2k (-8 dB); bass: 44% of the power, width -42 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-45 dB); other: 14% of the power, width -5 dB, pan -0.05, mono loss 1.2 dB, widest in mid_500_2k (-4 dB); vocals: 27% of the power, width -3 dB, pan -0.01, mono loss 1.8 dB, widest in low_120_500 (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix): 89 BPM, 13 settled chords a minute, 5% of energy above 2 kHz, width -8 dB; - Dam Ambience: 123 BPM, 6 settled chords a minute, 21% of energy above 2 kHz, width -2 dB; - Classical Information (Machinegirl - Full Moon Future Mix): 79 BPM, 10 settled chords a minute, 8% of energy above 2 kHz, width -8 dB; - One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit): 85 BPM, 9 settled chords a minute, 2% of energy above 2 kHz, width -11 dB; - Screamography (Wonkavision Particles Re-imagination Edit): 127 BPM, 14 settled chords a minute, 6% of energy above 2 kHz, width -9 dB; - Experience ☆ Slips ☆ Away (Toiret Status Remix): 117 BPM, 14 settled chords a minute, 7% of energy above 2 kHz, width -8 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- - Classical Information (Machinegirl - Full Moon Future Mix), other group `other-1` (348 notes): around C2, mixed or noisy partials, soft attack, falls 18 dB/s, centered; hear it at 5:22.9, 5:16.8. **[JUDGMENT]** why it waits.
- - Screamography (Wonkavision Particles Re-imagination Edit), other group `other-1` (373 notes): around C2, bell- or metal-like (partials off whole multiples), soft attack, falls 17 dB/s, centered; hear it at 0:25.4, 0:26.0. **[JUDGMENT]** why it waits.
- - Experience ☆ Slips ☆ Away (Toiret Status Remix), bass group `bass-1` (62 notes): around G#1, harmonic (string/reed/pad-like), odd harmonics stronger (square/clarinet-like), slow swell, falls 12 dB/s, centered; hear it at 3:15.8, 3:13.0. **[JUDGMENT]** why it waits.
- - She Was Me, My Name Was Surrounded (Equip Edge Of Sleep Remix), other group `other-1` (280 notes): around D2, mixed or noisy partials, soft attack, falls 9 dB/s, centered; hear it at 1:04.2, 1:06.1. **[JUDGMENT]** why it waits.
- - Classical Information (Machinegirl - Full Moon Future Mix), other group `other-2` (152 notes): around F3, mixed or noisy partials, slow swell, falls 16 dB/s, centered; hear it at 5:28.3, 5:25.3. **[JUDGMENT]** why it waits.
- - Screamography (Wonkavision Particles Re-imagination Edit), bass group `bass-2` (50 notes): around F2, harmonic (string/reed/pad-like), soft attack, falls 9 dB/s, centered; hear it at 1:39.9, 2:59.4. **[JUDGMENT]** why it waits.
- - Dam Ambience, other group `other-2` (201 notes): around F2, mixed or noisy partials, slow swell, falls 21 dB/s, centered; hear it at 4:53.7, 5:06.7. **[JUDGMENT]** why it waits.
- - One Byte At A Time (Conglomerate Remix - 2K17 New Whirled Edit), other group `other-1` (132 notes): around D3, mixed or noisy partials, slow swell, falls 11 dB/s, centered; hear it at 2:16.4, 2:26.4. **[JUDGMENT]** why it waits.
- **- Smiling At Sunbears Grooming In Sunbeams (Synths Only Edit)** (3:49.1, 129 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 17.80 (high, album median 4.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- The Pain-Body (STCLVR - Catch A Body Remix)** (3:17.7, 136 BPM by the mix-level count): stands out for pitch bends a minute 39.46 (high, album median 14.60). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Cloud-Hidden (CVN Remix)** (2:41.7, 118 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 16.30 (high, album median 4.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Clear Game & Evolutionary Light (Tiger Village - Arbelos Process)** (2:45.9, 129 BPM by the mix-level count): stands out for pitch bends a minute 36.52 (high, album median 14.60). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Planck Lengths (Eyeliner - Strong Nuclear Force Remix)** (4:05.1, 144 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 13.70 (high, album median 4.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Foam, Vacuum, Om (Qualchan - Swimming In The Syrup Edit)** (6:52.4, 118 BPM by the mix-level count): stands out for repetition 0.77 (high, album median 0.47). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Window 2 Window (Early 2016 Demo)** (3:26.5, 129 BPM by the mix-level count): stands out for tail (dB a second) -4.60 (low, album median -1.05). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
