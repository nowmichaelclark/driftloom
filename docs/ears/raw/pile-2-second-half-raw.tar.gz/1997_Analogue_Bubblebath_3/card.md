## 1997 - Analogue Bubblebath 3 (draft card from Ears 3 tools, 2026-10-18)

How it was made: 12 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: - .000890569; - [untitled]; - .942937; - (CAT 00897-A2). Typical track: - .000890569. Least like the rest: - [untitled], - .942937, - (CAT 00897-A2).
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- .000890569**: share of power drums 85%, bass 1%, other 12%, vocals 2%.
  - bass stem is near empty (0.5%): bass notes, pumping and wobble are void.
  - vocals stem holds 2.4%: bleed on an instrumental, not a voice.
  - meter tool 94 BPM is two thirds of the drum-grid beat of 139.5 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- [untitled]**: share of power drums 25%, bass 2%, other 72%, vocals 0%.
  - bass stem is thin (2.3%): bass notes, pumping and wobble are guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 124 BPM is two thirds of the drum-grid beat of 178.0 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- .942937**: share of power drums 88%, bass 1%, other 9%, vocals 3%.
  - bass stem is near empty (0.8%): bass notes, pumping and wobble are void.
  - vocals stem holds 2.8%: bleed on an instrumental, not a voice.
  - meter tool 73 BPM agrees with the drum-grid beat of 72.8 BPM.
- **- (CAT 00897-A2)**: share of power drums 89%, bass 0%, other 8%, vocals 3%.
  - bass stem is near empty (0.2%): bass notes, pumping and wobble are void.
  - vocals stem holds 2.6%: bleed on an instrumental, not a voice.
  - meter tool 74 BPM is half of the drum-grid beat of 147.8 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 73 to 124 BPM (octave-uncertain); keys G# phrygian, C aeolian, F lydian, F# lydian; mix width -14 to 1 dB; chord changes 8 to 44 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - [untitled]: other group `other-1` (169 notes, 60% of the track's note energy)
- In synth terms: around C4, bell- or metal-like (partials off whole multiples), soft attack, falls 27 dB/s, centered.
- Hear it at: 0:19.3 (F#3, 0.18 s, +23 dB alone), 0:21.2 (F#3, 0.33 s, +22 dB alone), 0:43.3 (?, 0.17 s, +21 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 261 (185 to 597) Hz; attack 132 (29 to 334) ms; decay -27 (-154 to 0) dB/s
  - brightness at the start 1183 (641 to 1630) Hz; slope over the note 0.00 (-0.18 to 0.08) octaves
  - harmonic share 0.29 (0.14 to 0.44); partials off whole multiples 75 (53 to 113) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.4 (-17.4 to -2.5) dB; pan -0.06 (-0.16 to 0.00); left-right correlation -0.05 (-0.30 to 0.68)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. - .942937: drums group `drums-1` (424 notes, 56% of the track's note energy)
- In synth terms: high tick, soft attack, falls 88 dB/s, centered.
- Hear it at: 3:15.8 (F#1, 0.17 s, +33 dB alone), 3:22.4 (D#2, 0.13 s, +33 dB alone), 3:19.1 (D2, 0.13 s, +32 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (47 to 84) Hz; attack 75 (60 to 103) ms; decay -88 (-127 to -48) dB/s
  - brightness at the start 3098 (2400 to 3579) Hz; slope over the note -0.01 (-1.12 to 0.45) octaves
  - harmonic share 0.43 (0.10 to 0.91); partials off whole multiples 91 (25 to 153) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.9 (-1.6 to -0.1) dB; pan 0.00 (-0.01 to 0.04); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S3. - .000890569: drums group `drums-1` (471 notes, 51% of the track's note energy)
- In synth terms: low thump, soft attack, falls 478 dB/s, gets brighter over the note, centered.
- Hear it at: 2:57.8 (?, 0.22 s, +43 dB alone), 2:58.7 (?, 0.26 s, +40 dB alone), 2:57.6 (D2, 0.21 s, +36 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 75 (67 to 75) Hz; attack 93 (42 to 99) ms; decay -478 (-604 to -224) dB/s
  - brightness at the start 108 (84 to 215) Hz; slope over the note 2.15 (0.00 to 3.45) octaves
  - harmonic share 0.94 (0.87 to 0.96); partials off whole multiples 223 (171 to 294) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-0.7 to -0.2) dB; pan 0.04 (0.03 to 0.06); left-right correlation 0.96 (0.88 to 0.98)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S4. - (CAT 00897-A2): drums group `drums-1` (412 notes, 36% of the track's note energy)
- In synth terms: low thump, soft attack, falls 396 dB/s, centered.
- Hear it at: 1:53.5 (E2, 0.09 s, +26 dB alone), 1:42.1 (D#2, 0.11 s, +25 dB alone), 5:02.7 (D#2, 0.13 s, +25 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 78 (76 to 80) Hz; attack 51 (49 to 71) ms; decay -396 (-702 to -303) dB/s
  - brightness at the start 227 (137 to 410) Hz; slope over the note 0.00 (0.00 to 0.00) octaves
  - harmonic share 0.74 (0.63 to 0.87); partials off whole multiples 213 (181 to 232) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.2 (-0.4 to -0.1) dB; pan 0.00 (-0.01 to 0.01); left-right correlation 1.00 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. - .000890569: other group `other-1` (316 notes, 28% of the track's note energy)
- In synth terms: around D#3, mixed or noisy partials, soft attack, falls 17 dB/s, centered.
- Hear it at: 4:16.3 (G#3, 0.3 s, +56 dB alone), 4:16.0 (B2, 0.15 s, +56 dB alone), 4:15.7 (F#3, 0.12 s, +55 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 158 (122 to 216) Hz; attack 123 (35 to 676) ms; decay -17 (-63 to -1) dB/s
  - brightness at the start 793 (620 to 951) Hz; slope over the note 0.00 (-0.23 to 0.19) octaves
  - harmonic share 0.59 (0.26 to 0.85); partials off whole multiples 51 (24 to 92) cents
  - vibrato 0 (0 to 17) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -8.2 (-14.3 to -0.3) dB; pan 0.09 (0.07 to 0.12); left-right correlation 0.86 (0.79 to 0.91)
- Group quality: weak (silhouette 0.25, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. - (CAT 00897-A2): other group `other-1` (438 notes, 26% of the track's note energy)
- In synth terms: around D1, bell- or metal-like (partials off whole multiples), soft attack, falls 49 dB/s, centered.
- Hear it at: 3:15.0 (?, 0.4 s, +42 dB alone), 3:15.3 (?, 0.4 s, +41 dB alone), 4:08.4 (D1, 0.33 s, +40 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 37 (32 to 48) Hz; attack 99 (26 to 207) ms; decay -49 (-140 to -17) dB/s
  - brightness at the start 346 (206 to 669) Hz; slope over the note 0.00 (-0.80 to 0.56) octaves
  - harmonic share 0.21 (0.08 to 0.67); partials off whole multiples 114 (55 to 197) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -9.7 (-12.8 to -1.2) dB; pan -0.00 (-0.05 to 0.04); left-right correlation 0.69 (0.49 to 0.86)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. - .942937: other group `other-1` (435 notes, 24% of the track's note energy)
- In synth terms: around F2, bell- or metal-like (partials off whole multiples), soft attack, falls 25 dB/s, centered.
- Hear it at: 4:17.4 (F2, 6.02 s, +10 dB alone), 4:07.6 (F2, 6.0 s, +8 dB alone), 0:40.3 (G2, 0.07 s, +4 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 88 (64 to 110) Hz; attack 99 (33 to 297) ms; decay -25 (-114 to -1) dB/s
  - brightness at the start 341 (287 to 402) Hz; slope over the note 0.00 (-0.08 to 0.16) octaves
  - harmonic share 0.50 (0.13 to 0.84); partials off whole multiples 74 (31 to 123) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.0 (-8.7 to -5.3) dB; pan 0.14 (0.04 to 0.25); left-right correlation 0.46 (0.17 to 0.65)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S8. - [untitled]: drums group `drums-1` (79 notes, 16% of the track's note energy)
- In synth terms: mid snap, slow swell, falls 17 dB/s, centered.
- Hear it at: 0:39.1 (E4, 0.41 s, +16 dB alone), 0:39.5 (G#3, 0.36 s, +13 dB alone), 0:40.1 (A#3, 0.19 s, +14 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 185 (125 to 285) Hz; attack 170 (44 to 402) ms; decay -17 (-48 to 2) dB/s
  - brightness at the start 1184 (1030 to 1860) Hz; slope over the note 0.00 (-0.53 to 0.15) octaves
  - harmonic share 0.31 (0.19 to 0.63); partials off whole multiples 70 (42 to 99) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -9.4 (-17.2 to -4.3) dB; pan -0.04 (-0.13 to 0.00); left-right correlation -0.16 (-0.34 to 0.69)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- .000890569 sections:** 10 boundaries at 0:03.0, 0:23.0, 0:36.0, 1:17.0, 1:33.0, 3:20.0, 3:35.0, 4:08.0, 4:22.0, 4:35.0; section lengths median 15 s (range 3 to 107). Reliable for sections of 10 s or more.
- **- .000890569 stem entries and exits:** drums plays 79% of the time (in: 0:03.0, 0:34.5, 1:29.5, 4:20.5; out: 0:11.0, 1:18.0, 4:09.0, 4:36.5); bass plays 71% of the time (in: 0:11.5, 0:24.0, 1:30.0, 3:47.0, 3:54.0; out: 0:14.5, 1:18.0, 3:32.0, 3:50.0, 4:07.5); other plays 95% of the time (in: 0:03.5, 0:21.5; out: 0:18.0, 4:41.5); vocals plays 44% of the time (in: 0:02.5, 0:41.0, 1:35.0, 3:23.0, 3:47.5; out: 0:09.5, 0:49.0, 2:57.0, 3:27.5, 3:56.5).
- **- .000890569 floor drops (kick and bass out 2 s or more while the rest plays):** 0.70 a minute: 0:21.5 for 13.8 s, 1:17.0 for 13.5 s, 4:07.8 for 13.2 s.
- **- .000890569 brightness sweeps (0.7 octave or more):** mix down 3.7 oct 0:04.0 to 0:15.5; mix up 1.1 oct 0:16.0 to 0:24.0; mix up 1.4 oct 1:01.5 to 1:06.5; mix up 0.7 oct 2:03.0 to 2:09.0; mix up 1.8 oct 2:44.0 to 2:51.0; mix up 1.4 oct 2:58.5 to 3:04.0; mix down 1.1 oct 3:04.0 to 3:09.0; mix down 0.8 oct 3:19.0 to 3:28.5 (23 more in techniques.json).
- **- .000890569 echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- .000890569 pumping locked to the kick:** other dips 1.8 dB at the kick (peak 10 ms after, kick every 0.23 s); bass dips 11.3 dB at the kick (peak 180 ms after, kick every 0.23 s). The tool reads about 70% of the true depth, so this is a floor.
- **- .000890569 tape wobble and speed:** other wobbles about 19 cents at 4.1 Hz.
- **- .000890569 stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- [untitled] sections:** 2 boundaries at 0:05.0, 0:42.0; section lengths median 12 s (range 5 to 37). Reliable for sections of 10 s or more.
- **- [untitled] stem entries and exits:** drums plays 89% of the time (in: 0:03.0; out: 0:51.0); bass plays 70% of the time (in: 0:05.5; out: 0:43.0); other plays 83% of the time (in: 0:03.5; out: 0:48.0); vocals plays 6% of the time (in: 0:43.0; out: 0:46.0).
- **- [untitled] floor drops (kick and bass out 2 s or more while the rest plays):** 1.26 a minute: 0:04.2 for 2.5 s.
- **- [untitled] brightness sweeps (0.7 octave or more):** mix down 1.3 oct 0:42.5 to 0:53.0; other up 4.5 oct 0:00.0 to 0:13.5; other down 1.6 oct 0:38.5 to 0:45.5; bass down 1.1 oct 0:02.5 to 0:13.5; bass up 2.3 oct 0:35.0 to 0:45.5.
- **- [untitled] echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- [untitled] pumping locked to the kick:** under 1.5 dB; none found.
- **- [untitled] tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- [untitled] stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **- [untitled] builds:** 0:00.0 to 0:20.0.
- **- .942937 sections:** 15 boundaries at 0:04.0, 0:16.0, 0:30.0, 0:40.0, 0:52.0, 1:12.0, 1:28.0, 1:40.0, 1:52.0, 2:21.0, 2:39.0, 3:02.0; section lengths median 15 s (range 4 to 42). Reliable for sections of 10 s or more.
- **- .942937 stem entries and exits:** drums plays 91% of the time (in: 0:02.0, 4:13.5; out: 4:08.5, 4:18.5); bass plays 86% of the time (in: 0:11.5, 4:14.0; out: 4:07.5, 4:17.5); other plays 90% of the time (in: 0:01.5, 3:15.5, 3:26.5; out: 3:03.0, 3:19.0, 4:30.5); vocals plays 79% of the time (in: 0:15.5, 0:46.5, 0:58.0, 2:53.0, 3:42.5; out: 0:31.0, 0:55.5, 2:49.5, 3:38.5, 4:19.5).
- **- .942937 floor drops (kick and bass out 2 s or more while the rest plays):** 0.48 a minute: 4:07.8 for 6.5 s, 4:17.8 for 5.0 s.
- **- .942937 brightness sweeps (0.7 octave or more):** mix down 2.6 oct 0:00.0 to 0:12.0; mix up 5.2 oct 0:12.0 to 0:20.0; mix down 0.9 oct 1:54.0 to 2:02.0; mix down 4.2 oct 4:00.5 to 4:11.0; mix up 4.2 oct 4:11.0 to 4:16.0; mix down 4.1 oct 4:16.0 to 4:25.5; other up 1.5 oct 0:12.5 to 0:20.0; other down 3.5 oct 0:26.5 to 0:33.5 (19 more in techniques.json).
- **- .942937 echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- .942937 pumping locked to the kick:** other dips 2.8 dB at the kick (peak 150 ms after, kick every 0.39 s); bass dips 2.0 dB at the kick (peak 150 ms after, kick every 0.39 s). The tool reads about 70% of the true depth, so this is a floor.
- **- .942937 tape wobble and speed:** other wobbles about 5 cents at 2.2 Hz.
- **- .942937 stereo movement:** other pan range 0.21, cycling every 4 s.
- **- .942937 builds:** 0:00.0 to 0:21.0.
- **- (CAT 00897-A2) sections:** 16 boundaries at 0:25.0, 0:37.0, 1:00.0, 1:24.0, 1:37.0, 1:50.0, 2:05.0, 2:18.0, 2:40.0, 2:54.0, 3:12.0, 3:43.0; section lengths median 18 s (range 12 to 31). Reliable for sections of 10 s or more.
- **- (CAT 00897-A2) stem entries and exits:** drums plays 85% of the time (in: 0:21.0, 1:08.0, 2:10.5, 4:08.5; out: 1:01.5, 2:07.0, 4:03.5, 5:04.0); bass plays 28% of the time (in: 0:15.0, 0:55.0, 1:25.0, 1:58.5, 2:18.5; out: 0:35.0, 1:03.0, 1:29.5, 2:04.5, 2:21.0); other plays 99% of the time (in: 0:02.0; out: never); vocals plays 64% of the time (in: 0:01.5, 0:29.0, 0:58.5, 1:38.5, 2:33.5; out: 0:25.5, 0:38.5, 1:36.0, 2:25.5, 2:42.0).
- **- (CAT 00897-A2) floor drops (kick and bass out 2 s or more while the rest plays):** 1.27 a minute: 0:15.5 for 6.0 s, 1:00.8 for 8.0 s, 2:06.0 for 11.0 s, 4:03.0 for 7.2 s, 4:10.0 for 8.8 s, 4:23.8 for 2.0 s.
- **- (CAT 00897-A2) brightness sweeps (0.7 octave or more):** mix up 1.0 oct 0:00.0 to 0:09.5; mix down 2.7 oct 0:17.5 to 0:24.5; mix up 2.7 oct 0:56.0 to 1:04.0; mix down 2.9 oct 1:04.5 to 1:14.0; mix down 3.1 oct 2:53.5 to 3:02.0; mix up 2.6 oct 3:37.0 to 3:43.0; mix down 2.3 oct 3:49.5 to 3:54.5; mix up 1.9 oct 4:11.0 to 4:18.0 (46 more in techniques.json).
- **- (CAT 00897-A2) echo times:** drums: 718 ms (+7.7 dB, 1 later repeats).
- **- (CAT 00897-A2) pumping locked to the kick:** other dips 1.7 dB at the kick (peak 55 ms after, kick every 0.30 s); bass dips 6.1 dB at the kick (peak 65 ms after, kick every 0.30 s). The tool reads about 70% of the true depth, so this is a floor.
- **- (CAT 00897-A2) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- (CAT 00897-A2) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- .000890569 meter:** about 94 BPM (could be 47 or 188; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- .000890569 key and mode:** G# phrygian (low confidence: the key signature margin is 0.013, so read this as a guess); pitch-class weights C# 0.16, E 0.11, C 0.10, F# 0.10, G# 0.10.
- **- .000890569 chords:** 44 changes a minute (16 a minute are chords that last 1.5 s or more); median chord 1.1 s (10th to 90th percentile 0.5 to 2.3 s); 29 distinct chords; most time on F#min7 15%, C#min7 14%, A#dim 11%, Cmin7 10%. The old counter in this same run said 10; Ears 1's 2-s counter said 3.  43% of the changes land on a beat (chance would be 47%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- .000890569 bass:** pedal (one note held or repeated); 0.65 notes a second; most time on G# 0.92, D 0.03, G 0.03, F# 0.01; steps 8%, thirds 1%, fourths and fifths 0%, octaves 0%, repeats 91%.
- **- .000890569 top line (from the 'other' stem; read by ear before trusting):** 625 notes, range 9 semitones (10th to 90th percentile); steps 12%, thirds 27%, fourths and fifths 20%, leaps 15%, repeats 27%; median interval 3 semitones; 54% of moves go up; phrases of about 8 notes, arch 39%, rising 25%, falling 21%, flat or wavy 14%. Reliable only when the line sits clearly above its accompaniment.
- **- .000890569 repetition:** 112 bars of 2.6 s; strongest repeat distances 1 bars (0.77); 22% of bars near-duplicate an earlier bar.
- **- [untitled] meter:** about 124 BPM (could be 62 or 248; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.13); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- [untitled] key and mode:** C aeolian (minor) (low confidence: the key signature margin is 0.011, so read this as a guess); pitch-class weights D 0.11, C 0.10, D# 0.10, E 0.09, C# 0.09.
- **- [untitled] chords:** 8 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 5.2 s (10th to 90th percentile 3.3 to 13.7 s); 7 distinct chords; most time on G#maj7 26%, C#maj7 25%, D#maj7 19%, C7 12%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- [untitled] top line (from the 'other' stem; read by ear before trusting):** 107 notes, range 12 semitones (10th to 90th percentile); steps 40%, thirds 19%, fourths and fifths 12%, leaps 14%, repeats 15%; median interval 2 semitones; 54% of moves go up; phrases of about 10 notes, arch 12%, rising 38%, falling 12%, flat or wavy 38%. Reliable only when the line sits clearly above its accompaniment.
- **- [untitled] repetition:** 55 bars of 1.0 s; strongest repeat distances 1 bars (0.53), 9 bars (0.13), 15 bars (0.01); 6% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **- .942937 meter:** about 73 BPM (could be 36 or 145; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.60 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- .942937 key and mode:** F lydian (key signature margin 0.024); pitch-class weights E 0.17, A 0.14, C 0.10, D 0.09, G 0.09.
- **- .942937 chords:** 21 changes a minute (16 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 1.1 to 5.1 s); 15 distinct chords; most time on Amin7 32%, Fmaj7 18%, Gmaj7 18%, Asus2 8%. The old counter in this same run said 8; Ears 1's 2-s counter said 3.  44% of the changes land on a beat (chance would be 36%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- .942937 bass:** root-note movement / mixed; 0.18 notes a second; most time on F# 0.68, F 0.17, G 0.15; steps 53%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 47%.
- **- .942937 top line (from the 'other' stem; read by ear before trusting):** 721 notes, range 7 semitones (10th to 90th percentile); steps 5%, thirds 33%, fourths and fifths 33%, leaps 4%, repeats 25%; median interval 4 semitones; 50% of moves go up; phrases of about 24 notes, arch 33%, rising 21%, falling 12%, flat or wavy 33%. Reliable only when the line sits clearly above its accompaniment.
- **- .942937 repetition:** 83 bars of 3.3 s; strongest repeat distances 4 bars (0.70), 8 bars (0.47), 32 bars (0.33); 39% of bars near-duplicate an earlier bar.
- **- (CAT 00897-A2) meter:** about 74 BPM (could be 37 or 147; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.75 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **- (CAT 00897-A2) key and mode:** F# lydian (key signature margin 0.024); pitch-class weights F# 0.16, F 0.13, G 0.10, E 0.09, C 0.09.
- **- (CAT 00897-A2) chords:** 23 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 0.6 to 5.9 s); 18 distinct chords; most time on F#maj7 71%, Gmaj7 6%, Cmaj7 4%, Fmaj7 3%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  9% of the changes land on a beat (chance would be 37%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- (CAT 00897-A2) top line (from the 'other' stem; read by ear before trusting):** 839 notes, range 11 semitones (10th to 90th percentile); steps 14%, thirds 5%, fourths and fifths 23%, leaps 26%, repeats 32%; median interval 4 semitones; 50% of moves go up; phrases of about 13 notes, arch 21%, rising 21%, falling 31%, flat or wavy 28%. Reliable only when the line sits clearly above its accompaniment.
- **- (CAT 00897-A2) repetition:** 193 bars of 1.6 s; strongest repeat distances 1 bars (0.74), 8 bars (0.32), 32 bars (0.24); 29% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- .000890569 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -22 (corr 0.99); low_120_500 -14 (corr 0.94); mid_500_2k -10 (corr 0.82); pres_2k_5k -3 (corr 0.33); air_gt5k 5 (corr -0.52); over time (2-s windows) 10th/50th/90th percentile -10/-6/-2 dB.
- **- .000890569 by part:** drums: 85% of the power, width -12 dB, pan +0.09, mono loss 0.3 dB, widest in sub_lt120 (-22 dB); bass: 0% of the power, width -28 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-29 dB); other: 12% of the power, width -10 dB, pan +0.19, mono loss 0.4 dB, widest in mid_500_2k (-9 dB); vocals: 2% of the power, width -10 dB, pan +0.19, mono loss 0.4 dB, widest in mid_500_2k (-10 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- [untitled] mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -17 (corr 0.96); low_120_500 1 (corr -0.13); mid_500_2k 2 (corr -0.20); pres_2k_5k 0 (corr -0.05); air_gt5k -2 (corr 0.28); over time (2-s windows) 10th/50th/90th percentile -1/1/2 dB.
- **- [untitled] by part:** drums: 27% of the power, width 2 dB, pan -0.08, mono loss 4.2 dB, widest in mid_500_2k (2 dB); bass: 1% of the power, width -18 dB, pan -0.02, mono loss 0.1 dB, widest in sub_lt120 (-18 dB); other: 72% of the power, width 1 dB, pan -0.14, mono loss 3.8 dB, widest in mid_500_2k (2 dB); vocals: 0% of the power, width -6 dB, pan -0.58, mono loss 1.0 dB, widest in low_120_500 (-6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- .942937 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -23 (corr 0.99); low_120_500 -7 (corr 0.68); mid_500_2k -7 (corr 0.65); pres_2k_5k -26 (corr 1.00); air_gt5k -26 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -24/-11/-7 dB.
- **- .942937 by part:** drums: 74% of the power, width -26 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-24 dB); bass: 1% of the power, width -31 dB, pan +0.02, mono loss 0.0 dB, widest in sub_lt120 (-30 dB); other: 21% of the power, width -4 dB, pan +0.26, mono loss 1.6 dB, widest in low_120_500 (-3 dB); vocals: 5% of the power, width -25 dB, pan -0.06, mono loss 0.0 dB, widest in air_gt5k (-24 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- (CAT 00897-A2) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -15 (corr 0.94); low_120_500 -14 (corr 0.92); mid_500_2k -10 (corr 0.83); pres_2k_5k -12 (corr 0.89); air_gt5k -16 (corr 0.95); over time (2-s windows) 10th/50th/90th percentile -18/-14/-7 dB.
- **- (CAT 00897-A2) by part:** drums: 88% of the power, width -19 dB, pan +0.02, mono loss 0.1 dB, widest in air_gt5k (-17 dB); bass: 0% of the power, width -10 dB, pan +0.04, mono loss 0.4 dB, widest in sub_lt120 (-9 dB); other: 9% of the power, width -7 dB, pan +0.00, mono loss 0.7 dB, widest in sub_lt120 (-7 dB); vocals: 3% of the power, width -8 dB, pan +0.00, mono loss 0.6 dB, widest in low_120_500 (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - .000890569: 94 BPM, 16 settled chords a minute, 8% of energy above 2 kHz, width -12 dB; - [untitled]: 124 BPM, 9 settled chords a minute, 4% of energy above 2 kHz, width 1 dB; - .942937: 73 BPM, 16 settled chords a minute, 44% of energy above 2 kHz, width -12 dB; - (CAT 00897-A2): 74 BPM, 12 settled chords a minute, 11% of energy above 2 kHz, width -14 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: - [untitled]: mono loss 3.8 dB (opposite-polarity parts); - .942937: 44% of energy above 2 kHz (bright or harsh).

### For later
- - (CAT 00897-A2), vocals group `vocals-1` (411 notes): around F3, bell- or metal-like (partials off whole multiples), soft attack, falls 61 dB/s, centered; hear it at 0:02.4, 5:05.6. **[JUDGMENT]** why it waits.
- - (CAT 00897-A2), drums group `drums-2` (72 notes): mid snap, slow swell, falls 403 dB/s, centered; hear it at 1:33.1, 1:36.3. **[JUDGMENT]** why it waits.
- - .000890569, other group `other-2` (166 notes): around E2, mixed or noisy partials, soft attack, falls 14 dB/s, centered; hear it at 0:22.6, 0:22.4. **[JUDGMENT]** why it waits.
- - [untitled], drums group `drums-2` (12 notes): mid snap, soft attack, falls 42 dB/s, leans left (-0.22); hear it at 0:50.4, 0:49.6. **[JUDGMENT]** why it waits.
- - .942937, vocals group `vocals-1` (406 notes): around G6, bell- or metal-like (partials off whole multiples), soft attack, falls 74 dB/s, centered; hear it at 3:17.0, 1:47.6. **[JUDGMENT]** why it waits.
- - .942937, drums group `drums-2` (76 notes): mid snap, soft attack, falls 76 dB/s, centered; hear it at 3:19.3, 3:12.6. **[JUDGMENT]** why it waits.
- - [untitled], other group `other-2` (17 notes): around G1, harmonic (string/reed/pad-like), soft attack, falls 8 dB/s, centered; hear it at 0:42.6, 0:43.1. **[JUDGMENT]** why it waits.
- - .000890569, vocals group `vocals-1` (392 notes): around F3, mixed or noisy partials, soft attack, falls 39 dB/s, centered; hear it at 4:32.9, 4:34.8. **[JUDGMENT]** why it waits.
- **- .1993841** (8:02.9, 136 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 8.60 (high, album median 1.70); width (side/mid dB) -23.30 (low, album median -12.80). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- (CAT 00897-AA1)** (4:05.6, 123 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 5.90 (high, album median 1.70). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- .0180871R** (4:16.2, 162 BPM by the mix-level count): stands out for width (side/mid dB) -24.50 (low, album median -12.80). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- [untitled]** (4:41.8, 123 BPM by the mix-level count): stands out for pulse strength 0.41 (low, album median 0.77); width (side/mid dB) -3.40 (high, album median -12.80). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- AFX 6_B** (0:36.0, 96 BPM by the mix-level count): no outstanding number. Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
