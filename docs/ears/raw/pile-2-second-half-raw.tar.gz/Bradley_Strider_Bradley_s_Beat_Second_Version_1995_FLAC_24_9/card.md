## Bradley Strider - Bradley's Beat (Second Version) (1995) [FLAC  24-96] (draft card from Ears 3 tools, 2026-10-18)

How it was made: EP or short record (2 usable tracks): every track. Deep pass on: Bradley's Beat (Part One); Bradley's Beat (Part Two). Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Bradley's Beat (Part One)**: share of power drums 91%, bass 6%, other 2%, vocals 0%.
  - other stem holds 2.4% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.3%: bleed on an instrumental, not a voice.
  - meter tool 73 BPM is half of the drum-grid beat of 147.8 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Bradley's Beat (Part Two)**: share of power drums 96%, bass 0%, other 4%, vocals 1%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - other stem holds 3.9% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.6%: bleed on an instrumental, not a voice.
  - meter tool 143 BPM agrees with the drum-grid beat of 143.5 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 73 to 143 BPM (octave-uncertain); keys E phrygian, C lydian; mix width -23 to -19 dB; chord changes 16 to 60 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Bradley's Beat (Part Two): drums group `drums-1` (451 notes, 60% of the track's note energy)
- In synth terms: low thump, quick attack, falls 52 dB/s, centered.
- Hear it at: 0:02.2 (A1, 0.1 s, +50 dB alone), 0:07.3 (A#1, 0.12 s, +50 dB alone), 0:07.7 (A1, 0.13 s, +49 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (50 to 62) Hz; attack 28 (17 to 70) ms; decay -52 (-86 to -23) dB/s
  - brightness at the start 176 (125 to 204) Hz; slope over the note 0.00 (0.00 to 1.01) octaves
  - harmonic share 0.75 (0.19 to 0.91); partials off whole multiples 113 (63 to 246) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.1 (-0.2 to -0.0) dB; pan 0.03 (0.02 to 0.04); left-right correlation 0.99 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S2. Bradley's Beat (Part One): bass group `bass-1` (444 notes, 23% of the track's note energy)
- In synth terms: around E2, mixed or noisy partials, quick attack, falls 89 dB/s, centered.
- Hear it at: 5:39.1 (D#2, 0.31 s, +11 dB alone), 5:51.4 (E2, 0.29 s, +11 dB alone), 5:41.5 (E2, 0.32 s, +11 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 81 (62 to 84) Hz; attack 25 (17 to 48) ms; decay -89 (-115 to -22) dB/s
  - brightness at the start 95 (86 to 104) Hz; slope over the note 0.04 (-0.19 to 0.56) octaves
  - harmonic share 0.79 (0.56 to 0.99); partials off whole multiples 38 (15 to 57) cents
  - vibrato 0 (0 to 53) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -10.8 (-15.9 to -2.4) dB; pan 0.01 (0.00 to 0.03); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S3. Bradley's Beat (Part One): drums group `drums-1` (98 notes, 21% of the track's note energy)
- In synth terms: low thump, quick attack, falls 65 dB/s, centered.
- Hear it at: 4:03.9 (G1, 0.77 s, +26 dB alone), 4:03.1 (G1, 0.39 s, +24 dB alone), 4:05.1 (G1, 0.79 s, +22 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 50 (50 to 50) Hz; attack 17 (8 to 23) ms; decay -65 (-73 to -61) dB/s
  - brightness at the start 126 (72 to 239) Hz; slope over the note 0.14 (-1.45 to 5.49) octaves
  - harmonic share 1.00 (0.99 to 1.00); partials off whole multiples 15 (4 to 83) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-0.7 to -0.1) dB; pan 0.03 (0.01 to 0.04); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S4. Bradley's Beat (Part Two): other group `other-1` (276 notes, 14% of the track's note energy)
- In synth terms: around E2, bell- or metal-like (partials off whole multiples), soft attack, falls 64 dB/s, centered.
- Hear it at: 2:59.1 (E2, 0.15 s, +22 dB alone), 2:57.4 (B2, 0.14 s, +20 dB alone), 2:57.7 (B2, 0.16 s, +17 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 84 (74 to 125) Hz; attack 86 (36 to 271) ms; decay -64 (-121 to -7) dB/s
  - brightness at the start 500 (426 to 580) Hz; slope over the note -0.03 (-0.35 to 0.12) octaves
  - harmonic share 0.42 (0.13 to 0.68); partials off whole multiples 69 (45 to 105) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -10.3 (-13.6 to -1.8) dB; pan 0.01 (-0.04 to 0.05); left-right correlation 0.79 (0.72 to 0.86)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Bradley's Beat (Part One) sections:** 14 boundaries at 0:02.0, 0:40.0, 1:06.0, 1:58.0, 2:12.0, 2:39.0, 3:44.0, 3:58.0, 4:24.0, 4:45.0, 4:59.0, 5:15.0; section lengths median 21 s (range 2 to 65). Reliable for sections of 10 s or more.
- **Bradley's Beat (Part One) stem entries and exits:** drums plays 98% of the time (in: from the start; out: 5:59.0); bass plays 86% of the time (in: 2:09.5, 2:32.0, 3:56.5, 4:09.5; out: 1:59.5, 2:15.5, 3:45.0, 4:02.0, 6:00.0); other plays 99% of the time (in: from the start; out: 6:02.0); vocals plays 64% of the time (in: 0:40.5, 1:03.0, 1:34.5, 1:58.0, 2:37.5; out: 0:55.5, 1:26.5, 1:52.5, 2:34.5, 3:04.0).
- **Bradley's Beat (Part One) floor drops (kick and bass out 2 s or more while the rest plays):** 0.55 a minute: 3:44.2 for 7.5 s, 3:51.5 for 2.0 s, 3:53.2 for 4.0 s.
- **Bradley's Beat (Part One) brightness sweeps (0.7 octave or more):** mix up 1.2 oct 0:17.5 to 0:22.5; mix up 0.8 oct 0:33.5 to 0:38.5; mix down 0.7 oct 0:45.0 to 0:50.5; mix up 1.0 oct 1:12.0 to 1:18.0; mix down 1.7 oct 1:18.0 to 1:23.0; mix up 2.2 oct 1:52.0 to 1:59.5; mix down 2.1 oct 2:12.5 to 2:20.5; mix down 3.1 oct 2:25.0 to 2:34.5 (43 more in techniques.json).
- **Bradley's Beat (Part One) echo times:** drums: 414 ms (+9.4 dB, 2 later repeats).
- **Bradley's Beat (Part One) pumping locked to the kick:** other dips 5.0 dB at the kick (peak 10 ms after, kick every 0.41 s); bass dips 5.3 dB at the kick (peak 80 ms after, kick every 0.41 s). The tool reads about 70% of the true depth, so this is a floor.
- **Bradley's Beat (Part One) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Bradley's Beat (Part One) stereo movement:** other pan range 0.09, cycling every 49 s.
- **Bradley's Beat (Part Two) sections:** 13 boundaries at 0:03.0, 0:42.0, 1:09.0, 1:37.0, 2:34.0, 2:56.0, 3:18.0, 3:51.0, 4:32.0, 5:04.0, 5:23.0, 5:34.0; section lengths median 24 s (range 3 to 57). Reliable for sections of 10 s or more.
- **Bradley's Beat (Part Two) stem entries and exits:** drums plays 99% of the time (in: from the start; out: 5:48.5); bass plays 0% of the time (in: from the start; out: never); other plays 82% of the time (in: 0:25.0, 0:39.5, 3:47.5, 4:35.5, 4:53.5; out: 0:03.0, 0:30.0, 3:43.5, 4:28.0, 4:48.0); vocals plays 45% of the time (in: 1:08.5, 1:23.5, 1:44.5, 2:20.5, 3:01.0; out: 1:18.5, 1:35.5, 2:16.5, 2:27.0, 3:07.5).
- **Bradley's Beat (Part Two) floor drops (kick and bass out 2 s or more while the rest plays):** 0.19 a minute: 2:59.0 for 2.2 s.
- **Bradley's Beat (Part Two) brightness sweeps (0.7 octave or more):** mix down 3.1 oct 0:00.0 to 0:05.5; mix up 1.0 oct 1:04.5 to 1:12.5; mix down 1.1 oct 1:32.5 to 1:41.0; mix up 2.0 oct 2:51.0 to 3:00.0; mix down 0.8 oct 3:14.0 to 3:20.0; mix down 0.7 oct 3:33.5 to 3:40.5; mix down 0.7 oct 3:50.5 to 3:56.0; mix up 1.8 oct 5:21.5 to 5:31.5 (25 more in techniques.json).
- **Bradley's Beat (Part Two) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Bradley's Beat (Part Two) pumping locked to the kick:** other dips 2.5 dB at the kick (peak 15 ms after, kick every 0.42 s); bass dips 7.4 dB at the kick (peak 274 ms after, kick every 0.42 s). The tool reads about 70% of the true depth, so this is a floor.
- **Bradley's Beat (Part Two) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Bradley's Beat (Part Two) stereo movement:** drums pan range 0.03, cycling every 49 s.
- **Bradley's Beat (Part Two) builds:** 3:03.0 to 3:23.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Bradley's Beat (Part One) meter:** about 73 BPM (could be 36 or 146; the tool cannot tell the beat level), bar length unclear (best guess 12, score 0.00); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Bradley's Beat (Part One) key and mode:** E phrygian (low confidence: the key signature margin is 0.009, so read this as a guess); pitch-class weights E 0.15, F 0.15, F# 0.09, G 0.09, D# 0.09.
- **Bradley's Beat (Part One) chords:** 60 changes a minute (4 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.4 to 1.5 s); 23 distinct chords; most time on Fmaj7 44%, G#maj7 12%, Gsus2 9%, Cmaj7 8%. The old counter in this same run said 22; Ears 1's 2-s counter said 3.  40% of the changes land on a beat (chance would be 36%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Bradley's Beat (Part One) bass:** walking (steady stepwise motion); 1.42 notes a second; most time on E 0.41, F 0.23, B 0.20, C 0.07; steps 52%, thirds 10%, fourths and fifths 24%, octaves 0%, repeats 14%.
- **Bradley's Beat (Part One) top line (from the 'other' stem; read by ear before trusting):** 945 notes, range 10 semitones (10th to 90th percentile); steps 34%, thirds 9%, fourths and fifths 5%, leaps 35%, repeats 17%; median interval 2 semitones; 48% of moves go up; phrases of about 5 notes, arch 46%, rising 10%, falling 29%, flat or wavy 15%. Reliable only when the line sits clearly above its accompaniment.
- **Bradley's Beat (Part One) repetition:** 37 bars of 9.9 s; strongest repeat distances 1 bars (0.68), 12 bars (0.03); 11% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Bradley's Beat (Part Two) meter:** about 143 BPM (could be 71 or 286; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.04); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Bradley's Beat (Part Two) key and mode:** C lydian (low confidence: the key signature margin is 0.008, so read this as a guess); fits C major pentatonic; pitch-class weights C 0.17, B 0.17, A# 0.11, C# 0.10, E 0.09.
- **Bradley's Beat (Part Two) chords:** 16 changes a minute (7 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.8 to 9.1 s); 15 distinct chords; most time on Cmaj7 64%, A#sus2 6%, Gmaj7 5%, F#maj7 5%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  68% of the changes land on a beat (chance would be 71%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Bradley's Beat (Part Two) top line (from the 'other' stem; read by ear before trusting):** 980 notes, range 8 semitones (10th to 90th percentile); steps 52%, thirds 8%, fourths and fifths 16%, leaps 9%, repeats 15%; median interval 2 semitones; 50% of moves go up; phrases of about 83 notes, arch 0%, rising 17%, falling 17%, flat or wavy 67%. Reliable only when the line sits clearly above its accompaniment.
- **Bradley's Beat (Part Two) repetition:** 104 bars of 3.4 s; strongest repeat distances 1 bars (0.79), 24 bars (0.02); 18% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Bradley's Beat (Part One) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -27 (corr 1.00); low_120_500 -22 (corr 0.99); mid_500_2k -10 (corr 0.84); pres_2k_5k -11 (corr 0.87); air_gt5k -16 (corr 0.95); over time (2-s windows) 10th/50th/90th percentile -21/-19/-16 dB.
- **Bradley's Beat (Part One) by part:** drums: 91% of the power, width -24 dB, pan +0.06, mono loss 0.0 dB, widest in low_120_500 (-24 dB); bass: 6% of the power, width -28 dB, pan +0.03, mono loss 0.0 dB, widest in low_120_500 (-27 dB); other: 2% of the power, width -15 dB, pan +0.07, mono loss 0.1 dB, widest in mid_500_2k (-11 dB); vocals: 0% of the power, width -15 dB, pan +0.08, mono loss 0.1 dB, widest in mid_500_2k (-14 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Bradley's Beat (Part Two) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -26 (corr 1.00); low_120_500 -17 (corr 0.96); mid_500_2k -10 (corr 0.83); pres_2k_5k -10 (corr 0.83); air_gt5k -13 (corr 0.91); over time (2-s windows) 10th/50th/90th percentile -19/-15/-13 dB.
- **Bradley's Beat (Part Two) by part:** drums: 95% of the power, width -23 dB, pan +0.05, mono loss 0.0 dB, widest in low_120_500 (-21 dB); bass: 0% of the power, width -14 dB, pan -0.01, mono loss 0.2 dB, widest in mid_500_2k (-12 dB); other: 4% of the power, width -9 dB, pan +0.03, mono loss 0.5 dB, widest in mid_500_2k (-8 dB); vocals: 1% of the power, width -9 dB, pan -0.03, mono loss 0.5 dB, widest in mid_500_2k (-8 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Bradley's Beat (Part One): 73 BPM, 4 settled chords a minute, 2% of energy above 2 kHz, width -23 dB; Bradley's Beat (Part Two): 143 BPM, 7 settled chords a minute, 1% of energy above 2 kHz, width -19 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Bradley's Beat (Part One), drums group `drums-2` (145 notes): low thump, quick attack, falls 84 dB/s, gets brighter over the note, centered; hear it at 2:00.5, 2:03.8. **[JUDGMENT]** why it waits.
- Bradley's Beat (Part Two), other group `other-2` (190 notes): around A#3, bell- or metal-like (partials off whole multiples), soft attack, falls 29 dB/s, centered; hear it at 2:57.4, 2:59.4. **[JUDGMENT]** why it waits.
- Bradley's Beat (Part Two), drums group `drums-2` (49 notes): low thump, soft attack, falls 120 dB/s, centered; hear it at 0:27.4, 3:43.0. **[JUDGMENT]** why it waits.
- Bradley's Beat (Part One), other group `other-1` (208 notes): around F3, mixed or noisy partials, quick attack, falls 84 dB/s, gets brighter over the note, centered; hear it at 0:01.6, 5:48.8. **[JUDGMENT]** why it waits.
- Bradley's Beat (Part One), other group `other-2` (147 notes): around D2, bell- or metal-like (partials off whole multiples), quick attack, falls 68 dB/s, centered; hear it at 0:01.5, 5:52.8. **[JUDGMENT]** why it waits.
- Bradley's Beat (Part Two), vocals group `vocals-1` (316 notes): around B3, bell- or metal-like (partials off whole multiples), soft attack, falls 63 dB/s, centered; hear it at 3:36.1, 3:32.8. **[JUDGMENT]** why it waits.
