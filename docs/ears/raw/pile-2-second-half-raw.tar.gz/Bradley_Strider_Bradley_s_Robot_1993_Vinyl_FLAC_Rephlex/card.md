## Bradley Strider - Bradley's Robot (1993) [Vinyl FLAC] {Rephlex} (draft card from Ears 3 tools, 2026-10-18)

How it was made: EP or short record (4 usable tracks): every track. Deep pass on: 01. Untitled (A1); 02. Untitled (A2); 03. Untitled (B1); 04. Untitled (B2). Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **01. Untitled (A1)**: share of power drums 84%, bass 1%, other 13%, vocals 1%.
  - bass stem is near empty (1.2%): bass notes, pumping and wobble are void.
  - vocals stem holds 1.2%: bleed on an instrumental, not a voice.
  - meter tool 133 BPM agrees with the drum-grid beat of 132.5 BPM.
- **02. Untitled (A2)**: share of power drums 69%, bass 30%, other 1%, vocals 0%.
  - other stem holds 0.6% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 123 BPM agrees with the drum-grid beat of 123.0 BPM.
- **03. Untitled (B1)**: share of power drums 85%, bass 13%, other 2%, vocals 0%.
  - other stem holds 2.1% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 83 BPM is two thirds of the drum-grid beat of 126.1 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **04. Untitled (B2)**: share of power drums 86%, bass 12%, other 2%, vocals 0%.
  - other stem holds 1.5% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 97 BPM agrees with the drum-grid beat of 97.6 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 83 to 133 BPM (octave-uncertain); keys A phrygian, D locrian, G phrygian, A ionian; mix width -21 to -7 dB; chord changes 10 to 49 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 01. Untitled (A1): drums group `drums-1` (419 notes, 49% of the track's note energy)
- In synth terms: low thump, soft attack, falls 32 dB/s, centered.
- Hear it at: 2:37.4 (B1, 0.19 s, +23 dB alone), 2:50.9 (B1, 0.19 s, +22 dB alone), 2:40.5 (G#1, 0.24 s, +23 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 62 (52 to 68) Hz; attack 44 (23 to 144) ms; decay -32 (-53 to -5) dB/s
  - brightness at the start 107 (80 to 312) Hz; slope over the note 0.00 (-0.24 to 0.42) octaves
  - harmonic share 0.93 (0.11 to 0.99); partials off whole multiples 132 (55 to 194) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.6 (-1.4 to -0.4) dB; pan 0.03 (-0.04 to 0.07); left-right correlation 0.82 (0.61 to 0.92)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S2. 04. Untitled (B2): drums group `drums-1` (342 notes, 43% of the track's note energy)
- In synth terms: low thump, quick attack, falls 36 dB/s, centered.
- Hear it at: 0:03.5 (G#2, 0.17 s, +41 dB alone), 4:29.3 (G#1, 0.17 s, +38 dB alone), 4:32.5 (?, 0.13 s, +36 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 55 (34 to 72) Hz; attack 39 (16 to 106) ms; decay -36 (-60 to -9) dB/s
  - brightness at the start 151 (137 to 173) Hz; slope over the note 0.00 (0.00 to 0.00) octaves
  - harmonic share 0.58 (0.19 to 0.77); partials off whole multiples 145 (31 to 215) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-0.6 to -0.1) dB; pan -0.02 (-0.04 to -0.01); left-right correlation 0.98 (0.96 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S3. 02. Untitled (A2): bass group `bass-1` (366 notes, 35% of the track's note energy)
- In synth terms: around D2, bell- or metal-like (partials off whole multiples), soft attack, falls 36 dB/s, centered.
- Hear it at: 7:43.7 (D2, 0.28 s, +32 dB alone), 7:43.8 (D2, 0.33 s, +30 dB alone), 7:44.2 (D2, 0.28 s, +30 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 75 (67 to 100) Hz; attack 58 (39 to 94) ms; decay -36 (-346 to -5) dB/s
  - brightness at the start 75 (69 to 101) Hz; slope over the note 0.03 (-0.00 to 0.13) octaves
  - harmonic share 0.98 (0.96 to 1.00); partials off whole multiples 191 (0 to 411) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.2 (-4.2 to -0.8) dB; pan -0.01 (-0.02 to -0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S4. 03. Untitled (B1): drums group `drums-1` (351 notes, 28% of the track's note energy)
- In synth terms: low thump, quick attack, falls 43 dB/s, centered.
- Hear it at: 5:52.8 (G1, 0.22 s, +48 dB alone), 5:45.2 (A#1, 0.12 s, +47 dB alone), 5:42.4 (F#1, 0.11 s, +45 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (50 to 61) Hz; attack 32 (15 to 68) ms; decay -43 (-115 to -18) dB/s
  - brightness at the start 104 (84 to 138) Hz; slope over the note 0.00 (-0.12 to 0.03) octaves
  - harmonic share 0.96 (0.16 to 1.00); partials off whole multiples 151 (49 to 283) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-0.8 to -0.1) dB; pan -0.03 (-0.04 to -0.02); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. 02. Untitled (A2): drums group `drums-1` (305 notes, 25% of the track's note energy)
- In synth terms: mid snap, soft attack, falls 106 dB/s, centered.
- Hear it at: 2:13.7 (A#1, 0.14 s, +42 dB alone), 7:25.2 (B1, 0.14 s, +42 dB alone), 2:05.9 (A#1, 0.17 s, +41 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 59 (35 to 65) Hz; attack 73 (64 to 82) ms; decay -106 (-258 to -76) dB/s
  - brightness at the start 527 (314 to 903) Hz; slope over the note 0.00 (0.00 to 2.47) octaves
  - harmonic share 0.90 (0.73 to 0.98); partials off whole multiples 91 (14 to 146) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.2 (-2.2 to -0.0) dB; pan -0.01 (-0.02 to -0.01); left-right correlation 0.99 (0.94 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S6. 01. Untitled (A1): other group `other-1` (294 notes, 23% of the track's note energy)
- In synth terms: around F#3, bell- or metal-like (partials off whole multiples), quick attack, falls 44 dB/s, centered.
- Hear it at: 2:10.1 (A3, 0.23 s, +48 dB alone), 2:14.0 (F#3, 0.22 s, +46 dB alone), 2:13.6 (A3, 0.09 s, +46 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 186 (158 to 270) Hz; attack 31 (7 to 172) ms; decay -44 (-97 to -7) dB/s
  - brightness at the start 1073 (571 to 1803) Hz; slope over the note 0.00 (-0.75 to 0.21) octaves
  - harmonic share 0.48 (0.11 to 0.93); partials off whole multiples 79 (26 to 203) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-7.3 to -0.8) dB; pan -0.04 (-0.11 to 0.02); left-right correlation 0.63 (0.48 to 0.78)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. 04. Untitled (B2): drums group `drums-2` (116 notes, 20% of the track's note energy)
- In synth terms: low thump, soft attack, falls 31 dB/s, centered.
- Hear it at: 0:01.9 (G2, 0.15 s, +43 dB alone), 0:05.6 (F#2, 0.16 s, +39 dB alone), 0:00.8 (A#1, 0.21 s, +36 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 57 (45 to 93) Hz; attack 41 (19 to 87) ms; decay -31 (-70 to -11) dB/s
  - brightness at the start 119 (99 to 133) Hz; slope over the note 0.00 (-0.16 to 0.42) octaves
  - harmonic share 0.74 (0.22 to 0.95); partials off whole multiples 127 (42 to 272) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.2 (-0.5 to -0.1) dB; pan -0.02 (-0.04 to -0.01); left-right correlation 0.98 (0.97 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. 03. Untitled (B1): drums group `drums-2` (149 notes, 18% of the track's note energy)
- In synth terms: low thump, soft attack, falls 30 dB/s, centered.
- Hear it at: 5:42.2 (A1, 0.2 s, +46 dB alone), 5:44.1 (A1, 0.19 s, +46 dB alone), 5:52.6 (D#2, 0.07 s, +46 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 55 (43 to 60) Hz; attack 46 (19 to 113) ms; decay -30 (-76 to -3) dB/s
  - brightness at the start 162 (145 to 201) Hz; slope over the note 0.00 (-0.74 to 0.00) octaves
  - harmonic share 0.60 (0.04 to 0.97); partials off whole multiples 180 (100 to 251) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-0.6 to -0.1) dB; pan -0.03 (-0.05 to -0.02); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **01. Untitled (A1) sections:** 14 boundaries at 0:02.0, 0:49.0, 1:08.0, 1:18.0, 2:07.0, 2:18.0, 2:53.0, 3:17.0, 3:37.0, 4:28.0, 4:50.0, 5:11.0; section lengths median 21 s (range 2 to 51). Reliable for sections of 10 s or more.
- **01. Untitled (A1) stem entries and exits:** drums plays 72% of the time (in: 0:47.0, 2:16.5, 3:14.5, 4:48.5; out: 2:07.5, 2:53.0, 4:28.5, 5:53.0); bass plays 32% of the time (in: 1:16.0, 1:28.0, 2:21.0, 3:41.5, 5:05.0; out: 1:24.0, 1:59.0, 2:51.5, 4:02.0, 5:11.0); other plays 100% of the time (in: from the start; out: never); vocals plays 39% of the time (in: 0:59.0, 1:40.0, 2:24.0, 2:55.5, 3:29.0; out: 0:49.0, 1:07.0, 1:45.5, 2:26.5, 3:24.5).
- **01. Untitled (A1) floor drops:** low end too sparse to say (on in under 75% of the track).
- **01. Untitled (A1) brightness sweeps (0.7 octave or more):** mix up 1.2 oct 0:12.5 to 0:18.0; mix down 1.1 oct 0:57.0 to 1:03.5; mix down 0.7 oct 1:05.0 to 1:10.0; mix down 1.7 oct 1:13.0 to 1:19.0; mix up 2.1 oct 1:33.5 to 1:38.5; mix up 2.5 oct 1:49.0 to 1:54.0; mix down 2.3 oct 2:14.5 to 2:24.0; mix up 3.1 oct 2:47.5 to 2:55.5 (33 more in techniques.json).
- **01. Untitled (A1) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **01. Untitled (A1) pumping locked to the kick:** bass dips 2.3 dB at the kick (peak 354 ms after, kick every 0.55 s). The tool reads about 70% of the true depth, so this is a floor.
- **01. Untitled (A1) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **01. Untitled (A1) stereo movement:** bass pan range 0.40; other pan range 0.15, cycling every 4 s.
- **02. Untitled (A2) sections:** 22 boundaries at 0:03.0, 0:26.0, 0:41.0, 1:06.0, 1:22.0, 1:52.0, 2:03.0, 2:23.0, 2:33.0, 2:52.0, 3:04.0, 3:46.0; section lengths median 16 s (range 1 to 60). Reliable for sections of 10 s or more.
- **02. Untitled (A2) stem entries and exits:** drums plays 99% of the time (in: 0:02.0; out: 7:43.5); bass plays 88% of the time (in: 0:32.0, 0:51.5, 1:03.0, 6:04.5; out: 0:39.5, 0:59.5, 5:55.0); other plays 99% of the time (in: 0:03.0; out: never); vocals plays 26% of the time (in: 2:51.0, 4:37.5; out: 4:00.0, 5:28.0).
- **02. Untitled (A2) floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **02. Untitled (A2) brightness sweeps (0.7 octave or more):** mix up 2.1 oct 0:00.0 to 0:09.0; mix down 2.2 oct 0:09.0 to 0:22.0; mix up 3.4 oct 0:22.5 to 0:30.5; mix down 3.3 oct 0:30.5 to 0:42.0; mix up 2.7 oct 0:42.5 to 0:52.5; mix down 1.8 oct 0:53.0 to 1:01.5; mix up 2.1 oct 1:02.0 to 1:08.5; mix down 1.8 oct 1:13.0 to 1:21.0 (67 more in techniques.json).
- **02. Untitled (A2) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **02. Untitled (A2) pumping locked to the kick:** other dips 3.5 dB at the kick (peak 10 ms after, kick every 0.49 s); bass dips 21.9 dB at the kick (peak 429 ms after, kick every 0.49 s). The tool reads about 70% of the true depth, so this is a floor.
- **02. Untitled (A2) tape wobble and speed:** other wobbles about 21 cents at 0.5 Hz.
- **02. Untitled (A2) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **03. Untitled (B1) sections:** 17 boundaries at 0:22.0, 0:41.0, 1:08.0, 1:33.0, 1:57.0, 2:11.0, 2:21.0, 2:44.0, 3:04.0, 3:50.0, 4:19.0, 4:43.0; section lengths median 20 s (range 4 to 46). Reliable for sections of 10 s or more.
- **03. Untitled (B1) stem entries and exits:** drums plays 86% of the time (in: 0:09.0, 3:48.0; out: 3:10.0, 5:55.5); bass plays 98% of the time (in: 5:45.0; out: 5:42.5, 5:54.0); other plays 94% of the time (in: 1:16.0; out: 1:11.5, 5:40.0); vocals plays 0% of the time (in: from the start; out: never).
- **03. Untitled (B1) floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **03. Untitled (B1) brightness sweeps (0.7 octave or more):** mix down 1.2 oct 0:19.0 to 0:24.5; mix up 0.7 oct 0:25.5 to 0:30.5; mix down 0.7 oct 0:31.0 to 0:37.0; mix up 0.8 oct 0:37.5 to 0:43.0; mix up 0.8 oct 0:59.0 to 1:06.5; mix up 0.9 oct 1:25.5 to 1:30.5; mix down 1.2 oct 1:42.0 to 1:49.0; mix down 1.4 oct 2:08.5 to 2:13.5 (35 more in techniques.json).
- **03. Untitled (B1) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **03. Untitled (B1) pumping locked to the kick:** bass dips 2.5 dB at the kick (peak 90 ms after, kick every 0.39 s). The tool reads about 70% of the true depth, so this is a floor.
- **03. Untitled (B1) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **03. Untitled (B1) stereo movement:** bass pan range 0.13, cycling every 5 s.
- **03. Untitled (B1) builds:** 0:00.0 to 0:21.0.
- **04. Untitled (B2) sections:** 11 boundaries at 0:02.0, 0:44.0, 1:16.0, 1:45.0, 2:32.0, 2:42.0, 3:07.0, 4:02.0, 4:43.0, 5:09.0, 5:50.0; section lengths median 30 s (range 2 to 55). Reliable for sections of 10 s or more.
- **04. Untitled (B2) stem entries and exits:** drums plays 100% of the time (in: from the start; out: never); bass plays 87% of the time (in: 3:02.5, 4:39.5; out: 2:46.0, 4:19.5, 5:44.0); other plays 91% of the time (in: 0:37.5; out: 0:07.5); vocals plays 0% of the time (in: from the start; out: never).
- **04. Untitled (B2) floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **04. Untitled (B2) brightness sweeps (0.7 octave or more):** mix up 4.5 oct 3:04.5 to 3:11.0; mix down 1.2 oct 3:34.0 to 3:42.5; mix up 2.3 oct 3:47.0 to 3:52.0; mix down 2.8 oct 3:55.0 to 4:03.5; mix down 0.9 oct 4:08.5 to 4:16.5; mix up 3.1 oct 4:40.5 to 4:48.0; mix down 2.4 oct 4:48.0 to 4:53.5; other up 1.5 oct 0:00.0 to 0:10.5 (15 more in techniques.json).
- **04. Untitled (B2) echo times:** other: 414 ms (+3.3 dB, 2 later repeats).
- **04. Untitled (B2) pumping locked to the kick:** under 1.5 dB; none found.
- **04. Untitled (B2) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **04. Untitled (B2) stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **01. Untitled (A1) meter:** about 133 BPM (could be 67 or 266; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:3, 5:4), which means irregular timing, not a cross-rhythm claim.
- **01. Untitled (A1) key and mode:** A phrygian (low confidence: the key signature margin is 0.012, so read this as a guess); pitch-class weights A 0.11, F 0.09, F# 0.09, A# 0.09, C 0.09.
- **01. Untitled (A1) chords:** 37 changes a minute (8 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.5 to 2.2 s); 35 distinct chords; most time on Amaj7 26%, Fmaj7 22%, Amin7 4%, D7 4%. The old counter in this same run said 8; Ears 1's 2-s counter said 5.  79% of the changes land on a beat (chance would be 67%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **01. Untitled (A1) bass:** root-note movement / mixed; 0.19 notes a second; most time on A 0.56, B 0.27, C 0.06, A# 0.05; steps 43%, thirds 10%, fourths and fifths 0%, octaves 0%, repeats 44%.
- **01. Untitled (A1) top line (from the 'other' stem; read by ear before trusting):** 915 notes, range 15 semitones (10th to 90th percentile); steps 25%, thirds 13%, fourths and fifths 23%, leaps 20%, repeats 19%; median interval 3 semitones; 49% of moves go up; phrases of about 8 notes, arch 36%, rising 19%, falling 26%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **01. Untitled (A1) repetition:** 395 bars of 0.9 s; strongest repeat distances 4 bars (0.72), 1 bars (0.61), 8 bars (0.57); 7% of bars near-duplicate an earlier bar.
- **02. Untitled (A2) meter:** about 123 BPM (could be 62 or 246; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.25); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **02. Untitled (A2) key and mode:** D locrian (low confidence: the key signature margin is 0.001, so read this as a guess); pitch-class weights D 0.18, D# 0.14, F 0.11, C# 0.09, F# 0.08.
- **02. Untitled (A2) chords:** 45 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 0.8 s (10th to 90th percentile 0.4 to 3.3 s); 23 distinct chords; most time on D#maj7 29%, Fmaj7 21%, Amin7 11%, C#maj7 9%. The old counter in this same run said 2; Ears 1's 2-s counter said 0.  68% of the changes land on a beat (chance would be 62%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **02. Untitled (A2) bass:** root-note movement / mixed; 1.31 notes a second; most time on A 0.56, D 0.19, F 0.09, D# 0.04; steps 19%, thirds 23%, fourths and fifths 12%, octaves 1%, repeats 40%.
- **02. Untitled (A2) top line (from the 'other' stem; read by ear before trusting):** 1134 notes, range 8 semitones (10th to 90th percentile); steps 17%, thirds 27%, fourths and fifths 33%, leaps 6%, repeats 18%; median interval 3 semitones; 50% of moves go up; phrases of about 10 notes, arch 28%, rising 31%, falling 9%, flat or wavy 32%. Reliable only when the line sits clearly above its accompaniment.
- **02. Untitled (A2) repetition:** 238 bars of 2.0 s; strongest repeat distances 4 bars (0.84), 8 bars (0.71), 2 bars (0.65); 27% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **03. Untitled (B1) meter:** about 83 BPM (could be 42 or 167; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **03. Untitled (B1) key and mode:** G phrygian (low confidence: the key signature margin is 0.011, so read this as a guess); pitch-class weights F 0.13, D 0.13, G 0.12, D# 0.10, F# 0.08.
- **03. Untitled (B1) chords:** 49 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 1.1 s (10th to 90th percentile 0.5 to 2.2 s); 17 distinct chords; most time on D#maj7 29%, F5 17%, G5 12%, F7 8%. The old counter in this same run said 21; Ears 1's 2-s counter said 2.  40% of the changes land on a beat (chance would be 42%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **03. Untitled (B1) bass:** root-note movement / mixed; 0.89 notes a second; most time on G 0.42, F 0.27, D 0.16, A 0.12; steps 21%, thirds 17%, fourths and fifths 10%, octaves 3%, repeats 38%.
- **03. Untitled (B1) top line (from the 'other' stem; read by ear before trusting):** 721 notes, range 15 semitones (10th to 90th percentile); steps 18%, thirds 20%, fourths and fifths 0%, leaps 30%, repeats 32%; median interval 3 semitones; 50% of moves go up; phrases of about 9 notes, arch 45%, rising 13%, falling 23%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **03. Untitled (B1) repetition:** 124 bars of 2.9 s; strongest repeat distances 4 bars (0.60), 1 bars (0.56), 8 bars (0.40); 5% of bars near-duplicate an earlier bar.
- **04. Untitled (B2) meter:** about 97 BPM (could be 49 or 195; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.66 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **04. Untitled (B2) key and mode:** A ionian (major) (key signature margin 0.031); pitch-class weights D 0.12, C# 0.11, A 0.11, G# 0.10, A# 0.08.
- **04. Untitled (B2) chords:** 10 changes a minute (7 a minute are chords that last 1.5 s or more); median chord 2.4 s (10th to 90th percentile 0.8 to 14.7 s); 18 distinct chords; most time on Dmaj7 63%, Amaj7 13%, Emaj7 8%, A#maj7 4%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  46% of the changes land on a beat (chance would be 49%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **04. Untitled (B2) bass:** root-note movement / mixed; 0.09 notes a second; most time on A 0.38, C 0.33, B 0.15, D 0.05; steps 16%, thirds 42%, fourths and fifths 16%, octaves 0%, repeats 16%.
- **04. Untitled (B2) top line (from the 'other' stem; read by ear before trusting):** 983 notes, range 8 semitones (10th to 90th percentile); steps 19%, thirds 49%, fourths and fifths 8%, leaps 4%, repeats 19%; median interval 3 semitones; 51% of moves go up; phrases of about 15 notes, arch 25%, rising 25%, falling 5%, flat or wavy 45%. Reliable only when the line sits clearly above its accompaniment.
- **04. Untitled (B2) repetition:** 142 bars of 2.5 s; strongest repeat distances 1 bars (0.68), 6 bars (0.48), 12 bars (0.27); 5% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **01. Untitled (A1) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -13 (corr 0.90); low_120_500 -3 (corr 0.37); mid_500_2k -3 (corr 0.29); pres_2k_5k -4 (corr 0.49); air_gt5k -11 (corr 0.87); over time (2-s windows) 10th/50th/90th percentile -6/-3/-2 dB.
- **01. Untitled (A1) by part:** drums: 82% of the power, width -7 dB, pan -0.00, mono loss 0.7 dB, widest in low_120_500 (-3 dB); bass: 1% of the power, width -12 dB, pan -0.14, mono loss 0.3 dB, widest in sub_lt120 (-13 dB); other: 15% of the power, width -5 dB, pan -0.09, mono loss 1.2 dB, widest in pres_2k_5k (-5 dB); vocals: 1% of the power, width -6 dB, pan -0.13, mono loss 1.1 dB, widest in low_120_500 (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **02. Untitled (A2) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -28 (corr 1.00); low_120_500 -17 (corr 0.96); mid_500_2k -6 (corr 0.59); pres_2k_5k -1 (corr 0.11); air_gt5k -6 (corr 0.57); over time (2-s windows) 10th/50th/90th percentile -17/-14/-4 dB.
- **02. Untitled (A2) by part:** drums: 69% of the power, width -17 dB, pan -0.03, mono loss 0.1 dB, widest in sub_lt120 (-33 dB); bass: 30% of the power, width -34 dB, pan -0.02, mono loss 0.0 dB, widest in sub_lt120 (-35 dB); other: 1% of the power, width -5 dB, pan -0.05, mono loss 1.3 dB, widest in sub_lt120 (-1 dB); vocals: 0% of the power, width -3 dB, pan +0.02, mono loss 1.6 dB, widest in mid_500_2k (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **03. Untitled (B1) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 1.00); low_120_500 -17 (corr 0.97); mid_500_2k -6 (corr 0.61); pres_2k_5k -8 (corr 0.74); air_gt5k -17 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -19/-17/-14 dB.
- **03. Untitled (B1) by part:** drums: 84% of the power, width -24 dB, pan -0.07, mono loss 0.0 dB, widest in low_120_500 (-21 dB); bass: 13% of the power, width -18 dB, pan -0.07, mono loss 0.1 dB, widest in low_120_500 (-18 dB); other: 2% of the power, width -11 dB, pan -0.05, mono loss 0.4 dB, widest in low_120_500 (-14 dB); vocals: 0% of the power, width -15 dB, pan -0.04, mono loss 0.2 dB, widest in sub_lt120 (-13 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **04. Untitled (B2) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.98); low_120_500 -14 (corr 0.93); mid_500_2k -12 (corr 0.87); pres_2k_5k -12 (corr 0.89); air_gt5k -11 (corr 0.88); over time (2-s windows) 10th/50th/90th percentile -15/-14/-13 dB.
- **04. Untitled (B2) by part:** drums: 86% of the power, width -18 dB, pan -0.04, mono loss 0.1 dB, widest in low_120_500 (-15 dB); bass: 12% of the power, width -28 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-28 dB); other: 2% of the power, width -6 dB, pan -0.20, mono loss 1.0 dB, widest in low_120_500 (-5 dB); vocals: 0% of the power, width -9 dB, pan -0.00, mono loss 0.5 dB, widest in mid_500_2k (-6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 01. Untitled (A1): 133 BPM, 8 settled chords a minute, 5% of energy above 2 kHz, width -7 dB; 02. Untitled (A2): 123 BPM, 9 settled chords a minute, 6% of energy above 2 kHz, width -18 dB; 03. Untitled (B1): 83 BPM, 13 settled chords a minute, 1% of energy above 2 kHz, width -21 dB; 04. Untitled (B2): 97 BPM, 7 settled chords a minute, 2% of energy above 2 kHz, width -16 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- 04. Untitled (B2), bass group `bass-1` (363 notes): around G#1, bell- or metal-like (partials off whole multiples), soft attack, falls 25 dB/s, centered; hear it at 4:54.6, 3:29.8. **[JUDGMENT]** why it waits.
- 03. Untitled (B1), other group `other-1` (332 notes): around F3, bell- or metal-like (partials off whole multiples), soft attack, falls 38 dB/s, centered; hear it at 0:03.5, 0:02.7. **[JUDGMENT]** why it waits.
- 02. Untitled (A2), drums group `drums-2` (147 notes): low thump, soft attack, falls 266 dB/s, gets brighter over the note, centered; hear it at 7:13.6, 7:21.4. **[JUDGMENT]** why it waits.
- 02. Untitled (A2), bass group `bass-2` (134 notes): around F1, harmonic (string/reed/pad-like), soft attack, falls 62 dB/s, centered; hear it at 7:43.3, 7:43.2. **[JUDGMENT]** why it waits.
- 03. Untitled (B1), bass group `bass-1` (268 notes): around A1, bell- or metal-like (partials off whole multiples), soft attack, falls 25 dB/s, centered; hear it at 3:11.9, 3:10.7. **[JUDGMENT]** why it waits.
- 03. Untitled (B1), bass group `bass-2` (232 notes): around F3, bell- or metal-like (partials off whole multiples), soft attack, falls 27 dB/s, centered; hear it at 3:11.2, 3:10.8. **[JUDGMENT]** why it waits.
- 01. Untitled (A1), other group `other-2` (206 notes): around B1, mixed or noisy partials, quick attack, falls 55 dB/s, centered; hear it at 2:13.7, 2:08.6. **[JUDGMENT]** why it waits.
- 03. Untitled (B1), other group `other-2` (168 notes): around G1, mixed or noisy partials, soft attack, falls 37 dB/s, centered; hear it at 3:44.0, 0:02.2. **[JUDGMENT]** why it waits.
