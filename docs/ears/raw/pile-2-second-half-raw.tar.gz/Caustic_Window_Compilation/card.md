## Caustic Window - Compilation (draft card from Ears 3 tools, 2026-10-18)

How it was made: 12 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: Joyrex J4; Cordialatron; AFX 114; Fantasia. Typical track: Joyrex J4. Least like the rest: Cordialatron, AFX 114, Fantasia.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Joyrex J4**: share of power drums 81%, bass 15%, other 2%, vocals 1%.
  - other stem holds 2.5% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.6%: bleed on an instrumental, not a voice.
  - meter tool 98 BPM is two thirds of the drum-grid beat of 147.8 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Cordialatron**: share of power drums 47%, bass 27%, other 25%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 64 BPM is three quarters of the drum-grid beat of 84.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **AFX 114**: share of power drums 72%, bass 0%, other 28%, vocals 0%.
  - bass stem is near empty (0.4%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 74 BPM is double the drum-grid beat of 37.2 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Fantasia**: share of power drums 74%, bass 2%, other 4%, vocals 21%.
  - bass stem is near empty (1.9%): bass notes, pumping and wobble are void.
  - other stem holds 3.7% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - meter tool 102 BPM does not match the drum-grid beat of 38.3 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 64 to 102 BPM (octave-uncertain); keys D# lydian, F dorian, C# ionian, G lydian; mix width -30 to -8 dB; chord changes 8 to 46 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. AFX 114: drums group `drums-1` (105 notes, 48% of the track's note energy)
- In synth terms: low thump, soft attack, falls 39 dB/s, gets brighter over the note, centered.
- Hear it at: 0:01.5 (A1, 0.35 s, +16 dB alone), 0:09.3 (G#1, 0.62 s, +14 dB alone), 0:23.8 (G#1, 0.6 s, +14 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (51 to 63) Hz; attack 100 (36 to 326) ms; decay -39 (-65 to -4) dB/s
  - brightness at the start 207 (163 to 313) Hz; slope over the note 2.03 (0.28 to 3.71) octaves
  - harmonic share 0.20 (0.13 to 0.76); partials off whole multiples 152 (41 to 283) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.6 (-3.2 to -0.6) dB; pan -0.01 (-0.03 to 0.02); left-right correlation 0.67 (0.48 to 0.82)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S2. Joyrex J4: drums group `drums-1` (394 notes, 41% of the track's note energy)
- In synth terms: low thump, quick attack, falls 24 dB/s, centered.
- Hear it at: 3:44.3 (C2, 0.13 s, +43 dB alone), 1:08.8 (C2, 0.14 s, +42 dB alone), 1:10.2 (C2, 0.33 s, +41 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 65 (50 to 69) Hz; attack 38 (19 to 114) ms; decay -24 (-52 to 23) dB/s
  - brightness at the start 186 (110 to 300) Hz; slope over the note 0.00 (-0.56 to 0.52) octaves
  - harmonic share 0.88 (0.19 to 0.96); partials off whole multiples 157 (104 to 291) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.3 (-0.5 to -0.1) dB; pan -0.02 (-0.04 to -0.01); left-right correlation 0.99 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S3. Fantasia: vocals group `vocals-1` (462 notes, 40% of the track's note energy)
- In synth terms: around G#2, bell- or metal-like (partials off whole multiples), soft attack, falls 30 dB/s, centered.
- Hear it at: 2:27.1 (D#4, 1.4 s, +40 dB alone), 2:28.5 (F4, 0.41 s, +42 dB alone), 2:23.9 (D#4, 1.4 s, +37 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 102 (58 to 306) Hz; attack 129 (39 to 702) ms; decay -30 (-155 to -2) dB/s
  - brightness at the start 1816 (705 to 4149) Hz; slope over the note 0.00 (-1.34 to 0.99) octaves
  - harmonic share 0.40 (0.13 to 0.81); partials off whole multiples 66 (25 to 125) cents
  - vibrato 0 (0 to 37) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.6 (-13.8 to -0.8) dB; pan -0.00 (-0.01 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

#### S4. Cordialatron: other group `other-1` (500 notes, 38% of the track's note energy)
- In synth terms: around A#2, mixed or noisy partials, soft attack, falls 25 dB/s, centered.
- Hear it at: 0:21.7 (C3, 0.26 s, +56 dB alone), 0:24.4 (A#2, 0.29 s, +55 dB alone), 0:25.4 (C3, 0.23 s, +56 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 116 (65 to 292) Hz; attack 99 (17 to 260) ms; decay -25 (-55 to -0) dB/s
  - brightness at the start 595 (473 to 807) Hz; slope over the note -0.01 (-0.25 to 0.16) octaves
  - harmonic share 0.70 (0.15 to 0.92); partials off whole multiples 50 (13 to 127) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.3 (-9.4 to -1.1) dB; pan 0.04 (-0.05 to 0.14); left-right correlation 0.45 (0.21 to 0.69)
- Group quality: weak (silhouette 0.15, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. AFX 114: other group `other-1` (345 notes, 22% of the track's note energy)
- In synth terms: around D#1, bell- or metal-like (partials off whole multiples), soft attack, falls 85 dB/s, centered.
- Hear it at: 0:49.6 (?, 0.24 s, +9 dB alone), 1:10.3 (C1, 0.11 s, +6 dB alone), 0:50.1 (E1, 0.09 s, +5 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 38 (32 to 43) Hz; attack 55 (20 to 194) ms; decay -85 (-298 to -0) dB/s
  - brightness at the start 145 (118 to 243) Hz; slope over the note 0.00 (-0.22 to 0.31) octaves
  - harmonic share 0.22 (0.08 to 0.60); partials off whole multiples 148 (75 to 230) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -10.0 (-20.9 to -3.3) dB; pan -0.04 (-0.07 to -0.01); left-right correlation 0.99 (0.96 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. Joyrex J4: bass group `bass-1` (187 notes, 20% of the track's note energy)
- In synth terms: around A1, bell- or metal-like (partials off whole multiples), slow swell, falls 13 dB/s, gets darker over the note, centered.
- Hear it at: 1:37.8 (B1, 0.38 s, +28 dB alone), 1:40.8 (G1, 0.52 s, +25 dB alone), 1:40.3 (F#1, 0.39 s, +25 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 54 (39 to 74) Hz; attack 295 (68 to 595) ms; decay -13 (-125 to 3) dB/s
  - brightness at the start 886 (331 to 1769) Hz; slope over the note -0.81 (-2.79 to 0.17) octaves
  - harmonic share 0.29 (0.08 to 0.97); partials off whole multiples 104 (15 to 240) cents
  - vibrato 0 (0 to 26) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -8.7 (-10.4 to -0.4) dB; pan -0.03 (-0.06 to 0.00); left-right correlation 0.96 (0.92 to 0.97)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S7. Fantasia: drums group `drums-1` (170 notes, 19% of the track's note energy)
- In synth terms: mid snap, soft attack, falls 9 dB/s, gets darker over the note, centered.
- Hear it at: 5:58.8 (C#2, 0.97 s, +24 dB alone), 5:59.6 (C#2, 0.33 s, +27 dB alone), 5:59.9 (C#1, 0.54 s, +26 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 59 (33 to 80) Hz; attack 59 (30 to 225) ms; decay -9 (-24 to 1) dB/s
  - brightness at the start 415 (131 to 823) Hz; slope over the note -0.63 (-1.77 to 0.55) octaves
  - harmonic share 0.16 (0.04 to 0.42); partials off whole multiples 160 (126 to 263) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.5 (-0.9 to -0.2) dB; pan -0.01 (-0.02 to -0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S8. Cordialatron: bass group `bass-1` (62 notes, 14% of the track's note energy)
- In synth terms: around E1, bell- or metal-like (partials off whole multiples), soft attack, falls 28 dB/s, centered.
- Hear it at: 2:57.9 (E1, 0.11 s, +14 dB alone), 2:42.3 (E1, 0.82 s, +9 dB alone), 0:38.5 (E1, 0.86 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 41 (41 to 42) Hz; attack 45 (28 to 110) ms; decay -28 (-43 to -15) dB/s
  - brightness at the start 118 (98 to 129) Hz; slope over the note -0.00 (-0.50 to 0.63) octaves
  - harmonic share 1.00 (0.96 to 1.00); partials off whole multiples 120 (38 to 239) cents
  - vibrato 7 (0 to 18) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.2 (-15.1 to -1.1) dB; pan 0.00 (-0.03 to 0.03); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Joyrex J4 sections:** 11 boundaries at 0:03.0, 0:14.0, 0:59.0, 1:36.0, 1:56.0, 2:22.0, 2:42.0, 3:07.0, 3:37.0, 3:50.0, 4:22.0; section lengths median 22 s (range 3 to 45). Reliable for sections of 10 s or more.
- **Joyrex J4 stem entries and exits:** drums plays 91% of the time (in: 0:01.5, 0:26.0, 1:41.5; out: 0:14.5, 1:38.5, 4:21.5); bass plays 94% of the time (in: 0:09.0; out: 4:23.0); other plays 97% of the time (in: 0:05.0; out: 4:27.5); vocals plays 44% of the time (in: 1:12.5, 1:45.0, 2:37.0, 2:50.0, 3:49.5; out: 1:35.5, 2:34.0, 2:42.0, 3:06.5, 4:08.0).
- **Joyrex J4 floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **Joyrex J4 brightness sweeps (0.7 octave or more):** mix down 1.8 oct 0:22.0 to 0:32.0; mix up 0.8 oct 0:38.5 to 0:44.5; mix up 0.8 oct 0:45.0 to 0:53.0; mix up 0.9 oct 0:57.0 to 1:02.5; mix down 1.6 oct 1:02.5 to 1:10.5; mix up 3.1 oct 1:10.5 to 1:16.5; mix down 1.4 oct 1:41.5 to 1:49.0; mix up 2.3 oct 2:06.0 to 2:11.5 (31 more in techniques.json).
- **Joyrex J4 echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Joyrex J4 pumping locked to the kick:** other dips 2.8 dB at the kick (peak 110 ms after, kick every 0.41 s); bass dips 4.2 dB at the kick (peak 80 ms after, kick every 0.41 s). The tool reads about 70% of the true depth, so this is a floor.
- **Joyrex J4 tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Joyrex J4 stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Cordialatron sections:** 12 boundaries at 0:14.0, 0:35.0, 0:45.0, 1:00.0, 1:31.0, 2:01.0, 2:31.0, 3:04.0, 3:30.0, 3:51.0, 4:10.0, 4:32.0; section lengths median 21 s (range 10 to 33). Reliable for sections of 10 s or more.
- **Cordialatron stem entries and exits:** drums plays 83% of the time (in: 0:29.5, 1:37.5, 2:15.0, 2:30.0, 4:23.0; out: 0:15.5, 1:31.5, 2:04.0, 2:24.5, 4:17.0); bass plays 26% of the time (in: 0:08.0, 0:41.5, 0:49.0, 1:00.0, 1:11.5; out: 0:14.0, 0:44.0, 0:55.5, 1:06.5, 1:21.5); other plays 96% of the time (in: from the start; out: 4:33.5); vocals plays 0% of the time (in: from the start; out: never).
- **Cordialatron floor drops (kick and bass out 2 s or more while the rest plays):** 1.18 a minute: 0:15.0 for 15.2 s, 1:30.2 for 7.8 s, 2:03.2 for 14.5 s, 2:23.0 for 7.8 s, 4:15.8 for 7.8 s.
- **Cordialatron brightness sweeps (0.7 octave or more):** mix up 0.8 oct 0:13.0 to 0:21.5; mix down 1.9 oct 1:30.0 to 1:35.5; mix up 2.4 oct 1:36.0 to 1:45.0; mix down 1.4 oct 1:45.5 to 1:50.5; mix up 1.4 oct 1:51.5 to 2:04.5; mix up 1.5 oct 2:12.0 to 2:19.0; mix down 1.3 oct 2:19.5 to 2:26.5; mix down 1.3 oct 2:28.0 to 2:33.0 (18 more in techniques.json).
- **Cordialatron echo times:** drums: 234 ms (+9.9 dB, 4 later repeats).
- **Cordialatron pumping locked to the kick:** other dips 3.4 dB at the kick (peak 449 ms after, kick every 0.64 s); bass dips 7.8 dB at the kick (peak 564 ms after, kick every 0.64 s). The tool reads about 70% of the true depth, so this is a floor.
- **Cordialatron tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Cordialatron stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **AFX 114 sections:** 4 boundaries at 0:02.0, 0:30.0, 0:53.0, 1:18.0; section lengths median 23 s (range 2 to 28). Reliable for sections of 10 s or more.
- **AFX 114 stem entries and exits:** drums plays 97% of the time (in: from the start; out: 1:19.0); bass plays 37% of the time (in: 0:05.0, 1:10.5; out: 0:27.0, 1:18.5); other plays 97% of the time (in: from the start; out: 1:18.5); vocals plays 0% of the time (in: from the start; out: never).
- **AFX 114 floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **AFX 114 brightness sweeps (0.7 octave or more):** mix down 2.9 oct 0:00.0 to 0:05.0; mix up 1.4 oct 0:37.5 to 0:48.5; mix down 2.5 oct 0:48.5 to 0:56.0; mix up 3.6 oct 1:13.0 to 1:20.5; other up 2.7 oct 0:28.5 to 0:34.0; other up 2.9 oct 0:38.0 to 0:47.5; other down 4.1 oct 0:47.5 to 0:56.0; other up 1.9 oct 0:56.5 to 1:01.5 (6 more in techniques.json).
- **AFX 114 echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **AFX 114 pumping locked to the kick:** other dips 4.0 dB at the kick (peak 25 ms after, kick every 0.31 s); bass dips 4.1 dB at the kick (peak 220 ms after, kick every 0.31 s). The tool reads about 70% of the true depth, so this is a floor.
- **AFX 114 tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **AFX 114 stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **Fantasia sections:** 12 boundaries at 0:02.0, 0:25.0, 1:04.0, 1:45.0, 1:59.0, 2:31.0, 3:13.0, 4:09.0, 4:30.0, 4:50.0, 5:33.0, 6:00.0; section lengths median 27 s (range 2 to 56). Reliable for sections of 10 s or more.
- **Fantasia stem entries and exits:** drums plays 82% of the time (in: 0:14.5, 0:31.5, 1:58.0, 2:29.0, 4:33.5; out: 0:25.5, 1:54.5, 2:23.0, 4:31.0, 4:51.0); bass plays 72% of the time (in: 0:17.5, 1:03.5, 1:57.5, 2:31.5, 4:00.0; out: 1:00.5, 1:52.5, 2:22.5, 3:56.5, 4:19.5); other plays 98% of the time (in: 2:29.5; out: 2:22.5); vocals plays 97% of the time (in: 1:57.5, 3:51.0; out: 1:54.5, 3:47.0, 6:00.0).
- **Fantasia floor drops (kick and bass out 2 s or more while the rest plays):** 2.03 a minute: 0:24.5 for 7.8 s, 1:46.0 for 3.0 s, 1:54.0 for 4.5 s, 2:22.2 for 7.5 s, 3:14.0 for 3.0 s, 4:21.8 for 3.0 s, 4:30.5 for 3.8 s, 4:50.2 for 3.2 s.
- **Fantasia brightness sweeps (0.7 octave or more):** mix down 4.2 oct 0:17.0 to 0:22.5; mix up 3.0 oct 0:22.5 to 0:28.0; mix down 1.2 oct 0:28.5 to 0:36.0; mix down 0.9 oct 0:40.5 to 0:46.5; mix up 1.2 oct 0:48.0 to 0:53.5; mix up 1.3 oct 0:57.5 to 1:02.5; mix down 3.1 oct 1:02.5 to 1:09.0; mix up 2.6 oct 1:09.0 to 1:16.0 (68 more in techniques.json).
- **Fantasia echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Fantasia pumping locked to the kick:** other dips 3.4 dB at the kick (peak 20 ms after, kick every 0.24 s); bass dips 5.7 dB at the kick (peak 60 ms after, kick every 0.24 s). The tool reads about 70% of the true depth, so this is a floor.
- **Fantasia tape wobble and speed:** other wobbles about 6 cents at 3.6 Hz; bass wobbles about 11 cents at 3.3 Hz.
- **Fantasia stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Joyrex J4 meter:** about 98 BPM (could be 49 or 195; the tool cannot tell the beat level), 2 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **Joyrex J4 key and mode:** D# lydian (low confidence: the key signature margin is 0.015, so read this as a guess); pitch-class weights A 0.12, D# 0.12, F 0.11, E 0.10, G# 0.09.
- **Joyrex J4 chords:** 28 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 0.8 s (10th to 90th percentile 0.5 to 5.5 s); 22 distinct chords; most time on Amaj7 21%, Adim 14%, F7 12%, Fmaj7 11%. The old counter in this same run said 2; Ears 1's 2-s counter said 2.  50% of the changes land on a beat (chance would be 49%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Joyrex J4 bass:** root-note movement / mixed; 0.50 notes a second; most time on D# 0.34, F 0.24, A 0.17, C 0.12; steps 47%, thirds 15%, fourths and fifths 15%, octaves 2%, repeats 16%.
- **Joyrex J4 top line (from the 'other' stem; read by ear before trusting):** 569 notes, range 12 semitones (10th to 90th percentile); steps 42%, thirds 22%, fourths and fifths 5%, leaps 12%, repeats 20%; median interval 2 semitones; 45% of moves go up; phrases of about 21 notes, arch 36%, rising 18%, falling 36%, flat or wavy 9%. Reliable only when the line sits clearly above its accompaniment.
- **Joyrex J4 repetition:** 220 bars of 1.2 s; strongest repeat distances 1 bars (0.74), 8 bars (0.48), 16 bars (0.28); 32% of bars near-duplicate an earlier bar.
- **Cordialatron meter:** about 64 BPM (could be 32 or 128; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.02); swung: off-beat at 0.75 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Cordialatron key and mode:** F dorian (key signature margin 0.031); pitch-class weights F 0.16, D# 0.12, G# 0.12, A# 0.11, C 0.11.
- **Cordialatron chords:** 46 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.6 to 2.2 s); 27 distinct chords; most time on Fmin7 22%, A#5 9%, A#7 8%, D#sus2 6%. The old counter in this same run said 23; Ears 1's 2-s counter said 12.  16% of the changes land on a beat (chance would be 32%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Cordialatron bass:** pedal (one note held or repeated); 0.19 notes a second; most time on E 0.98, A# 0.01; steps 4%, thirds 4%, fourths and fifths 0%, octaves 0%, repeats 89%.
- **Cordialatron top line (from the 'other' stem; read by ear before trusting):** 804 notes, range 13 semitones (10th to 90th percentile); steps 15%, thirds 19%, fourths and fifths 19%, leaps 24%, repeats 23%; median interval 3 semitones; 50% of moves go up; phrases of about 20 notes, arch 45%, rising 9%, falling 23%, flat or wavy 23%. Reliable only when the line sits clearly above its accompaniment.
- **Cordialatron repetition:** 151 bars of 1.9 s; strongest repeat distances 2 bars (0.52), 4 bars (0.47), 8 bars (0.46); 18% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **AFX 114 meter:** about 74 BPM (could be 37 or 148; the tool cannot tell the beat level), bar length unclear (best guess 5, score 0.07); swung: off-beat at 0.62 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **AFX 114 key and mode:** C# ionian (major) (low confidence: the key signature margin is 0.002, so read this as a guess); pitch-class weights E 0.15, C# 0.14, D# 0.12, F 0.11, C 0.09.
- **AFX 114 chords:** 9 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 3.6 s (10th to 90th percentile 1.1 to 13.8 s); 9 distinct chords; most time on C#dim 71%, Fmaj7 8%, C#maj7 7%, A7 6%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  58% of the changes land on a beat (chance would be 37%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **AFX 114 top line (from the 'other' stem; read by ear before trusting):** 189 notes, range 3 semitones (10th to 90th percentile); steps 69%, thirds 6%, fourths and fifths 1%, leaps 1%, repeats 23%; median interval 1 semitones; 44% of moves go up; phrases of about 8 notes, arch 0%, rising 0%, falling 6%, flat or wavy 94%. Reliable only when the line sits clearly above its accompaniment.
- **AFX 114 repetition:** 20 bars of 4.0 s; strongest repeat distances 1 bars (0.41), 6 bars (-0.06); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Fantasia meter:** about 102 BPM (could be 51 or 204; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.25); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **Fantasia key and mode:** G lydian (key signature margin 0.031); pitch-class weights F# 0.11, G 0.11, C# 0.10, D 0.09, A 0.09.
- **Fantasia chords:** 8 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 4.0 s (10th to 90th percentile 0.3 to 19.7 s); 17 distinct chords; most time on Dmaj7 61%, Gmaj7 20%, F#min7 7%, F#maj7 4%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  42% of the changes land on a beat (chance would be 51%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Fantasia bass:** root-note movement / mixed; 0.03 notes a second; most time on G 0.64, E 0.18, D 0.09, G# 0.07; steps 9%, thirds 0%, fourths and fifths 18%, octaves 0%, repeats 55%.
- **Fantasia top line (from the 'other' stem; read by ear before trusting):** 958 notes, range 34 semitones (10th to 90th percentile); steps 16%, thirds 6%, fourths and fifths 25%, leaps 37%, repeats 16%; median interval 6 semitones; 50% of moves go up; phrases of about 16 notes, arch 24%, rising 32%, falling 24%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **Fantasia repetition:** 154 bars of 2.4 s; strongest repeat distances 1 bars (0.61), 14 bars (0.24), 32 bars (-0.00); 11% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Joyrex J4 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -16 (corr 0.96); low_120_500 -13 (corr 0.90); mid_500_2k -11 (corr 0.85); pres_2k_5k -20 (corr 0.98); air_gt5k -11 (corr 0.87); over time (2-s windows) 10th/50th/90th percentile -16/-13/-8 dB.
- **Joyrex J4 by part:** drums: 81% of the power, width -20 dB, pan -0.04, mono loss 0.0 dB, widest in sub_lt120 (-22 dB); bass: 16% of the power, width -15 dB, pan -0.04, mono loss 0.1 dB, widest in sub_lt120 (-15 dB); other: 3% of the power, width -7 dB, pan -0.06, mono loss 0.8 dB, widest in sub_lt120 (-5 dB); vocals: 1% of the power, width -16 dB, pan +0.01, mono loss 0.1 dB, widest in mid_500_2k (-12 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Cordialatron mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -27 (corr 1.00); low_120_500 -5 (corr 0.54); mid_500_2k -4 (corr 0.46); pres_2k_5k -4 (corr 0.42); air_gt5k -2 (corr 0.24); over time (2-s windows) 10th/50th/90th percentile -6/-4/-2 dB.
- **Cordialatron by part:** drums: 44% of the power, width -11 dB, pan +0.06, mono loss 0.4 dB, widest in air_gt5k (-2 dB); bass: 24% of the power, width -28 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-28 dB); other: 31% of the power, width -4 dB, pan +0.08, mono loss 1.5 dB, widest in low_120_500 (-3 dB); vocals: 0% of the power, width -8 dB, pan +0.02, mono loss 0.7 dB, widest in mid_500_2k (-8 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **AFX 114 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -24 (corr 0.99); low_120_500 -22 (corr 0.99); mid_500_2k -13 (corr 0.90); pres_2k_5k 1 (corr -0.13); air_gt5k 8 (corr -0.73); over time (2-s windows) 10th/50th/90th percentile -7/-6/-4 dB.
- **AFX 114 by part:** drums: 75% of the power, width -6 dB, pan -0.01, mono loss 0.9 dB, widest in air_gt5k (8 dB); bass: 0% of the power, width -35 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-43 dB); other: 25% of the power, width -14 dB, pan -0.07, mono loss 0.2 dB, widest in sub_lt120 (-21 dB); vocals: 0% of the power, width -7 dB, pan -0.06, mono loss 0.7 dB, widest in pres_2k_5k (-0 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Fantasia mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -33 (corr 1.00); low_120_500 -31 (corr 1.00); mid_500_2k -28 (corr 1.00); pres_2k_5k -31 (corr 1.00); air_gt5k -24 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -30/-29/-27 dB.
- **Fantasia by part:** drums: 74% of the power, width -32 dB, pan -0.02, mono loss 0.0 dB, widest in low_120_500 (-33 dB); bass: 2% of the power, width -48 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-49 dB); other: 4% of the power, width -28 dB, pan -0.01, mono loss 0.0 dB, widest in sub_lt120 (-26 dB); vocals: 21% of the power, width -30 dB, pan -0.01, mono loss 0.0 dB, widest in air_gt5k (-28 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Joyrex J4: 98 BPM, 9 settled chords a minute, 5% of energy above 2 kHz, width -16 dB; Cordialatron: 64 BPM, 12 settled chords a minute, 8% of energy above 2 kHz, width -8 dB; AFX 114: 74 BPM, 6 settled chords a minute, 18% of energy above 2 kHz, width -8 dB; Fantasia: 102 BPM, 6 settled chords a minute, 14% of energy above 2 kHz, width -30 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Cordialatron, drums group `drums-1` (139 notes): mid snap, quick attack, falls 92 dB/s, gets brighter over the note, centered; hear it at 0:56.0, 0:44.7. **[JUDGMENT]** why it waits.
- AFX 114, drums group `drums-2` (76 notes): mid snap, quick attack, falls 83 dB/s, centered; hear it at 1:18.0, 0:00.0. **[JUDGMENT]** why it waits.
- Fantasia, other group `other-1` (345 notes): around C2, mixed or noisy partials, soft attack, falls 36 dB/s, centered; hear it at 1:56.8, 1:57.0. **[JUDGMENT]** why it waits.
- Cordialatron, drums group `drums-2` (72 notes): mid snap, quick attack, falls 95 dB/s, gets brighter over the note, centered; hear it at 0:40.9, 0:33.4. **[JUDGMENT]** why it waits.
- Joyrex J4, bass group `bass-2` (120 notes): around F2, bell- or metal-like (partials off whole multiples), soft attack, falls 99 dB/s, centered; hear it at 0:21.5, 0:19.8. **[JUDGMENT]** why it waits.
- Fantasia, drums group `drums-2` (112 notes): mid snap, slow swell, falls 92 dB/s, centered; hear it at 2:55.2, 3:29.5. **[JUDGMENT]** why it waits.
- AFX 114, other group `other-2` (96 notes): around F1, bell- or metal-like (partials off whole multiples), soft attack, falls 85 dB/s, centered; hear it at 0:50.4, 0:49.8. **[JUDGMENT]** why it waits.
- Joyrex J4, drums group `drums-2` (106 notes): low thump, soft attack, falls 215 dB/s, centered; hear it at 3:46.3, 1:11.6. **[JUDGMENT]** why it waits.
- **Pigeon Street** (0:23.1, 118 BPM by the mix-level count): stands out for pulse strength 0.54 (low, album median 0.82); pitch bends a minute 5.20 (low, album median 40.38). Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **On The Romance Tip** (5:06.1, 144 BPM by the mix-level count): stands out for pitch bends a minute 0.98 (low, album median 40.38); wobble (cents) 2.34 (low, album median 7.14). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
