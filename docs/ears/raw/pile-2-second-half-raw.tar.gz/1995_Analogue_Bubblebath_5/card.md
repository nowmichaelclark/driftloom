## (1995) Analogue Bubblebath 5 (draft card from Ears 3 tools, 2026-10-18)

How it was made: EP or short record (8 usable tracks): every track. Deep pass on: 01 (untitled); 02 (untitled); 04 (untitled); 05 (untitled); 06 (untitled); 07 (untitled); 08 (untitled); 09 (untitled). Typical track: none (EP). Least like the rest: n/a.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **01 (untitled)**: share of power drums 44%, bass 42%, other 11%, vocals 3%.
  - vocals stem holds 2.6%: bleed on an instrumental, not a voice.
  - meter tool 61 BPM agrees with the drum-grid beat of 60.8 BPM.
- **02 (untitled)**: share of power drums 63%, bass 1%, other 33%, vocals 3%.
  - bass stem is near empty (0.9%): bass notes, pumping and wobble are void.
  - vocals stem holds 2.7%: bleed on an instrumental, not a voice.
  - meter tool 76 BPM agrees with the drum-grid beat of 76.0 BPM.
- **04 (untitled)**: share of power drums 74%, bass 25%, other 1%, vocals 0%.
  - other stem holds 1.0% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 98 BPM agrees with the drum-grid beat of 97.6 BPM.
- **05 (untitled)**: share of power drums 98%, bass 0%, other 2%, vocals 0%.
  - bass stem is near empty (0.2%): bass notes, pumping and wobble are void.
  - other stem holds 2.2% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 92 BPM is half of the drum-grid beat of 184.6 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **06 (untitled)**: share of power drums 51%, bass 37%, other 10%, vocals 1%.
  - vocals stem holds 1.3%: bleed on an instrumental, not a voice.
  - meter tool 89 BPM is half of the drum-grid beat of 178.0 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **07 (untitled)**: share of power drums 74%, bass 23%, other 3%, vocals 0%.
  - other stem holds 2.9% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 122 BPM agrees with the drum-grid beat of 123.0 BPM.
- **08 (untitled)**: share of power drums 69%, bass 8%, other 24%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 106 BPM is double the drum-grid beat of 52.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **09 (untitled)**: share of power drums 85%, bass 13%, other 2%, vocals 1%.
  - other stem holds 1.5% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 0.6%: bleed on an instrumental, not a voice.
  - meter tool 69 BPM is half of the drum-grid beat of 136.1 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 61 to 122 BPM (octave-uncertain); keys E lydian, G aeolian, F# lydian, D# phrygian, A# aeolian, A mixolydian, D aeolian, G dorian; mix width -21 to -10 dB; chord changes 11 to 48 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 05 (untitled): drums group `drums-1` (371 notes, 56% of the track's note energy)
- In synth terms: low thump, quick attack, falls 53 dB/s, centered.
- Hear it at: 0:08.4 (F#1, 0.23 s, +46 dB alone), 0:16.8 (F#1, 0.12 s, +46 dB alone), 0:01.1 (B1, 0.14 s, +46 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 50 (43 to 89) Hz; attack 33 (19 to 62) ms; decay -53 (-115 to -14) dB/s
  - brightness at the start 99 (81 to 143) Hz; slope over the note 0.00 (-0.13 to 1.03) octaves
  - harmonic share 0.90 (0.05 to 0.99); partials off whole multiples 164 (90 to 309) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.0 (-0.1 to -0.0) dB; pan 0.05 (0.04 to 0.07); left-right correlation 0.99 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S2. 06 (untitled): bass group `bass-1` (488 notes, 42% of the track's note energy)
- In synth terms: around A#1, bell- or metal-like (partials off whole multiples), soft attack, falls 84 dB/s, centered.
- Hear it at: 3:39.3 (A#1, 0.35 s, +20 dB alone), 0:32.4 (A#1, 0.33 s, +19 dB alone), 3:39.2 (A#1, 0.27 s, +20 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 58 (37 to 68) Hz; attack 54 (20 to 131) ms; decay -84 (-357 to -14) dB/s
  - brightness at the start 116 (71 to 543) Hz; slope over the note 0.04 (-0.21 to 1.16) octaves
  - harmonic share 0.91 (0.16 to 0.99); partials off whole multiples 72 (21 to 224) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.5 (-10.8 to -0.5) dB; pan 0.06 (0.03 to 0.09); left-right correlation 0.99 (0.97 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S3. 04 (untitled): bass group `bass-1` (458 notes, 40% of the track's note energy)
- In synth terms: around F#1, harmonic (string/reed/pad-like), soft attack, falls 61 dB/s, gets darker over the note, centered.
- Hear it at: 3:30.3 (?, 0.21 s, +24 dB alone), 4:01.4 (?, 0.27 s, +22 dB alone), 1:32.6 (D#1, 0.48 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (36 to 51) Hz; attack 42 (13 to 125) ms; decay -61 (-140 to -22) dB/s
  - brightness at the start 211 (123 to 430) Hz; slope over the note -0.44 (-1.54 to -0.01) octaves
  - harmonic share 0.95 (0.11 to 1.00); partials off whole multiples 30 (5 to 168) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.1 (-8.9 to -2.3) dB; pan 0.05 (0.03 to 0.07); left-right correlation 0.99 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S4. 02 (untitled): drums group `drums-1` (396 notes, 39% of the track's note energy)
- In synth terms: low thump, soft attack, falls 741 dB/s, centered.
- Hear it at: 5:54.3 (F#1, 0.16 s, +36 dB alone), 5:53.9 (F#1, 0.16 s, +34 dB alone), 5:53.1 (E1, 0.2 s, +31 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 39 (38 to 43) Hz; attack 58 (45 to 60) ms; decay -741 (-809 to -461) dB/s
  - brightness at the start 117 (76 to 176) Hz; slope over the note 0.00 (0.00 to 1.57) octaves
  - harmonic share 0.57 (0.39 to 0.78); partials off whole multiples 209 (167 to 251) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.7 (-1.6 to -0.2) dB; pan 0.07 (0.06 to 0.08); left-right correlation 0.99 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. 02 (untitled): other group `other-1` (463 notes, 38% of the track's note energy)
- In synth terms: around D#3, harmonic (string/reed/pad-like), soft attack, falls 37 dB/s, centered.
- Hear it at: 3:04.4 (C3, 0.26 s, +45 dB alone), 3:06.8 (?, 0.46 s, +43 dB alone), 5:35.6 (?, 0.14 s, +44 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 156 (133 to 177) Hz; attack 45 (19 to 143) ms; decay -37 (-113 to -11) dB/s
  - brightness at the start 763 (288 to 4541) Hz; slope over the note 0.00 (-2.25 to 0.47) octaves
  - harmonic share 0.87 (0.49 to 0.98); partials off whole multiples 44 (13 to 93) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-6.6 to -0.2) dB; pan -0.00 (-0.06 to 0.03); left-right correlation 0.86 (0.70 to 0.95)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. 08 (untitled): other group `other-1` (429 notes, 35% of the track's note energy)
- In synth terms: around C2, mixed or noisy partials, soft attack, falls 17 dB/s, centered.
- Hear it at: 1:09.8 (C2, 0.39 s, +15 dB alone), 1:19.1 (?, 0.24 s, +14 dB alone), 1:57.6 (?, 0.35 s, +13 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 66 (44 to 75) Hz; attack 145 (39 to 366) ms; decay -17 (-61 to -1) dB/s
  - brightness at the start 380 (312 to 497) Hz; slope over the note 0.00 (-0.33 to 0.24) octaves
  - harmonic share 0.79 (0.15 to 0.97); partials off whole multiples 33 (9 to 109) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.5 (-7.8 to -1.9) dB; pan -0.03 (-0.13 to 0.08); left-right correlation 0.56 (0.36 to 0.74)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. 01 (untitled): bass group `bass-1` (495 notes, 34% of the track's note energy)
- In synth terms: around E2, bell- or metal-like (partials off whole multiples), quick attack, falls 119 dB/s, centered.
- Hear it at: 0:25.7 (E2, 0.24 s, +20 dB alone), 0:31.6 (E2, 0.29 s, +18 dB alone), 0:20.7 (E2, 0.29 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 82 (81 to 83) Hz; attack 33 (30 to 35) ms; decay -119 (-136 to -95) dB/s
  - brightness at the start 82 (82 to 89) Hz; slope over the note -0.01 (-0.06 to 0.06) octaves
  - harmonic share 0.99 (0.98 to 1.00); partials off whole multiples 146 (43 to 266) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.0 (-3.7 to -1.3) dB; pan 0.05 (0.04 to 0.07); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S8. 09 (untitled): drums group `drums-1` (237 notes, 29% of the track's note energy)
- In synth terms: low thump, quick attack, falls 191 dB/s, gets brighter over the note, centered.
- Hear it at: 1:06.1 (C2, 0.23 s, +22 dB alone), 4:22.0 (C2, 0.24 s, +19 dB alone), 4:19.8 (C2, 0.26 s, +19 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 65 (64 to 65) Hz; attack 29 (28 to 30) ms; decay -191 (-196 to -186) dB/s
  - brightness at the start 72 (70 to 75) Hz; slope over the note 1.14 (0.54 to 1.83) octaves
  - harmonic share 1.00 (0.99 to 1.00); partials off whole multiples 37 (5 to 100) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.4 (-0.6 to -0.2) dB; pan 0.10 (0.09 to 0.12); left-right correlation 0.99 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **01 (untitled) sections:** 24 boundaries at 0:26.0, 0:43.0, 0:53.0, 1:20.0, 1:30.0, 1:51.0, 2:08.0, 2:22.0, 2:55.0, 3:53.0, 4:26.0, 5:01.0; section lengths median 21 s (range 9 to 58). Reliable for sections of 10 s or more.
- **01 (untitled) stem entries and exits:** drums plays 91% of the time (in: 0:07.0, 0:15.5, 5:26.5, 5:56.0; out: 0:12.0, 5:19.5, 5:29.0, 9:10.5); bass plays 83% of the time (in: 0:10.0, 4:21.0, 5:56.5; out: 3:44.5, 5:18.0, 9:10.5); other plays 91% of the time (in: 0:12.0, 0:39.5, 8:20.5; out: 0:16.5, 8:13.5, 9:10.0); vocals plays 33% of the time (in: 1:50.5, 2:42.0, 3:57.5, 5:25.0, 6:12.0; out: 2:05.0, 3:51.5, 4:06.5, 5:28.5, 6:14.5).
- **01 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.12 a minute: 5:17.2 for 39.2 s.
- **01 (untitled) brightness sweeps (0.7 octave or more):** mix down 6.5 oct 0:06.0 to 0:20.0; mix up 1.4 oct 0:20.0 to 0:25.0; mix down 1.0 oct 0:25.0 to 0:32.0; mix up 6.5 oct 0:32.0 to 0:56.5; mix down 6.3 oct 0:57.5 to 1:08.5; mix up 0.9 oct 1:09.5 to 1:15.0; mix up 3.3 oct 1:21.5 to 1:32.5; mix up 4.0 oct 1:36.0 to 1:46.0 (86 more in techniques.json).
- **01 (untitled) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **01 (untitled) pumping locked to the kick:** other dips 2.0 dB at the kick (peak 40 ms after, kick every 0.37 s); bass dips 18.1 dB at the kick (peak 354 ms after, kick every 0.37 s). The tool reads about 70% of the true depth, so this is a floor.
- **01 (untitled) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **01 (untitled) stereo movement:** drums pan range 0.05, cycling every 50 s.
- **01 (untitled) builds:** 0:00.0 to 0:22.0.
- **02 (untitled) sections:** 17 boundaries at 0:06.0, 0:38.0, 0:55.0, 1:07.0, 1:19.0, 1:39.0, 1:58.0, 2:28.0, 2:54.0, 3:26.0, 3:45.0, 4:06.0; section lengths median 20 s (range 6 to 33). Reliable for sections of 10 s or more.
- **02 (untitled) stem entries and exits:** drums plays 93% of the time (in: 0:04.0, 3:44.0, 4:21.0; out: 3:40.5, 4:06.0, 5:56.0); bass plays 27% of the time (in: 0:41.0, 1:17.5, 2:15.5, 3:37.5, 4:07.0; out: 0:07.5, 0:43.5, 1:43.5, 2:22.5, 3:44.0); other plays 97% of the time (in: 0:04.0; out: 5:52.5); vocals plays 50% of the time (in: 0:43.0, 0:53.5, 1:04.0, 1:22.0, 2:07.5; out: 0:48.0, 1:01.0, 1:12.0, 1:54.0, 2:27.0).
- **02 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.56 a minute: 3:39.5 for 5.2 s, 4:05.2 for 6.0 s, 4:11.5 for 10.0 s.
- **02 (untitled) brightness sweeps (0.7 octave or more):** mix up 3.3 oct 0:00.0 to 0:06.5; mix up 2.1 oct 0:10.0 to 0:15.5; mix down 1.1 oct 0:15.5 to 0:21.5; mix up 1.9 oct 0:21.5 to 0:27.0; mix down 2.6 oct 0:27.0 to 0:32.0; mix up 2.9 oct 0:32.0 to 0:39.0; mix up 1.1 oct 0:44.0 to 0:49.0; mix down 1.9 oct 0:56.0 to 1:03.0 (50 more in techniques.json).
- **02 (untitled) echo times:** drums: 254 ms (+22.1 dB, 1 later repeats).
- **02 (untitled) pumping locked to the kick:** other dips 3.6 dB at the kick (peak 509 ms after, kick every 0.51 s); bass dips 4.2 dB at the kick (peak 509 ms after, kick every 0.51 s). The tool reads about 70% of the true depth, so this is a floor.
- **02 (untitled) tape wobble and speed:** bass wobbles about 7 cents at 0.6 Hz.
- **02 (untitled) stereo movement:** vocals pan range 0.30.
- **04 (untitled) sections:** 17 boundaries at 0:02.0, 0:22.0, 0:32.0, 0:52.0, 1:04.0, 1:20.0, 1:31.0, 1:51.0, 2:04.0, 2:20.0, 2:33.0, 2:55.0; section lengths median 15 s (range 2 to 22). Reliable for sections of 10 s or more.
- **04 (untitled) stem entries and exits:** drums plays 97% of the time (in: from the start; out: 4:17.5); bass plays 97% of the time (in: from the start; out: 4:17.5); other plays 98% of the time (in: from the start; out: 4:19.0); vocals plays 0% of the time (in: from the start; out: never).
- **04 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **04 (untitled) brightness sweeps (0.7 octave or more):** mix up 0.8 oct 0:09.0 to 0:14.5; mix up 1.3 oct 0:36.0 to 0:46.5; mix down 1.4 oct 0:55.0 to 1:00.0; mix up 1.0 oct 1:04.5 to 1:17.0; mix down 1.3 oct 1:23.5 to 1:28.5; mix down 2.5 oct 2:59.5 to 3:11.0; mix up 1.2 oct 3:11.5 to 3:20.5; mix up 0.8 oct 3:45.0 to 3:54.0 (11 more in techniques.json).
- **04 (untitled) echo times:** drums: 634 ms (+14.4 dB, 2 later repeats).
- **04 (untitled) pumping locked to the kick:** other dips 3.3 dB at the kick (peak 35 ms after, kick every 0.31 s); bass dips 4.1 dB at the kick (peak 279 ms after, kick every 0.31 s). The tool reads about 70% of the true depth, so this is a floor.
- **04 (untitled) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **04 (untitled) stereo movement:** other pan range 0.53, cycling every 2 s.
- **05 (untitled) sections:** 22 boundaries at 0:15.0, 0:33.0, 0:47.0, 1:07.0, 1:23.0, 1:44.0, 1:58.0, 2:10.0, 2:38.0, 2:49.0, 3:14.0, 3:34.0; section lengths median 16 s (range 11 to 28). Reliable for sections of 10 s or more.
- **05 (untitled) stem entries and exits:** drums plays 96% of the time (in: from the start; out: 6:28.0); bass plays 5% of the time (in: 4:47.0; out: 5:08.0); other plays 96% of the time (in: from the start; out: 6:25.0); vocals plays 1% of the time (in: 3:37.0; out: 3:41.0).
- **05 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **05 (untitled) brightness sweeps (0.7 octave or more):** mix down 3.6 oct 0:04.0 to 0:09.0; mix up 4.1 oct 0:09.0 to 0:15.5; mix up 3.2 oct 0:20.0 to 0:26.5; mix down 1.5 oct 0:26.5 to 0:31.5; mix up 1.1 oct 0:32.0 to 0:37.5; mix down 2.0 oct 0:37.5 to 0:43.5; mix up 1.9 oct 0:43.5 to 0:48.5; mix down 1.9 oct 0:48.5 to 0:54.0 (65 more in techniques.json).
- **05 (untitled) echo times:** other: 718 ms (+3.2 dB, 1 later repeats).
- **05 (untitled) pumping locked to the kick:** other dips 1.7 dB at the kick (peak 15 ms after, kick every 0.33 s); bass dips 3.3 dB at the kick (peak 269 ms after, kick every 0.33 s). The tool reads about 70% of the true depth, so this is a floor.
- **05 (untitled) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **05 (untitled) stereo movement:** drums pan range 0.09, cycling every 3 s; other pan range 0.43, cycling every 4 s.
- **06 (untitled) sections:** 13 boundaries at 0:26.0, 2:00.0, 2:12.0, 2:31.0, 3:00.0, 3:10.0, 3:26.0, 3:37.0, 4:00.0, 4:26.0, 5:12.0, 5:34.0; section lengths median 22 s (range 4 to 94). Reliable for sections of 10 s or more.
- **06 (untitled) stem entries and exits:** drums plays 93% of the time (in: 0:24.0; out: 6:14.0); bass plays 84% of the time (in: 0:24.0, 2:20.0, 2:50.0, 3:25.0, 4:16.5; out: 2:17.5, 2:44.0, 3:22.0, 4:13.5, 4:24.5); other plays 98% of the time (in: 0:02.0, 0:20.0; out: 0:17.5, 6:14.0); vocals plays 31% of the time (in: 1:29.5, 2:42.0, 2:58.0, 3:12.0, 4:41.5; out: 1:32.0, 2:45.0, 3:03.5, 3:32.0, 4:44.5).
- **06 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.18 a minute: 0:19.8 for 4.8 s.
- **06 (untitled) brightness sweeps (0.7 octave or more):** mix up 0.8 oct 0:06.5 to 0:12.5; mix up 0.7 oct 0:14.0 to 0:19.5; mix down 1.2 oct 0:38.0 to 0:44.5; mix up 1.0 oct 0:45.0 to 0:54.0; mix down 1.4 oct 0:54.5 to 1:04.5; mix up 1.1 oct 1:04.5 to 1:10.5; mix down 1.4 oct 1:10.5 to 1:21.5; mix up 1.0 oct 1:22.0 to 1:27.0 (62 more in techniques.json).
- **06 (untitled) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **06 (untitled) pumping locked to the kick:** other dips 2.0 dB at the kick (peak 30 ms after, kick every 0.35 s); bass dips 5.4 dB at the kick (peak 55 ms after, kick every 0.35 s). The tool reads about 70% of the true depth, so this is a floor.
- **06 (untitled) tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **06 (untitled) stereo movement:** bass pan range 0.08, cycling every 3 s; other pan range 0.37.
- **07 (untitled) sections:** 14 boundaries at 0:34.0, 0:55.0, 1:15.0, 1:33.0, 1:52.0, 2:22.0, 2:45.0, 3:25.0, 3:44.0, 3:54.0, 4:12.0, 4:26.0; section lengths median 19 s (range 5 to 40). Reliable for sections of 10 s or more.
- **07 (untitled) stem entries and exits:** drums plays 95% of the time (in: 2:44.0, 3:52.5; out: 2:40.5, 3:45.5, 4:48.5); bass plays 96% of the time (in: 3:00.0; out: 2:52.0, 4:48.5); other plays 98% of the time (in: from the start; out: 4:48.0); vocals plays 7% of the time (in: 1:11.0, 1:47.5, 2:41.5, 3:04.5, 3:26.5; out: 1:18.0, 1:51.5, 2:46.5, 3:07.0, 3:29.5).
- **07 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **07 (untitled) brightness sweeps (0.7 octave or more):** mix up 1.9 oct 0:04.5 to 0:12.0; mix down 1.2 oct 0:12.0 to 0:18.0; mix down 1.2 oct 0:21.5 to 0:26.5; mix up 1.8 oct 0:27.0 to 0:35.0; mix down 0.9 oct 0:35.5 to 0:40.5; mix down 1.4 oct 0:51.5 to 0:56.5; mix up 1.6 oct 1:22.0 to 1:27.5; mix down 2.8 oct 1:28.0 to 1:35.0 (38 more in techniques.json).
- **07 (untitled) echo times:** drums: 614 ms (+19.8 dB, 1 later repeats).
- **07 (untitled) pumping locked to the kick:** other dips 3.4 dB at the kick (peak 10 ms after, kick every 0.73 s); bass dips 22.2 dB at the kick (peak 693 ms after, kick every 0.73 s). The tool reads about 70% of the true depth, so this is a floor.
- **07 (untitled) tape wobble and speed:** other wobbles about 15 cents at 4.3 Hz.
- **07 (untitled) stereo movement:** other pan range 0.23, cycling every 11 s; vocals pan range 0.68.
- **08 (untitled) sections:** 19 boundaries at 0:14.0, 1:17.0, 1:35.0, 1:54.0, 2:06.0, 2:20.0, 2:31.0, 2:41.0, 3:15.0, 3:32.0, 3:57.0, 4:08.0; section lengths median 18 s (range 10 to 63). Reliable for sections of 10 s or more.
- **08 (untitled) stem entries and exits:** drums plays 94% of the time (in: from the start; out: 6:32.0); bass plays 78% of the time (in: 0:04.0, 0:29.0, 0:46.5; out: 0:08.5, 0:33.5, 6:05.5); other plays 94% of the time (in: 0:03.5; out: 6:35.5); vocals plays 2% of the time (in: 6:08.5; out: 6:15.0).
- **08 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.16 a minute: 6:30.5 for 2.2 s.
- **08 (untitled) brightness sweeps (0.7 octave or more):** mix up 2.7 oct 0:13.5 to 0:19.5; mix down 1.1 oct 0:25.0 to 0:31.5; mix down 3.3 oct 0:43.5 to 0:52.0; mix up 1.8 oct 1:29.0 to 1:34.0; mix down 1.7 oct 1:34.0 to 1:42.0; mix down 1.1 oct 2:23.0 to 2:32.0; mix down 0.8 oct 3:26.0 to 3:31.0; mix up 1.1 oct 3:35.5 to 3:43.0 (14 more in techniques.json).
- **08 (untitled) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **08 (untitled) pumping locked to the kick:** other dips 2.4 dB at the kick (peak 20 ms after, kick every 0.46 s). The tool reads about 70% of the true depth, so this is a floor.
- **08 (untitled) tape wobble and speed:** other wobbles about 18 cents at 1.1 Hz.
- **08 (untitled) stereo movement:** drums pan range 0.13, cycling every 2 s; bass pan range 0.09, cycling every 5 s; other pan range 0.26.
- **09 (untitled) sections:** 13 boundaries at 0:11.0, 0:32.0, 1:33.0, 1:49.0, 2:00.0, 2:16.0, 2:43.0, 4:07.0, 4:36.0, 5:05.0, 5:21.0, 5:31.0; section lengths median 18 s (range 10 to 84). Reliable for sections of 10 s or more.
- **09 (untitled) stem entries and exits:** drums plays 90% of the time (in: 0:13.0, 0:30.0, 4:13.5; out: 0:24.0, 4:07.5, 5:53.0); bass plays 74% of the time (in: 0:30.0, 5:02.5; out: 4:08.0, 5:53.5); other plays 97% of the time (in: 0:11.5; out: 0:06.5, 6:01.5); vocals plays 64% of the time (in: 0:16.5, 1:25.0, 2:43.0, 2:56.0, 4:11.5; out: 0:13.0, 1:13.5, 1:55.5, 2:51.5, 4:07.5).
- **09 (untitled) floor drops (kick and bass out 2 s or more while the rest plays):** 0.37 a minute: 0:18.2 for 12.2 s, 4:07.2 for 6.8 s.
- **09 (untitled) brightness sweeps (0.7 octave or more):** mix up 2.1 oct 0:06.5 to 0:13.0; mix down 4.1 oct 0:17.0 to 0:36.5; mix down 1.1 oct 1:13.0 to 1:18.5; mix down 0.8 oct 3:41.5 to 3:50.5; mix up 3.7 oct 4:03.5 to 4:10.5; mix down 1.6 oct 4:10.5 to 4:16.5; mix up 3.7 oct 5:48.5 to 5:55.0; other down 1.6 oct 0:01.5 to 0:15.5 (31 more in techniques.json).
- **09 (untitled) echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **09 (untitled) pumping locked to the kick:** bass dips 4.2 dB at the kick (peak 414 ms after, kick every 0.43 s). The tool reads about 70% of the true depth, so this is a floor.
- **09 (untitled) tape wobble and speed:** other wobbles about 12 cents at 1.1 Hz.
- **09 (untitled) stereo movement:** other pan range 0.30.
- **09 (untitled) builds:** 0:13.0 to 0:36.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **01 (untitled) meter:** about 61 BPM (could be 30 or 121; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.00); swung: off-beat at 0.63 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **01 (untitled) key and mode:** E lydian (low confidence: the key signature margin is 0.005, so read this as a guess); fits E major pentatonic; pitch-class weights E 0.23, D# 0.17, C# 0.13, F 0.12, D 0.08.
- **01 (untitled) chords:** 20 changes a minute (13 a minute are chords that last 1.5 s or more); median chord 1.7 s (10th to 90th percentile 0.8 to 4.4 s); 24 distinct chords; most time on Emaj7 56%, C#min 15%, Dmin 4%, Fmaj7 4%. The old counter in this same run said 8; Ears 1's 2-s counter said 4.  35% of the changes land on a beat (chance would be 30%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **01 (untitled) bass:** pedal (one note held or repeated); 1.52 notes a second; most time on E 0.94, F# 0.01, D 0.01, F 0.01; steps 4%, thirds 3%, fourths and fifths 1%, octaves 0%, repeats 91%.
- **01 (untitled) top line (from the 'other' stem; read by ear before trusting):** 957 notes, range 13 semitones (10th to 90th percentile); steps 8%, thirds 8%, fourths and fifths 43%, leaps 23%, repeats 17%; median interval 5 semitones; 50% of moves go up; phrases of about 10 notes, arch 32%, rising 36%, falling 16%, flat or wavy 16%. Reliable only when the line sits clearly above its accompaniment.
- **01 (untitled) repetition:** 141 bars of 4.0 s; strongest repeat distances 2 bars (0.79), 4 bars (0.63), 6 bars (0.47); 25% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **02 (untitled) meter:** about 76 BPM (could be 38 or 153; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.12); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **02 (untitled) key and mode:** G aeolian (minor) (key signature margin 0.024); pitch-class weights D# 0.15, C 0.14, F 0.13, E 0.10, D 0.09.
- **02 (untitled) chords:** 38 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.3 s (10th to 90th percentile 0.6 to 2.9 s); 18 distinct chords; most time on D#sus2 20%, F7 18%, F 14%, Csus2 10%. The old counter in this same run said 18; Ears 1's 2-s counter said 16.  35% of the changes land on a beat (chance would be 38%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **02 (untitled) bass:** pedal (one note held or repeated); 0.27 notes a second; most time on G 0.80, B 0.06, D# 0.04, D 0.03; steps 15%, thirds 11%, fourths and fifths 3%, octaves 5%, repeats 56%.
- **02 (untitled) top line (from the 'other' stem; read by ear before trusting):** 944 notes, range 14 semitones (10th to 90th percentile); steps 30%, thirds 15%, fourths and fifths 10%, leaps 26%, repeats 20%; median interval 3 semitones; 45% of moves go up; phrases of about 14 notes, arch 23%, rising 31%, falling 25%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **02 (untitled) repetition:** 50 bars of 7.1 s; strongest repeat distances 1 bars (0.43), 25 bars (0.18), 6 bars (0.16); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **04 (untitled) meter:** about 98 BPM (could be 49 or 195; the tool cannot tell the beat level), 8 beats a bar; swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **04 (untitled) key and mode:** F# lydian (low confidence: the key signature margin is 0.015, so read this as a guess); pitch-class weights C# 0.12, D 0.12, F# 0.12, C 0.09, D# 0.09.
- **04 (untitled) chords:** 37 changes a minute (8 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.6 to 2.3 s); 21 distinct chords; most time on Dmaj7 42%, D#min7 9%, G#maj7 8%, C#maj7 7%. The old counter in this same run said 2; Ears 1's 2-s counter said 0.  42% of the changes land on a beat (chance would be 49%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **04 (untitled) bass:** root-note movement / mixed; 0.51 notes a second; most time on F# 0.41, G# 0.22, A 0.15, G 0.12; steps 65%, thirds 7%, fourths and fifths 0%, octaves 0%, repeats 17%.
- **04 (untitled) top line (from the 'other' stem; read by ear before trusting):** 374 notes, range 17 semitones (10th to 90th percentile); steps 33%, thirds 34%, fourths and fifths 6%, leaps 11%, repeats 15%; median interval 3 semitones; 53% of moves go up; phrases of about 6 notes, arch 33%, rising 11%, falling 11%, flat or wavy 44%. Reliable only when the line sits clearly above its accompaniment.
- **04 (untitled) repetition:** 53 bars of 4.9 s; strongest repeat distances 1 bars (0.69), 26 bars (-0.09), 18 bars (-0.26); 13% of bars near-duplicate an earlier bar.
- **05 (untitled) meter:** about 92 BPM (could be 46 or 183; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:4), which means irregular timing, not a cross-rhythm claim.
- **05 (untitled) key and mode:** D# phrygian (low confidence: the key signature margin is 0.009, so read this as a guess); pitch-class weights E 0.20, D# 0.20, G 0.10, F# 0.09, D 0.07.
- **05 (untitled) chords:** 48 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.4 to 1.8 s); 46 distinct chords; most time on D#maj7 25%, C#maj7 16%, Esus2 15%, Emaj7 15%. The old counter in this same run said 2; Ears 1's 2-s counter said 0.  44% of the changes land on a beat (chance would be 46%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **05 (untitled) bass:** root-note movement / mixed; 0.05 notes a second; most time on D# 0.66, G 0.17, E 0.08, F# 0.04; steps 11%, thirds 11%, fourths and fifths 0%, octaves 5%, repeats 26%.
- **05 (untitled) top line (from the 'other' stem; read by ear before trusting):** 1019 notes, range 8 semitones (10th to 90th percentile); steps 43%, thirds 24%, fourths and fifths 17%, leaps 7%, repeats 8%; median interval 2 semitones; 53% of moves go up; phrases of about 8 notes, arch 58%, rising 25%, falling 8%, flat or wavy 8%. Reliable only when the line sits clearly above its accompaniment.
- **05 (untitled) repetition:** 153 bars of 2.6 s; strongest repeat distances 1 bars (0.75); 18% of bars near-duplicate an earlier bar.
- **06 (untitled) meter:** about 89 BPM (could be 44 or 177; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **06 (untitled) key and mode:** A# aeolian (minor) (low confidence: the key signature margin is 0.010, so read this as a guess); pitch-class weights C# 0.11, C 0.10, D 0.10, E 0.10, D# 0.10.
- **06 (untitled) chords:** 11 changes a minute (5 a minute are chords that last 1.5 s or more); median chord 1.6 s (10th to 90th percentile 0.7 to 6.6 s); 21 distinct chords; most time on C#maj7 63%, Fmin7 9%, F#min7 5%, D#min7 4%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  59% of the changes land on a beat (chance would be 44%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **06 (untitled) bass:** pedal (one note held or repeated); 0.41 notes a second; most time on A# 0.93, C 0.03, A 0.02, D# 0.01; steps 14%, thirds 1%, fourths and fifths 4%, octaves 0%, repeats 79%.
- **06 (untitled) top line (from the 'other' stem; read by ear before trusting):** 789 notes, range 18 semitones (10th to 90th percentile); steps 33%, thirds 17%, fourths and fifths 13%, leaps 28%, repeats 9%; median interval 3 semitones; 47% of moves go up; phrases of about 11 notes, arch 54%, rising 10%, falling 22%, flat or wavy 15%. Reliable only when the line sits clearly above its accompaniment.
- **06 (untitled) repetition:** 139 bars of 2.7 s; strongest repeat distances 1 bars (0.84); 43% of bars near-duplicate an earlier bar.
- **07 (untitled) meter:** about 122 BPM (could be 61 or 245; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **07 (untitled) key and mode:** A mixolydian (low confidence: the key signature margin is 0.000, so read this as a guess); pitch-class weights A 0.11, D 0.10, F# 0.09, G 0.09, G# 0.09.
- **07 (untitled) chords:** 31 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 1.2 s (10th to 90th percentile 0.9 to 4.2 s); 14 distinct chords; most time on A7 22%, Dmaj7 15%, G#maj7 14%, F#maj7 14%. The old counter in this same run said 12; Ears 1's 2-s counter said 1.  46% of the changes land on a beat (chance would be 61%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **07 (untitled) bass:** root-note movement / mixed; 0.84 notes a second; most time on A 0.34, B 0.18, F# 0.17, F 0.12; steps 27%, thirds 24%, fourths and fifths 9%, octaves 0%, repeats 40%.
- **07 (untitled) top line (from the 'other' stem; read by ear before trusting):** 670 notes, range 12 semitones (10th to 90th percentile); steps 19%, thirds 25%, fourths and fifths 18%, leaps 13%, repeats 25%; median interval 3 semitones; 51% of moves go up; phrases of about 16 notes, arch 40%, rising 26%, falling 7%, flat or wavy 26%. Reliable only when the line sits clearly above its accompaniment.
- **07 (untitled) repetition:** 149 bars of 2.0 s; strongest repeat distances 4 bars (0.57), 1 bars (0.52), 8 bars (0.34); 12% of bars near-duplicate an earlier bar.
- **08 (untitled) meter:** about 106 BPM (could be 53 or 211; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **08 (untitled) key and mode:** D aeolian (minor) (low confidence: the key signature margin is 0.010, so read this as a guess); pitch-class weights A 0.20, D 0.14, C 0.13, A# 0.13, G 0.07.
- **08 (untitled) chords:** 45 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.6 to 2.2 s); 33 distinct chords; most time on A#maj7 20%, D5 14%, D7 11%, Amin7 10%. The old counter in this same run said 18; Ears 1's 2-s counter said 6.  67% of the changes land on a beat (chance would be 53%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **08 (untitled) bass:** root-note movement / mixed; 1.01 notes a second; most time on D 0.27, C 0.25, A# 0.19, F 0.17; steps 28%, thirds 24%, fourths and fifths 17%, octaves 0%, repeats 30%.
- **08 (untitled) top line (from the 'other' stem; read by ear before trusting):** 654 notes, range 8 semitones (10th to 90th percentile); steps 10%, thirds 29%, fourths and fifths 28%, leaps 8%, repeats 26%; median interval 3 semitones; 51% of moves go up; phrases of about 10 notes, arch 69%, rising 4%, falling 8%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **08 (untitled) repetition:** 368 bars of 1.1 s; strongest repeat distances 16 bars (0.69), 32 bars (0.53), 8 bars (0.45); 17% of bars near-duplicate an earlier bar.
- **09 (untitled) meter:** about 69 BPM (could be 34 or 137; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.22); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **09 (untitled) key and mode:** G dorian (low confidence: the key signature margin is 0.011, so read this as a guess); pitch-class weights G 0.15, F# 0.13, F 0.12, E 0.10, A 0.09.
- **09 (untitled) chords:** 33 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.7 to 3.5 s); 23 distinct chords; most time on Gmaj7 35%, Fmaj7 20%, A#maj7 10%, Amaj7 9%. The old counter in this same run said 21; Ears 1's 2-s counter said 18.  5% of the changes land on a beat (chance would be 34%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **09 (untitled) bass:** root-note movement / mixed; 1.07 notes a second; most time on G 0.33, A 0.22, A# 0.15, F 0.10; steps 37%, thirds 5%, fourths and fifths 9%, octaves 0%, repeats 48%.
- **09 (untitled) top line (from the 'other' stem; read by ear before trusting):** 904 notes, range 26 semitones (10th to 90th percentile); steps 26%, thirds 23%, fourths and fifths 18%, leaps 18%, repeats 15%; median interval 4 semitones; 49% of moves go up; phrases of about 19 notes, arch 18%, rising 29%, falling 35%, flat or wavy 18%. Reliable only when the line sits clearly above its accompaniment.
- **09 (untitled) repetition:** 104 bars of 3.5 s; strongest repeat distances 2 bars (0.67), 4 bars (0.57), 6 bars (0.47); 16% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **01 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -19 (corr 0.98); low_120_500 -6 (corr 0.62); mid_500_2k -9 (corr 0.78); pres_2k_5k -11 (corr 0.86); air_gt5k -28 (corr 1.00); over time (2-s windows) 10th/50th/90th percentile -24/-9/-4 dB.
- **01 (untitled) by part:** drums: 41% of the power, width -22 dB, pan +0.09, mono loss 0.0 dB, widest in sub_lt120 (-22 dB); bass: 40% of the power, width -23 dB, pan +0.10, mono loss 0.0 dB, widest in sub_lt120 (-23 dB); other: 17% of the power, width -4 dB, pan -0.08, mono loss 1.5 dB, widest in low_120_500 (-3 dB); vocals: 2% of the power, width -26 dB, pan +0.01, mono loss 0.0 dB, widest in mid_500_2k (-24 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **02 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.98); low_120_500 -16 (corr 0.96); mid_500_2k -4 (corr 0.45); pres_2k_5k -9 (corr 0.78); air_gt5k -25 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -13/-10/-6 dB.
- **02 (untitled) by part:** drums: 60% of the power, width -21 dB, pan +0.13, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); bass: 1% of the power, width -23 dB, pan +0.08, mono loss 0.0 dB, widest in sub_lt120 (-22 dB); other: 36% of the power, width -8 dB, pan +0.02, mono loss 0.6 dB, widest in mid_500_2k (-4 dB); vocals: 3% of the power, width -10 dB, pan -0.00, mono loss 0.4 dB, widest in mid_500_2k (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **04 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -21 (corr 0.99); low_120_500 -23 (corr 0.99); mid_500_2k -22 (corr 0.99); pres_2k_5k -19 (corr 0.98); air_gt5k -17 (corr 0.96); over time (2-s windows) 10th/50th/90th percentile -25/-23/-22 dB.
- **04 (untitled) by part:** drums: 73% of the power, width -24 dB, pan +0.08, mono loss 0.0 dB, widest in sub_lt120 (-24 dB); bass: 25% of the power, width -20 dB, pan +0.12, mono loss 0.0 dB, widest in sub_lt120 (-20 dB); other: 1% of the power, width -10 dB, pan +0.02, mono loss 0.4 dB, widest in sub_lt120 (-3 dB); vocals: 0% of the power, width -9 dB, pan +0.02, mono loss 0.5 dB, widest in mid_500_2k (-8 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **05 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.99); low_120_500 -13 (corr 0.90); mid_500_2k -5 (corr 0.48); pres_2k_5k -8 (corr 0.75); air_gt5k -12 (corr 0.89); over time (2-s windows) 10th/50th/90th percentile -17/-13/-9 dB.
- **05 (untitled) by part:** drums: 96% of the power, width -22 dB, pan +0.09, mono loss 0.0 dB, widest in sub_lt120 (-23 dB); bass: 0% of the power, width -24 dB, pan +0.07, mono loss 0.0 dB, widest in sub_lt120 (-25 dB); other: 4% of the power, width -2 dB, pan -0.09, mono loss 2.0 dB, widest in mid_500_2k (0 dB); vocals: 0% of the power, width 1 dB, pan -0.21, mono loss 3.7 dB, widest in mid_500_2k (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **06 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.98); low_120_500 -20 (corr 0.98); mid_500_2k -21 (corr 0.99); pres_2k_5k -19 (corr 0.98); air_gt5k -14 (corr 0.93); over time (2-s windows) 10th/50th/90th percentile -23/-21/-16 dB.
- **06 (untitled) by part:** drums: 49% of the power, width -21 dB, pan +0.04, mono loss 0.0 dB, widest in low_120_500 (-22 dB); bass: 38% of the power, width -21 dB, pan +0.15, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); other: 12% of the power, width -12 dB, pan +0.06, mono loss 0.3 dB, widest in sub_lt120 (-7 dB); vocals: 1% of the power, width -20 dB, pan +0.03, mono loss 0.0 dB, widest in mid_500_2k (-16 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **07 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.99); low_120_500 -14 (corr 0.92); mid_500_2k -14 (corr 0.93); pres_2k_5k -16 (corr 0.96); air_gt5k -17 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -17/-14/-12 dB.
- **07 (untitled) by part:** drums: 73% of the power, width -21 dB, pan +0.15, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); bass: 22% of the power, width -20 dB, pan +0.10, mono loss 0.0 dB, widest in sub_lt120 (-20 dB); other: 5% of the power, width -5 dB, pan -0.36, mono loss 1.2 dB, widest in sub_lt120 (4 dB); vocals: 0% of the power, width -4 dB, pan -0.40, mono loss 1.5 dB, widest in low_120_500 (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **08 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -16 (corr 0.97); low_120_500 -7 (corr 0.69); mid_500_2k -7 (corr 0.70); pres_2k_5k -9 (corr 0.76); air_gt5k -16 (corr 0.96); over time (2-s windows) 10th/50th/90th percentile -17/-7/-6 dB.
- **08 (untitled) by part:** drums: 62% of the power, width -19 dB, pan +0.17, mono loss 0.1 dB, widest in sub_lt120 (-19 dB); bass: 7% of the power, width -16 dB, pan +0.04, mono loss 0.1 dB, widest in sub_lt120 (-16 dB); other: 30% of the power, width -5 dB, pan -0.03, mono loss 1.3 dB, widest in low_120_500 (-5 dB); vocals: 0% of the power, width -18 dB, pan +0.12, mono loss 0.1 dB, widest in pres_2k_5k (-18 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **09 (untitled) mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.99); low_120_500 -12 (corr 0.90); mid_500_2k -7 (corr 0.72); pres_2k_5k -5 (corr 0.51); air_gt5k -0 (corr 0.01); over time (2-s windows) 10th/50th/90th percentile -13/-10/-5 dB.
- **09 (untitled) by part:** drums: 84% of the power, width -18 dB, pan +0.21, mono loss 0.1 dB, widest in sub_lt120 (-19 dB); bass: 13% of the power, width -17 dB, pan +0.23, mono loss 0.1 dB, widest in sub_lt120 (-17 dB); other: 2% of the power, width -5 dB, pan +0.16, mono loss 1.2 dB, widest in sub_lt120 (-2 dB); vocals: 1% of the power, width -5 dB, pan +0.14, mono loss 1.3 dB, widest in low_120_500 (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 01 (untitled): 61 BPM, 13 settled chords a minute, 7% of energy above 2 kHz, width -13 dB; 02 (untitled): 76 BPM, 15 settled chords a minute, 9% of energy above 2 kHz, width -12 dB; 04 (untitled): 98 BPM, 8 settled chords a minute, 1% of energy above 2 kHz, width -21 dB; 05 (untitled): 92 BPM, 11 settled chords a minute, 2% of energy above 2 kHz, width -18 dB; 06 (untitled): 89 BPM, 5 settled chords a minute, 5% of energy above 2 kHz, width -19 dB; 07 (untitled): 122 BPM, 10 settled chords a minute, 1% of energy above 2 kHz, width -17 dB; 08 (untitled): 106 BPM, 10 settled chords a minute, 2% of energy above 2 kHz, width -10 dB; 09 (untitled): 69 BPM, 15 settled chords a minute, 1% of energy above 2 kHz, width -16 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- 07 (untitled), bass group `bass-1` (459 notes): around G#1, harmonic (string/reed/pad-like), quick attack, falls 115 dB/s, centered; hear it at 1:24.4, 3:50.9. **[JUDGMENT]** why it waits.
- 06 (untitled), drums group `drums-1` (353 notes): low thump, quick attack, falls 71 dB/s, centered; hear it at 4:07.9, 4:16.0. **[JUDGMENT]** why it waits.
- 09 (untitled), bass group `bass-1` (452 notes): around F#2, harmonic (string/reed/pad-like), quick attack, falls 40 dB/s, centered; hear it at 2:20.4, 2:37.4. **[JUDGMENT]** why it waits.
- 08 (untitled), drums group `drums-1` (329 notes): low thump, soft attack, falls 38 dB/s, centered; hear it at 0:19.2, 0:16.9. **[JUDGMENT]** why it waits.
- 04 (untitled), drums group `drums-1` (190 notes): low thump, quick attack, falls 139 dB/s, centered; hear it at 0:49.6, 3:46.5. **[JUDGMENT]** why it waits.
- 05 (untitled), drums group `drums-2` (129 notes): mid snap, soft attack, falls 24 dB/s, centered; hear it at 0:32.0, 0:13.8. **[JUDGMENT]** why it waits.
- 07 (untitled), drums group `drums-1` (256 notes): low thump, quick attack, falls 61 dB/s, centered; hear it at 4:44.7, 4:46.7. **[JUDGMENT]** why it waits.
- 07 (untitled), drums group `drums-2` (116 notes): low thump, quick attack, falls 46 dB/s, centered; hear it at 4:40.4, 4:46.2. **[JUDGMENT]** why it waits.
- **03 (untitled)** (0:37.0, 86 BPM by the mix-level count): stands out for pulse strength 0.27 (low, album median 0.83); repetition 0.19 (low, album median 0.57); width (side/mid dB) -4.90 (high, album median -13.80). Too short for the deep pass (under 45 s). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
