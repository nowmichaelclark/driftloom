#!/bin/bash
export TMPDIR=/home/kruu-mikey/ears-tmp
cd /home/kruu-mikey/driftloom/tools/ears
P="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 2"
for a in "$@"; do
  python3 -P album.py "$P/$a" /home/kruu-mikey/ears7/work --stages "${STAGES:-pick}" >> /home/kruu-mikey/ears7/chain.log 2>&1
done
echo CHAIN-DONE $(date +%T) >> /home/kruu-mikey/ears7/chain.log
