Ears 7's session notes, kept when ~/ears7 was deleted (2026-10-18). chain.sh ran album.py over the albums
(resuming from cache) and chain.log is its log (stage times per album). cards/ holds the working card drafts
and comp_draft.md, ab5_body.txt and ab5_stem.txt the drafts for the Compilation and Analogue Bubblebath 5
cards; the finished cards are in docs/ears/cards-pile-2.md. separator-test-split.json is the 20 s Demucs
check from before the first album. The Demucs stems themselves were not kept; split.py rebuilds them from
the records (about 1.1 s per second of audio).
