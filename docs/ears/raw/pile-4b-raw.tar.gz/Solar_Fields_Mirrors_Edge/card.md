## Solar Fields - Mirrors Edge (draft card from Ears 3 tools, 2026-11-03)

How it was made: 10 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden; Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction; Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight. Typical track: Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden. Least like the rest: Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction, Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden**: share of power drums 26%, bass 60%, other 14%, vocals 0%.
  - vocals stem holds 0.4%: bleed on an instrumental, not a voice.
  - meter tool 75 BPM is half of the drum-grid beat of 151.9 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction**: share of power drums 23%, bass 51%, other 24%, vocals 1%.
  - vocals stem holds 1.4%: bleed on an instrumental, not a voice.
  - meter tool 107 BPM does not match the drum-grid beat of 26.8 BPM by a simple ratio: listen.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight**: share of power drums 43%, bass 20%, other 35%, vocals 2%.
  - vocals stem holds 1.9%: bleed on an instrumental, not a voice.
  - meter tool 71 BPM does not match the drum-grid beat of 80.8 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 71 to 107 BPM (octave-uncertain); keys D# phrygian, B lydian, A# locrian; mix width -10 to -6 dB; chord changes 7 to 23 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight: other group `other-1` (415 notes, 38% of the track's note energy)
- In synth terms: around A#2, mixed or noisy partials, soft attack, falls 25 dB/s, centered.
- Hear it at: 4:36.7 (E2, 4.15 s, +39 dB alone), 4:47.3 (E2, 0.54 s, +42 dB alone), 4:46.1 (E2, 1.11 s, +29 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 113 (50 to 124) Hz; attack 116 (30 to 563) ms; decay -25 (-97 to -0) dB/s
  - brightness at the start 562 (320 to 917) Hz; slope over the note 0.00 (-0.23 to 0.36) octaves
  - harmonic share 0.73 (0.18 to 0.93); partials off whole multiples 42 (18 to 70) cents
  - vibrato 0 (0 to 3) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.4 (-11.6 to -2.7) dB; pan 0.05 (-0.05 to 0.13); left-right correlation 0.33 (0.10 to 0.66)
- Group quality: weak (silhouette 0.24, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction: other group `other-1` (391 notes, 34% of the track's note energy)
- In synth terms: around C#3, mixed or noisy partials, slow swell, falls 15 dB/s, leans right (+0.16).
- Hear it at: 5:19.0 (C#3, 1.89 s, +51 dB alone), 5:18.8 (C#3, 0.49 s, +54 dB alone), 5:18.5 (C#3, 0.38 s, +53 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 139 (92 to 309) Hz; attack 202 (41 to 769) ms; decay -15 (-64 to 0) dB/s
  - brightness at the start 956 (573 to 1269) Hz; slope over the note 0.00 (-0.15 to 0.53) octaves
  - harmonic share 0.70 (0.31 to 0.93); partials off whole multiples 39 (16 to 99) cents
  - vibrato 0 (0 to 7) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.8 (-9.4 to -1.3) dB; pan 0.16 (0.07 to 0.24); left-right correlation 0.48 (0.24 to 0.73)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden: bass group `bass-1` (131 notes, 27% of the track's note energy)
- In synth terms: around D#1, harmonic (string/reed/pad-like), slow swell, falls 3 dB/s, centered.
- Hear it at: 0:00.0 (D#1, 6.05 s, +8 dB alone), 6:27.1 (D#1, 1.74 s, +6 dB alone), 6:24.2 (D#1, 2.09 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 39 (38 to 39) Hz; attack 255 (32 to 1122) ms; decay -3 (-22 to 7) dB/s
  - brightness at the start 124 (88 to 187) Hz; slope over the note 0.00 (-0.43 to 0.05) octaves
  - harmonic share 0.99 (0.52 to 1.00); partials off whole multiples 6 (2 to 64) cents
  - vibrato 0 (0 to 12) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.4 (-5.0 to -1.0) dB; pan 0.04 (0.03 to 0.05); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S4. Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight: drums group `drums-1` (288 notes, 21% of the track's note energy)
- In synth terms: low thump, soft attack, falls 79 dB/s, gets brighter over the note, centered.
- Hear it at: 2:19.1 (B1, 0.12 s, +18 dB alone), 2:21.0 (B1, 0.13 s, +15 dB alone), 2:52.9 (D2, 0.11 s, +16 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 57 (37 to 74) Hz; attack 49 (11 to 86) ms; decay -79 (-216 to -29) dB/s
  - brightness at the start 235 (86 to 540) Hz; slope over the note 0.92 (0.00 to 3.99) octaves
  - harmonic share 0.93 (0.40 to 1.00); partials off whole multiples 140 (50 to 226) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.6 (-2.9 to -0.4) dB; pan 0.03 (0.01 to 0.05); left-right correlation 1.00 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction: bass group `bass-1` (75 notes, 19% of the track's note energy)
- In synth terms: around B1, harmonic (string/reed/pad-like), slow swell, falls 8 dB/s, vibrato about 9 cents at 3.0 Hz, centered.
- Hear it at: 4:16.5 (D#2, 1.39 s, +4 dB alone), 1:26.0 (B1, 1.45 s, +2 dB alone), 0:48.9 (B1, 6.79 s, +1 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 62 (62 to 78) Hz; attack 428 (143 to 639) ms; decay -8 (-47 to -1) dB/s
  - brightness at the start 75 (68 to 84) Hz; slope over the note -0.03 (-0.17 to 0.33) octaves
  - harmonic share 0.99 (0.96 to 1.00); partials off whole multiples 19 (5 to 53) cents
  - vibrato 9 (0 to 30) cents; detune beating 0.0 (0.0 to 1.2) Hz
  - level against the mix -3.9 (-6.0 to -2.2) dB; pan -0.01 (-0.01 to -0.00); left-right correlation 1.00 (0.99 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden: other group `other-1` (298 notes, 16% of the track's note energy)
- In synth terms: around D#2, mixed or noisy partials, soft attack, falls 14 dB/s, centered.
- Hear it at: 5:25.4 (D#2, 0.5 s, +45 dB alone), 4:58.7 (D#2, 0.4 s, +39 dB alone), 5:00.5 (D2, 0.17 s, +37 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 78 (46 to 80) Hz; attack 124 (31 to 436) ms; decay -14 (-52 to 1) dB/s
  - brightness at the start 434 (318 to 674) Hz; slope over the note 0.00 (-0.15 to 0.14) octaves
  - harmonic share 0.80 (0.11 to 0.99); partials off whole multiples 31 (9 to 77) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.4 (-8.8 to -1.6) dB; pan 0.06 (-0.03 to 0.17); left-right correlation 0.43 (0.14 to 0.66)
- Group quality: weak (silhouette 0.22, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden sections:** 19 boundaries at 0:13.0, 0:39.0, 0:52.0, 2:08.0, 2:20.0, 2:47.0, 3:19.0, 3:34.0, 3:53.0, 4:16.0, 4:34.0, 4:44.0; section lengths median 18 s (range 3 to 76). Reliable for sections of 10 s or more.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden stem entries and exits:** drums plays 76% of the time (in: 0:25.5, 0:50.5, 4:02.5, 4:15.5, 4:23.5; out: 0:03.0, 0:29.0, 3:53.0, 4:09.0, 4:20.0); bass plays 84% of the time (in: 3:30.5, 4:02.0, 5:28.0, 6:19.0; out: 3:25.5, 3:53.5, 4:50.0, 6:15.5, 7:33.5); other plays 97% of the time (in: 1:22.5, 1:29.0; out: 1:18.0, 1:25.5, 7:47.0); vocals plays 15% of the time (in: 1:40.5, 3:12.0, 3:24.5, 6:07.5, 6:23.5; out: 1:55.0, 3:19.5, 3:49.0, 6:20.0, 6:30.5).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden floor drops (kick and bass out 2 s or more while the rest plays):** 1.41 a minute: 3:25.8 for 3.0 s, 3:29.0 for 2.0 s, 3:52.8 for 10.2 s, 4:03.5 for 3.8 s, 4:08.2 for 6.0 s, 4:13.8 for 2.2 s, 4:47.2 for 18.0 s, 5:19.2 for 9.2 s.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden brightness sweeps (0.7 octave or more):** mix up 2.8 oct 0:08.0 to 0:23.5; mix down 1.3 oct 0:24.0 to 0:36.0; mix down 0.8 oct 0:49.5 to 0:54.5; mix up 1.2 oct 0:54.5 to 1:05.0; mix down 0.9 oct 1:15.5 to 1:21.5; mix up 0.8 oct 1:26.0 to 1:33.0; mix down 1.7 oct 1:42.0 to 1:52.0; mix up 1.1 oct 1:58.5 to 2:16.5 (50 more in techniques.json).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden pumping locked to the kick:** bass dips 2.3 dB at the kick (peak 35 ms after, kick every 0.38 s). The tool reads about 70% of the true depth, so this is a floor.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden tape wobble and speed:** other wobbles about 11 cents at 1.8 Hz; other speed moves up to 19 cents in 4 s; bass wobbles about 9 cents at 2.3 Hz; bass speed moves up to 25 cents in 4 s.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden stereo movement:** other pan range 0.29.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden builds:** 3:57.0 to 4:18.0.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction sections:** 13 boundaries at 0:05.0, 0:42.0, 1:12.0, 1:40.0, 1:51.0, 2:29.0, 2:48.0, 3:26.0, 3:58.0, 4:32.0, 4:44.0, 5:14.0; section lengths median 29 s (range 3 to 38). Reliable for sections of 10 s or more.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction stem entries and exits:** drums plays 64% of the time (in: 0:19.5, 1:15.0, 3:03.5; out: 0:03.5, 0:23.5, 2:29.5, 5:15.5); bass plays 75% of the time (in: 0:40.0, 2:45.5, 3:07.0, 4:02.0; out: 2:29.0, 3:03.0, 3:59.0, 5:15.0); other plays 98% of the time (in: 0:04.0; out: 5:31.0); vocals plays 61% of the time (in: 0:01.5, 0:21.5, 0:52.5, 1:05.5, 1:29.5; out: 0:19.0, 0:42.0, 1:00.5, 1:17.5, 1:35.5).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction floor drops (kick and bass out 2 s or more while the rest plays):** 1.20 a minute: 0:16.5 for 5.5 s, 0:21.8 for 19.0 s, 2:28.8 for 18.0 s, 3:01.5 for 2.8 s, 3:58.5 for 4.0 s, 5:14.8 for 2.8 s.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction brightness sweeps (0.7 octave or more):** mix down 1.0 oct 0:03.0 to 0:12.5; mix up 1.1 oct 0:18.0 to 0:23.0; mix down 0.7 oct 0:23.5 to 0:28.5; mix down 1.1 oct 1:12.5 to 1:25.5; mix up 1.2 oct 1:42.5 to 1:47.5; mix up 1.1 oct 2:09.0 to 2:23.5; mix up 0.8 oct 2:26.0 to 2:31.0; mix down 0.7 oct 2:47.0 to 2:52.0 (18 more in techniques.json).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction pumping locked to the kick:** under 1.5 dB; none found.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction tape wobble and speed:** other wobbles about 5 cents at 2.3 Hz; bass wobbles about 7 cents at 0.5 Hz.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction stereo movement:** bass pan range 0.26; vocals pan range 0.32.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight sections:** 15 boundaries at 0:02.0, 0:40.0, 1:13.0, 1:36.0, 2:18.0, 3:26.0, 4:27.0, 4:40.0, 4:53.0, 5:04.0, 5:16.0, 5:28.0; section lengths median 14 s (range 2 to 68). Reliable for sections of 10 s or more.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight stem entries and exits:** drums plays 68% of the time (in: 0:24.0, 0:54.0, 1:10.0, 1:32.0, 3:19.5; out: 0:16.5, 0:45.0, 1:00.5, 1:16.5, 3:11.0); bass plays 83% of the time (in: 1:27.5, 3:37.0, 4:51.0, 5:51.0, 6:27.0; out: 1:23.0, 3:21.5, 4:30.5, 5:45.0, 6:15.5); other plays 98% of the time (in: from the start; out: 6:47.5); vocals plays 42% of the time (in: 1:12.0, 1:33.0, 1:47.0, 2:00.5, 2:49.5; out: 1:22.0, 1:39.0, 1:53.5, 2:46.0, 3:27.5).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight floor drops (kick and bass out 2 s or more while the rest plays):** 1.45 a minute: 1:05.2 for 2.2 s, 1:14.0 for 4.2 s, 1:18.8 for 10.5 s, 3:20.0 for 3.5 s, 3:24.5 for 14.8 s, 4:09.5 for 5.0 s, 4:17.0 for 2.5 s, 4:27.5 for 24.0 s.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight brightness sweeps (0.7 octave or more):** mix down 1.2 oct 0:04.5 to 0:14.5; mix up 0.9 oct 0:15.0 to 0:22.0; mix down 0.9 oct 0:35.5 to 0:43.5; mix up 2.0 oct 0:57.0 to 1:13.0; mix down 0.9 oct 1:24.5 to 1:30.5; mix down 1.4 oct 1:34.5 to 1:42.0; mix up 0.9 oct 1:43.5 to 1:49.5; mix down 1.1 oct 2:02.5 to 2:08.0 (59 more in techniques.json).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight echo times:** drums: 743 ms (+9.5 dB, 1 later repeats).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight pumping locked to the kick:** other dips 1.5 dB at the kick (peak 0 ms after, kick every 0.38 s); bass dips 5.3 dB at the kick (peak 0 ms after, kick every 0.38 s). The tool reads about 70% of the true depth, so this is a floor.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight tape wobble and speed:** other wobbles about 11 cents at 2.2 Hz; bass wobbles about 9 cents at 1.6 Hz; bass speed moves up to 12 cents in 4 s.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight stereo movement:** bass pan range 0.30.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight builds:** 3:31.0 to 3:55.0; 4:47.0 to 5:07.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden meter:** about 75 BPM (could be 37 or 150; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.15); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden key and mode:** D# phrygian (low confidence: the key signature margin is 0.003, so read this as a guess); fits D# pentatonic; pitch-class weights D# 0.31, A# 0.11, C# 0.11, D 0.10, E 0.07.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden chords:** 7 changes a minute (5 a minute are chords that last 1.5 s or more); median chord 2.8 s (10th to 90th percentile 1.2 to 24.9 s); 15 distinct chords; most time on D#5 42%, C#sus2 22%, D#maj7 16%, D#sus2 7%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  20% of the changes land on a beat (chance would be 37%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden bass:** pedal (one note held or repeated); 0.69 notes a second; most time on D# 0.96, F# 0.02; steps 9%, thirds 1%, fourths and fifths 1%, octaves 13%, repeats 75%.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden top line (from the 'other' stem; read by ear before trusting):** 1129 notes, range 17 semitones (10th to 90th percentile); steps 19%, thirds 6%, fourths and fifths 28%, leaps 21%, repeats 26%; median interval 3 semitones; 50% of moves go up; phrases of about 26 notes, arch 14%, rising 21%, falling 25%, flat or wavy 39%. Reliable only when the line sits clearly above its accompaniment.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden repetition:** 147 bars of 3.2 s; strongest repeat distances 1 bars (0.72); 13% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction meter:** about 107 BPM (could be 54 or 214; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction key and mode:** B lydian (low confidence: the key signature margin is 0.012, so read this as a guess); pitch-class weights C# 0.20, D# 0.19, A# 0.15, F# 0.08, F 0.07.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction chords:** 23 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 2.2 s (10th to 90th percentile 0.8 to 4.3 s); 18 distinct chords; most time on D#5 28%, D#min7 14%, Bmaj7 14%, C#5 9%. The old counter in this same run said 17; Ears 1's 2-s counter said 15.  37% of the changes land on a beat (chance would be 54%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction bass:** root-note movement / mixed; 0.95 notes a second; most time on B 0.41, D# 0.29, C# 0.22, A# 0.04; steps 14%, thirds 2%, fourths and fifths 4%, octaves 0%, repeats 72%.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction top line (from the 'other' stem; read by ear before trusting):** 784 notes, range 18 semitones (10th to 90th percentile); steps 17%, thirds 11%, fourths and fifths 17%, leaps 34%, repeats 21%; median interval 5 semitones; 49% of moves go up; phrases of about 7 notes, arch 38%, rising 19%, falling 24%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction repetition:** 149 bars of 2.2 s; strongest repeat distances 1 bars (0.59), 8 bars (0.37), 16 bars (0.15); 3% of bars near-duplicate an earlier bar.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight meter:** about 71 BPM (could be 36 or 142; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.04); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 7:4), which means irregular timing, not a cross-rhythm claim.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight key and mode:** A# locrian (low confidence: the key signature margin is 0.011, so read this as a guess); pitch-class weights B 0.15, A# 0.14, E 0.10, C 0.09, D# 0.09.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight chords:** 7 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 5.8 s (10th to 90th percentile 1.3 to 20.8 s); 22 distinct chords; most time on Esus2 21%, A#sus2 13%, E5 13%, A#5 12%. The old counter in this same run said 2; Ears 1's 2-s counter said 1.  34% of the changes land on a beat (chance would be 36%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight bass:** root-note movement / mixed; 0.24 notes a second; most time on A# 0.68, F 0.12, E 0.08, C 0.08; steps 5%, thirds 2%, fourths and fifths 5%, octaves 1%, repeats 85%.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight top line (from the 'other' stem; read by ear before trusting):** 731 notes, range 12 semitones (10th to 90th percentile); steps 6%, thirds 7%, fourths and fifths 35%, leaps 14%, repeats 39%; median interval 3 semitones; 50% of moves go up; phrases of about 7 notes, arch 32%, rising 20%, falling 24%, flat or wavy 24%. Reliable only when the line sits clearly above its accompaniment.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight repetition:** 123 bars of 3.4 s; strongest repeat distances 1 bars (0.76); 10% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -21 (corr 0.99); low_120_500 -9 (corr 0.76); mid_500_2k -2 (corr 0.23); pres_2k_5k -9 (corr 0.77); air_gt5k -12 (corr 0.88); over time (2-s windows) 10th/50th/90th percentile -13/-5/-1 dB.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden by part:** drums: 23% of the power, width -18 dB, pan +0.10, mono loss 0.1 dB, widest in low_120_500 (-17 dB); bass: 56% of the power, width -25 dB, pan +0.09, mono loss 0.0 dB, widest in low_120_500 (-23 dB); other: 20% of the power, width -2 dB, pan +0.18, mono loss 2.1 dB, widest in mid_500_2k (-1 dB); vocals: 1% of the power, width 1 dB, pan +0.15, mono loss 3.5 dB, widest in mid_500_2k (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -14 (corr 0.92); low_120_500 -7 (corr 0.69); mid_500_2k -4 (corr 0.45); pres_2k_5k -2 (corr 0.26); air_gt5k -8 (corr 0.72); over time (2-s windows) 10th/50th/90th percentile -7/-5/-3 dB.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction by part:** drums: 20% of the power, width -25 dB, pan +0.07, mono loss 0.0 dB, widest in sub_lt120 (-27 dB); bass: 48% of the power, width -12 dB, pan +0.00, mono loss 0.3 dB, widest in sub_lt120 (-12 dB); other: 30% of the power, width -4 dB, pan +0.29, mono loss 1.5 dB, widest in pres_2k_5k (-1 dB); vocals: 2% of the power, width -4 dB, pan +0.13, mono loss 1.5 dB, widest in mid_500_2k (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -9 (corr 0.80); low_120_500 -5 (corr 0.50); mid_500_2k -3 (corr 0.37); pres_2k_5k -6 (corr 0.61); air_gt5k -9 (corr 0.76); over time (2-s windows) 10th/50th/90th percentile -8/-4/-2 dB.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight by part:** drums: 36% of the power, width -16 dB, pan +0.07, mono loss 0.1 dB, widest in sub_lt120 (-18 dB); bass: 19% of the power, width -8 dB, pan +0.04, mono loss 0.6 dB, widest in sub_lt120 (-8 dB); other: 43% of the power, width -3 dB, pan +0.06, mono loss 1.7 dB, widest in mid_500_2k (-2 dB); vocals: 3% of the power, width -2 dB, pan +0.08, mono loss 2.3 dB, widest in mid_500_2k (-2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden: 75 BPM, 5 settled chords a minute, 2% of energy above 2 kHz, width -10 dB; Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction: 107 BPM, 17 settled chords a minute, 4% of energy above 2 kHz, width -8 dB; Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight: 71 BPM, 6 settled chords a minute, 5% of energy above 2 kHz, width -6 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction, drums group `drums-1` (414 notes): low thump, quick attack, falls 71 dB/s, centered; hear it at 4:48.5, 4:06.0. **[JUDGMENT]** why it waits.
- Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight, drums group `drums-2` (210 notes): high tick, soft attack, falls 88 dB/s, gets brighter over the note, centered; hear it at 6:19.2, 2:25.9. **[JUDGMENT]** why it waits.
- Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden, drums group `drums-1` (371 notes): low thump, quick attack, falls 109 dB/s, gets brighter over the note, centered; hear it at 6:19.3, 4:07.4. **[JUDGMENT]** why it waits.
- Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden, bass group `bass-2` (100 notes): around D#2, harmonic (string/reed/pad-like), slow swell, falls 3 dB/s, centered; hear it at 2:43.4, 6:21.1. **[JUDGMENT]** why it waits.
- Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction, bass group `bass-2` (35 notes): around D#1, harmonic (string/reed/pad-like), slow swell, falls 6 dB/s, centered; hear it at 3:28.3, 1:07.3. **[JUDGMENT]** why it waits.
- Solar Fields - Mirror's Edge (Original Videogame Score) - 02 - Edge Flight, bass group `bass-1` (434 notes): around A#1, mixed or noisy partials, quick attack, falls 51 dB/s, centered; hear it at 2:07.2, 1:44.9. **[JUDGMENT]** why it waits.
- Solar Fields - Mirror's Edge (Original Videogame Score) - 06 - New Eden, other group `other-2` (202 notes): around D#3, mixed or noisy partials, soft attack, falls 14 dB/s, centered; hear it at 5:25.1, 5:23.9. **[JUDGMENT]** why it waits.
- Solar Fields - Mirror's Edge (Original Videogame Score) - 01 - Introduction, other group `other-2` (109 notes): around D#4, mixed or noisy partials, slow swell, falls 13 dB/s, leans right (+0.21); hear it at 5:17.6, 2:29.5. **[JUDGMENT]** why it waits.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 04 - Heat** (7:01.1, 136 BPM by the mix-level count): stands out for width (side/mid dB) -13.50 (low, album median -9.25). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 03 - Jacknife** (6:25.3, 112 BPM by the mix-level count): stands out for brightness sweep (octaves) 3.02 (high, album median 1.61). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Solar Fields - Mirror's Edge (Original Videogame Score) - 10 - Shard** (7:16.8, 136 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 8.50 (high, album median 1.90). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
