# Ears 10b: fit the beat from the drums stem's kicks (5 ms frames), then give moment times in beats from the grid's zero.
# Usage: python3 -P beatfit.py STEMDIR BEAT_GUESS_S T1 T2 ...
import sys, numpy as np, soundfile as sf
from scipy.signal import butter, sosfiltfilt, find_peaks
HOP = 0.005
d, P0, events = sys.argv[1], float(sys.argv[2]), np.array([float(t) for t in sys.argv[3:]])
x, sr = sf.read(d + "/drums.wav", dtype="float32"); x = x.mean(1)
x = sosfiltfilt(butter(4, (30, 150), btype="band", fs=sr, output="sos"), x)
h = int(HOP * sr); n = len(x) // h
e = 20 * np.log10(np.sqrt((x[: n * h].reshape(n, h) ** 2).mean(1)) + 1e-9)
de = np.convolve(np.diff(e, prepend=e[0]), np.ones(4), mode="same")
p, _ = find_peaks(de, height=6, distance=int(0.2 / HOP)); k = np.array([i for i in p if e[i] > e.max() - 18]) * HOP
Ps = np.linspace(P0 * 0.99, P0 * 1.01, 4001); sc = [abs(np.exp(2j * np.pi * k / P).mean()) for P in Ps]
P = Ps[int(np.argmax(sc))]; ph = np.angle(np.exp(2j * np.pi * k / P).mean()) / (2 * np.pi) * P
b = (events - ph) / P
print("kicks", len(k), "beat %.5f s = %.2f BPM, lock %.2f" % (P, 60 / P, max(sc)))
print("moments in beats:", [round(float(v), 1) for v in b]); print("gaps:", [round(float(v), 1) for v in np.diff(b)])
