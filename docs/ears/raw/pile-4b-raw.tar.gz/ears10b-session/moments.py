"""Ears 10b: how a track changes at its moments (for the core's loop changes at a beat, bar, phrase or pass).

For each stem entry or exit (techniques.json stem_activity), each floor drop and each strong section boundary:
- refine the time to the steepest level change of that stem (50 ms frames, within +-2 s);
- the change's length: 10% to 90% of the dB step between [t-4, t-1] and [t+1, t+4] (a cut is under ~100 ms, a fade longer);
- where it lands against the drum grid: kicks from the drums stem (30-150 Hz onsets); the beat is the median kick gap
  folded to the grid beat when given; offset from the nearest kick in beats, and the beat count since the first kick.
Usage: python3 -P moments.py TRACKWORK STEMDIR [GRID_BEAT_S]
"""
import json, sys, os
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfiltfilt, find_peaks

work, stems = sys.argv[1], sys.argv[2]
grid = float(sys.argv[3]) if len(sys.argv) > 3 else None
tech = json.load(open(os.path.join(work, "techniques.json")))
HOP = 0.05


def env(name, band=None):
    x, sr = sf.read(os.path.join(stems, name + ".wav"), dtype="float32")
    x = x.mean(axis=1) if x.ndim > 1 else x
    if band:
        x = sosfiltfilt(butter(4, band, btype="band", fs=sr, output="sos"), x)
    h = int(HOP * sr)
    n = len(x) // h
    r = np.sqrt((x[: n * h].reshape(n, h) ** 2).mean(axis=1) + 1e-12)
    return 20 * np.log10(r)


E = {s: env(s) for s in ("drums", "bass", "other", "vocals")}
mix = 10 * np.log10(sum(10 ** (E[s] / 10) for s in E))
E["mix"] = mix

# kicks
kd = env("drums", (30, 150))
dk = np.diff(kd, prepend=kd[0])
pk, _ = find_peaks(dk, height=6, distance=int(0.25 / HOP))
pk = [p for p in pk if kd[p] > kd.max() - 18]
kicks = np.array(pk) * HOP
beat = None
if len(kicks) > 8:
    g = np.median(np.diff(kicks))
    beat = grid if grid else g


def refine(s, t):
    e = E[s]
    i0, i1 = max(1, int((t - 2) / HOP)), min(len(e) - 1, int((t + 2) / HOP))
    d = np.convolve(np.diff(e), np.ones(3) / 3, mode="same")
    j = i0 + int(np.argmax(np.abs(d[i0:i1])))
    return j * HOP


def length(s, t):
    e = E[s]
    a = np.median(e[max(0, int((t - 4) / HOP)): max(1, int((t - 1) / HOP))])
    b = np.median(e[int((t + 1) / HOP): int((t + 4) / HOP)])
    if abs(b - a) < 3:
        return None, round(float(b - a), 1)
    seg = 10 ** (e[max(0, int((t - 4) / HOP)): int((t + 4) / HOP)] / 20)
    a, b, step = 10 ** (a / 20), 10 ** (b / 20), b - a
    lo, hi = a + 0.1 * (b - a), a + 0.9 * (b - a)
    up = b > a
    c10 = next((i for i, v in enumerate(seg) if (v >= lo if up else v <= lo)), None)
    c90 = next((i for i, v in enumerate(seg) if (v >= hi if up else v <= hi)), None)
    if c10 is None or c90 is None:
        return None, round(float(step), 1)
    return round(abs(c90 - c10) * HOP, 2), round(float(step), 1)


def where(t):
    if beat is None:
        return None
    k = kicks[np.argmin(np.abs(kicks - t))]
    n = (t - kicks[0]) / beat
    return {"beats_since_first_kick": round(float(n), 1), "near_kick_s": round(float(t - k), 2),
            "off_beat": round(float((t - k) / beat), 2)}


ev = []
for s, a in tech["stem_activity"].items():
    for t in a.get("enters", []):
        ev.append((s, "enters", t))
    for t in a.get("leaves", []):
        if t < tech["seconds"] - 3:
            ev.append((s, "leaves", t))
for d in tech["floor_drops"]["drops"]:
    ev.append(("bass", "floor drop", d["t0"]))
    ev.append(("bass", "floor back", d["t1"]))
for b in tech["sections"]["boundaries"]:
    if b["strength"] >= 0.6:
        ev.append(("mix", "section", b["t"]))
out = {"beat_s": round(beat, 4) if beat else None, "kicks": len(kicks), "first_kick": round(float(kicks[0]), 2) if len(kicks) else None, "moments": []}
for s, kind, t in sorted(ev, key=lambda e: e[2]):
    tr = refine(s, t)
    ln, step = length(s, tr)
    out["moments"].append({"stem": s, "kind": kind, "t": round(tr, 2), "len_s": ln, "step_db": step, "grid": where(tr)})
if len(sys.argv) > 4:
    json.dump(out, open(sys.argv[4], "w"), indent=1)
print("beat", out["beat_s"], "kicks", out["kicks"], "first", out["first_kick"])
for m in out["moments"]:
    g = m["grid"] or {}
    print("%7.2f %-6s %-10s len %-5s step %6s  beats %s off_kick %s beat" % (m["t"], m["stem"], m["kind"], m["len_s"], m["step_db"], g.get("beats_since_first_kick"), g.get("off_beat")))
