#!/bin/bash
# Ears 10b: 2814 and Mirror's Edge, one album.py stage per process (memory freed between stages), resumes from cache.
export TMPDIR=~/ears10/tmp
cd ~/ears10
T=/home/kruu-mikey/driftloom/tools/ears
run() { A="$1"; W="$2"; S=$(date +%s); echo "$(date +%T) START $A"
  for st in split events techniques theory space check card; do
    python3 -P $T/album.py "audio/$A" work --stages $st --workers $W || echo "FAILED $st $A"
    echo "$(date +%T) stage $st done"
  done
  python3 -P ~/ears10/lf_album.py "audio/$A" work || echo "FAILED longform $A"
  echo "$(date +%T) END $A $(( $(date +%s) - S )) s"; }
run "Solar Fields - Mirrors Edge" 2
run "2814 - Birth of a New Day" 1
echo CHAINDONE
