## 2814 - Birth of a New Day (draft card from Ears 3 tools, 2026-11-03)

How it was made: 9 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: 恢复; 新しい日の誕生; 悲哀. Typical track: 恢复. Least like the rest: 新しい日の誕生, 悲哀.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **恢复**: share of power drums 33%, bass 16%, other 50%, vocals 1%.
  - vocals stem holds 0.7%: bleed on an instrumental, not a voice.
  - meter tool 88 BPM is half of the drum-grid beat of 178.0 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **新しい日の誕生**: share of power drums 2%, bass 7%, other 88%, vocals 4%.
  - vocals stem holds 3.7%: bleed on an instrumental, not a voice.
- **悲哀**: share of power drums 23%, bass 26%, other 39%, vocals 12%.
  - meter tool 106 BPM does not match the drum-grid beat of 26.5 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 88 to 132 BPM (octave-uncertain); keys C# lydian, A dorian, G# ionian; mix width -3 to 0 dB; chord changes 3 to 15 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 新しい日の誕生: other group `other-1` (435 notes, 57% of the track's note energy)
- In synth terms: around A1, mixed or noisy partials, soft attack, falls 6 dB/s, centered.
- Hear it at: 11:09.3 (A1, 0.21 s, +44 dB alone), 11:09.0 (A1, 0.36 s, +44 dB alone), 7:03.2 (C2, 0.11 s, +43 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 56 (54 to 66) Hz; attack 149 (36 to 392) ms; decay -6 (-41 to 2) dB/s
  - brightness at the start 524 (441 to 641) Hz; slope over the note 0.00 (-0.19 to 0.19) octaves
  - harmonic share 0.63 (0.27 to 0.82); partials off whole multiples 46 (28 to 85) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.8 (-3.7 to -2.0) dB; pan 0.03 (-0.01 to 0.10); left-right correlation 0.09 (-0.10 to 0.30)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. 恢复: other group `other-1` (314 notes, 35% of the track's note energy)
- In synth terms: around C#2, mixed or noisy partials, slow swell, falls 12 dB/s, centered.
- Hear it at: 4:55.5 (D#2, 2.05 s, +53 dB alone), 0:47.6 (F2, 3.36 s, +52 dB alone), 1:20.9 (A#2, 4.4 s, +52 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 70 (52 to 105) Hz; attack 229 (52 to 552) ms; decay -12 (-52 to 0) dB/s
  - brightness at the start 585 (424 to 759) Hz; slope over the note 0.00 (-0.42 to 0.16) octaves
  - harmonic share 0.57 (0.33 to 0.81); partials off whole multiples 57 (28 to 128) cents
  - vibrato 0 (0 to 7) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -3.2 (-7.5 to -2.4) dB; pan 0.02 (-0.08 to 0.09); left-right correlation 0.12 (-0.10 to 0.26)
- Group quality: weak (silhouette 0.19, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. 悲哀: bass group `bass-1` (205 notes, 28% of the track's note energy)
- In synth terms: around G#2, bell- or metal-like (partials off whole multiples), quick attack, falls 26 dB/s, vibrato about 20 cents at 3.0 Hz, centered.
- Hear it at: 7:30.7 (G#2, 0.82 s, +1 dB alone), 1:17.1 (G#2, 0.94 s, +1 dB alone), 2:40.9 (G#2, 0.9 s, +1 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 104 (98 to 105) Hz; attack 15 (13 to 26) ms; decay -26 (-62 to -23) dB/s
  - brightness at the start 104 (103 to 130) Hz; slope over the note 0.03 (-0.03 to 0.22) octaves
  - harmonic share 0.97 (0.15 to 0.99); partials off whole multiples 92 (21 to 320) cents
  - vibrato 20 (0 to 29) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.9 (-27.4 to -3.2) dB; pan -0.00 (-0.03 to 0.03); left-right correlation 0.96 (0.92 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S4. 恢复: drums group `drums-1` (172 notes, 24% of the track's note energy)
- In synth terms: low thump, soft attack, falls 57 dB/s, gets brighter over the note, centered.
- Hear it at: 1:32.8 (F1, 0.29 s, +13 dB alone), 1:31.6 (E1, 0.82 s, +11 dB alone), 1:48.0 (E1, 0.32 s, +12 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 39 (39 to 44) Hz; attack 121 (55 to 168) ms; decay -57 (-67 to -49) dB/s
  - brightness at the start 120 (103 to 167) Hz; slope over the note 0.35 (-0.33 to 2.46) octaves
  - harmonic share 1.00 (0.98 to 1.00); partials off whole multiples 150 (33 to 264) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.3 (-6.3 to -0.7) dB; pan -0.00 (-0.00 to 0.00); left-right correlation 1.00 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S5. 悲哀: other group `other-1` (283 notes, 20% of the track's note energy)
- In synth terms: around G#1, mixed or noisy partials, slow swell, falls 11 dB/s, centered.
- Hear it at: 3:02.6 (G1, 0.72 s, +43 dB alone), 3:05.6 (G#1, 0.32 s, +42 dB alone), 4:10.6 (D#1, 0.34 s, +42 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 51 (37 to 52) Hz; attack 186 (50 to 497) ms; decay -11 (-40 to 0) dB/s
  - brightness at the start 537 (313 to 750) Hz; slope over the note 0.00 (-0.46 to 0.31) octaves
  - harmonic share 0.75 (0.39 to 0.92); partials off whole multiples 33 (16 to 82) cents
  - vibrato 0 (0 to 9) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.9 (-8.6 to -2.9) dB; pan 0.00 (-0.08 to 0.07); left-right correlation -0.19 (-0.42 to 0.23)
- Group quality: weak (silhouette 0.25, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. 新しい日の誕生: bass group `bass-1` (467 notes, 17% of the track's note energy)
- In synth terms: around A1, harmonic (string/reed/pad-like), slow swell, falls 8 dB/s, centered.
- Hear it at: 4:43.9 (A1, 0.88 s, -1 dB alone), 5:24.3 (A1, 1.01 s, -3 dB alone), 10:59.3 (A1, 1.69 s, -6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 55 (55 to 56) Hz; attack 231 (29 to 614) ms; decay -8 (-73 to 1) dB/s
  - brightness at the start 102 (71 to 117) Hz; slope over the note 0.00 (-0.07 to 0.16) octaves
  - harmonic share 0.99 (0.76 to 1.00); partials off whole multiples 18 (5 to 79) cents
  - vibrato 0 (0 to 9) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -12.7 (-18.2 to -7.0) dB; pan -0.00 (-0.14 to 0.10); left-right correlation 0.94 (0.65 to 0.99)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **恢复 sections:** 9 boundaries at 0:45.0, 1:31.0, 2:17.0, 2:36.0, 2:58.0, 3:44.0, 4:03.0, 4:28.0, 5:13.0; section lengths median 42 s (range 19 to 46). Reliable for sections of 10 s or more.
- **恢复 stem entries and exits:** drums plays 28% of the time (in: 1:29.5, 2:40.0, 2:56.5, 5:37.5; out: 2:14.5, 2:45.0, 3:41.5, 5:40.0); bass plays 50% of the time (in: 1:29.5; out: 4:25.0); other plays 99% of the time (in: 0:02.0; out: never); vocals plays 11% of the time (in: 2:26.0, 4:00.0, 4:14.5, 5:33.0; out: 0:02.5, 2:28.5, 4:07.0, 4:30.0, 5:42.5).
- **恢复 floor drops:** low end too sparse to say (on in under 75% of the track).
- **恢复 brightness sweeps (0.7 octave or more):** mix up 1.2 oct 0:40.5 to 0:46.0; mix up 0.7 oct 0:51.0 to 0:56.5; mix up 1.1 oct 1:01.0 to 1:07.5; mix down 1.3 oct 1:07.5 to 1:12.5; mix up 1.2 oct 1:13.0 to 1:19.0; mix down 3.0 oct 1:26.5 to 1:36.5; mix up 0.9 oct 2:33.0 to 2:38.5; mix down 2.5 oct 2:53.0 to 3:00.5 (22 more in techniques.json).
- **恢复 echo times:** drums: 604 ms (+4.7 dB, 2 later repeats).
- **恢复 pumping locked to the kick:** other dips 5.3 dB at the kick (peak 85 ms after, kick every 0.55 s); bass dips 8.2 dB at the kick (peak 85 ms after, kick every 0.55 s). The tool reads about 70% of the true depth, so this is a floor.
- **恢复 tape wobble and speed:** other wobbles about 11 cents at 1.5 Hz.
- **恢复 stereo movement:** bass pan range 0.26; vocals pan range 0.37.
- **恢复 builds:** 0:00.0 to 0:21.0.
- **新しい日の誕生 sections:** 30 boundaries at 0:02.0, 1:29.0, 2:26.0, 2:56.0, 3:15.0, 3:28.0, 3:39.0, 3:52.0, 4:16.0, 4:27.0, 4:49.0, 5:21.0; section lengths median 19 s (range 2 to 107). Reliable for sections of 10 s or more.
- **新しい日の誕生 stem entries and exits:** drums plays 69% of the time (in: 2:09.0, 12:35.5; out: 11:02.0, 12:44.5); bass plays 63% of the time (in: 1:28.5, 1:51.0, 2:22.0, 3:24.5, 3:53.5; out: 1:35.0, 2:16.5, 3:21.0, 3:38.0, 4:09.0); other plays 97% of the time (in: from the start; out: 12:42.5); vocals plays 50% of the time (in: 0:12.0, 0:29.0, 0:42.0, 0:58.5, 3:13.0; out: 0:08.0, 0:25.5, 0:37.0, 0:54.0, 2:32.5).
- **新しい日の誕生 floor drops (kick and bass out 2 s or more while the rest plays):** 1.02 a minute: 0:42.2 for 47.8 s, 1:32.8 for 19.8 s, 2:00.2 for 2.8 s, 7:02.5 for 6.2 s, 7:09.8 for 5.0 s, 7:27.5 for 2.5 s, 8:33.0 for 2.5 s, 11:07.0 for 20.5 s.
- **新しい日の誕生 brightness sweeps (0.7 octave or more):** mix up 1.6 oct 0:03.0 to 0:11.0; mix down 1.1 oct 0:12.0 to 0:19.0; mix up 1.1 oct 0:19.0 to 0:26.0; mix down 1.4 oct 0:26.5 to 0:33.0; mix up 1.4 oct 0:33.0 to 0:40.5; mix down 1.2 oct 0:41.0 to 0:48.0; mix up 1.2 oct 0:48.5 to 0:55.0; mix down 1.4 oct 0:56.0 to 1:02.5 (73 more in techniques.json).
- **新しい日の誕生 echo times:** drums: 688 ms (+11.9 dB, 1 later repeats).
- **新しい日の誕生 pumping locked to the kick:** under 1.5 dB; none found.
- **新しい日の誕生 tape wobble and speed:** other wobbles about 10 cents at 4.6 Hz; bass wobbles about 17 cents at 1.1 Hz.
- **新しい日の誕生 stereo movement:** drums pan range 0.28; vocals pan range 0.32.
- **悲哀 sections:** 24 boundaries at 1:04.0, 1:22.0, 1:40.0, 1:58.0, 2:17.0, 2:53.0, 3:32.0, 3:50.0, 4:06.0, 4:22.0, 4:40.0, 5:00.0; section lengths median 18 s (range 12 to 64). Reliable for sections of 10 s or more.
- **悲哀 stem entries and exits:** drums plays 89% of the time (in: 0:07.0, 0:35.5; out: 0:23.0, 8:43.5); bass plays 55% of the time (in: 0:40.0, 0:56.0, 2:13.0, 2:22.0, 2:35.5; out: 0:53.5, 2:04.0, 2:19.5, 2:29.0, 2:42.5); other plays 99% of the time (in: 9:19.5; out: 9:11.5); vocals plays 26% of the time (in: 0:26.5, 0:46.0, 1:39.0, 5:16.5, 6:29.0; out: 0:43.0, 1:05.5, 2:16.0, 5:52.5, 7:03.0).
- **悲哀 floor drops (kick and bass out 2 s or more while the rest plays):** 0.36 a minute: 0:28.0 for 8.2 s, 8:44.2 for 2.0 s, 8:46.5 for 2.5 s.
- **悲哀 brightness sweeps (0.7 octave or more):** mix up 0.7 oct 0:43.0 to 0:48.0; mix down 0.8 oct 1:13.5 to 1:20.0; mix up 1.0 oct 1:20.5 to 1:28.5; mix up 0.8 oct 2:31.0 to 2:37.5; mix down 0.8 oct 3:25.5 to 3:32.0; mix up 1.1 oct 4:03.5 to 4:10.0; mix down 0.8 oct 4:55.0 to 5:02.0; mix up 1.1 oct 5:15.0 to 5:22.5 (35 more in techniques.json).
- **悲哀 echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **悲哀 pumping locked to the kick:** other dips 2.3 dB at the kick (peak 25 ms after, kick every 0.57 s); bass dips 5.8 dB at the kick (peak 249 ms after, kick every 0.57 s). The tool reads about 70% of the true depth, so this is a floor.
- **悲哀 tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **悲哀 stereo movement:** drums pan range 0.15, cycling every 3 s.
- **悲哀 builds:** 0:00.0 to 0:36.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **恢复 meter:** about 88 BPM (could be 44 or 176; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **恢复 key and mode:** C# lydian (key signature margin 0.026); pitch-class weights F 0.19, C# 0.14, C 0.13, D# 0.12, A# 0.08.
- **恢复 chords:** 14 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 1.4 s (10th to 90th percentile 0.7 to 4.9 s); 19 distinct chords; most time on Fmin7 36%, A#min 28%, C#maj7 16%, D#sus2 3%. The old counter in this same run said 2; Ears 1's 2-s counter said 2.  28% of the changes land on a beat (chance would be 44%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **恢复 bass:** root-note movement / mixed; 0.38 notes a second; most time on C# 0.66, F 0.23, D# 0.11; steps 24%, thirds 4%, fourths and fifths 0%, octaves 2%, repeats 46%.
- **恢复 top line (from the 'other' stem; read by ear before trusting):** 892 notes, range 15 semitones (10th to 90th percentile); steps 5%, thirds 28%, fourths and fifths 32%, leaps 17%, repeats 18%; median interval 4 semitones; 52% of moves go up; phrases of about 14 notes, arch 18%, rising 18%, falling 45%, flat or wavy 18%. Reliable only when the line sits clearly above its accompaniment.
- **恢复 repetition:** 128 bars of 2.7 s; strongest repeat distances 1 bars (0.79), 32 bars (0.06); 28% of bars near-duplicate an earlier bar.
- **新しい日の誕生 meter:** about 132 BPM (could be 66 or 264; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.04); straight eighths; no cross-rhythm claim; many unrelated periodicities found (4:3, 5:2, 5:3, 5:4), which means irregular timing, not a cross-rhythm claim.
- **新しい日の誕生 key and mode:** A dorian (low confidence: the key signature margin is 0.000, so read this as a guess); pitch-class weights C 0.18, E 0.15, A 0.14, G 0.13, B 0.10.
- **新しい日の誕生 chords:** 3 changes a minute (3 a minute are chords that last 1.5 s or more); median chord 9.3 s (10th to 90th percentile 2.9 to 72.5 s); 9 distinct chords; most time on Amin7 81%, Cmaj7 9%, Emin7 5%, Asus2 2%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  62% of the changes land on a beat (chance would be 66%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **新しい日の誕生 bass:** pedal (one note held or repeated); 0.43 notes a second; most time on A 0.93, C 0.07; steps 0%, thirds 8%, fourths and fifths 0%, octaves 6%, repeats 86%.
- **新しい日の誕生 top line (from the 'other' stem; read by ear before trusting):** 1911 notes, range 9 semitones (10th to 90th percentile); steps 10%, thirds 26%, fourths and fifths 21%, leaps 18%, repeats 24%; median interval 4 semitones; 50% of moves go up; phrases of about 13 notes, arch 30%, rising 5%, falling 24%, flat or wavy 41%. Reliable only when the line sits clearly above its accompaniment.
- **新しい日の誕生 repetition:** 431 bars of 1.8 s; strongest repeat distances 1 bars (0.70), 8 bars (0.53), 16 bars (0.46); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **悲哀 meter:** about 106 BPM (could be 53 or 212; the tool cannot tell the beat level), 12 beats a bar; straight eighths; no cross-rhythm claim.
- **悲哀 key and mode:** G# ionian (major) (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights G# 0.18, D# 0.12, G 0.09, C# 0.09, D 0.09.
- **悲哀 chords:** 15 changes a minute (11 a minute are chords that last 1.5 s or more); median chord 3.0 s (10th to 90th percentile 0.9 to 8.5 s); 15 distinct chords; most time on G#min7 29%, C#sus2 25%, G#maj7 12%, G#sus2 7%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  55% of the changes land on a beat (chance would be 53%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **悲哀 bass:** pedal (one note held or repeated); 0.56 notes a second; most time on G# 0.95, A 0.01, C# 0.01; steps 9%, thirds 4%, fourths and fifths 2%, octaves 1%, repeats 84%.
- **悲哀 top line (from the 'other' stem; read by ear before trusting):** 1442 notes, range 12 semitones (10th to 90th percentile); steps 20%, thirds 15%, fourths and fifths 27%, leaps 19%, repeats 19%; median interval 3 semitones; 53% of moves go up; phrases of about 11 notes, arch 53%, rising 27%, falling 5%, flat or wavy 15%. Reliable only when the line sits clearly above its accompaniment.
- **悲哀 repetition:** 82 bars of 6.8 s; strongest repeat distances 1 bars (0.50), 32 bars (0.37), 11 bars (0.36); 30% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **恢复 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -15 (corr 0.94); low_120_500 -1 (corr 0.17); mid_500_2k 0 (corr -0.02); pres_2k_5k 0 (corr -0.04); air_gt5k 0 (corr -0.04); over time (2-s windows) 10th/50th/90th percentile -3/-1/1 dB.
- **恢复 by part:** drums: 22% of the power, width -25 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-42 dB); bass: 12% of the power, width -11 dB, pan +0.05, mono loss 0.3 dB, widest in sub_lt120 (-11 dB); other: 65% of the power, width -0 dB, pan +0.02, mono loss 2.9 dB, widest in mid_500_2k (0 dB); vocals: 1% of the power, width -6 dB, pan +0.27, mono loss 0.9 dB, widest in mid_500_2k (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **新しい日の誕生 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -7 (corr 0.69); low_120_500 -2 (corr 0.25); mid_500_2k 1 (corr -0.13); pres_2k_5k 9 (corr -0.77); air_gt5k 8 (corr -0.74); over time (2-s windows) 10th/50th/90th percentile -1/1/4 dB.
- **新しい日の誕生 by part:** drums: 4% of the power, width 4 dB, pan -0.10, mono loss 5.6 dB, widest in air_gt5k (8 dB); bass: 4% of the power, width -12 dB, pan -0.02, mono loss 0.2 dB, widest in sub_lt120 (-13 dB); other: 89% of the power, width 0 dB, pan +0.06, mono loss 3.0 dB, widest in mid_500_2k (1 dB); vocals: 4% of the power, width 1 dB, pan +0.16, mono loss 3.5 dB, widest in mid_500_2k (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **悲哀 mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -14 (corr 0.93); low_120_500 -2 (corr 0.20); mid_500_2k 5 (corr -0.50); pres_2k_5k 1 (corr -0.16); air_gt5k 0 (corr -0.04); over time (2-s windows) 10th/50th/90th percentile -1/2/4 dB.
- **悲哀 by part:** drums: 12% of the power, width -11 dB, pan +0.01, mono loss 0.3 dB, widest in low_120_500 (-13 dB); bass: 13% of the power, width -16 dB, pan -0.01, mono loss 0.1 dB, widest in sub_lt120 (-16 dB); other: 48% of the power, width 2 dB, pan +0.01, mono loss 3.9 dB, widest in mid_500_2k (5 dB); vocals: 26% of the power, width 6 dB, pan -0.01, mono loss 6.7 dB, widest in mid_500_2k (6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 恢复: 88 BPM, 6 settled chords a minute, 2% of energy above 2 kHz, width -3 dB; 新しい日の誕生: 132 BPM, 3 settled chords a minute, 15% of energy above 2 kHz, width 0 dB; 悲哀: 106 BPM, 11 settled chords a minute, 3% of energy above 2 kHz, width 0 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- 恢复, other group `other-2` (186 notes): around F3, bell- or metal-like (partials off whole multiples), slow swell, falls 15 dB/s, centered; hear it at 5:03.2, 4:52.8. **[JUDGMENT]** why it waits.
- 悲哀, other group `other-2` (217 notes): around G#2, bell- or metal-like (partials off whole multiples), slow swell, falls 13 dB/s, centered; hear it at 3:07.3, 7:57.1. **[JUDGMENT]** why it waits.
- 新しい日の誕生, vocals group `vocals-1` (356 notes): around A#2, bell- or metal-like (partials off whole multiples), slow swell, falls 10 dB/s, centered; hear it at 1:43.6, 1:45.4. **[JUDGMENT]** why it waits.
- 悲哀, drums group `drums-1` (200 notes): mid snap, quick attack, falls 129 dB/s, gets darker over the note, centered; hear it at 1:29.3, 5:33.8. **[JUDGMENT]** why it waits.
- 恢复, bass group `bass-1` (115 notes): around C#2, bell- or metal-like (partials off whole multiples), slow swell, falls 126 dB/s, centered; hear it at 1:38.8, 1:49.6. **[JUDGMENT]** why it waits.
- 悲哀, vocals group `vocals-1` (206 notes): around C#4, bell- or metal-like (partials off whole multiples), slow swell, falls 13 dB/s, centered; hear it at 0:53.3, 6:37.5. **[JUDGMENT]** why it waits.
- 悲哀, drums group `drums-2` (149 notes): low thump, quick attack, falls 103 dB/s, centered; hear it at 5:53.1, 1:05.0. **[JUDGMENT]** why it waits.
- 恢复, bass group `bass-2` (142 notes): around E1, bell- or metal-like (partials off whole multiples), soft attack, falls 134 dB/s, centered; hear it at 1:42.3, 1:43.4. **[JUDGMENT]** why it waits.
- **余波** (5:34.7, 123 BPM by the mix-level count): stands out for width (side/mid dB) -9.40 (low, album median -0.20); brightness sweep (octaves) 1.79 (high, album median 0.99); wobble (cents) 6.50 (high, album median 4.97). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **新宿ゴールデン街** (8:51.6, 99 BPM by the mix-level count): stands out for wobble (cents) 2.68 (low, album median 4.97); chord changes a minute (2-s counter) 6.80 (high, album median 1.20); width (side/mid dB) -6.20 (low, album median -0.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **遠くの愛好家** (6:18.4, 118 BPM by the mix-level count): stands out for wobble (cents) 2.99 (low, album median 4.97). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **ふわっと** (6:36.0, 129 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 5.20 (high, album median 1.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
