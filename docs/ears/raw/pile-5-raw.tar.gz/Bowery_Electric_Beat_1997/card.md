## Bowery Electric - Beat 1997 (draft card from Ears 3 tools, 2026-11-03)

How it was made: 11 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: - Without Stopping; - Looped; - Fear of Flying. Typical track: - Without Stopping. Least like the rest: - Looped, - Fear of Flying.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- Without Stopping**: share of power drums 26%, bass 68%, other 3%, vocals 3%.
  - other stem holds 3.0% of the power: top line, chords, other-stem pumping and echoes are void or guesses.
  - vocals stem holds 3.2%: bleed on an instrumental, not a voice.
  - meter tool 139 BPM does not match the drum-grid beat of 35.1 BPM by a simple ratio: listen.
- **- Looped**: share of power drums 0%, bass 0%, other 100%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
- **- Fear of Flying**: share of power drums 65%, bass 28%, other 7%, vocals 0%.
  - vocals stem holds 0.2%: bleed on an instrumental, not a voice.
  - meter tool 94 BPM agrees with the drum-grid beat of 93.9 BPM.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 94 to 139 BPM (octave-uncertain); keys E phrygian, C# aeolian, E mixolydian; mix width -12 to 3 dB; chord changes 1 to 66 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Looped: other group `other-1` (475 notes, 96% of the track's note energy)
- In synth terms: around C#3, bell- or metal-like (partials off whole multiples), soft attack, falls 19 dB/s, centered.
- Hear it at: 1:33.0 (C#3, 0.95 s, +53 dB alone), 0:35.8 (C#3, 0.11 s, +56 dB alone), 1:27.5 (C3, 0.87 s, +53 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 136 (132 to 138) Hz; attack 86 (14 to 192) ms; decay -19 (-59 to 3) dB/s
  - brightness at the start 482 (372 to 580) Hz; slope over the note 0.00 (-0.13 to 0.09) octaves
  - harmonic share 0.47 (0.18 to 0.78); partials off whole multiples 110 (52 to 188) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.7 (-6.4 to -3.4) dB; pan -0.13 (-0.23 to -0.01); left-right correlation -0.34 (-0.56 to -0.09)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. - Without Stopping: bass group `bass-1` (214 notes, 32% of the track's note energy)
- In synth terms: around E1, harmonic (string/reed/pad-like), slow swell, falls 1 dB/s, centered.
- Hear it at: 2:46.7 (E1, 0.34 s, +12 dB alone), 2:43.2 (E1, 1.02 s, +9 dB alone), 0:40.0 (E1, 1.04 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 41 (41 to 41) Hz; attack 210 (30 to 675) ms; decay -1 (-7 to 2) dB/s
  - brightness at the start 93 (88 to 100) Hz; slope over the note -0.01 (-0.08 to 0.11) octaves
  - harmonic share 1.00 (0.98 to 1.00); partials off whole multiples 2 (0 to 6) cents
  - vibrato 0 (0 to 6) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.8 (-1.5 to -0.5) dB; pan 0.01 (0.00 to 0.02); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S3. - Fear of Flying: drums group `drums-1` (234 notes, 30% of the track's note energy)
- In synth terms: low thump, quick attack, falls 24 dB/s, gets brighter over the note, centered.
- Hear it at: 0:17.6 (G1, 0.37 s, +13 dB alone), 0:12.5 (F#1, 0.39 s, +9 dB alone), 0:22.7 (G1, 0.31 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (46 to 47) Hz; attack 33 (30 to 64) ms; decay -24 (-37 to -12) dB/s
  - brightness at the start 80 (75 to 104) Hz; slope over the note 0.34 (-0.01 to 3.66) octaves
  - harmonic share 0.94 (0.61 to 0.95); partials off whole multiples 75 (45 to 130) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-2.2 to -1.0) dB; pan 0.00 (-0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S4. - Without Stopping: bass group `bass-2` (179 notes, 29% of the track's note energy)
- In synth terms: around E2, bell- or metal-like (partials off whole multiples), slow swell, falls 0 dB/s, centered.
- Hear it at: 0:42.2 (E2, 0.62 s, +11 dB alone), 4:39.9 (E2, 1.73 s, +7 dB alone), 3:37.1 (E2, 1.04 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 82 (80 to 83) Hz; attack 208 (30 to 693) ms; decay -0 (-7 to 5) dB/s
  - brightness at the start 88 (85 to 93) Hz; slope over the note -0.01 (-0.09 to 0.07) octaves
  - harmonic share 0.94 (0.89 to 0.98); partials off whole multiples 129 (22 to 404) cents
  - vibrato 0 (0 to 11) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.9 (-1.5 to -0.6) dB; pan 0.01 (0.00 to 0.02); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S5. - Fear of Flying: drums group `drums-2` (58 notes, 10% of the track's note energy)
- In synth terms: low thump, slow swell, falls 19 dB/s, centered.
- Hear it at: 0:48.5 (F#1, 0.62 s, +7 dB alone), 4:27.1 (F#1, 0.6 s, +6 dB alone), 5:12.9 (F#1, 0.54 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (46 to 46) Hz; attack 312 (284 to 354) ms; decay -19 (-26 to -4) dB/s
  - brightness at the start 84 (74 to 137) Hz; slope over the note 0.02 (-0.19 to 0.55) octaves
  - harmonic share 0.94 (0.93 to 0.97); partials off whole multiples 64 (45 to 129) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.3 (-2.2 to -1.1) dB; pan 0.01 (-0.00 to 0.02); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S6. - Looped: other group `other-2` (24 notes, 4% of the track's note energy)
- In synth terms: around B1, mixed or noisy partials, soft attack, falls 16 dB/s, centered.
- Hear it at: 0:09.9 (F1, 0.36 s, +53 dB alone), 2:10.7 (D2, 0.07 s, +52 dB alone), 0:53.0 (C#2, 0.22 s, +51 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 61 (43 to 71) Hz; attack 58 (5 to 141) ms; decay -16 (-66 to 1) dB/s
  - brightness at the start 467 (370 to 570) Hz; slope over the note 0.00 (-0.19 to 0.28) octaves
  - harmonic share 0.37 (0.19 to 0.70); partials off whole multiples 47 (33 to 86) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.7 (-7.3 to -4.7) dB; pan -0.05 (-0.12 to 0.01); left-right correlation -0.46 (-0.63 to -0.32)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- Without Stopping sections:** 13 boundaries at 0:21.0, 0:40.0, 1:02.0, 1:20.0, 1:47.0, 2:23.0, 2:42.0, 3:11.0, 3:38.0, 3:57.0, 4:14.0, 4:32.0; section lengths median 20 s (range 17 to 36). Reliable for sections of 10 s or more.
- **- Without Stopping stem entries and exits:** drums plays 99% of the time (in: from the start; out: 5:09.5); bass plays 85% of the time (in: 0:27.0, 2:39.5; out: 2:24.0, 5:10.0); other plays 98% of the time (in: 2:29.5; out: 2:25.5, 5:10.5); vocals plays 71% of the time (in: 0:14.5, 0:58.0, 1:19.0, 1:50.0, 2:51.5; out: 0:54.0, 1:08.0, 1:47.5, 2:22.5, 3:04.5).
- **- Without Stopping floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Without Stopping brightness sweeps (0.7 octave or more):** mix up 3.3 oct 0:00.0 to 0:06.5; mix down 3.1 oct 0:13.5 to 0:24.5; mix down 0.9 oct 1:33.5 to 1:38.5; mix down 1.7 oct 2:15.5 to 2:27.0; mix up 0.8 oct 2:35.0 to 2:40.0; mix down 1.3 oct 3:01.5 to 3:06.5; mix down 0.8 oct 3:28.0 to 3:33.5; mix up 0.9 oct 3:57.5 to 4:02.5 (12 more in techniques.json).
- **- Without Stopping echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Without Stopping pumping locked to the kick:** under 1.5 dB; none found.
- **- Without Stopping tape wobble and speed:** other wobbles about 10 cents at 0.7 Hz; bass wobbles about 16 cents at 1.2 Hz.
- **- Without Stopping stereo movement:** vocals pan range 0.37.
- **- Looped sections:** 6 boundaries at 0:05.0, 0:24.0, 0:42.0, 0:55.0, 1:45.0, 2:30.0; section lengths median 18 s (range 5 to 50). Reliable for sections of 10 s or more.
- **- Looped stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 0% of the time (in: from the start; out: never); other plays 94% of the time (in: 0:02.5; out: 2:33.0); vocals plays 0% of the time (in: from the start; out: never).
- **- Looped floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Looped brightness sweeps (0.7 octave or more):** bass down 2.8 oct 0:00.0 to 0:06.5; bass down 0.9 oct 0:28.0 to 0:36.0; bass up 1.2 oct 0:36.0 to 0:44.0; bass up 0.8 oct 1:03.0 to 1:09.0; bass down 1.0 oct 1:09.5 to 1:14.5; bass up 1.3 oct 1:17.5 to 1:25.5; bass up 1.1 oct 1:33.0 to 1:41.0; bass up 1.3 oct 2:16.5 to 2:23.0 (1 more in techniques.json).
- **- Looped echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Looped pumping locked to the kick:** under 1.5 dB; none found.
- **- Looped tape wobble and speed:** other wobbles about 6 cents at 2.0 Hz; other speed moves up to 27 cents in 4 s.
- **- Looped stereo movement:** bass pan range 0.17, cycling every 5 s; vocals pan range 0.05, cycling every 5 s.
- **- Fear of Flying sections:** 11 boundaries at 0:02.0, 0:22.0, 1:09.0, 1:50.0, 2:15.0, 2:53.0, 3:12.0, 3:51.0, 4:32.0, 5:05.0, 5:21.0; section lengths median 29 s (range 2 to 47). Reliable for sections of 10 s or more.
- **- Fear of Flying stem entries and exits:** drums plays 97% of the time (in: from the start; out: 5:30.0); bass plays 97% of the time (in: from the start; out: 5:30.5); other plays 95% of the time (in: 0:06.5; out: 5:30.5); vocals plays 23% of the time (in: 1:09.0, 3:10.5; out: 1:48.5, 3:50.5).
- **- Fear of Flying floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **- Fear of Flying brightness sweeps (0.7 octave or more):** mix up 2.1 oct 0:00.0 to 0:09.0; mix up 2.8 oct 0:14.0 to 0:23.0; mix up 1.6 oct 0:26.0 to 0:31.5; mix down 1.9 oct 0:32.0 to 0:39.0; mix up 3.1 oct 0:47.0 to 0:54.0; mix down 2.6 oct 1:03.0 to 1:08.5; mix down 1.5 oct 1:12.0 to 1:17.5; mix up 2.0 oct 1:18.0 to 1:24.5 (29 more in techniques.json).
- **- Fear of Flying echo times:** drums: 474 ms (+6.0 dB, 1 later repeats).
- **- Fear of Flying pumping locked to the kick:** bass dips 3.6 dB at the kick (peak 474 ms after, kick every 0.48 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Fear of Flying tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **- Fear of Flying stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Without Stopping meter:** about 139 BPM (could be 69 or 278; the tool cannot tell the beat level), 4 beats a bar; swung: off-beat at 0.66 of the beat (triplet feel); possible cross-rhythm 3:2, 4:3 (weak evidence, check by ear).
- **- Without Stopping key and mode:** E phrygian (low confidence: the key signature margin is 0.005, so read this as a guess); fits E pentatonic; pitch-class weights E 0.41, B 0.14, D 0.08, D# 0.07, F 0.07.
- **- Without Stopping chords:** 9 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 3.1 s (10th to 90th percentile 0.7 to 14.6 s); 6 distinct chords; most time on E5 84%, Emaj7 5%, Fmaj7 4%, Dsus2 4%. The old counter in this same run said 1; Ears 1's 2-s counter said 1.  73% of the changes land on a beat (chance would be 69%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Without Stopping bass:** pedal (one note held or repeated); 1.10 notes a second; most time on E 1.00; steps 0%, thirds 0%, fourths and fifths 0%, octaves 2%, repeats 97%.
- **- Without Stopping top line (from the 'other' stem; read by ear before trusting):** 536 notes, range 3 semitones (10th to 90th percentile); steps 36%, thirds 2%, fourths and fifths 13%, leaps 1%, repeats 48%; median interval 1 semitones; 50% of moves go up; phrases of about 18 notes, arch 19%, rising 6%, falling 0%, flat or wavy 75%. Reliable only when the line sits clearly above its accompaniment.
- **- Without Stopping repetition:** 181 bars of 1.7 s; strongest repeat distances 1 bars (0.44), 3 bars (0.39), 8 bars (0.26); 8% of bars near-duplicate an earlier bar.
- **- Looped meter:** about 139 BPM (could be 69 or 277; the tool cannot tell the beat level), 12 beats a bar; swung: off-beat at 0.77 of the beat; no cross-rhythm claim.
- **- Looped key and mode:** C# aeolian (minor) (key signature margin 0.024); fits C# minor pentatonic; pitch-class weights C# 0.22, C 0.17, A 0.16, G# 0.14, E 0.13.
- **- Looped chords:** 1 changes a minute (1 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.9 to 126.1 s); 3 distinct chords; most time on Amaj7 98%, D7 1%, Dmin7 0%. The old counter in this same run said 0; Ears 1's 2-s counter said 0.  Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Looped top line (from the 'other' stem; read by ear before trusting):** 388 notes, range 4 semitones (10th to 90th percentile); steps 10%, thirds 51%, fourths and fifths 6%, leaps 13%, repeats 20%; median interval 4 semitones; 48% of moves go up; phrases of about 13 notes, arch 0%, rising 7%, falling 18%, flat or wavy 75%. Reliable only when the line sits clearly above its accompaniment.
- **- Looped repetition:** 30 bars of 5.2 s; strongest repeat distances 1 bars (0.75), 15 bars (-0.09); 0% of bars near-duplicate an earlier bar.
- **- Fear of Flying meter:** about 94 BPM (could be 47 or 189; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 7:4), which means irregular timing, not a cross-rhythm claim.
- **- Fear of Flying key and mode:** E mixolydian (key signature margin 0.021); pitch-class weights E 0.24, A 0.12, D 0.12, B 0.10, D# 0.09.
- **- Fear of Flying chords:** 66 changes a minute (2 a minute are chords that last 1.5 s or more); median chord 0.7 s (10th to 90th percentile 0.5 to 1.2 s); 20 distinct chords; most time on E5 37%, Dsus2 18%, A5 15%, Asus2 7%. The old counter in this same run said 1; Ears 1's 2-s counter said 0.  26% of the changes land on a beat (chance would be 47%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Fear of Flying bass:** root-note movement / mixed; 1.84 notes a second; most time on E 0.51, A 0.22, D 0.09, F# 0.07; steps 32%, thirds 16%, fourths and fifths 21%, octaves 16%, repeats 14%.
- **- Fear of Flying top line (from the 'other' stem; read by ear before trusting):** 816 notes, range 7 semitones (10th to 90th percentile); steps 6%, thirds 1%, fourths and fifths 46%, leaps 11%, repeats 35%; median interval 5 semitones; 51% of moves go up; phrases of about 14 notes, arch 43%, rising 20%, falling 17%, flat or wavy 20%. Reliable only when the line sits clearly above its accompaniment.
- **- Fear of Flying repetition:** 66 bars of 5.1 s; strongest repeat distances 24 bars (0.56), 2 bars (0.47), 26 bars (0.34); 0% of bars near-duplicate an earlier bar.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Without Stopping mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 1.00); low_120_500 -7 (corr 0.65); mid_500_2k -4 (corr 0.40); pres_2k_5k -7 (corr 0.70); air_gt5k -7 (corr 0.69); over time (2-s windows) 10th/50th/90th percentile -12/-9/-3 dB.
- **- Without Stopping by part:** drums: 25% of the power, width -24 dB, pan +0.03, mono loss 0.0 dB, widest in low_120_500 (-24 dB); bass: 65% of the power, width -38 dB, pan +0.02, mono loss 0.0 dB, widest in sub_lt120 (-38 dB); other: 4% of the power, width -2 dB, pan -0.04, mono loss 2.0 dB, widest in low_120_500 (-2 dB); vocals: 6% of the power, width 0 dB, pan +0.01, mono loss 3.2 dB, widest in low_120_500 (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Looped mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub 2 (corr -0.28); low_120_500 4 (corr -0.45); mid_500_2k 2 (corr -0.27); pres_2k_5k -2 (corr 0.22); air_gt5k -2 (corr 0.26); over time (2-s windows) 10th/50th/90th percentile 2/3/4 dB.
- **- Looped by part:** drums: 0% of the power, width -2 dB, pan -0.13, mono loss 2.3 dB, widest in mid_500_2k (1 dB); bass: 0% of the power, width -6 dB, pan -0.09, mono loss 1.0 dB, widest in mid_500_2k (-5 dB); other: 100% of the power, width 3 dB, pan -0.24, mono loss 4.8 dB, widest in low_120_500 (4 dB); vocals: 0% of the power, width -13 dB, pan -0.06, mono loss 0.2 dB, widest in low_120_500 (-10 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Fear of Flying mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -25 (corr 0.99); low_120_500 -3 (corr 0.34); mid_500_2k -3 (corr 0.30); pres_2k_5k -0 (corr 0.05); air_gt5k -7 (corr 0.64); over time (2-s windows) 10th/50th/90th percentile -3/-2/-1 dB.
- **- Fear of Flying by part:** drums: 59% of the power, width -30 dB, pan +0.01, mono loss 0.0 dB, widest in sub_lt120 (-33 dB); bass: 25% of the power, width -38 dB, pan +0.00, mono loss 0.0 dB, widest in sub_lt120 (-38 dB); other: 15% of the power, width 1 dB, pan -0.13, mono loss 3.7 dB, widest in low_120_500 (2 dB); vocals: 0% of the power, width -13 dB, pan -0.07, mono loss 0.2 dB, widest in low_120_500 (-13 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Without Stopping: 139 BPM, 6 settled chords a minute, 1% of energy above 2 kHz, width -12 dB; - Looped: 139 BPM, 1 settled chords a minute, 0% of energy above 2 kHz, width 3 dB; - Fear of Flying: 94 BPM, 2 settled chords a minute, 8% of energy above 2 kHz, width -10 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: - Looped: mono loss 4.8 dB (opposite-polarity parts).

### For later
- - Without Stopping, drums group `drums-1` (262 notes): mid snap, quick attack, falls 42 dB/s, centered; hear it at 2:25.1, 2:27.5. **[JUDGMENT]** why it waits.
- - Fear of Flying, bass group `bass-1` (76 notes): around A2, bell- or metal-like (partials off whole multiples), quick attack, falls 1 dB/s, centered; hear it at 3:16.8, 3:19.9. **[JUDGMENT]** why it waits.
- - Fear of Flying, bass group `bass-2` (138 notes): around D2, harmonic (string/reed/pad-like), soft attack, falls 4 dB/s, centered; hear it at 3:49.7, 2:07.1. **[JUDGMENT]** why it waits.
- - Without Stopping, drums group `drums-2` (224 notes): low thump, quick attack, falls 263 dB/s, centered; hear it at 2:27.2, 2:28.9. **[JUDGMENT]** why it waits.
- - Fear of Flying, other group `other-1` (303 notes): around E3, mixed or noisy partials, slow swell, falls 10 dB/s, centered; hear it at 0:42.2, 3:04.3. **[JUDGMENT]** why it waits.
- - Without Stopping, vocals group `vocals-1` (255 notes): around D#4, bell- or metal-like (partials off whole multiples), slow swell, falls 16 dB/s, centered; hear it at 0:15.7, 0:16.3. **[JUDGMENT]** why it waits.
- - Fear of Flying, other group `other-2` (185 notes): around E2, harmonic (string/reed/pad-like), slow swell, falls 11 dB/s, centered; hear it at 0:29.8, 0:39.6. **[JUDGMENT]** why it waits.
- - Without Stopping, other group `other-1` (376 notes): around C#2, bell- or metal-like (partials off whole multiples), slow swell, falls 10 dB/s, centered; hear it at 4:23.8, 3:58.9. **[JUDGMENT]** why it waits.
- **- Under the Sun** (3:32.6, 144 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 15.80 (high, album median 1.80). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Low Density** (7:16.3, 123 BPM by the mix-level count): stands out for width (side/mid dB) -24.10 (low, album median -7.10). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Coming Down** (4:36.0, 162 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 8.90 (high, album median 1.80). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **- Black Light** (6:53.5, 129 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 8.30 (high, album median 1.80). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
