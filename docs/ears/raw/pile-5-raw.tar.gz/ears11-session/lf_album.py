import json, os, re, sys, time
sys.path.insert(0, "/home/kruu-mikey/driftloom/tools/ears")
import longform
def slug(s): return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")[:60]
album_dir, workdir = sys.argv[1], sys.argv[2]
work = os.path.join(os.path.abspath(workdir), slug(os.path.basename(album_dir.rstrip("/"))))
rep = json.load(open(os.path.join(work, "pick.json")))
secs = {r["track"]: r.get("seconds", 0) for r in rep["rows"]}
os.makedirs(os.path.join(work, "longform"), exist_ok=True)
t0 = time.time()
for tr, path in sorted(rep["paths"].items()):
    if tr not in rep["picks"] and secs.get(tr, 0) < 480:
        continue
    out = os.path.join(work, "longform", slug(tr) + ".json")
    if os.path.exists(out):
        continue
    longform.run(path, out)
    print(time.strftime("%H:%M:%S"), "longform:", tr, flush=True)
with open(os.path.join(work, "progress.log"), "a") as f:
    f.write(time.strftime("%H:%M:%S ") + f"longform: done in {time.time() - t0:.0f} s\n")
