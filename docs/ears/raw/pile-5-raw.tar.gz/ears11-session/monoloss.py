# Ears 10b: the mix's left-right correlation and mono loss (dB lost when L and R are summed) by band, per track
import json, sys, subprocess, numpy as np
from scipy.signal import butter, sosfiltfilt
d = json.load(open(sys.argv[1] + "/pick.json"))
print("track  [corr, mono loss dB] for <120, 120-500, 500-2k, 2-5k, >5k")
for tr, p in sorted(d["paths"].items()):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "2", "-ar", "32000", "-f", "f32le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.float32).reshape(-1, 2).astype(np.float64)
    out = []
    for lo, hi in [(20, 120), (120, 500), (500, 2000), (2000, 5000), (5000, 15000)]:
        y = sosfiltfilt(butter(4, (lo, hi), btype="band", fs=32000, output="sos"), x, axis=0)
        L, R = y[:, 0], y[:, 1]
        c = (L * R).mean() / np.sqrt((L * L).mean() * (R * R).mean())
        loss = 10 * np.log10(((L * L).mean() + (R * R).mean()) / 2 / (((L + R) / 2) ** 2).mean())
        out.append("%+.2f %.1f" % (c, loss))
    print(tr[-24:], " | ".join(out))
