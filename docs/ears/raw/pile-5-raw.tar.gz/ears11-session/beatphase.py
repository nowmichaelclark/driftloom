# Ears 11: where the drum stem's onsets fall inside the beat (the meter tool's beat and phase), 12 bins per beat.
# Triplet-shuffle test: a swung eighth sits at bin 8 of 12 (0.667), a straight eighth at bin 6, sixteenths at 3 and 9.
import sys, json, numpy as np, librosa
work, track = sys.argv[1], sys.argv[2]
th = json.load(open(f"{work}/{track}/theory.json"))["meter"]
per, ph = th["period_s"], th["phase_s"]
y, sr = librosa.load(f"{work}/stems/{track}/drums.wav", sr=22050, mono=True)
oenv = librosa.onset.onset_strength(y=y, sr=sr, hop_length=256)
on = librosa.onset.onset_detect(onset_envelope=oenv, sr=sr, hop_length=256, units="time", backtrack=False)
p = ((on - ph) / per) % 1.0
h, _ = np.histogram(p, bins=24, range=(0, 1))   # 24 bins: 1/24 beat each
h12 = h.reshape(12, 2).sum(1)
share = h12 / h12.sum()
print(track, "beat %.3f s (%.1f BPM), %d onsets" % (per, 60 / per, len(on)))
print("  share by twelfth of a beat (0=on the beat):", " ".join("%d:%.0f%%" % (i, 100 * s) for i, s in enumerate(share)))
def near(c, w=0.5):  # share within +-w twelfth-bins of position c (in beat)
    d = np.abs(((p - c + 0.5) % 1.0) - 0.5); return (d < w / 12).mean()
print("  on beat %.0f%%  straight eighth(.50) %.0f%%  swung eighth(.667) %.0f%%  16ths(.25/.75) %.0f%%  triplet(.333) %.0f%%" % (100*near(0), 100*near(.5), 100*near(2/3), 100*(near(.25)+near(.75)), 100*near(1/3)))
