import json, sys, numpy as np
d = json.load(open(sys.argv[1] + "/pick.json"))
rows = [r for r in d["rows"] if "error" not in r and "skip" not in r]
for k in ["seconds","lufs","centroid_hz","width_db","tail_db_per_s","pulse","chord_changes_per_min","sweep_oct","arc_db","repeat","tuning_cents","wobble_cents","sub_lt120","low_120_500","mid_500_2k","pres_2k_5k","air_gt5k"]:
    v = np.array([r[k] for r in rows if r.get(k) is not None], float)
    print("%-22s median %8.3f  p10 %8.3f  p90 %8.3f  n %d" % (k, np.median(v), np.percentile(v,10), np.percentile(v,90), len(v)))
dr = [r["drift60"]/r["drift10"] for r in rows if r.get("drift60") and r.get("drift10")]
print("drift ratio median %.2f p10 %.2f p90 %.2f; above 1: %d of %d" % (np.median(dr), np.percentile(dr,10), np.percentile(dr,90), sum(x>1 for x in dr), len(dr)))
