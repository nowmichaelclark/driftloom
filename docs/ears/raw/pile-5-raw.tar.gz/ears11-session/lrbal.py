# Ears 10b: the master's left-right balance by band (dB, + = right louder), per track of an album's pick.json
import json, sys, subprocess, numpy as np
from scipy.signal import butter, sosfiltfilt
d = json.load(open(sys.argv[1] + "/pick.json"))
for tr, p in sorted(d["paths"].items()):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "2", "-ar", "22050", "-f", "f32le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.float32).reshape(-1, 2)
    out = []
    for lo, hi in [(20, 120), (120, 500), (500, 2000), (2000, 8000)]:
        y = sosfiltfilt(butter(4, (lo, hi), btype="band", fs=22050, output="sos"), x, axis=0)
        L, R = np.sqrt((y ** 2).mean(0))
        out.append(round(20 * np.log10(R / L), 1))
    print(tr[-28:], out)
