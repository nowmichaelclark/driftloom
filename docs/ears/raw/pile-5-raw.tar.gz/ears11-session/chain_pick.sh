#!/bin/bash
P="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 5"
for d in "(1998) Music Has the Right to Children" "Ulrich Schnauss - Far Away Trains Passing By 2005" "Lifeforms" "Bowery Electric - Beat 1997" "2000 - Perdition City" "1980 - Synthesist"; do
  python3 -P /home/kruu-mikey/driftloom/tools/ears/album.py "$P/$d" /home/kruu-mikey/ears11/work --stages pick --workers 2
done
echo CHAIN_DONE
