#!/bin/bash
# waits for the running Bowery album.py stage, then runs the remaining Bowery stages (cached stages skip)
while kill -0 22919 2>/dev/null; do sleep 5; done
./chain.sh "Bowery Electric - Beat 1997"
