#!/bin/bash
# usage: chain.sh "folder" ...
P="/home/kruu-mikey/Music/Drift Loom Inspiration/for-claude - pile 5"
for d in "$@"; do
  s=$(date +%s)
  for st in split events techniques theory space check card; do
    python3 -P /home/kruu-mikey/driftloom/tools/ears/album.py "$P/$d" /home/kruu-mikey/ears11/work --stages $st --workers 2
  done
  echo "ALBUM_DONE $d $(( $(date +%s) - s )) s"
done
echo CHAIN_DONE
