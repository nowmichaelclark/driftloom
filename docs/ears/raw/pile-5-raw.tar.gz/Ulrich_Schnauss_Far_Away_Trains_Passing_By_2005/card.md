## Ulrich Schnauss - Far Away Trains Passing By 2005 (draft card from Ears 3 tools, 2026-11-03)

How it was made: 12 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: - Suddenly The Trees Are Giving Way; - Sunday Evening In Your Street; - Knuddelmaus; - Between Us And Them. Typical track: - Suddenly The Trees Are Giving Way. Least like the rest: - Sunday Evening In Your Street, - Knuddelmaus, - Between Us And Them.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **- Suddenly The Trees Are Giving Way**: share of power drums 43%, bass 37%, other 20%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 100 BPM is half of the drum-grid beat of 198.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Sunday Evening In Your Street**: share of power drums 51%, bass 28%, other 20%, vocals 0%.
  - vocals stem holds 0.2%: bleed on an instrumental, not a voice.
  - meter tool 100 BPM does not match the drum-grid beat of 25.0 BPM by a simple ratio: listen.
- **- Knuddelmaus**: share of power drums 20%, bass 62%, other 18%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 100 BPM is half of the drum-grid beat of 198.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **- Between Us And Them**: share of power drums 16%, bass 56%, other 28%, vocals 0%.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 87 BPM is half of the drum-grid beat of 172.4 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 87 to 100 BPM (octave-uncertain); keys F# ionian, E phrygian, G ionian, D# mixolydian; mix width -11 to -7 dB; chord changes 21 to 26 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. - Knuddelmaus: bass group `bass-1` (424 notes, 66% of the track's note energy)
- In synth terms: around C2, harmonic (string/reed/pad-like), slow swell, falls 8 dB/s, centered.
- Hear it at: 0:55.3 (C2, 0.57 s, +17 dB alone), 0:55.6 (C2, 1.14 s, +13 dB alone), 0:52.6 (G2, 1.2 s, +14 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 66 (49 to 98) Hz; attack 179 (19 to 574) ms; decay -8 (-28 to -1) dB/s
  - brightness at the start 111 (80 to 189) Hz; slope over the note -0.00 (-0.35 to 0.42) octaves
  - harmonic share 0.99 (0.28 to 1.00); partials off whole multiples 12 (3 to 87) cents
  - vibrato 0 (0 to 22) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.0 (-5.7 to -0.8) dB; pan 0.00 (-0.08 to 0.06); left-right correlation 0.96 (0.91 to 0.98)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S2. - Between Us And Them: bass group `bass-1` (403 notes, 48% of the track's note energy)
- In synth terms: around D#1, harmonic (string/reed/pad-like), soft attack, falls 10 dB/s, centered.
- Hear it at: 3:15.5 (G#1, 0.14 s, +10 dB alone), 3:30.1 (?, 1.05 s, +5 dB alone), 3:05.2 (C#1, 0.56 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 39 (35 to 40) Hz; attack 135 (16 to 358) ms; decay -10 (-97 to 2) dB/s
  - brightness at the start 81 (70 to 106) Hz; slope over the note 0.00 (-0.08 to 0.10) octaves
  - harmonic share 0.99 (0.22 to 1.00); partials off whole multiples 16 (3 to 80) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.5 (-4.1 to -1.5) dB; pan 0.02 (-0.10 to 0.10); left-right correlation 0.92 (0.79 to 0.97)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S3. - Suddenly The Trees Are Giving Way: bass group `bass-1` (318 notes, 39% of the track's note energy)
- In synth terms: around F#1, harmonic (string/reed/pad-like), quick attack, falls 4 dB/s, centered.
- Hear it at: 5:42.5 (F#1, 2.4 s, +2 dB alone), 5:52.5 (F#1, 2.58 s, +2 dB alone), 3:44.8 (B1, 1.47 s, +2 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (31 to 62) Hz; attack 39 (7 to 118) ms; decay -4 (-7 to -3) dB/s
  - brightness at the start 113 (100 to 126) Hz; slope over the note -0.04 (-0.16 to 0.00) octaves
  - harmonic share 1.00 (0.99 to 1.00); partials off whole multiples 3 (1 to 6) cents
  - vibrato 1 (0 to 5) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.7 (-9.9 to -2.2) dB; pan 0.00 (-0.00 to 0.00); left-right correlation 1.00 (1.00 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S4. - Sunday Evening In Your Street: other group `other-1` (253 notes, 24% of the track's note energy)
- In synth terms: around E2, mixed or noisy partials, slow swell, falls 8 dB/s, centered.
- Hear it at: 0:00.0 (E2, 2.82 s, +56 dB alone), 0:09.4 (F2, 3.05 s, +55 dB alone), 0:15.7 (C2, 1.51 s, +54 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 82 (44 to 89) Hz; attack 173 (41 to 593) ms; decay -8 (-24 to -1) dB/s
  - brightness at the start 336 (229 to 549) Hz; slope over the note 0.00 (-0.31 to 0.63) octaves
  - harmonic share 0.64 (0.22 to 0.86); partials off whole multiples 59 (27 to 120) cents
  - vibrato 0 (0 to 18) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.2 (-11.4 to -1.8) dB; pan 0.01 (-0.08 to 0.14); left-right correlation 0.47 (0.05 to 0.70)
- Group quality: weak (silhouette 0.23, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. - Knuddelmaus: other group `other-1` (500 notes, 18% of the track's note energy)
- In synth terms: around G2, mixed or noisy partials, soft attack, falls 15 dB/s, centered.
- Hear it at: 0:29.8 (G2, 0.27 s, +59 dB alone), 0:30.4 (G2, 0.32 s, +58 dB alone), 0:20.2 (G2, 0.29 s, +57 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 99 (65 to 146) Hz; attack 145 (42 to 375) ms; decay -15 (-56 to -2) dB/s
  - brightness at the start 682 (513 to 941) Hz; slope over the note 0.00 (-0.27 to 0.41) octaves
  - harmonic share 0.66 (0.28 to 0.93); partials off whole multiples 48 (16 to 99) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.1 (-9.0 to -2.3) dB; pan 0.03 (-0.06 to 0.10); left-right correlation 0.52 (0.25 to 0.66)
- Group quality: weak (silhouette 0.14, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. - Between Us And Them: bass group `bass-2` (97 notes, 17% of the track's note energy)
- In synth terms: around A#1, harmonic (string/reed/pad-like), soft attack, falls 10 dB/s, centered.
- Hear it at: 2:43.2 (G#1, 1.03 s, +6 dB alone), 4:43.0 (G#1, 1.34 s, +5 dB alone), 3:27.3 (G#1, 0.52 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 58 (52 to 78) Hz; attack 139 (37 to 490) ms; decay -10 (-36 to -1) dB/s
  - brightness at the start 76 (67 to 90) Hz; slope over the note 0.02 (-0.01 to 0.37) octaves
  - harmonic share 1.00 (0.94 to 1.00); partials off whole multiples 12 (4 to 71) cents
  - vibrato 0 (0 to 14) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.8 (-3.6 to -1.0) dB; pan 0.01 (-0.16 to 0.10); left-right correlation 0.94 (0.84 to 0.98)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S7. - Sunday Evening In Your Street: other group `other-2` (197 notes, 16% of the track's note energy)
- In synth terms: around B2, mixed or noisy partials, soft attack, falls 6 dB/s, centered.
- Hear it at: 0:07.4 (A2, 1.18 s, +57 dB alone), 0:03.7 (B2, 1.21 s, +57 dB alone), 0:04.8 (A2, 2.83 s, +56 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 125 (87 to 245) Hz; attack 136 (36 to 502) ms; decay -6 (-15 to -2) dB/s
  - brightness at the start 791 (466 to 1142) Hz; slope over the note 0.04 (-0.30 to 0.49) octaves
  - harmonic share 0.75 (0.46 to 0.94); partials off whole multiples 40 (15 to 123) cents
  - vibrato 0 (0 to 10) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -7.1 (-12.9 to -1.9) dB; pan -0.01 (-0.08 to 0.19); left-right correlation 0.46 (0.32 to 0.58)
- Group quality: weak (silhouette 0.23, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S8. - Suddenly The Trees Are Giving Way: other group `other-1` (315 notes, 16% of the track's note energy)
- In synth terms: around F#3, mixed or noisy partials, slow swell, falls 11 dB/s, centered.
- Hear it at: 2:59.7 (F#3, 0.3 s, +54 dB alone), 3:07.8 (F#3, 0.38 s, +53 dB alone), 3:02.1 (F#3, 0.33 s, +54 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 186 (124 to 372) Hz; attack 164 (41 to 668) ms; decay -11 (-45 to -1) dB/s
  - brightness at the start 1317 (990 to 1617) Hz; slope over the note 0.00 (-0.24 to 0.26) octaves
  - harmonic share 0.72 (0.38 to 0.96); partials off whole multiples 45 (14 to 98) cents
  - vibrato 0 (0 to 8) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.8 (-9.4 to -2.9) dB; pan -0.00 (-0.05 to 0.05); left-right correlation 0.04 (-0.06 to 0.23)
- Group quality: weak (silhouette 0.25, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **- Suddenly The Trees Are Giving Way sections:** 16 boundaries at 0:03.0, 0:19.0, 1:04.0, 1:20.0, 1:44.0, 2:00.0, 2:24.0, 2:42.0, 2:57.0, 3:24.0, 3:52.0, 4:14.0; section lengths median 22 s (range 3 to 53). Reliable for sections of 10 s or more.
- **- Suddenly The Trees Are Giving Way stem entries and exits:** drums plays 92% of the time (in: 3:14.5; out: 2:56.0, 6:13.0); bass plays 63% of the time (in: 1:17.5, 3:22.5; out: 2:43.0, 5:59.5); other plays 98% of the time (in: from the start; out: 6:15.5); vocals plays 0% of the time (in: from the start; out: never).
- **- Suddenly The Trees Are Giving Way floor drops (kick and bass out 2 s or more while the rest plays):** 0.17 a minute: 2:57.0 for 20.8 s.
- **- Suddenly The Trees Are Giving Way brightness sweeps (0.7 octave or more):** mix up 3.0 oct 0:12.0 to 0:18.5; mix up 3.1 oct 0:23.0 to 0:29.0; mix down 3.3 oct 0:29.0 to 0:36.5; mix up 2.5 oct 0:36.5 to 0:42.0; mix down 2.4 oct 0:42.0 to 0:47.0; mix up 3.1 oct 0:47.0 to 0:53.5; mix down 2.2 oct 0:53.5 to 0:58.5; mix up 1.2 oct 0:58.5 to 1:05.5 (38 more in techniques.json).
- **- Suddenly The Trees Are Giving Way echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Suddenly The Trees Are Giving Way pumping locked to the kick:** other dips 1.9 dB at the kick (peak 0 ms after, kick every 0.43 s); bass dips 2.2 dB at the kick (peak 234 ms after, kick every 0.43 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Suddenly The Trees Are Giving Way tape wobble and speed:** other wobbles about 8 cents at 0.7 Hz; other speed moves up to 7 cents in 4 s; bass wobbles about 12 cents at 3.3 Hz.
- **- Suddenly The Trees Are Giving Way stereo movement:** other pan range 0.34.
- **- Suddenly The Trees Are Giving Way builds:** 0:00.0 to 0:23.0.
- **- Sunday Evening In Your Street sections:** 19 boundaries at 0:02.0, 0:22.0, 1:14.0, 2:06.0, 2:17.0, 2:28.0, 2:52.0, 3:14.0, 3:30.0, 3:50.0, 4:01.0, 4:13.0; section lengths median 17 s (range 2 to 52). Reliable for sections of 10 s or more.
- **- Sunday Evening In Your Street stem entries and exits:** drums plays 86% of the time (in: 0:20.0, 3:12.0, 6:25.5; out: 3:06.5, 6:09.5, 6:28.5); bass plays 41% of the time (in: 1:19.0, 2:44.5, 3:12.5, 5:37.5, 5:48.0; out: 2:22.5, 2:47.0, 4:13.5, 5:40.0, 6:26.5); other plays 98% of the time (in: from the start; out: 6:35.0); vocals plays 11% of the time (in: 3:05.5, 5:01.5; out: 3:16.0, 5:36.5).
- **- Sunday Evening In Your Street floor drops (kick and bass out 2 s or more while the rest plays):** 1.81 a minute: 0:22.8 for 2.0 s, 3:05.2 for 8.0 s, 4:31.8 for 3.8 s, 4:36.5 for 3.0 s, 4:41.2 for 3.8 s, 4:46.0 for 3.2 s, 4:51.0 for 3.8 s, 4:55.8 for 3.0 s.
- **- Sunday Evening In Your Street brightness sweeps (0.7 octave or more):** mix up 1.9 oct 0:00.0 to 0:05.5; mix down 2.6 oct 0:05.5 to 0:18.0; mix up 3.4 oct 0:18.5 to 0:26.0; mix down 1.5 oct 0:26.0 to 0:31.0; mix down 1.5 oct 0:50.0 to 0:55.5; mix up 2.0 oct 0:56.0 to 1:01.5; mix down 0.9 oct 1:01.5 to 1:10.0; mix down 1.9 oct 1:26.0 to 1:33.0 (61 more in techniques.json).
- **- Sunday Evening In Your Street echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Sunday Evening In Your Street pumping locked to the kick:** bass dips 2.9 dB at the kick (peak 95 ms after, kick every 0.46 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Sunday Evening In Your Street tape wobble and speed:** other wobbles about 6 cents at 4.6 Hz; bass wobbles about 9 cents at 6.5 Hz.
- **- Sunday Evening In Your Street stereo movement:** other pan range 0.29; vocals pan range 0.32.
- **- Knuddelmaus sections:** 20 boundaries at 0:02.0, 0:38.0, 0:58.0, 1:16.0, 1:28.0, 1:43.0, 1:53.0, 2:11.0, 2:52.0, 3:08.0, 3:23.0, 3:47.0; section lengths median 18 s (range 2 to 41). Reliable for sections of 10 s or more.
- **- Knuddelmaus stem entries and exits:** drums plays 81% of the time (in: 0:35.5, 1:15.5; out: 0:43.0, 6:48.0); bass plays 83% of the time (in: 0:37.5; out: 6:27.5); other plays 98% of the time (in: from the start; out: 6:54.0); vocals plays 3% of the time (in: 3:10.5, 4:45.0; out: 3:16.0, 4:51.0).
- **- Knuddelmaus floor drops (kick and bass out 2 s or more while the rest plays):** 0.16 a minute: 0:21.0 for 17.5 s.
- **- Knuddelmaus brightness sweeps (0.7 octave or more):** mix up 1.3 oct 0:11.5 to 0:20.5; mix down 2.0 oct 0:36.5 to 0:42.0; mix up 1.7 oct 0:54.5 to 0:59.5; mix up 0.8 oct 1:03.5 to 1:15.5; mix up 0.9 oct 1:50.0 to 1:57.0; mix up 0.9 oct 2:28.5 to 2:36.5; mix down 1.8 oct 3:10.5 to 3:17.0; mix down 0.8 oct 3:27.5 to 3:33.0 (27 more in techniques.json).
- **- Knuddelmaus echo times:** drums: 494 ms (+12.8 dB, 1 later repeats).
- **- Knuddelmaus pumping locked to the kick:** other dips 1.8 dB at the kick (peak 10 ms after, kick every 0.42 s). The tool reads about 70% of the true depth, so this is a floor.
- **- Knuddelmaus tape wobble and speed:** other wobbles about 10 cents at 0.4 Hz.
- **- Knuddelmaus stereo movement:** bass pan range 0.17, cycling every 6 s.
- **- Between Us And Them sections:** 20 boundaries at 0:12.0, 0:37.0, 1:28.0, 1:39.0, 1:49.0, 2:09.0, 2:27.0, 2:52.0, 3:11.0, 3:27.0, 3:38.0, 3:48.0; section lengths median 19 s (range 1 to 68). Reliable for sections of 10 s or more.
- **- Between Us And Them stem entries and exits:** drums plays 69% of the time (in: 1:19.0; out: 6:30.0); bass plays 63% of the time (in: 1:21.5, 3:40.5, 4:00.5, 5:51.5; out: 3:33.5, 3:55.5, 5:46.5, 6:20.5); other plays 91% of the time (in: 0:12.5; out: 7:00.0); vocals plays 8% of the time (in: 2:37.0, 3:25.5, 4:16.0, 4:30.0, 4:40.5; out: 2:39.5, 3:31.5, 4:22.0, 4:32.5, 4:45.5).
- **- Between Us And Them floor drops:** low end too sparse to say (on in under 75% of the track).
- **- Between Us And Them brightness sweeps (0.7 octave or more):** mix down 0.8 oct 2:00.5 to 2:09.0; mix down 2.0 oct 2:24.0 to 2:31.5; mix up 2.1 oct 2:31.5 to 2:39.5; mix down 1.4 oct 2:59.5 to 3:07.5; mix up 2.2 oct 3:29.5 to 3:36.0; mix down 1.4 oct 4:13.5 to 4:19.0; mix up 1.0 oct 4:42.5 to 4:49.0; mix down 0.9 oct 4:49.0 to 4:56.5 (14 more in techniques.json).
- **- Between Us And Them echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **- Between Us And Them pumping locked to the kick:** under 1.5 dB; none found.
- **- Between Us And Them tape wobble and speed:** bass wobbles about 19 cents at 2.9 Hz.
- **- Between Us And Them stereo movement:** bass pan range 0.30; vocals pan range 0.32.
- **- Between Us And Them builds:** 0:00.0 to 0:40.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **- Suddenly The Trees Are Giving Way meter:** about 100 BPM (could be 50 or 200; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim.
- **- Suddenly The Trees Are Giving Way key and mode:** F# ionian (major) (key signature margin 0.023); fits F# major pentatonic; pitch-class weights F# 0.25, C# 0.16, B 0.15, D# 0.13, A# 0.09.
- **- Suddenly The Trees Are Giving Way chords:** 22 changes a minute (21 a minute are chords that last 1.5 s or more); median chord 2.4 s (10th to 90th percentile 1.7 to 2.7 s); 17 distinct chords; most time on F#5 26%, B 25%, F#maj7 17%, Bsus2 9%. The old counter in this same run said 16; Ears 1's 2-s counter said 14.  83% of the changes land on a beat (chance would be 50%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Suddenly The Trees Are Giving Way bass:** root-note movement / mixed; 0.64 notes a second; most time on F# 0.57, B 0.36, D# 0.04, G 0.03; steps 0%, thirds 5%, fourths and fifths 30%, octaves 3%, repeats 61%.
- **- Suddenly The Trees Are Giving Way top line (from the 'other' stem; read by ear before trusting):** 931 notes, range 12 semitones (10th to 90th percentile); steps 8%, thirds 13%, fourths and fifths 39%, leaps 22%, repeats 18%; median interval 5 semitones; 50% of moves go up; phrases of about 12 notes, arch 44%, rising 15%, falling 22%, flat or wavy 19%. Reliable only when the line sits clearly above its accompaniment.
- **- Suddenly The Trees Are Giving Way repetition:** 159 bars of 2.4 s; strongest repeat distances 2 bars (0.62), 4 bars (0.52), 6 bars (0.39); 12% of bars near-duplicate an earlier bar.
- **- Sunday Evening In Your Street meter:** about 100 BPM (could be 50 or 200; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Sunday Evening In Your Street key and mode:** E phrygian (key signature margin 0.047); pitch-class weights C 0.14, A 0.13, D 0.13, E 0.12, F 0.11.
- **- Sunday Evening In Your Street chords:** 26 changes a minute (9 a minute are chords that last 1.5 s or more); median chord 1.2 s (10th to 90th percentile 0.7 to 3.2 s); 31 distinct chords; most time on Dmin7 34%, Amin7 18%, Fmaj7 15%, Amin 7%. The old counter in this same run said 10; Ears 1's 2-s counter said 10.  44% of the changes land on a beat (chance would be 50%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Sunday Evening In Your Street bass:** root-note movement / mixed; 0.38 notes a second; most time on E 0.32, D 0.16, C 0.14, A 0.14; steps 35%, thirds 11%, fourths and fifths 7%, octaves 2%, repeats 12%.
- **- Sunday Evening In Your Street top line (from the 'other' stem; read by ear before trusting):** 627 notes, range 12 semitones (10th to 90th percentile); steps 27%, thirds 16%, fourths and fifths 15%, leaps 17%, repeats 25%; median interval 2 semitones; 46% of moves go up; phrases of about 8 notes, arch 44%, rising 12%, falling 27%, flat or wavy 17%. Reliable only when the line sits clearly above its accompaniment.
- **- Sunday Evening In Your Street repetition:** 84 bars of 4.8 s; strongest repeat distances 1 bars (0.50), 4 bars (0.37), 8 bars (0.15); 5% of bars near-duplicate an earlier bar.
- **- Knuddelmaus meter:** about 100 BPM (could be 50 or 200; the tool cannot tell the beat level), 4 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:2, 5:3, 5:4), which means irregular timing, not a cross-rhythm claim.
- **- Knuddelmaus key and mode:** G ionian (major) (key signature margin 0.042); fits G major pentatonic; pitch-class weights G 0.23, C 0.20, D 0.16, C# 0.07, F# 0.07.
- **- Knuddelmaus chords:** 21 changes a minute (20 a minute are chords that last 1.5 s or more); median chord 2.3 s (10th to 90th percentile 1.6 to 4.0 s); 4 distinct chords; most time on G5 47%, C5 26%, Csus2 21%, Gmaj7 6%. The old counter in this same run said 18; Ears 1's 2-s counter said 16.  68% of the changes land on a beat (chance would be 50%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Knuddelmaus bass:** root-note movement / mixed; 1.12 notes a second; most time on G 0.54, C 0.35, D 0.11; steps 7%, thirds 0%, fourths and fifths 25%, octaves 15%, repeats 43%.
- **- Knuddelmaus top line (from the 'other' stem; read by ear before trusting):** 1071 notes, range 10 semitones (10th to 90th percentile); steps 15%, thirds 7%, fourths and fifths 43%, leaps 12%, repeats 23%; median interval 5 semitones; 53% of moves go up; phrases of about 11 notes, arch 57%, rising 6%, falling 13%, flat or wavy 23%. Reliable only when the line sits clearly above its accompaniment.
- **- Knuddelmaus repetition:** 175 bars of 2.4 s; strongest repeat distances 4 bars (0.73), 2 bars (0.70), 8 bars (0.54); 22% of bars near-duplicate an earlier bar.
- **- Between Us And Them meter:** about 87 BPM (could be 43 or 174; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.09); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **- Between Us And Them key and mode:** D# mixolydian (key signature margin 0.051); pitch-class weights D# 0.20, C# 0.17, F 0.15, A# 0.12, G 0.08.
- **- Between Us And Them chords:** 22 changes a minute (16 a minute are chords that last 1.5 s or more); median chord 2.1 s (10th to 90th percentile 0.8 to 5.2 s); 19 distinct chords; most time on D#sus2 27%, D#5 14%, A#min7 14%, C#5 11%. The old counter in this same run said 11; Ears 1's 2-s counter said 10.  21% of the changes land on a beat (chance would be 43%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **- Between Us And Them bass:** root-note movement / mixed; 1.07 notes a second; most time on D# 0.47, A# 0.28, C# 0.12, G# 0.10; steps 7%, thirds 0%, fourths and fifths 7%, octaves 0%, repeats 85%.
- **- Between Us And Them top line (from the 'other' stem; read by ear before trusting):** 1067 notes, range 7 semitones (10th to 90th percentile); steps 25%, thirds 30%, fourths and fifths 9%, leaps 17%, repeats 19%; median interval 4 semitones; 49% of moves go up; phrases of about 14 notes, arch 34%, rising 16%, falling 28%, flat or wavy 22%. Reliable only when the line sits clearly above its accompaniment.
- **- Between Us And Them repetition:** 162 bars of 2.8 s; strongest repeat distances 1 bars (0.66), 4 bars (0.55), 16 bars (0.14); 17% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **- Suddenly The Trees Are Giving Way mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -26 (corr 0.99); low_120_500 -8 (corr 0.72); mid_500_2k -1 (corr 0.16); pres_2k_5k -4 (corr 0.38); air_gt5k -13 (corr 0.91); over time (2-s windows) 10th/50th/90th percentile -8/-5/-2 dB.
- **- Suddenly The Trees Are Giving Way by part:** drums: 37% of the power, width -21 dB, pan -0.01, mono loss 0.0 dB, widest in low_120_500 (-18 dB); bass: 32% of the power, width -44 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-41 dB); other: 31% of the power, width -1 dB, pan +0.02, mono loss 2.6 dB, widest in mid_500_2k (-0 dB); vocals: 0% of the power, width 1 dB, pan +0.47, mono loss 3.6 dB, widest in pres_2k_5k (4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Sunday Evening In Your Street mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -24 (corr 0.99); low_120_500 -7 (corr 0.70); mid_500_2k -5 (corr 0.51); pres_2k_5k -10 (corr 0.82); air_gt5k -21 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -10/-7/-2 dB.
- **- Sunday Evening In Your Street by part:** drums: 48% of the power, width -35 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-41 dB); bass: 26% of the power, width -38 dB, pan -0.00, mono loss 0.0 dB, widest in low_120_500 (-33 dB); other: 26% of the power, width -4 dB, pan +0.02, mono loss 1.4 dB, widest in mid_500_2k (-3 dB); vocals: 0% of the power, width -0 dB, pan +0.05, mono loss 2.8 dB, widest in low_120_500 (1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Knuddelmaus mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.97); low_120_500 -7 (corr 0.67); mid_500_2k -5 (corr 0.55); pres_2k_5k -6 (corr 0.63); air_gt5k -10 (corr 0.80); over time (2-s windows) 10th/50th/90th percentile -9/-7/-4 dB.
- **- Knuddelmaus by part:** drums: 19% of the power, width -14 dB, pan -0.08, mono loss 0.2 dB, widest in mid_500_2k (-8 dB); bass: 58% of the power, width -16 dB, pan -0.01, mono loss 0.1 dB, widest in low_120_500 (-12 dB); other: 23% of the power, width -4 dB, pan +0.07, mono loss 1.4 dB, widest in low_120_500 (-4 dB); vocals: 0% of the power, width -4 dB, pan -0.05, mono loss 1.5 dB, widest in pres_2k_5k (2 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **- Between Us And Them mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -12 (corr 0.89); low_120_500 -5 (corr 0.53); mid_500_2k -3 (corr 0.33); pres_2k_5k -3 (corr 0.33); air_gt5k -4 (corr 0.39); over time (2-s windows) 10th/50th/90th percentile -5/-4/0 dB.
- **- Between Us And Them by part:** drums: 14% of the power, width -13 dB, pan +0.03, mono loss 0.2 dB, widest in mid_500_2k (-13 dB); bass: 50% of the power, width -13 dB, pan +0.02, mono loss 0.2 dB, widest in sub_lt120 (-13 dB); other: 36% of the power, width -2 dB, pan -0.07, mono loss 2.0 dB, widest in pres_2k_5k (-1 dB); vocals: 0% of the power, width 4 dB, pan -0.07, mono loss 5.2 dB, widest in low_120_500 (6 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: - Suddenly The Trees Are Giving Way: 100 BPM, 21 settled chords a minute, 10% of energy above 2 kHz, width -8 dB; - Sunday Evening In Your Street: 100 BPM, 9 settled chords a minute, 4% of energy above 2 kHz, width -11 dB; - Knuddelmaus: 100 BPM, 20 settled chords a minute, 2% of energy above 2 kHz, width -10 dB; - Between Us And Them: 87 BPM, 16 settled chords a minute, 6% of energy above 2 kHz, width -7 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- - Between Us And Them, other group `other-1` (402 notes): around D#3, bell- or metal-like (partials off whole multiples), soft attack, falls 12 dB/s, centered; hear it at 1:16.9, 1:16.2. **[JUDGMENT]** why it waits.
- - Suddenly The Trees Are Giving Way, drums group `drums-1` (168 notes): low thump, quick attack, falls 103 dB/s, centered; hear it at 0:23.0, 0:32.6. **[JUDGMENT]** why it waits.
- - Sunday Evening In Your Street, bass group `bass-1` (92 notes): around E3, harmonic (string/reed/pad-like), soft attack, falls 17 dB/s, vibrato about 9 cents at 7.9 Hz, centered; hear it at 1:27.1, 1:48.7. **[JUDGMENT]** why it waits.
- - Sunday Evening In Your Street, drums group `drums-1` (230 notes): low thump, quick attack, falls 137 dB/s, centered; hear it at 2:24.8, 2:25.8. **[JUDGMENT]** why it waits.
- - Sunday Evening In Your Street, bass group `bass-2` (194 notes): around B1, bell- or metal-like (partials off whole multiples), soft attack, falls 35 dB/s, centered; hear it at 1:24.4, 3:26.9. **[JUDGMENT]** why it waits.
- - Knuddelmaus, drums group `drums-1` (372 notes): low thump, quick attack, falls 118 dB/s, centered; hear it at 1:30.4, 4:35.4. **[JUDGMENT]** why it waits.
- - Suddenly The Trees Are Giving Way, other group `other-2` (185 notes): around D#2, harmonic (string/reed/pad-like), soft attack, falls 6 dB/s, centered; hear it at 1:09.9, 1:07.5. **[JUDGMENT]** why it waits.
- - Suddenly The Trees Are Giving Way, drums group `drums-2` (139 notes): low thump, soft attack, falls 141 dB/s, gets brighter over the note, centered; hear it at 0:24.4, 0:20.6. **[JUDGMENT]** why it waits.
