## Lifeforms (draft card from Ears 3 tools, 2026-11-03)

How it was made: 19 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: 1-06 Lifeforms; Cerebral; Domain; Vertical Pig. Typical track: 1-06 Lifeforms. Least like the rest: Cerebral, Domain, Vertical Pig.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **1-06 Lifeforms**: share of power drums 52%, bass 0%, other 44%, vocals 4%.
  - bass stem is near empty (0.2%): bass notes, pumping and wobble are void.
  - vocals stem holds 4.1%: bleed on an instrumental, not a voice.
  - meter tool 133 BPM agrees with the drum-grid beat of 132.5 BPM.
- **Cerebral**: share of power drums 6%, bass 21%, other 50%, vocals 24%.
  - meter tool 97 BPM is half of the drum-grid beat of 191.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Domain**: share of power drums 14%, bass 13%, other 72%, vocals 2%.
  - vocals stem holds 1.8%: bleed on an instrumental, not a voice.
  - meter tool 133 BPM is two thirds of the drum-grid beat of 198.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **Vertical Pig**: share of power drums 22%, bass 33%, other 28%, vocals 16%.
  - meter tool 123 BPM is two thirds of the drum-grid beat of 184.6 BPM (use the grid; if it is off by a simple ratio, check by ear).

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 97 to 133 BPM (octave-uncertain); keys D# mixolydian, E aeolian, D# ionian, C lydian; mix width -12 to -2 dB; chord changes 9 to 32 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. Domain: other group `other-1` (436 notes, 73% of the track's note energy)
- In synth terms: around C2, bell- or metal-like (partials off whole multiples), slow swell, falls 12 dB/s, leans right (+0.15).
- Hear it at: 0:19.3 (F#1, 2.45 s, +39 dB alone), 0:18.3 (F#1, 1.16 s, +39 dB alone), 0:15.8 (C2, 0.64 s, +34 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 65 (37 to 86) Hz; attack 159 (38 to 569) ms; decay -12 (-72 to 0) dB/s
  - brightness at the start 554 (240 to 1654) Hz; slope over the note 0.00 (-0.22 to 0.45) octaves
  - harmonic share 0.42 (0.15 to 0.85); partials off whole multiples 64 (25 to 124) cents
  - vibrato 0 (0 to 14) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.2 (-7.6 to -2.0) dB; pan 0.15 (0.03 to 0.28); left-right correlation 0.15 (-0.10 to 0.43)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. 1-06 Lifeforms: other group `other-1` (338 notes, 54% of the track's note energy)
- In synth terms: around A#1, mixed or noisy partials, slow swell, falls 6 dB/s, centered.
- Hear it at: 5:18.3 (?, 0.21 s, +54 dB alone), 5:03.5 (A#1, 3.32 s, +54 dB alone), 4:53.6 (A#1, 2.36 s, +51 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 58 (34 to 78) Hz; attack 211 (48 to 941) ms; decay -6 (-54 to 1) dB/s
  - brightness at the start 493 (280 to 905) Hz; slope over the note 0.00 (-0.61 to 0.46) octaves
  - harmonic share 0.61 (0.16 to 0.92); partials off whole multiples 54 (19 to 150) cents
  - vibrato 0 (0 to 14) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.2 (-14.1 to -0.7) dB; pan 0.04 (-0.12 to 0.17); left-right correlation 0.72 (0.18 to 0.96)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. Cerebral: other group `other-1` (162 notes, 46% of the track's note energy)
- In synth terms: around F#1, bell- or metal-like (partials off whole multiples), soft attack, falls 12 dB/s, centered.
- Hear it at: 2:32.9 (E1, 0.9 s, +36 dB alone), 0:48.8 (E1, 1.01 s, +32 dB alone), 0:42.5 (E1, 0.89 s, +28 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (41 to 83) Hz; attack 101 (25 to 493) ms; decay -12 (-38 to -2) dB/s
  - brightness at the start 384 (185 to 601) Hz; slope over the note -0.03 (-0.43 to 0.34) octaves
  - harmonic share 0.38 (0.16 to 0.85); partials off whole multiples 68 (22 to 141) cents
  - vibrato 0 (0 to 24) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.9 (-12.4 to -0.6) dB; pan 0.01 (-0.09 to 0.07); left-right correlation 0.62 (0.00 to 0.85)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S4. Vertical Pig: bass group `bass-1` (288 notes, 27% of the track's note energy)
- In synth terms: around C1, harmonic (string/reed/pad-like), soft attack, falls 10 dB/s, centered.
- Hear it at: 5:23.5 (C1, 0.24 s, +8 dB alone), 5:15.6 (C1, 0.39 s, +7 dB alone), 5:22.6 (C1, 0.14 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 33 (32 to 34) Hz; attack 116 (10 to 587) ms; decay -10 (-78 to 2) dB/s
  - brightness at the start 112 (95 to 149) Hz; slope over the note 0.00 (-0.23 to 0.44) octaves
  - harmonic share 0.94 (0.10 to 1.00); partials off whole multiples 24 (7 to 98) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.2 (-10.9 to -2.4) dB; pan 0.05 (-0.00 to 0.11); left-right correlation 0.92 (0.76 to 0.98)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S5. 1-06 Lifeforms: drums group `drums-1` (281 notes, 22% of the track's note energy)
- In synth terms: low thump, quick attack, falls 115 dB/s, gets brighter over the note, centered.
- Hear it at: 3:59.6 (F#1, 0.26 s, +18 dB alone), 3:58.7 (F#1, 0.25 s, +17 dB alone), 3:40.6 (F#1, 0.26 s, +17 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 47 (47 to 48) Hz; attack 10 (7 to 12) ms; decay -115 (-124 to -106) dB/s
  - brightness at the start 84 (80 to 173) Hz; slope over the note 0.95 (0.35 to 4.66) octaves
  - harmonic share 0.96 (0.82 to 0.99); partials off whole multiples 119 (58 to 174) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-2.7 to -0.4) dB; pan 0.01 (0.00 to 0.02); left-right correlation 1.00 (0.98 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S6. Vertical Pig: other group `other-1` (442 notes, 20% of the track's note energy)
- In synth terms: around C2, mixed or noisy partials, soft attack, falls 16 dB/s, centered.
- Hear it at: 0:54.2 (F#2, 0.13 s, +41 dB alone), 0:54.0 (D#2, 0.23 s, +33 dB alone), 4:15.1 (A#1, 0.24 s, +25 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 65 (34 to 131) Hz; attack 132 (36 to 351) ms; decay -16 (-98 to 0) dB/s
  - brightness at the start 694 (407 to 1160) Hz; slope over the note 0.00 (-0.31 to 0.20) octaves
  - harmonic share 0.46 (0.20 to 0.78); partials off whole multiples 60 (27 to 125) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.5 (-6.9 to -1.8) dB; pan -0.00 (-0.08 to 0.06); left-right correlation 0.74 (0.26 to 0.90)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. Cerebral: other group `other-2` (41 notes, 19% of the track's note energy)
- In synth terms: around B2, mixed or noisy partials, soft attack, falls 14 dB/s, centered.
- Hear it at: 0:45.5 (B2, 3.49 s, +21 dB alone), 0:39.4 (B2, 3.06 s, +18 dB alone), 2:11.6 (A2, 0.95 s, +18 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 125 (83 to 187) Hz; attack 55 (30 to 328) ms; decay -14 (-31 to -7) dB/s
  - brightness at the start 505 (357 to 584) Hz; slope over the note -0.29 (-0.63 to 0.21) octaves
  - harmonic share 0.81 (0.72 to 0.90); partials off whole multiples 40 (23 to 82) cents
  - vibrato 4 (0 to 13) cents; detune beating 0.0 (0.0 to 0.3) Hz
  - level against the mix -2.2 (-8.2 to -0.5) dB; pan 0.02 (-0.03 to 0.08); left-right correlation 0.72 (0.22 to 0.89)
- Group quality: weak (silhouette 0.23, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S8. Domain: bass group `bass-1` (235 notes, 14% of the track's note energy)
- In synth terms: around D#2, bell- or metal-like (partials off whole multiples), soft attack, falls 37 dB/s, centered.
- Hear it at: 2:30.4 (D#2, 0.48 s, +4 dB alone), 2:18.8 (C#2, 3.04 s, -2 dB alone), 1:57.4 (D#2, 0.32 s, +2 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 76 (56 to 98) Hz; attack 87 (19 to 338) ms; decay -37 (-376 to -3) dB/s
  - brightness at the start 98 (78 to 129) Hz; slope over the note 0.00 (-0.04 to 0.41) octaves
  - harmonic share 0.92 (0.04 to 0.99); partials off whole multiples 103 (17 to 315) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -15.2 (-31.0 to -4.9) dB; pan 0.11 (-0.24 to 0.29); left-right correlation 0.57 (-0.62 to 0.94)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **1-06 Lifeforms sections:** 18 boundaries at 0:09.0, 0:23.0, 0:37.0, 0:52.0, 1:06.0, 1:20.0, 1:35.0, 1:49.0, 2:04.0, 2:18.0, 2:32.0, 2:47.0; section lengths median 15 s (range 9 to 41). Reliable for sections of 10 s or more.
- **1-06 Lifeforms stem entries and exits:** drums plays 78% of the time (in: 0:06.5, 2:16.5, 3:06.0; out: 2:03.0, 2:53.5, 4:42.0); bass plays 28% of the time (in: 0:11.0, 0:30.5, 0:46.0, 1:27.5, 1:39.0; out: 0:25.5, 0:36.5, 0:50.5, 1:34.5, 1:49.0); other plays 98% of the time (in: 0:06.5; out: never); vocals plays 51% of the time (in: 0:21.5, 1:03.0, 1:19.5, 1:28.0, 2:38.5; out: 0:18.0, 0:51.0, 1:07.5, 1:24.0, 2:31.0).
- **1-06 Lifeforms floor drops (kick and bass out 2 s or more while the rest plays):** 0.84 a minute: 2:02.5 for 14.8 s, 2:53.0 for 13.8 s, 3:56.2 for 2.0 s, 4:41.5 for 21.0 s.
- **1-06 Lifeforms brightness sweeps (0.7 octave or more):** mix down 0.9 oct 0:27.0 to 0:34.5; mix down 0.9 oct 0:39.5 to 0:48.0; mix up 1.1 oct 0:48.0 to 0:53.0; mix down 1.3 oct 1:36.5 to 1:43.5; mix up 1.0 oct 1:44.0 to 1:51.5; mix down 1.4 oct 1:51.5 to 1:56.5; mix down 1.1 oct 2:12.0 to 2:21.5; mix up 2.1 oct 2:50.5 to 2:55.5 (51 more in techniques.json).
- **1-06 Lifeforms echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **1-06 Lifeforms pumping locked to the kick:** bass dips 5.8 dB at the kick (peak 314 ms after, kick every 0.45 s). The tool reads about 70% of the true depth, so this is a floor.
- **1-06 Lifeforms tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **1-06 Lifeforms stereo movement:** other pan range 0.20, cycling every 2 s.
- **Cerebral sections:** 11 boundaries at 0:36.0, 1:02.0, 1:17.0, 1:33.0, 1:52.0, 2:05.0, 2:17.0, 2:37.0, 2:54.0, 3:11.0, 3:28.0; section lengths median 17 s (range 3 to 36). Reliable for sections of 10 s or more.
- **Cerebral stem entries and exits:** drums plays 26% of the time (in: 0:59.5, 1:32.0, 1:46.5, 2:23.5; out: 0:36.5, 1:05.0, 1:38.0, 1:49.5, 2:26.5); bass plays 40% of the time (in: 0:17.0, 0:28.0, 0:35.0, 1:02.0, 1:12.5; out: 0:25.5, 0:31.0, 0:45.5, 1:09.5, 1:15.5); other plays 100% of the time (in: from the start; out: never); vocals plays 90% of the time (in: 0:50.5; out: 0:30.5).
- **Cerebral floor drops:** low end too sparse to say (on in under 75% of the track).
- **Cerebral brightness sweeps (0.7 octave or more):** mix down 0.8 oct 0:00.0 to 0:07.0; mix up 2.4 oct 0:07.0 to 0:12.5; mix up 1.5 oct 0:20.5 to 0:25.5; mix down 1.2 oct 1:00.5 to 1:06.0; mix up 1.3 oct 1:28.5 to 1:34.0; mix down 1.1 oct 1:34.0 to 1:41.5; mix down 1.5 oct 1:46.0 to 1:53.5; mix up 1.1 oct 1:53.5 to 2:00.5 (23 more in techniques.json).
- **Cerebral echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Cerebral pumping locked to the kick:** under 1.5 dB; none found.
- **Cerebral tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Cerebral stereo movement:** drums pan range 0.45; bass pan range 0.29; other pan range 0.27.
- **Domain sections:** 7 boundaries at 0:03.0, 0:33.0, 1:03.0, 1:32.0, 1:56.0, 2:18.0, 2:29.0; section lengths median 23 s (range 3 to 30). Reliable for sections of 10 s or more.
- **Domain stem entries and exits:** drums plays 78% of the time (in: 0:22.5, 1:05.0, 1:12.0, 1:21.5, 1:27.0; out: 0:18.5, 0:59.5, 1:09.0, 1:18.0, 1:24.5); bass plays 75% of the time (in: 0:28.0, 0:47.0; out: 0:42.5, 2:38.5); other plays 99% of the time (in: from the start; out: never); vocals plays 30% of the time (in: 0:51.5, 1:35.5, 2:22.5, 2:39.5; out: 0:59.0, 1:57.0, 2:36.0).
- **Domain floor drops (kick and bass out 2 s or more while the rest plays):** 1.99 a minute: 0:13.8 for 3.5 s, 0:17.5 for 6.2 s, 1:17.0 for 5.8 s, 1:23.5 for 4.0 s, 2:21.2 for 3.0 s.
- **Domain brightness sweeps (0.7 octave or more):** mix up 1.6 oct 0:21.5 to 0:37.0; mix down 1.4 oct 0:37.0 to 0:42.5; mix up 1.6 oct 0:48.0 to 0:53.0; mix down 0.9 oct 0:53.5 to 0:59.5; mix up 0.8 oct 0:59.5 to 1:07.5; mix up 2.4 oct 1:27.0 to 1:32.5; mix down 1.8 oct 1:39.0 to 1:46.0; mix down 2.3 oct 1:52.5 to 1:58.0 (21 more in techniques.json).
- **Domain echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **Domain pumping locked to the kick:** under 1.5 dB; none found.
- **Domain tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **Domain stereo movement:** drums pan range 0.43; bass pan range 0.70; other pan range 0.27; vocals pan range 0.36.
- **Vertical Pig sections:** 16 boundaries at 0:48.0, 1:28.0, 1:55.0, 2:11.0, 2:24.0, 2:56.0, 3:06.0, 3:22.0, 3:49.0, 4:07.0, 4:29.0, 4:57.0; section lengths median 16 s (range 1 to 48). Reliable for sections of 10 s or more.
- **Vertical Pig stem entries and exits:** drums plays 89% of the time (in: 0:06.5, 0:21.0, 0:32.0, 0:46.5, 3:03.0; out: 0:16.5, 0:25.5, 0:34.5, 2:59.5, 4:10.0); bass plays 84% of the time (in: 0:06.0, 0:58.5, 3:04.0; out: 0:11.0, 3:01.0); other plays 100% of the time (in: from the start; out: never); vocals plays 83% of the time (in: 1:10.0, 1:27.5, 2:54.5, 3:11.5, 3:20.0; out: 0:48.5, 1:23.0, 2:50.0, 3:03.5, 3:17.5).
- **Vertical Pig floor drops (kick and bass out 2 s or more while the rest plays):** 0.57 a minute: 0:17.2 for 29.8 s, 0:52.8 for 2.0 s, 2:59.0 for 5.2 s.
- **Vertical Pig brightness sweeps (0.7 octave or more):** mix down 1.0 oct 0:13.5 to 0:18.5; mix up 2.3 oct 0:18.5 to 0:25.0; mix up 1.3 oct 0:29.5 to 0:36.0; mix down 1.9 oct 0:36.0 to 0:44.5; mix up 2.1 oct 0:45.0 to 0:50.5; mix down 2.1 oct 0:50.5 to 0:58.5; mix up 2.0 oct 0:59.0 to 1:04.0; mix down 1.4 oct 1:04.5 to 1:13.5 (60 more in techniques.json).
- **Vertical Pig echo times:** drums: 319 ms (+10.2 dB, 2 later repeats).
- **Vertical Pig pumping locked to the kick:** under 1.5 dB; none found.
- **Vertical Pig tape wobble and speed:** bass wobbles about 21 cents at 1.9 Hz; bass speed moves up to 24 cents in 4 s.
- **Vertical Pig stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **1-06 Lifeforms meter:** about 133 BPM (could be 66 or 266; the tool cannot tell the beat level), bar length unclear (best guess 4, score 0.03); swung: off-beat at 0.65 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (4:3, 5:2, 5:3, 5:4), which means irregular timing, not a cross-rhythm claim.
- **1-06 Lifeforms key and mode:** D# mixolydian (low confidence: the key signature margin is 0.014, so read this as a guess); pitch-class weights C 0.16, D# 0.15, G 0.13, A# 0.11, E 0.07.
- **1-06 Lifeforms chords:** 12 changes a minute (8 a minute are chords that last 1.5 s or more); median chord 6.3 s (10th to 90th percentile 0.5 to 7.5 s); 18 distinct chords; most time on C5 22%, Cmin7 21%, D#5 21%, A#min7 15%. The old counter in this same run said 6; Ears 1's 2-s counter said 5.  66% of the changes land on a beat (chance would be 66%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **1-06 Lifeforms bass:** root-note movement / mixed; 0.14 notes a second; most time on D# 0.58, C 0.32, C# 0.09, G 0.01; steps 5%, thirds 9%, fourths and fifths 0%, octaves 14%, repeats 61%.
- **1-06 Lifeforms top line (from the 'other' stem; read by ear before trusting):** 648 notes, range 12 semitones (10th to 90th percentile); steps 6%, thirds 7%, fourths and fifths 46%, leaps 22%, repeats 19%; median interval 5 semitones; 50% of moves go up; phrases of about 17 notes, arch 48%, rising 36%, falling 8%, flat or wavy 8%. Reliable only when the line sits clearly above its accompaniment.
- **1-06 Lifeforms repetition:** 176 bars of 1.8 s; strongest repeat distances 1 bars (0.60), 8 bars (0.43), 16 bars (0.13); 17% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Cerebral meter:** about 97 BPM (could be 49 or 194; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.13); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **Cerebral key and mode:** E aeolian (minor) (low confidence: the key signature margin is 0.011, so read this as a guess); pitch-class weights E 0.19, B 0.15, G 0.10, F# 0.10, D# 0.08.
- **Cerebral chords:** 32 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.8 to 3.2 s); 22 distinct chords; most time on Esus2 28%, Emin 14%, Asus2 12%, Bmin7 6%. The old counter in this same run said 15; Ears 1's 2-s counter said 14.  47% of the changes land on a beat (chance would be 49%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Cerebral bass:** root-note movement / mixed; 0.25 notes a second; most time on E 0.44, B 0.43, A 0.08, C 0.02; steps 8%, thirds 4%, fourths and fifths 13%, octaves 4%, repeats 56%.
- **Cerebral top line (from the 'other' stem; read by ear before trusting):** 378 notes, range 11 semitones (10th to 90th percentile); steps 16%, thirds 11%, fourths and fifths 30%, leaps 15%, repeats 28%; median interval 4 semitones; 52% of moves go up; phrases of about 10 notes, arch 41%, rising 53%, falling 0%, flat or wavy 6%. Reliable only when the line sits clearly above its accompaniment.
- **Cerebral repetition:** 170 bars of 1.2 s; strongest repeat distances 1 bars (0.49), 10 bars (0.35), 5 bars (0.31); 2% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Domain meter:** about 133 BPM (could be 67 or 267; the tool cannot tell the beat level), bar length unclear (best guess 5, score 0.03); straight eighths; no cross-rhythm claim; many unrelated periodicities found (4:3, 5:4, 7:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **Domain key and mode:** D# ionian (major) (low confidence: the key signature margin is 0.015, so read this as a guess); pitch-class weights D# 0.17, A# 0.10, D 0.10, C 0.09, C# 0.09.
- **Domain chords:** 27 changes a minute (17 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.9 to 3.6 s); 27 distinct chords; most time on D#maj7 26%, Cmin7 13%, D#5 12%, G#maj7 9%. The old counter in this same run said 15; Ears 1's 2-s counter said 14.  64% of the changes land on a beat (chance would be 67%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Domain bass:** root-note movement / mixed; 0.73 notes a second; most time on D# 0.57, G 0.17, A# 0.16, C 0.05; steps 13%, thirds 11%, fourths and fifths 19%, octaves 2%, repeats 50%.
- **Domain top line (from the 'other' stem; read by ear before trusting):** 377 notes, range 14 semitones (10th to 90th percentile); steps 28%, thirds 12%, fourths and fifths 19%, leaps 22%, repeats 19%; median interval 3 semitones; 50% of moves go up; phrases of about 16 notes, arch 25%, rising 17%, falling 25%, flat or wavy 33%. Reliable only when the line sits clearly above its accompaniment.
- **Domain repetition:** 74 bars of 2.2 s; strongest repeat distances 1 bars (0.51), 5 bars (0.28), 10 bars (0.11); 1% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **Vertical Pig meter:** about 123 BPM (could be 61 or 245; the tool cannot tell the beat level), bar length unclear (best guess 2, score 0.28); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim.
- **Vertical Pig key and mode:** C lydian (low confidence: the key signature margin is 0.018, so read this as a guess); pitch-class weights C 0.22, G 0.11, C# 0.08, F# 0.08, B 0.07.
- **Vertical Pig chords:** 9 changes a minute (6 a minute are chords that last 1.5 s or more); median chord 2.1 s (10th to 90th percentile 0.8 to 18.9 s); 23 distinct chords; most time on C5 69%, Gsus2 10%, Cmaj7 5%, Csus2 3%. The old counter in this same run said 2; Ears 1's 2-s counter said 2.  67% of the changes land on a beat (chance would be 61%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **Vertical Pig bass:** root-note movement / mixed; 0.81 notes a second; most time on C 0.98, G# 0.02; steps 1%, thirds 0%, fourths and fifths 0%, octaves 50%, repeats 48%.
- **Vertical Pig top line (from the 'other' stem; read by ear before trusting):** 793 notes, range 19 semitones (10th to 90th percentile); steps 21%, thirds 11%, fourths and fifths 19%, leaps 23%, repeats 27%; median interval 3 semitones; 50% of moves go up; phrases of about 10 notes, arch 29%, rising 22%, falling 29%, flat or wavy 20%. Reliable only when the line sits clearly above its accompaniment.
- **Vertical Pig repetition:** 357 bars of 1.0 s; strongest repeat distances 1 bars (0.71), 21 bars (0.21), 16 bars (0.16); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **1-06 Lifeforms mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -16 (corr 0.95); low_120_500 -12 (corr 0.89); mid_500_2k -9 (corr 0.79); pres_2k_5k -9 (corr 0.79); air_gt5k -15 (corr 0.94); over time (2-s windows) 10th/50th/90th percentile -16/-11/-7 dB.
- **1-06 Lifeforms by part:** drums: 50% of the power, width -16 dB, pan +0.01, mono loss 0.1 dB, widest in low_120_500 (-14 dB); bass: 0% of the power, width -15 dB, pan -0.07, mono loss 0.1 dB, widest in low_120_500 (-9 dB); other: 45% of the power, width -11 dB, pan +0.07, mono loss 0.4 dB, widest in mid_500_2k (-9 dB); vocals: 4% of the power, width -10 dB, pan +0.17, mono loss 0.4 dB, widest in mid_500_2k (-10 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Cerebral mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -13 (corr 0.90); low_120_500 -8 (corr 0.75); mid_500_2k -10 (corr 0.81); pres_2k_5k -3 (corr 0.32); air_gt5k -1 (corr 0.14); over time (2-s windows) 10th/50th/90th percentile -12/-8/-4 dB.
- **Cerebral by part:** drums: 6% of the power, width -10 dB, pan +0.14, mono loss 0.4 dB, widest in sub_lt120 (-10 dB); bass: 19% of the power, width -15 dB, pan +0.08, mono loss 0.1 dB, widest in low_120_500 (-12 dB); other: 53% of the power, width -7 dB, pan +0.00, mono loss 0.7 dB, widest in low_120_500 (-6 dB); vocals: 22% of the power, width -13 dB, pan +0.02, mono loss 0.2 dB, widest in low_120_500 (-15 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Domain mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -2 (corr 0.24); low_120_500 -3 (corr 0.36); mid_500_2k -1 (corr 0.11); pres_2k_5k -2 (corr 0.29); air_gt5k -2 (corr 0.28); over time (2-s windows) 10th/50th/90th percentile -4/-2/1 dB.
- **Domain by part:** drums: 14% of the power, width -2 dB, pan +0.13, mono loss 2.0 dB, widest in sub_lt120 (0 dB); bass: 12% of the power, width -2 dB, pan +0.34, mono loss 1.9 dB, widest in sub_lt120 (-3 dB); other: 73% of the power, width -2 dB, pan +0.28, mono loss 2.1 dB, widest in mid_500_2k (-0 dB); vocals: 1% of the power, width -6 dB, pan -0.08, mono loss 1.0 dB, widest in low_120_500 (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **Vertical Pig mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -10 (corr 0.81); low_120_500 -8 (corr 0.75); mid_500_2k -7 (corr 0.68); pres_2k_5k -5 (corr 0.56); air_gt5k -11 (corr 0.84); over time (2-s windows) 10th/50th/90th percentile -13/-9/-4 dB.
- **Vertical Pig by part:** drums: 22% of the power, width -9 dB, pan +0.03, mono loss 0.5 dB, widest in sub_lt120 (-8 dB); bass: 31% of the power, width -13 dB, pan +0.13, mono loss 0.2 dB, widest in low_120_500 (-10 dB); other: 31% of the power, width -6 dB, pan -0.03, mono loss 0.9 dB, widest in mid_500_2k (-6 dB); vocals: 17% of the power, width -7 dB, pan -0.04, mono loss 0.8 dB, widest in pres_2k_5k (-1 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 1-06 Lifeforms: 133 BPM, 8 settled chords a minute, 3% of energy above 2 kHz, width -12 dB; Cerebral: 97 BPM, 15 settled chords a minute, 1% of energy above 2 kHz, width -9 dB; Domain: 133 BPM, 17 settled chords a minute, 3% of energy above 2 kHz, width -2 dB; Vertical Pig: 123 BPM, 6 settled chords a minute, 9% of energy above 2 kHz, width -8 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- Cerebral, vocals group `vocals-1` (109 notes): around G4, mixed or noisy partials, slow swell, falls 12 dB/s, centered; hear it at 0:10.4, 3:29.4. **[JUDGMENT]** why it waits.
- Vertical Pig, bass group `bass-2` (160 notes): around C2, harmonic (string/reed/pad-like), slow swell, falls 7 dB/s, centered; hear it at 3:17.7, 5:24.1. **[JUDGMENT]** why it waits.
- Vertical Pig, drums group `drums-1` (378 notes): mid snap, soft attack, falls 123 dB/s, centered; hear it at 4:42.8, 3:40.1. **[JUDGMENT]** why it waits.
- Vertical Pig, vocals group `vocals-1` (299 notes): around E3, bell- or metal-like (partials off whole multiples), soft attack, falls 22 dB/s, centered; hear it at 0:19.1, 0:44.0. **[JUDGMENT]** why it waits.
- Vertical Pig, vocals group `vocals-2` (138 notes): around B4, bell- or metal-like (partials off whole multiples), soft attack, falls 28 dB/s, centered; hear it at 0:18.5, 0:03.3. **[JUDGMENT]** why it waits.
- Cerebral, bass group `bass-1` (40 notes): around A1, bell- or metal-like (partials off whole multiples), quick attack, falls 31 dB/s, centered; hear it at 2:38.1, 2:37.9. **[JUDGMENT]** why it waits.
- 1-06 Lifeforms, other group `other-2` (142 notes): around C3, bell- or metal-like (partials off whole multiples), soft attack, falls 25 dB/s, centered; hear it at 3:04.7, 3:06.4. **[JUDGMENT]** why it waits.
- 1-06 Lifeforms, drums group `drums-2` (137 notes): low thump, quick attack, falls 63 dB/s, centered; hear it at 3:39.3, 3:46.5. **[JUDGMENT]** why it waits.
- **Little Brother** (5:13.0, 144 BPM by the mix-level count): stands out for tail (dB a second) -5.20 (low, album median -1.00). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Eggshell** (5:49.4, 118 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 10.00 (high, album median 3.50). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Elaborate Burn** (3:15.6, 118 BPM by the mix-level count): stands out for pulse strength 0.15 (low, album median 0.65). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Interstat** (0:55.4, 112 BPM by the mix-level count): stands out for brightness sweep (octaves) 2.78 (high, album median 1.61). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **Spineless Jelly** (4:41.9, 112 BPM by the mix-level count): stands out for repetition 0.65 (high, album median 0.48). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
