## (1998) Music Has the Right to Children (draft card from Ears 3 tools, 2026-11-03)

How it was made: 18 usable tracks: the most typical plus the 3 least like the rest. Deep pass on: 15. Smokes Quantity; 09. Bocuma; 01. Wild Analysis; 17. One Very Important Thought. Typical track: 15. Smokes Quantity. Least like the rest: 09. Bocuma, 01. Wild Analysis, 17. One Very Important Thought.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **15. Smokes Quantity**: share of power drums 56%, bass 0%, other 44%, vocals 0%.
  - bass stem is near empty (0.0%): bass notes, pumping and wobble are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
  - meter tool 99 BPM is half of the drum-grid beat of 198.7 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **09. Bocuma**: share of power drums 0%, bass 0%, other 100%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
- **01. Wild Analysis**: share of power drums 0%, bass 0%, other 100%, vocals 0%.
  - drums and bass are empty: no beat; meter, swing and on-beat numbers are void.
  - vocals stem holds 0.0%: bleed on an instrumental, not a voice.
- **17. One Very Important Thought**: share of power drums 0%, bass 13%, other 80%, vocals 8%.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 63 to 101 BPM (octave-uncertain); keys C# dorian, G mixolydian, E aeolian, E locrian; mix width -19 to -8 dB; chord changes 17 to 48 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 01. Wild Analysis: bass group `bass-1` (74 notes, 88% of the track's note energy)
- In synth terms: around E1, harmonic (string/reed/pad-like), soft attack, falls 19 dB/s, centered.
- Hear it at: 0:50.4 (E1, 0.55 s, -24 dB alone), 0:50.1 (E1, 0.18 s, -24 dB alone), 0:50.3 (E1, 0.19 s, -24 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 41 (40 to 42) Hz; attack 48 (11 to 259) ms; decay -19 (-165 to 21) dB/s
  - brightness at the start 135 (116 to 215) Hz; slope over the note 0.00 (-0.01 to 0.23) octaves
  - harmonic share 0.93 (0.16 to 0.99); partials off whole multiples 27 (7 to 101) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -44.5 (-52.0 to -25.9) dB; pan 0.00 (-0.00 to 0.01); left-right correlation 1.00 (1.00 to 1.00)
- Group quality: weak (silhouette 0.00, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S2. 17. One Very Important Thought: other group `other-1` (231 notes, 53% of the track's note energy)
- In synth terms: around C#2, mixed or noisy partials, soft attack, falls 8 dB/s, centered.
- Hear it at: 0:03.8 (A2, 0.27 s, +78 dB alone), 0:04.0 (E2, 0.2 s, +69 dB alone), 0:06.9 (E2, 0.15 s, +67 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 71 (38 to 126) Hz; attack 107 (20 to 263) ms; decay -8 (-58 to 5) dB/s
  - brightness at the start 376 (320 to 430) Hz; slope over the note 0.00 (-0.08 to 0.15) octaves
  - harmonic share 0.75 (0.26 to 0.94); partials off whole multiples 43 (14 to 103) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.8 (-2.4 to -0.0) dB; pan -0.05 (-0.07 to -0.03); left-right correlation 0.99 (0.98 to 0.99)
- Group quality: weak (silhouette 0.21, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. 15. Smokes Quantity: drums group `drums-1` (218 notes, 49% of the track's note energy)
- In synth terms: low thump, quick attack, falls 169 dB/s, gets brighter over the note, centered.
- Hear it at: 0:37.9 (F1, 0.27 s, +5 dB alone), 1:19.1 (D#1, 0.6 s, +7 dB alone), 1:48.2 (D1, 0.32 s, +8 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 44 (37 to 53) Hz; attack 19 (15 to 38) ms; decay -169 (-234 to -119) dB/s
  - brightness at the start 155 (85 to 337) Hz; slope over the note 1.05 (0.08 to 2.45) octaves
  - harmonic share 0.98 (0.81 to 1.00); partials off whole multiples 156 (66 to 428) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-2.7 to -1.0) dB; pan 0.02 (-0.00 to 0.07); left-right correlation 0.91 (0.39 to 0.94)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

#### S4. 09. Bocuma: other group `other-1` (57 notes, 43% of the track's note energy)
- In synth terms: around F2, mixed or noisy partials, slow swell, falls 5 dB/s, centered.
- Hear it at: 1:34.9 (A2, 1.23 s, +60 dB alone), 0:03.9 (A2, 1.54 s, +58 dB alone), 0:29.1 (F2, 1.14 s, +58 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 89 (59 to 111) Hz; attack 337 (86 to 813) ms; decay -5 (-23 to -0) dB/s
  - brightness at the start 603 (512 to 705) Hz; slope over the note -0.02 (-0.51 to 0.11) octaves
  - harmonic share 0.85 (0.59 to 0.99); partials off whole multiples 26 (10 to 62) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.6 (-0.9 to -0.4) dB; pan -0.00 (-0.04 to 0.03); left-right correlation 0.73 (0.61 to 0.81)
- Group quality: weak (silhouette 0.20, 4 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. 09. Bocuma: other group `other-2` (56 notes, 37% of the track's note energy)
- In synth terms: around G#3, mixed or noisy partials, slow swell, falls 3 dB/s, centered.
- Hear it at: 0:38.3 (G3, 1.53 s, +56 dB alone), 1:26.7 (G3, 2.14 s, +56 dB alone), 0:41.0 (E3, 1.21 s, +58 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 213 (166 to 333) Hz; attack 286 (123 to 636) ms; decay -3 (-16 to 4) dB/s
  - brightness at the start 657 (575 to 749) Hz; slope over the note 0.03 (-0.19 to 0.28) octaves
  - harmonic share 0.82 (0.37 to 0.96); partials off whole multiples 39 (5 to 71) cents
  - vibrato 0 (0 to 10) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -0.5 (-0.9 to -0.3) dB; pan 0.02 (-0.04 to 0.04); left-right correlation 0.79 (0.63 to 0.85)
- Group quality: weak (silhouette 0.20, 4 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S6. 17. One Very Important Thought: other group `other-2` (118 notes, 29% of the track's note energy)
- In synth terms: around C#4, bell- or metal-like (partials off whole multiples), soft attack, falls 19 dB/s, centered.
- Hear it at: 0:03.5 (B3, 0.28 s, +76 dB alone), 0:04.9 (D4, 0.28 s, +71 dB alone), 0:02.2 (C#4, 0.43 s, +69 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 279 (113 to 299) Hz; attack 136 (23 to 310) ms; decay -19 (-101 to 2) dB/s
  - brightness at the start 402 (349 to 458) Hz; slope over the note 0.00 (-0.13 to 0.07) octaves
  - harmonic share 0.60 (0.09 to 0.90); partials off whole multiples 87 (23 to 185) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.0 (-2.8 to -0.0) dB; pan -0.05 (-0.07 to -0.03); left-right correlation 0.98 (0.97 to 0.99)
- Group quality: weak (silhouette 0.21, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S7. 01. Wild Analysis: vocals group `vocals-1` (7 notes, 12% of the track's note energy)
- In synth terms: around D5, mixed or noisy partials, odd harmonics stronger (square/clarinet-like), soft attack, falls 42 dB/s, vibrato about 15 cents at 3.0 Hz, centered.
- Hear it at: 1:13.8 (F#4, 2.06 s, -29 dB alone), 0:30.7 (D5, 2.06 s, -54 dB alone), 0:03.6 (E5, 3.5 s, -56 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 595 (412 to 646) Hz; attack 81 (79 to 168) ms; decay -42 (-135 to -20) dB/s
  - brightness at the start 669 (664 to 915) Hz; slope over the note -0.01 (-0.23 to 0.31) octaves
  - harmonic share 0.22 (0.06 to 0.74); partials off whole multiples 0 (0 to 17) cents
  - vibrato 15 (4 to 18) cents; detune beating 0.0 (0.0 to 0.7) Hz
  - level against the mix -55.8 (-56.9 to -43.9) dB; pan -0.00 (-0.00 to 0.27); left-right correlation 0.99 (0.53 to 1.00)
- Group quality: weak (silhouette 0.23, 5 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

#### S8. 15. Smokes Quantity: drums group `drums-2` (70 notes, 8% of the track's note energy)
- In synth terms: high tick, quick attack, falls 94 dB/s, centered.
- Hear it at: 1:10.0 (D1, 0.38 s, -2 dB alone), 0:53.0 (D1, 0.48 s, -3 dB alone), 1:13.6 (D1, 0.5 s, -2 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 37 (37 to 37) Hz; attack 17 (16 to 33) ms; decay -94 (-102 to -85) dB/s
  - brightness at the start 3338 (2891 to 3715) Hz; slope over the note 0.08 (-0.27 to 0.61) octaves
  - harmonic share 0.99 (0.93 to 1.00); partials off whole multiples 124 (26 to 200) cents
  - vibrato 0 (0 to 0) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -5.2 (-11.0 to -4.4) dB; pan -0.03 (-0.06 to 0.02); left-right correlation 0.56 (0.03 to 0.76)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the drums stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **15. Smokes Quantity sections:** 10 boundaries at 0:02.0, 0:20.0, 0:37.0, 0:50.0, 1:09.0, 1:36.0, 1:46.0, 1:57.0, 2:10.0, 2:42.0; section lengths median 17 s (range 2 to 32). Reliable for sections of 10 s or more.
- **15. Smokes Quantity stem entries and exits:** drums plays 73% of the time (in: 0:18.5, 1:45.5; out: 1:37.5, 2:43.0); bass plays 0% of the time (in: from the start; out: never); other plays 100% of the time (in: from the start; out: never); vocals plays 1% of the time (in: 2:10.5; out: 2:13.0).
- **15. Smokes Quantity floor drops (kick and bass out 2 s or more while the rest plays):** 1.07 a minute: 0:09.2 for 9.8 s, 1:36.8 for 9.5 s, 2:42.2 for 15.5 s.
- **15. Smokes Quantity brightness sweeps (0.7 octave or more):** mix down 1.0 oct 1:01.0 to 1:06.5; mix down 1.0 oct 1:32.5 to 1:38.0; mix down 3.2 oct 2:50.0 to 3:06.5; other down 0.9 oct 1:02.5 to 1:07.5; other up 0.7 oct 1:07.5 to 1:12.5; other down 3.2 oct 2:50.0 to 3:06.5; bass up 1.4 oct 0:14.0 to 0:19.5; bass up 1.0 oct 0:24.5 to 0:31.0 (7 more in techniques.json).
- **15. Smokes Quantity echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **15. Smokes Quantity pumping locked to the kick:** other dips 2.5 dB at the kick (peak 35 ms after, kick every 0.30 s); bass dips 10.1 dB at the kick (peak 210 ms after, kick every 0.30 s). The tool reads about 70% of the true depth, so this is a floor.
- **15. Smokes Quantity tape wobble and speed:** other wobbles about 19 cents at 0.6 Hz; other speed moves up to 48 cents in 4 s.
- **15. Smokes Quantity stereo movement:** vocals pan range 0.27.
- **09. Bocuma sections:** 7 boundaries at 0:02.0, 0:12.0, 0:30.0, 0:47.0, 1:00.0, 1:15.0, 1:31.0; section lengths median 14 s (range 2 to 18). Reliable for sections of 10 s or more.
- **09. Bocuma stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 0% of the time (in: from the start; out: never); other plays 100% of the time (in: from the start; out: never); vocals plays 0% of the time (in: from the start; out: never).
- **09. Bocuma floor drops (kick and bass out 2 s or more while the rest plays):** 0.00 a minute.
- **09. Bocuma brightness sweeps (0.7 octave or more):** mix up 0.9 oct 1:15.5 to 1:24.0; mix down 0.9 oct 1:24.5 to 1:33.0; other up 0.9 oct 1:15.5 to 1:24.0; other down 0.9 oct 1:24.5 to 1:33.0; bass down 1.8 oct 0:00.0 to 0:07.5; bass down 1.0 oct 0:16.0 to 0:22.5; bass down 1.2 oct 0:47.5 to 0:55.0; bass up 1.0 oct 1:06.5 to 1:14.0 (1 more in techniques.json).
- **09. Bocuma echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **09. Bocuma pumping locked to the kick:** under 1.5 dB; none found.
- **09. Bocuma tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **09. Bocuma stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **01. Wild Analysis sections:** 4 boundaries at 0:02.0, 0:21.0, 0:40.0, 1:02.0; section lengths median 19 s (range 2 to 22). Reliable for sections of 10 s or more.
- **01. Wild Analysis stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 10% of the time (in: 0:46.0; out: 0:54.0); other plays 100% of the time (in: from the start; out: never); vocals plays 0% of the time (in: from the start; out: never).
- **01. Wild Analysis floor drops:** low end too sparse to say (on in under 75% of the track).
- **01. Wild Analysis brightness sweeps (0.7 octave or more):** bass down 2.2 oct 0:37.5 to 0:49.5; bass up 2.6 oct 0:50.0 to 0:57.5.
- **01. Wild Analysis echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **01. Wild Analysis pumping locked to the kick:** under 1.5 dB; none found.
- **01. Wild Analysis tape wobble and speed:** other wobbles about 13 cents at 1.0 Hz; other speed moves up to 20 cents in 4 s; bass wobbles about 14 cents at 1.9 Hz; bass speed moves up to 11 cents in 4 s.
- **01. Wild Analysis stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **17. One Very Important Thought sections:** 4 boundaries at 0:02.0, 0:18.0, 0:53.0, 1:09.0; section lengths median 16 s (range 2 to 35). Reliable for sections of 10 s or more.
- **17. One Very Important Thought stem entries and exits:** drums plays 0% of the time (in: from the start; out: never); bass plays 60% of the time (in: 0:16.5, 0:51.5; out: 0:43.0, 1:12.0); other plays 88% of the time (in: 0:02.0; out: 1:11.5); vocals plays 60% of the time (in: 0:21.0; out: 1:08.0).
- **17. One Very Important Thought floor drops:** low end too sparse to say (on in under 75% of the track).
- **17. One Very Important Thought brightness sweeps (0.7 octave or more):** mix down 0.7 oct 1:05.0 to 1:13.0; other down 0.7 oct 1:05.5 to 1:14.0; bass down 0.7 oct 0:28.0 to 0:37.5; bass up 0.8 oct 0:44.5 to 0:56.0; bass down 1.5 oct 1:08.5 to 1:15.5.
- **17. One Very Important Thought echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **17. One Very Important Thought pumping locked to the kick:** under 1.5 dB; none found.
- **17. One Very Important Thought tape wobble and speed:** bass wobbles about 15 cents at 0.9 Hz; bass speed moves up to 51 cents in 4 s.
- **17. One Very Important Thought stereo movement:** parts stay near where they started (pan range under 0.25 and no clear cycle).
- **17. One Very Important Thought builds:** 0:00.0 to 0:23.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **15. Smokes Quantity meter:** about 99 BPM (could be 50 or 198; the tool cannot tell the beat level), 2 beats a bar; straight eighths; no cross-rhythm claim.
- **15. Smokes Quantity key and mode:** C# dorian (low confidence: the key signature margin is 0.013, so read this as a guess); fits C# minor pentatonic; pitch-class weights D# 0.20, C# 0.17, G# 0.16, E 0.11, D 0.05.
- **15. Smokes Quantity chords:** 17 changes a minute (16 a minute are chords that last 1.5 s or more); median chord 3.3 s (10th to 90th percentile 3.0 to 3.4 s); 8 distinct chords; most time on C#sus2 40%, C#min7 17%, C#min 13%, D#7 12%. The old counter in this same run said 11; Ears 1's 2-s counter said 5.  58% of the changes land on a beat (chance would be 50%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **15. Smokes Quantity top line (from the 'other' stem; read by ear before trusting):** 476 notes, range 7 semitones (10th to 90th percentile); steps 50%, thirds 1%, fourths and fifths 26%, leaps 0%, repeats 23%; median interval 2 semitones; 51% of moves go up; phrases of about 10 notes, arch 6%, rising 20%, falling 11%, flat or wavy 63%. Reliable only when the line sits clearly above its accompaniment.
- **15. Smokes Quantity repetition:** 154 bars of 1.2 s; strongest repeat distances 1 bars (0.59), 8 bars (0.47), 16 bars (0.32); 30% of bars near-duplicate an earlier bar.
- **09. Bocuma meter:** about 90 BPM (could be 45 or 180; the tool cannot tell the beat level), 8 beats a bar; straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **09. Bocuma key and mode:** G mixolydian (key signature margin 0.028); pitch-class weights G 0.18, D 0.15, F 0.11, E 0.09, A 0.08.
- **09. Bocuma chords:** 48 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.0 s (10th to 90th percentile 0.6 to 2.3 s); 18 distinct chords; most time on G5 39%, Fmaj7 10%, Dmin 10%, Fsus2 8%. The old counter in this same run said 22; Ears 1's 2-s counter said 22.  70% of the changes land on a beat (chance would be 45%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **09. Bocuma top line (from the 'other' stem; read by ear before trusting):** 248 notes, range 19 semitones (10th to 90th percentile); steps 3%, thirds 3%, fourths and fifths 21%, leaps 58%, repeats 15%; median interval 12 semitones; 49% of moves go up; phrases of about 7 notes, arch 50%, rising 5%, falling 36%, flat or wavy 9%. Reliable only when the line sits clearly above its accompaniment.
- **09. Bocuma repetition:** 18 bars of 5.3 s; strongest repeat distances 9 bars (0.10), 1 bars (0.08), 7 bars (0.05); 0% of bars near-duplicate an earlier bar.
- **01. Wild Analysis meter:** about 63 BPM (could be 32 or 127; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.13); no clear off-beat onsets; no cross-rhythm claim; many unrelated periodicities found (5:4), which means irregular timing, not a cross-rhythm claim.
- **01. Wild Analysis key and mode:** E aeolian (minor) (low confidence: the key signature margin is 0.002, so read this as a guess); fits E minor pentatonic; pitch-class weights B 0.23, E 0.18, D 0.15, A 0.13, G 0.08.
- **01. Wild Analysis chords:** 26 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.7 to 4.5 s); 11 distinct chords; most time on Emin7 44%, Asus2 31%, Dsus2 8%, E7 5%. The old counter in this same run said 2; Ears 1's 2-s counter said 2.  41% of the changes land on a beat (chance would be 32%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **01. Wild Analysis bass:** pedal (one note held or repeated); 0.18 notes a second; most time on E 1.00; steps 0%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 100%.
- **01. Wild Analysis top line (from the 'other' stem; read by ear before trusting):** 152 notes, range 10 semitones (10th to 90th percentile); steps 25%, thirds 21%, fourths and fifths 13%, leaps 13%, repeats 28%; median interval 2 semitones; 49% of moves go up; phrases of about 148 notes, arch 0%, rising 0%, falling 0%, flat or wavy 100%. Reliable only when the line sits clearly above its accompaniment.
- **17. One Very Important Thought meter:** about 101 BPM (could be 51 or 203; the tool cannot tell the beat level), bar length unclear (best guess 5, score 0.13); swung: off-beat at 0.67 of the beat (triplet feel); no cross-rhythm claim; many unrelated periodicities found (5:2, 5:3, 5:4, 7:5), which means irregular timing, not a cross-rhythm claim.
- **17. One Very Important Thought key and mode:** E locrian (low confidence: the key signature margin is 0.002, so read this as a guess); pitch-class weights D 0.16, E 0.14, A 0.13, C# 0.09, D# 0.08.
- **17. One Very Important Thought chords:** 31 changes a minute (10 a minute are chords that last 1.5 s or more); median chord 0.9 s (10th to 90th percentile 0.5 to 4.2 s); 15 distinct chords; most time on Dsus2 37%, E7 23%, Esus2 6%, Asus2 6%. The old counter in this same run said 5; Ears 1's 2-s counter said 5.  44% of the changes land on a beat (chance would be 51%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **17. One Very Important Thought bass:** pedal (one note held or repeated); 0.39 notes a second; most time on E 0.70, A 0.20, C 0.10; steps 0%, thirds 3%, fourths and fifths 0%, octaves 0%, repeats 90%.
- **17. One Very Important Thought top line (from the 'other' stem; read by ear before trusting):** 188 notes, range 6 semitones (10th to 90th percentile); steps 52%, thirds 10%, fourths and fifths 20%, leaps 5%, repeats 12%; median interval 2 semitones; 47% of moves go up; phrases of about 40 notes, arch 50%, rising 50%, falling 0%, flat or wavy 0%. Reliable only when the line sits clearly above its accompaniment.
- **17. One Very Important Thought repetition:** 26 bars of 3.0 s; strongest repeat distances 1 bars (0.59), 12 bars (0.11); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **15. Smokes Quantity mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -8 (corr 0.72); low_120_500 -14 (corr 0.94); mid_500_2k -10 (corr 0.86); pres_2k_5k -8 (corr 0.75); air_gt5k -2 (corr 0.25); over time (2-s windows) 10th/50th/90th percentile -16/-12/-10 dB.
- **15. Smokes Quantity by part:** drums: 58% of the power, width -8 dB, pan +0.03, mono loss 0.7 dB, widest in sub_lt120 (-7 dB); bass: 0% of the power, width -8 dB, pan +0.05, mono loss 0.7 dB, widest in sub_lt120 (-1 dB); other: 42% of the power, width -13 dB, pan +0.28, mono loss 0.2 dB, widest in mid_500_2k (-11 dB); vocals: 0% of the power, width 1 dB, pan +0.51, mono loss 3.3 dB, widest in mid_500_2k (4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **09. Bocuma mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -4 (corr 0.43); low_120_500 -7 (corr 0.68); mid_500_2k -9 (corr 0.77); pres_2k_5k -7 (corr 0.68); air_gt5k -8 (corr 0.73); over time (2-s windows) 10th/50th/90th percentile -9/-8/-7 dB.
- **09. Bocuma by part:** drums: 0% of the power, width -5 dB, pan -0.07, mono loss 1.2 dB, widest in mid_500_2k (-5 dB); bass: 0% of the power, width -12 dB, pan -0.01, mono loss 0.2 dB, widest in mid_500_2k (-14 dB); other: 100% of the power, width -8 dB, pan -0.01, mono loss 0.6 dB, widest in low_120_500 (-7 dB); vocals: 0% of the power, width -22 dB, pan -0.00, mono loss 0.0 dB, widest in mid_500_2k (-24 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **01. Wild Analysis mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -20 (corr 0.98); low_120_500 -15 (corr 0.94); mid_500_2k -14 (corr 0.93); pres_2k_5k -7 (corr 0.68); air_gt5k -8 (corr 0.73); over time (2-s windows) 10th/50th/90th percentile -16/-14/-13 dB.
- **01. Wild Analysis by part:** drums: 0% of the power, width -8 dB, pan -0.04, mono loss 0.6 dB, widest in mid_500_2k (-9 dB); bass: 0% of the power, width -43 dB, pan +0.00, mono loss 0.0 dB, widest in low_120_500 (-47 dB); other: 100% of the power, width -14 dB, pan +0.06, mono loss 0.2 dB, widest in mid_500_2k (-14 dB); vocals: 0% of the power, width -8 dB, pan +0.24, mono loss 0.7 dB, widest in mid_500_2k (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **17. One Very Important Thought mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.98); low_120_500 -20 (corr 0.99); mid_500_2k -17 (corr 0.97); pres_2k_5k -7 (corr 0.88); air_gt5k -16 (corr 0.98); over time (2-s windows) 10th/50th/90th percentile -20/-19/-17 dB.
- **17. One Very Important Thought by part:** drums: 0% of the power, width -4 dB, pan -0.16, mono loss 1.3 dB, widest in low_120_500 (-5 dB); bass: 13% of the power, width -18 dB, pan -0.18, mono loss 0.1 dB, widest in sub_lt120 (-17 dB); other: 79% of the power, width -20 dB, pan -0.10, mono loss 0.0 dB, widest in mid_500_2k (-18 dB); vocals: 8% of the power, width -14 dB, pan -0.04, mono loss 0.2 dB, widest in pres_2k_5k (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 15. Smokes Quantity: 99 BPM, 16 settled chords a minute, 3% of energy above 2 kHz, width -9 dB; 09. Bocuma: 90 BPM, 12 settled chords a minute, 0% of energy above 2 kHz, width -8 dB; 01. Wild Analysis: 63 BPM, 12 settled chords a minute, 0% of energy above 2 kHz, width -14 dB; 17. One Very Important Thought: 101 BPM, 10 settled chords a minute, 1% of energy above 2 kHz, width -19 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- 17. One Very Important Thought, bass group `bass-1` (172 notes): around E1, harmonic (string/reed/pad-like), soft attack, falls 5 dB/s, centered; hear it at 1:09.5, 1:09.4. **[JUDGMENT]** why it waits.
- 17. One Very Important Thought, vocals group `vocals-1` (152 notes): around A3, mixed or noisy partials, soft attack, falls 154 dB/s, centered; hear it at 0:22.0, 0:31.3. **[JUDGMENT]** why it waits.
- **08. Kaini Industries** (0:59.4, 96 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 18.20 (high, album median 5.15). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **10. Roygbiv** (2:31.3, 83 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 15.50 (high, album median 5.15). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **16. Open the Light** (4:25.0, 108 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 13.60 (high, album median 5.15); tail (dB a second) -6.20 (low, album median -1.20). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **12. Aquarius** (5:58.1, 172 BPM by the mix-level count): stands out for brightness sweep (octaves) 1.93 (high, album median 0.71). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **02. An Eagle in your Mind** (6:23.1, 96 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 12.80 (high, album median 5.15). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **06. Sixtyten** (5:48.2, 108 BPM by the mix-level count): stands out for pitch bends a minute 37.91 (high, album median 8.46). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **13. Olson** (1:31.7, 123 BPM by the mix-level count): stands out for chord changes a minute (2-s counter) 12.40 (high, album median 5.15). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
