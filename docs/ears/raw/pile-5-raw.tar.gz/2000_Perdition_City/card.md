## 2000 - Perdition City (draft card from Ears 3 tools, 2026-11-03)

How it was made: 9 usable tracks: the most typical plus the 2 least like the rest. Deep pass on: 05. The Future Sound Of Music; 06. We Are The Dead; 07. Dead City Centres. Typical track: 05. The Future Sound Of Music. Least like the rest: 06. We Are The Dead, 07. Dead City Centres.
Stems from Demucs htdemucs (drums, bass, other, vocals). Lines marked **[JUDGMENT]** need a person or a later session; every other line is a measurement or a threshold read off one.

### Stem check (read before trusting any number below)
- **05. The Future Sound Of Music**: share of power drums 23%, bass 56%, other 17%, vocals 4%.
  - vocals stem holds 3.7%: bleed on an instrumental, not a voice.
  - meter tool 91 BPM is half of the drum-grid beat of 184.6 BPM (use the grid; if it is off by a simple ratio, check by ear).
- **06. We Are The Dead**: share of power drums 2%, bass 1%, other 41%, vocals 56%.
  - bass stem is near empty (1.3%): bass notes, pumping and wobble are void.
- **07. Dead City Centres**: share of power drums 5%, bass 1%, other 81%, vocals 13%.
  - bass stem is near empty (0.8%): bass notes, pumping and wobble are void.
  - meter tool 71 BPM does not match the drum-grid beat of 206.9 BPM by a simple ratio: listen.

### The hook
- Numbers that repeat across the deep-pass tracks: tempo 71 to 151 BPM (octave-uncertain); keys D ionian, B phrygian, G aeolian; mix width -11 to -2 dB; chord changes 23 to 25 a minute.
- **[JUDGMENT]** The one thing that makes a listener say "that's them", in one line, after listening at the timestamps under Sounds.

### Sounds
Groups are ranked by share of the track's note energy, at most two per track. Examples are the clearest notes (loud against everything else playing).
#### S1. 07. Dead City Centres: other group `other-1` (246 notes, 57% of the track's note energy)
- In synth terms: around A1, mixed or noisy partials, slow swell, falls 10 dB/s, centered.
- Hear it at: 6:01.9 (C3, 1.41 s, +59 dB alone), 6:03.2 (C3, 1.58 s, +56 dB alone), 6:05.6 (G3, 2.01 s, +58 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 54 (34 to 196) Hz; attack 176 (30 to 697) ms; decay -10 (-55 to -1) dB/s
  - brightness at the start 349 (169 to 928) Hz; slope over the note 0.01 (-0.54 to 0.78) octaves
  - harmonic share 0.55 (0.11 to 0.94); partials off whole multiples 59 (16 to 161) cents
  - vibrato 0 (0 to 28) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.5 (-4.1 to -0.4) dB; pan -0.11 (-0.21 to 0.26); left-right correlation 0.85 (0.22 to 0.94)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S2. 06. We Are The Dead: other group `other-1` (165 notes, 49% of the track's note energy)
- In synth terms: around C4, mixed or noisy partials, slow swell, falls 5 dB/s, centered.
- Hear it at: 0:05.0 (F4, 0.55 s, +51 dB alone), 0:05.4 (G4, 0.63 s, +51 dB alone), 0:04.1 (D#4, 0.32 s, +50 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 258 (51 to 1093) Hz; attack 387 (99 to 1438) ms; decay -5 (-61 to 1) dB/s
  - brightness at the start 1230 (669 to 1420) Hz; slope over the note 0.00 (-0.26 to 0.17) octaves
  - harmonic share 0.34 (0.07 to 0.88); partials off whole multiples 54 (0 to 151) cents
  - vibrato 0 (0 to 30) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -4.2 (-12.1 to -2.5) dB; pan 0.07 (-0.47 to 0.53); left-right correlation -0.09 (-0.32 to 0.59)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S3. 06. We Are The Dead: vocals group `vocals-1` (270 notes, 43% of the track's note energy)
- In synth terms: around F#2, bell- or metal-like (partials off whole multiples), soft attack, falls 27 dB/s, centered.
- Hear it at: 2:13.1 (F2, 1.1 s, +19 dB alone), 2:12.9 (G2, 0.3 s, +22 dB alone), 3:18.9 (D3, 2.8 s, +16 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 91 (39 to 266) Hz; attack 128 (30 to 583) ms; decay -27 (-138 to -2) dB/s
  - brightness at the start 938 (455 to 4068) Hz; slope over the note -0.04 (-2.02 to 0.34) octaves
  - harmonic share 0.38 (0.14 to 0.77); partials off whole multiples 68 (33 to 142) cents
  - vibrato 0 (0 to 25) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -6.1 (-20.2 to -1.6) dB; pan 0.02 (-0.08 to 0.11); left-right correlation 0.75 (0.13 to 0.97)
- Group quality: weak (silhouette 0.17, 1 group in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the vocals stem (Demucs htdemucs), not on the raw mix.

#### S4. 07. Dead City Centres: other group `other-2` (203 notes, 27% of the track's note energy)
- In synth terms: around A2, mixed or noisy partials, soft attack, falls 45 dB/s, centered.
- Hear it at: 6:50.0 (?, 0.33 s, +62 dB alone), 7:04.2 (?, 0.33 s, +62 dB alone), 6:54.7 (?, 0.32 s, +62 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 108 (36 to 1982) Hz; attack 74 (16 to 384) ms; decay -45 (-333 to -4) dB/s
  - brightness at the start 2393 (1090 to 4577) Hz; slope over the note 0.00 (-0.68 to 0.21) octaves
  - harmonic share 0.74 (0.38 to 1.00); partials off whole multiples 30 (6 to 106) cents
  - vibrato 0 (0 to 18) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.1 (-3.2 to -0.2) dB; pan -0.08 (-0.35 to 0.19); left-right correlation 0.70 (0.15 to 0.97)
- Group quality: weak (silhouette 0.20, 2 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

#### S5. 05. The Future Sound Of Music: bass group `bass-1` (194 notes, 26% of the track's note energy)
- In synth terms: around F#1, harmonic (string/reed/pad-like), soft attack, falls 2 dB/s, centered.
- Hear it at: 5:40.7 (?, 2.26 s, +7 dB alone), 5:35.1 (D1, 3.31 s, +7 dB alone), 5:45.2 (F#1, 5.82 s, +6 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 46 (37 to 46) Hz; attack 135 (7 to 899) ms; decay -2 (-25 to 0) dB/s
  - brightness at the start 146 (89 to 174) Hz; slope over the note 0.00 (-0.16 to 0.21) octaves
  - harmonic share 0.98 (0.93 to 1.00); partials off whole multiples 30 (6 to 129) cents
  - vibrato 0 (0 to 15) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -2.7 (-13.8 to -1.7) dB; pan 0.00 (-0.01 to 0.00); left-right correlation 1.00 (0.84 to 1.00)
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the bass stem (Demucs htdemucs), not on the raw mix.

#### S6. 05. The Future Sound Of Music: other group `other-1` (167 notes, 25% of the track's note energy)
- In synth terms: around B2, bell- or metal-like (partials off whole multiples), slow swell, falls 12 dB/s, centered.
- Hear it at: 3:09.1 (B2, 2.02 s, +54 dB alone), 3:17.5 (B2, 2.74 s, +54 dB alone), 3:19.6 (B2, 2.02 s, +54 dB alone).
- Fingerprint, median (10th to 90th percentile):
  - register 124 (52 to 187) Hz; attack 194 (44 to 849) ms; decay -12 (-154 to 0) dB/s
  - brightness at the start 713 (470 to 1156) Hz; slope over the note 0.00 (-1.27 to 0.40) octaves
  - harmonic share 0.48 (0.16 to 0.92); partials off whole multiples 67 (24 to 148) cents
  - vibrato 0 (0 to 19) cents; detune beating 0.0 (0.0 to 0.0) Hz
  - level against the mix -1.4 (-6.5 to -0.8) dB; pan -0.04 (-0.38 to 0.08); left-right correlation 0.65 (0.44 to 0.87)
- Group quality: weak (silhouette 0.21, 3 groups in the stem). The notes in this stem do not fall into clearly separate instruments; treat this as one blended texture and listen before trusting the split.
- Building blocks it would need: **[JUDGMENT]** name the closest existing Driftloom block, or the one missing.
- Yardstick: the percentile ranges above, measured on the other stem (Demucs htdemucs), not on the raw mix.

### Techniques
- **05. The Future Sound Of Music sections:** 10 boundaries at 0:10.0, 0:41.0, 1:02.0, 1:13.0, 2:54.0, 4:01.0, 5:51.0, 6:02.0, 6:19.0, 6:36.0; section lengths median 17 s (range 4 to 110). Reliable for sections of 10 s or more.
- **05. The Future Sound Of Music stem entries and exits:** drums plays 62% of the time (in: 1:11.5, 3:58.5; out: 2:57.0, 6:22.0); bass plays 71% of the time (in: 0:12.5, 0:18.0, 1:01.0, 1:22.0, 3:28.0; out: 0:15.0, 0:26.0, 1:19.5, 2:57.0, 3:51.0); other plays 96% of the time (in: 0:09.0; out: 6:33.0); vocals plays 37% of the time (in: 3:59.5, 4:18.0, 4:58.0, 5:42.0; out: 4:14.0, 4:54.5, 5:37.0).
- **05. The Future Sound Of Music floor drops:** low end too sparse to say (on in under 75% of the track).
- **05. The Future Sound Of Music brightness sweeps (0.7 octave or more):** mix up 2.8 oct 0:04.5 to 0:09.5; mix down 2.3 oct 0:55.5 to 1:04.5; mix up 1.1 oct 1:12.0 to 1:18.0; mix up 0.8 oct 2:02.0 to 2:08.5; mix down 1.8 oct 2:30.0 to 2:35.0; mix up 1.1 oct 2:35.5 to 2:41.0; mix up 0.9 oct 2:49.0 to 2:57.0; mix up 0.9 oct 4:04.0 to 4:09.0 (37 more in techniques.json).
- **05. The Future Sound Of Music echo times:** drums: 479 ms (+7.5 dB, 2 later repeats).
- **05. The Future Sound Of Music pumping locked to the kick:** under 1.5 dB; none found.
- **05. The Future Sound Of Music tape wobble and speed:** other wobbles about 23 cents at 0.3 Hz; bass wobbles about 5 cents at 0.4 Hz; bass speed moves up to 20 cents in 4 s.
- **05. The Future Sound Of Music stereo movement:** other pan range 0.44, cycling every 5 s; vocals pan range 0.44.
- **06. We Are The Dead sections:** 10 boundaries at 0:02.0, 0:20.0, 0:47.0, 1:04.0, 1:16.0, 1:39.0, 2:12.0, 2:37.0, 3:04.0, 3:25.0; section lengths median 21 s (range 2 to 33). Reliable for sections of 10 s or more.
- **06. We Are The Dead stem entries and exits:** drums plays 23% of the time (in: 0:46.5, 1:02.0, 1:36.0, 1:44.0, 2:39.0; out: 0:51.5, 1:05.0, 1:38.5, 1:47.0, 2:42.0); bass plays 31% of the time (in: 1:02.0, 1:22.5, 1:33.0, 2:43.5, 3:27.0; out: 1:06.0, 1:28.0, 1:58.5, 3:04.0); other plays 98% of the time (in: 3:20.0; out: 3:16.0); vocals plays 83% of the time (in: 0:19.5, 1:18.5, 3:10.5, 3:31.5; out: 1:16.0, 3:08.0, 3:25.5, 3:35.0).
- **06. We Are The Dead floor drops:** low end too sparse to say (on in under 75% of the track).
- **06. We Are The Dead brightness sweeps (0.7 octave or more):** mix up 0.7 oct 0:22.0 to 0:31.0; mix up 0.7 oct 2:31.5 to 2:38.5; mix down 1.4 oct 2:38.5 to 2:45.0; mix up 2.7 oct 2:52.0 to 2:57.0; mix up 3.5 oct 3:01.5 to 3:08.5; mix down 0.9 oct 3:09.0 to 3:15.5; other down 3.6 oct 2:35.5 to 2:52.5; other up 4.0 oct 2:59.5 to 3:08.5 (5 more in techniques.json).
- **06. We Are The Dead echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **06. We Are The Dead pumping locked to the kick:** bass dips 3.9 dB at the kick (peak 449 ms after, kick every 0.46 s). The tool reads about 70% of the true depth, so this is a floor.
- **06. We Are The Dead tape wobble and speed:** nothing at 4 cents or more in the held partials that could be tracked.
- **06. We Are The Dead stereo movement:** other pan range 1.06, cycling every 35 s; vocals pan range 0.34.
- **07. Dead City Centres sections:** 12 boundaries at 0:02.0, 1:00.0, 1:13.0, 1:29.0, 1:45.0, 2:33.0, 2:44.0, 2:56.0, 3:06.0, 3:52.0, 5:59.0, 6:34.0; section lengths median 16 s (range 2 to 127). Reliable for sections of 10 s or more.
- **07. Dead City Centres stem entries and exits:** drums plays 53% of the time (in: 0:08.0, 1:09.0, 1:25.0, 1:48.5, 2:15.5; out: 0:12.5, 1:21.5, 1:44.5, 1:51.5, 2:51.0); bass plays 31% of the time (in: 0:28.5, 3:00.5, 3:24.0, 3:52.0, 4:07.0; out: 0:19.0, 0:58.5, 3:20.0, 3:26.5, 3:54.5); other plays 84% of the time (in: 1:32.5, 3:51.5; out: 1:05.5, 3:49.0, 6:33.5); vocals plays 31% of the time (in: 1:31.0, 3:07.0, 4:25.0, 4:49.5, 6:21.0; out: 1:39.0, 3:38.5, 4:46.5, 5:56.5, 6:25.0).
- **07. Dead City Centres floor drops:** low end too sparse to say (on in under 75% of the track).
- **07. Dead City Centres brightness sweeps (0.7 octave or more):** mix up 2.8 oct 0:47.0 to 1:03.0; mix down 0.7 oct 1:05.0 to 1:11.5; mix up 0.9 oct 1:21.0 to 1:26.0; mix down 0.7 oct 1:26.0 to 1:32.0; mix down 2.3 oct 1:36.5 to 1:44.5; mix down 2.8 oct 2:07.5 to 2:15.0; mix down 4.1 oct 2:29.5 to 2:40.5; mix up 3.1 oct 2:50.5 to 3:02.0 (49 more in techniques.json).
- **07. Dead City Centres echo times:** none found reliably (needs 6 or more notes that ring alone for 1.5 s).
- **07. Dead City Centres pumping locked to the kick:** bass dips 5.6 dB at the kick (peak 668 ms after, kick every 0.71 s). The tool reads about 70% of the true depth, so this is a floor.
- **07. Dead City Centres tape wobble and speed:** other wobbles about 6 cents at 5.5 Hz.
- **07. Dead City Centres stereo movement:** drums pan range 0.57; other pan range 0.81, cycling every 47 s; vocals pan range 0.44.
- **07. Dead City Centres builds:** 0:12.0 to 0:34.0.
- **[JUDGMENT]** Pick the 1 to 3 moves above that define the record and name them (a filter arc, a floor drop, tape speed changes, chopped loops, a build).

### Theory
- **05. The Future Sound Of Music meter:** about 91 BPM (could be 46 or 182; the tool cannot tell the beat level), bar length unclear (best guess 8, score 0.02); straight eighths; no cross-rhythm claim; many unrelated periodicities found (3:2, 4:3, 5:2, 5:3), which means irregular timing, not a cross-rhythm claim.
- **05. The Future Sound Of Music key and mode:** D ionian (major) (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights D 0.23, F# 0.15, C# 0.10, A 0.10, E 0.09.
- **05. The Future Sound Of Music chords:** 25 changes a minute (12 a minute are chords that last 1.5 s or more); median chord 1.5 s (10th to 90th percentile 0.9 to 5.4 s); 29 distinct chords; most time on D5 22%, F#7 16%, F#min 12%, F#5 11%. The old counter in this same run said 16; Ears 1's 2-s counter said 15.  42% of the changes land on a beat (chance would be 46%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **05. The Future Sound Of Music bass:** root-note movement / mixed; 0.59 notes a second; most time on D 0.50, F# 0.32, E 0.10, A# 0.06; steps 23%, thirds 9%, fourths and fifths 2%, octaves 4%, repeats 44%.
- **05. The Future Sound Of Music top line (from the 'other' stem; read by ear before trusting):** 927 notes, range 21 semitones (10th to 90th percentile); steps 11%, thirds 24%, fourths and fifths 24%, leaps 17%, repeats 23%; median interval 3 semitones; 50% of moves go up; phrases of about 11 notes, arch 38%, rising 15%, falling 25%, flat or wavy 21%. Reliable only when the line sits clearly above its accompaniment.
- **05. The Future Sound Of Music repetition:** 76 bars of 5.3 s; strongest repeat distances 1 bars (0.81); 48% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **06. We Are The Dead meter:** about 151 BPM (could be 76 or 302; the tool cannot tell the beat level), bar length unclear (best guess 9, score 0.07); swung: off-beat at 0.58 of the beat; no cross-rhythm claim.
- **06. We Are The Dead key and mode:** B phrygian (low confidence: the key signature margin is 0.006, so read this as a guess); pitch-class weights C 0.12, D# 0.10, D 0.09, E 0.09, B 0.09.
- **06. We Are The Dead chords:** 23 changes a minute (14 a minute are chords that last 1.5 s or more); median chord 1.8 s (10th to 90th percentile 0.9 to 5.0 s); 26 distinct chords; most time on Cmaj7 41%, D#maj7 19%, G#maj7 6%, C#maj7 6%. The old counter in this same run said 6; Ears 1's 2-s counter said 5.  79% of the changes land on a beat (chance would be 76%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **06. We Are The Dead bass:** root-note movement / mixed; 0.10 notes a second; most time on B 0.40, A# 0.21, A 0.19, G# 0.10; steps 60%, thirds 0%, fourths and fifths 0%, octaves 0%, repeats 40%.
- **06. We Are The Dead top line (from the 'other' stem; read by ear before trusting):** 432 notes, range 30 semitones (10th to 90th percentile); steps 29%, thirds 17%, fourths and fifths 4%, leaps 21%, repeats 28%; median interval 2 semitones; 52% of moves go up; phrases of about 10 notes, arch 22%, rising 19%, falling 22%, flat or wavy 38%. Reliable only when the line sits clearly above its accompaniment.
- **06. We Are The Dead repetition:** 61 bars of 3.6 s; strongest repeat distances 5 bars (0.34), 2 bars (0.28), 10 bars (0.15); 0% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **07. Dead City Centres meter:** about 71 BPM (could be 35 or 142; the tool cannot tell the beat level), bar length unclear (best guess 7, score 0.19); swung: off-beat at 0.57 of the beat; no cross-rhythm claim; many unrelated periodicities found (3:2, 5:3, 7:5), which means irregular timing, not a cross-rhythm claim.
- **07. Dead City Centres key and mode:** G aeolian (minor) (low confidence: the key signature margin is 0.003, so read this as a guess); pitch-class weights G 0.12, D# 0.12, A 0.10, G# 0.10, D 0.10.
- **07. Dead City Centres chords:** 25 changes a minute (15 a minute are chords that last 1.5 s or more); median chord 2.0 s (10th to 90th percentile 0.7 to 5.2 s); 44 distinct chords; most time on G#maj7 21%, D#maj7 10%, Gmaj7 8%, Dsus2 6%. The old counter in this same run said 9; Ears 1's 2-s counter said 8.  41% of the changes land on a beat (chance would be 35%), which is the check available on real music. Counts are calibrated on clean synthetic chords (exact down to a chord every 0.5 s); chord names on dense or noisy music are a guess.
- **07. Dead City Centres bass:** root-note movement / mixed; 0.13 notes a second; most time on G# 0.36, G 0.28, A 0.15, A# 0.07; steps 35%, thirds 11%, fourths and fifths 2%, octaves 11%, repeats 33%.
- **07. Dead City Centres top line (from the 'other' stem; read by ear before trusting):** 829 notes, range 28 semitones (10th to 90th percentile); steps 23%, thirds 12%, fourths and fifths 21%, leaps 27%, repeats 17%; median interval 4 semitones; 49% of moves go up; phrases of about 9 notes, arch 35%, rising 12%, falling 46%, flat or wavy 8%. Reliable only when the line sits clearly above its accompaniment.
- **07. Dead City Centres repetition:** 72 bars of 5.9 s; strongest repeat distances 1 bars (0.63), 15 bars (0.08), 32 bars (-0.10); 4% of bars near-duplicate an earlier bar. Bar length is uncertain, so these lags are weak evidence.
- **[JUDGMENT]** Pick 1 or 2 of the readings above and write each as something the generator could draw (a spread, not a rule).

### Space
- **05. The Future Sound Of Music mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -18 (corr 0.97); low_120_500 -10 (corr 0.80); mid_500_2k -6 (corr 0.59); pres_2k_5k -7 (corr 0.66); air_gt5k -9 (corr 0.80); over time (2-s windows) 10th/50th/90th percentile -9/-7/-5 dB.
- **05. The Future Sound Of Music by part:** drums: 21% of the power, width -18 dB, pan -0.02, mono loss 0.1 dB, widest in low_120_500 (-23 dB); bass: 53% of the power, width -22 dB, pan -0.00, mono loss 0.0 dB, widest in sub_lt120 (-24 dB); other: 21% of the power, width -5 dB, pan +0.01, mono loss 1.1 dB, widest in mid_500_2k (-4 dB); vocals: 4% of the power, width -9 dB, pan -0.00, mono loss 0.5 dB, widest in pres_2k_5k (-7 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **06. We Are The Dead mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -17 (corr 0.97); low_120_500 -8 (corr 0.74); mid_500_2k -1 (corr 0.11); pres_2k_5k -9 (corr 0.79); air_gt5k -22 (corr 0.99); over time (2-s windows) 10th/50th/90th percentile -6/-1/1 dB.
- **06. We Are The Dead by part:** drums: 1% of the power, width -18 dB, pan -0.10, mono loss 0.1 dB, widest in sub_lt120 (-22 dB); bass: 1% of the power, width -21 dB, pan -0.07, mono loss 0.0 dB, widest in sub_lt120 (-21 dB); other: 52% of the power, width 0 dB, pan +0.03, mono loss 3.0 dB, widest in mid_500_2k (1 dB); vocals: 46% of the power, width -5 dB, pan +0.16, mono loss 1.1 dB, widest in mid_500_2k (-4 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).
- **07. Dead City Centres mix width by band** (width dB; 0 = unrelated channels, below -20 = near mono): sub -9 (corr 0.77); low_120_500 -8 (corr 0.74); mid_500_2k -3 (corr 0.34); pres_2k_5k -7 (corr 0.64); air_gt5k -10 (corr 0.80); over time (2-s windows) 10th/50th/90th percentile -12/-5/-2 dB.
- **07. Dead City Centres by part:** drums: 4% of the power, width -5 dB, pan -0.05, mono loss 1.3 dB, widest in air_gt5k (-3 dB); bass: 1% of the power, width -15 dB, pan +0.01, mono loss 0.1 dB, widest in sub_lt120 (-14 dB); other: 84% of the power, width -5 dB, pan -0.05, mono loss 1.2 dB, widest in mid_500_2k (-3 dB); vocals: 12% of the power, width -8 dB, pan +0.02, mono loss 0.7 dB, widest in mid_500_2k (-3 dB). Bands holding under 10% of a part's energy are left out of 'widest' (they are too quiet to trust).

### Vibes
- **[JUDGMENT]** For each sound and technique: vibes that lean toward it (x1.5 to x3), ones that lean away (x0.2 to x0.5, never 0), any new vibe or profile. Numbers to start from: 05. The Future Sound Of Music: 91 BPM, 12 settled chords a minute, 9% of energy above 2 kHz, width -11 dB; 06. We Are The Dead: 151 BPM, 14 settled chords a minute, 7% of energy above 2 kHz, width -2 dB; 07. Dead City Centres: 71 BPM, 15 settled chords a minute, 22% of energy above 2 kHz, width -6 dB.

### Wholesome take
- **[JUDGMENT]** What to take, what to leave. Measured flags to consider: no brightness or polarity flags from the numbers; listening still decides.

### For later
- 05. The Future Sound Of Music, other group `other-2` (139 notes): around F#1, harmonic (string/reed/pad-like), soft attack, falls 4 dB/s, centered; hear it at 0:44.8, 0:44.9. **[JUDGMENT]** why it waits.
- 05. The Future Sound Of Music, bass group `bass-2` (35 notes): around D2, harmonic (string/reed/pad-like), slow swell, falls 2 dB/s, centered; hear it at 0:12.7, 2:32.6. **[JUDGMENT]** why it waits.
- 07. Dead City Centres, vocals group `vocals-1` (220 notes): around B2, mixed or noisy partials, soft attack, falls 40 dB/s, centered; hear it at 5:11.5, 5:10.8. **[JUDGMENT]** why it waits.
- 05. The Future Sound Of Music, drums group `drums-1` (249 notes): mid snap, soft attack, falls 36 dB/s, gets brighter over the note, centered; hear it at 3:59.4, 3:59.1. **[JUDGMENT]** why it waits.
- 07. Dead City Centres, drums group `drums-1` (207 notes): high tick, quick attack, falls 45 dB/s, centered; hear it at 1:18.9, 1:24.9. **[JUDGMENT]** why it waits.
- 05. The Future Sound Of Music, vocals group `vocals-1` (153 notes): around D6, bell- or metal-like (partials off whole multiples), slow swell, falls 26 dB/s, centered; hear it at 6:39.1, 6:34.5. **[JUDGMENT]** why it waits.
- 06. We Are The Dead, other group `other-2` (33 notes): around A1, bell- or metal-like (partials off whole multiples), slow swell, falls 11 dB/s, centered; hear it at 2:59.9, 3:00.9. **[JUDGMENT]** why it waits.
- 05. The Future Sound Of Music, drums group `drums-2` (251 notes): mid snap, soft attack, falls 42 dB/s, centered; hear it at 4:52.7, 4:21.1. **[JUDGMENT]** why it waits.
- **08. Catalept** (2:17.2, 152 BPM by the mix-level count): stands out for pitch bends a minute 46.78 (high, album median 9.23); wobble (cents) 7.75 (high, album median 3.44); brightness sweep (octaves) 0.28 (low, album median 1.74). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **09. Nowhere - Catastrophe** (4:48.6, 136 BPM by the mix-level count): stands out for repetition 0.34 (low, album median 0.54). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **02. Porn Piece Or The Scars Of Cold Kisses** (7:09.4, 86 BPM by the mix-level count): stands out for tail (dB a second) -4.20 (low, album median -1.40). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
- **03. Hallways Of Always** (6:35.6, 112 BPM by the mix-level count): stands out for tail (dB a second) -4.00 (low, album median -1.40); repetition 0.70 (high, album median 0.54). **[JUDGMENT]** listen and decide if it is worth a deep pass; why it waits is not measurable.
